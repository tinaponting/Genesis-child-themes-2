<?php
//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );

//* Set Localization (do not remove)
load_child_theme_textdomain( 'Mommy', apply_filters( 'child_theme_textdomain', get_stylesheet_directory() . '/languages', 'Mommy' ) );

//* Child theme (do not remove)
define( 'CHILD_THEME_NAME', __( 'Mommy Blogs Theme', 'Mommy' ) );
define( 'CHILD_THEME_VERSION', '2.0.0' );

//* Add HTML5 markup structure
add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list' ) );

//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Enqueue Google fonts
add_action( 'wp_enqueue_scripts', 'Mommy_google_fonts' );
function Mommy_google_fonts() {
	wp_enqueue_style( 'google-font', '//fonts.googleapis.com/css?family=Oswald:400', array(), CHILD_THEME_VERSION );
}

//* Enqueue Backstretch script and prepare images for loading
add_action( 'wp_enqueue_scripts', 'Mommy_enqueue_scripts' );
function Mommy_enqueue_scripts() {
	if ( ! get_background_image() )
		return;
	wp_enqueue_script( 'mommy-blogs-backstretch', get_bloginfo( 'stylesheet_directory' ) . '/js/backstretch.js', array( 'jquery' ), '1.0.0' );
	wp_enqueue_script( 'mommy-blogs-backstretch-set', get_bloginfo('stylesheet_directory').'/js/backstretch-set.js' , array( 'jquery', 'mommy-blogs-backstretch' ), '1.0.0' );
	wp_localize_script( 'mommy-blogs-backstretch-set', 'BackStretchImg', array( 'src' => str_replace( 'http:', '', get_background_image() ) ) );
}

//* Add custom background callback for background color
function Mommy_background_callback() {
	if ( ! get_background_color() )
		return;
	printf( '<style>body { background-color: #%s; }</style>' . "\n", get_background_color() );
}

//* Add new image sizes
add_image_size( 'home-bottom', 150, 150, TRUE );
add_image_size( 'home-middle', 332, 190, TRUE );
add_image_size( 'home-top', 700, 400, TRUE );

//* Add support for custom background
add_theme_support( 'custom-background', array( 'wp-head-callback' => 'Mommy_background_callback' ) );

//* Add support for custom header
add_theme_support( 'custom-header', array(
	'width'           => 270,
	'height'          => 80,
	'header-selector' => '.site-title a',
	'header-text'     => false
) );

//* Add support for additional color style options
add_theme_support( 'genesis-style-selector', array(
	'mommy-blogs-blue'  => __( 'Blue', 'mommy' ),
	'mommy-blogs-plum' => __( 'plum', 'mommy' ),
	'mommy-blogs-pink'  => __( 'Pink', 'mommy' ),
	'mommy-blogs-red'   => __( 'Red', 'mommy' ),
) );

//* Add support for 3-column footer widgets
add_theme_support( 'genesis-footer-widgets', 3 );

//* Reposition the secondary navigation
remove_action( 'genesis_after_header', 'genesis_do_subnav' );
add_action( 'genesis_before', 'genesis_do_subnav' );

//* Hooks after-entry widget area to single posts
add_action( 'genesis_entry_footer', 'Mommy_after_post'  ); 
function Mommy_after_post() {
    if ( ! is_singular( 'post' ) )
    	return;
    genesis_widget_area( 'after-entry', array(
		'before' => '<div class="after-entry widget-area"><div class="wrap">',
		'after'  => '</div></div>',
    ) );}

//* Remove comment form allowed tags
add_filter( 'comment_form_defaults', 'Mommy_remove_comment_form_allowed_tags' );
function Mommy_remove_comment_form_allowed_tags( $defaults ) {
	$defaults['comment_notes_after'] = '';return $defaults;
}
//* Reposition the footer widgets
remove_action( 'genesis_before_footer', 'genesis_footer_widget_areas' );
add_action( 'genesis_after', 'genesis_footer_widget_areas' );

//* Reposition the footer
remove_action( 'genesis_footer', 'genesis_footer_markup_open', 5 );
remove_action( 'genesis_footer', 'genesis_do_footer' );
remove_action( 'genesis_footer', 'genesis_footer_markup_close', 15 );
add_action( 'genesis_after', 'genesis_footer_markup_open', 11 );
add_action( 'genesis_after', 'genesis_do_footer', 12 );
add_action( 'genesis_after', 'genesis_footer_markup_close', 13 );

//* Register widget areas
genesis_register_sidebar( array(
	'id'          => 'home-top',
	'name'        => __( 'Home - Top', 'Mommy' ),
	'description' => __( 'This is the top section of the homepage.', 'Mommy' ),
) );
genesis_register_sidebar( array(
	'id'          => 'home-middle-left',
	'name'        => __( 'Home - Middle Left', 'Mommy' ),
	'description' => __( 'This is the middle left section of the homepage.', 'Mommy' ),
) );
genesis_register_sidebar( array(
	'id'          => 'home-middle-right',
	'name'        => __( 'Home - Middle Right', 'Mommy' ),
	'description' => __( 'This is the middle right section of the homepage.', 'Mommy' ),
) );
genesis_register_sidebar( array(
	'id'          => 'home-bottom',
	'name'        => __( 'Home - Bottom', 'Mommy' ),
	'description' => __( 'This is the bottom section of the homepage.', 'Mommy' ),
) );
genesis_register_sidebar( array(
	'id'          => 'after-entry',
	'name'        => __( 'After Entry', 'Mommy' ),
	'description' => __( 'This is the after entry section.', 'Mommy' ),
) );
//* Change the footer text
add_filter('genesis_footer_creds_text', 'sp_footer_creds_filter');
function sp_footer_creds_filter( $creds ) {
	$creds = '[footer_copyright] &middot; <a href="http://YOURDOMAIN.COM">YOUR SITE DOMAIN</a>';
	return $creds;
}
//* Genesis Slider
add_action( ‘init’ , ‘as247_remove_slider_styles’ , 15 );
function as247_remove_slider_styles() {
remove_action( ‘wp_print_styles’ , ‘genesis_slider_styles’ );
}

add_filter('body_class', 'string_body_class');
function string_body_class( $classes ) {
	if ( isset( $_GET['color'] ) ) :
		$classes[] = 'mommy-' . sanitize_html_class( $_GET['color'] );
	endif;
	return $classes;
}