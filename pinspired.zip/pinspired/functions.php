<?php
//* Start the engine
require_once( get_template_directory() . '/lib/init.php' );

//* Add HTML5 markup structure
add_theme_support( 'html5' );

//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Enqueue Google fonts
add_action( 'wp_enqueue_scripts', 'pinspired_google_fonts' );
function pinspired_google_fonts() {

	wp_enqueue_style( 'google-font', '//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700italic,700|Merriweather:400,400italic,700,700italic,300italic,300|Playfair+Display:400,400italic,700,700italic', array() );
	
}

//* Add new image sizes
add_image_size( 'blog-featured', 770, 340, TRUE );
add_image_size( 'sidebar-featured', 75, 75, TRUE );
add_image_size( 'masonry-brick-image', 295, 0, TRUE );

//* Add support for custom background
add_theme_support( 'custom-background' );

//* Add support for custom header
add_theme_support( 'custom-header', array(
	'width'           => 300,
	'height'          => 130,
	'header-selector' => '.site-title a',
	'header-text'     => false
) );

//* Add support for additional color style options
add_theme_support( 'genesis-style-selector', array(
	'pinspired-navy'  => __( 'Navy', 'pinspired' ),
	'pinspired-teal'  => __( 'Teal', 'pinspired' ),
	'pinspired-red'   => __( 'Red', 'pinspired' ),
	'pinspired-pink'  => __( 'Pink', 'pinspired' ),
	'pinspired-green' => __( 'Green', 'pinspired' ),
	'pinspired-purple'=> __( 'Purple', 'pinspired' ),
) );

//* Add support for 3-column footer widgets
add_theme_support( 'genesis-footer-widgets', 4 );

//* Unregister layout settings
genesis_unregister_layout( 'content-sidebar-sidebar' );
genesis_unregister_layout( 'sidebar-content-sidebar' );
genesis_unregister_layout( 'sidebar-sidebar-content' );

//* Unregister secondary sidebar
unregister_sidebar( 'sidebar-alt' );

//* Hooks widget area above header
add_action( 'genesis_before', 'widget_above_header'  ); 
function widget_above_header() {

    genesis_widget_area( 'widget-above-header', array(
		'before' => '<div class="widget-above-header widget-area"><div class="wrap">',
		'after'  => '</div></div>',
    ) );

}

//* Customize the post info function
add_filter( 'genesis_post_info', 'post_info_filter' );
function post_info_filter($post_info) {
if (is_home() || is_archive() || !is_page()) {
    $post_info = '[post_comments] [zilla_likes]';
    return $post_info;
}}

/** Add post navigation (requires HTML5 support) */
add_action( 'genesis_entry_footer', 'genesis_prev_next_post_nav', 5 );

//* Hooks after-entry widget area to single posts
add_action( 'genesis_entry_footer', 'pinspired_after_post'  ); 
function pinspired_after_post() {

    if ( ! is_singular( 'post' ) )
    	return;

    genesis_widget_area( 'after-entry', array(
		'before' => '<div class="after-entry widget-area"><div class="wrap">',
		'after'  => '</div></div>',
    ) );

}

//* Customize the credits 
add_filter('genesis_footer_creds_text', 'custom_footer_creds_text');
function custom_footer_creds_text() {
    echo '<div class="creds"><p>';
    echo 'Copyright &copy; ';
    echo date('Y');
    echo ' &middot; <a target="_blank" href="http://restored316designs.com/themes">pinspired theme</a> by <a target="_blank" href="http://www.restored316designs.com">Restored 316</a>';
    echo '</p></div>';

}

//* Enqueue and initialize jQuery Masonry script
function sk_masonry_script() {
	if (is_home() || is_archive()) {

		wp_enqueue_script( 'masonry-init', get_stylesheet_directory_uri().'/js/masonry-init.js' , array( 'jquery-masonry' ), '1.0', true );


    	//* Infinite Scroll
    	wp_enqueue_script( 'infinite-scroll', get_stylesheet_directory_uri().'/js/jquery.infinitescroll.min.js' , array('jquery'), '1.0', true );
    	wp_enqueue_script( 'infinite-scroll-init', get_stylesheet_directory_uri().'/js/infinitescroll-init.js' , array('jquery'), '1.0', true );
    }
}
add_action( 'wp_enqueue_scripts', 'sk_masonry_script' );

//* Add custom body class to the head
add_filter( 'body_class', 'sk_body_class' );
function sk_body_class( $classes ) {
	if (is_home()||is_archive())
		$classes[] = 'masonry-page';
		return $classes;
}

//* Display Post thumbnail, Post title, Post content/excerpt, Post info and Post meta in masonry brick
add_action('genesis_meta','sk_masonry_layout');
function sk_masonry_layout() {
	if (is_home()||is_archive()) {

		add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_content_sidebar' );

		remove_action( 'genesis_entry_header', 'genesis_do_post_title' );
		remove_action( 'genesis_entry_header', 'genesis_post_info', 12 );
		remove_action( 'genesis_entry_header', 'genesis_entry_header_markup_open', 5 );
		remove_action( 'genesis_entry_header', 'genesis_entry_header_markup_close', 15 );

		remove_action( 'genesis_entry_content', 'genesis_do_post_image', 8 );
		remove_action( 'genesis_entry_content', 'genesis_do_post_content' );

		remove_action( 'genesis_entry_footer', 'genesis_post_meta' );

		add_action( 'genesis_entry_content', 'sk_masonry_block_post_image', 8 ) ;
		add_action( 'genesis_entry_content', 'sk_masonry_title_content', 9 );

		add_action( 'genesis_entry_footer', 'sk_masonry_entry_footer' );

		remove_action( 'genesis_before_loop', 'genesis_do_breadcrumbs' );
		add_action( 'genesis_before_content', 'genesis_do_breadcrumbs' );

		remove_action( 'genesis_before_loop', 'genesis_do_taxonomy_title_description', 15 );
		add_action( 'genesis_before_content', 'genesis_do_taxonomy_title_description', 15 );

		remove_action( 'genesis_before_loop', 'genesis_do_author_title_description', 15 );
		add_action( 'genesis_before_content', 'genesis_do_author_title_description', 15 );

		remove_action( 'genesis_before_loop', 'genesis_do_author_box_archive', 15 );
		add_action( 'genesis_before_content', 'genesis_do_author_box_archive', 15 );

		remove_action( 'genesis_before_loop', 'genesis_do_cpt_archive_title_description' );
		add_action( 'genesis_before_content', 'genesis_do_cpt_archive_title_description' );

		remove_action( 'genesis_after_endwhile', 'genesis_posts_nav' );
		add_action( 'genesis_after_content', 'genesis_posts_nav' );

	}
}

//* Helper function to display Post title and Post content/excerpt wrapped in a custom div
function sk_masonry_title_content() {
	echo '<div class="title-content">';
		genesis_do_post_title();
		genesis_do_post_content();
	echo '</div>';
}

//* Helper function to display Post info and Post meta
function sk_masonry_entry_footer() {
		genesis_post_info();
}

//* Helper function to display featured image
//* Source: http://surefirewebservices.com/development/genesis-framework/using-the-genesis-featured-image
function sk_masonry_block_post_image() {
		$img = genesis_get_image( array( 'format' => 'html', 'size' => 'masonry-brick-image', 'attr' => array( 'class' => 'post-image' ) ) );
		printf( '<a href="%s" title="%s">%s</a>', get_permalink(), the_title_attribute( 'echo=0' ), $img );
}

//* Add more link when using excerpts
function sk_excerpt_more($more) {
    return '<a class="more-link" href="'. get_permalink() . '">&nbsp;&nbsp;[Continue Reading]</a>';
}
add_filter('excerpt_more', 'sk_excerpt_more');

//* Modify the length of post excerpts
add_filter( 'excerpt_length', 'sk_excerpt_length' );
function sk_excerpt_length( $length ) {
	return 20; // pull first 10 words
}

//* Register widget areas
genesis_register_sidebar( array(
	'id'			=> 'widget-above-header',
	'name'			=> __( 'Widget Above Header', 'pinspired' ),
	'description'	=> __( 'This is the widget area above the header', 'pinspired' ),
) );
genesis_register_sidebar( array(
	'id'			=> 'after-entry',
	'name'			=> __( 'After Entry', 'pinspired' ),
	'description'	=> __( 'This is the after post on single entries', 'pinspired' ),
) );
