jQuery(function($) {
	var $container = $('.content');

	$container.imagesLoaded( function(){
		$container.masonry({
			itemSelector: '.entry',
			isAnimated: true,
			gutterWidth: 20
		});
	});
});