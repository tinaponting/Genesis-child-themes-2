jQuery(function( $ ){

    // add js body class
    $('body').addClass('js');

    // find time for each entry and move it inside the image link
    $('.home-middle article, .home-top article').each(function(){
        var $time = $(this).find('.entry-time');

        $(this).find('a.alignleft, a.alignnone, a.alignright').append($time);

    }); 
	
});