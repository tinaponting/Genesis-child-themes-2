<?php
/**
 * Define and require all the necessary 'bits and pieces'
 * and build all necessary Static Homepage and Featured area functions.
 * @package Dynamik
 */
/**
 * Call Genesis's core functions.
 */
require_once( get_template_directory() . '/lib/init.php' );

/**
 * Define child theme constants.
 */
define( 'CHILD_THEME_NAME', 'Sweet Kitchen' );
define( 'CHILD_THEME_VERSION', '1.0' );

add_filter( 'avatar_defaults', 'child_default_avatar' );
/**
 * Display a Custom Avatar if one exists with the correct name
 * and in the correct images directory.
 * @return custom avatar.
 */
function child_default_avatar( $avatar_defaults )
{
	$custom_avatar_image = '';
	if( file_exists( CHILD_DIR . '/images/custom-avatar.png' ) )
		$custom_avatar_image = CHILD_URL . '/images/custom-avatar.png';
	elseif( file_exists( CHILD_DIR . '/images/custom-avatar.jpg' ) )
		$custom_avatar_image = CHILD_URL . '/images/custom-avatar.jpg';
	elseif( file_exists( CHILD_DIR . '/images/custom-avatar.gif' ) )
		$custom_avatar_image = CHILD_URL . '/images/custom-avatar.gif';
	elseif( file_exists( CHILD_DIR . '/images/custom-avatar.jpg' ) )
		$custom_avatar_image = CHILD_URL . '/images/custom-avatar.jpg';
	$custom_avatar = apply_filters( 'child_custom_avatar_path', $custom_avatar_image );
	$avatar_defaults[$custom_avatar] = 'Custom Avatar';
	return $avatar_defaults;
}

/**
 * Manage the placement of navbars.
 */
remove_action( 'genesis_after_header', 'genesis_do_subnav' );
add_action( 'genesis_before_header', 'genesis_do_subnav' );

add_action( 'genesis_meta', 'child_responsive_viewport' );
/**
 * Add viewport meta tag to the genesis_meta hook
 * to force 'real' scale of site when viewed in mobile devices.
 */
function child_responsive_viewport() {
echo '<meta name="viewport" content="width=device-width, initial-scale=1.0"/>' . "\n";
}

/**
 * Add support for Genesis HTML5 Markup.
 */
add_theme_support( 'html5' );

/**
 * Add support for Genesis 'Fancy Dropdowns'.
 */
add_filter( 'genesis_superfish_enabled', '__return_true' );

/**
 * This is altered version of the genesis_get_custom_field() function
 * which includes the additional ability to work with array() values.
 */
function dynamik_get_custom_field( $field, $single = true, $explode = false )
{
	if( null === get_the_ID() )
		return '';
	$custom_field = get_post_meta( get_the_ID(), $field, $single );
	if( !$custom_field )
		return '';
	if( !$single )
	{
		$custom_field_string = implode( ',', $custom_field );
		if( $explode )
		{
			$custom_field_array_pre = explode( ',', $custom_field_string );
			foreach( $custom_field_array_pre as $key => $value )
			{
				$custom_field_array[$value] = $value;
			}
			return $custom_field_array;
		}
		return $custom_field_string;
	}
	return is_array( $custom_field ) ? stripslashes_deep( $custom_field ) : stripslashes( wp_kses_decode_entities( $custom_field ) );
}

/**
 * Create a Dynamik Label conditional tag which
 * allows content to be conditionally placed on pages and posts
 * that have specific Dynamik Labels assigned to them.
 */
function dynamik_has_label( $label = 'label' )
{
	$labels_meta_array = dynamik_get_custom_field( '_dyn_labels', false, true ) != '' ? dynamik_get_custom_field( '_dyn_labels', false, true ) : array();

	if( is_singular() )
	{
		if( in_array( $label, $labels_meta_array ) ) return true;
	}
	return false;
}

/**
 * Create a Genesis Simple Sidebars conditional tag which
 * allows content to be conditionally placed on pages and posts
 * that have specific simple sidebars assigned to them.
 */
function dynamik_is_ss( $sidebar_id = 'sb-id' )
{
	if( !defined( 'SS_SETTINGS_FIELD' ) )
		return false;
	static $taxonomies = null;
	if( is_singular() )
	{
		if( $sidebar_id == genesis_get_custom_field( '_ss_sidebar' ) ) return true;
	}
	if( is_category() )
	{
		$term = get_term( get_query_var( 'cat' ), 'category' );
		if( isset( $term->meta['_ss_sidebar'] ) && $sidebar_id == $term->meta['_ss_sidebar'] ) return true;
	}
	if( is_tag() )
	{
		$term = get_term( get_query_var( 'tag_id' ), 'post_tag' );
		if( isset( $term->meta['_ss_sidebar'] ) && $sidebar_id == $term->meta['_ss_sidebar'] ) return true;
	}
	if( is_tax() )
	{
		if ( null === $taxonomies )
			$taxonomies = ss_get_taxonomies();
		foreach ( $taxonomies as $tax )
		{
			if ( 'post_tag' == $tax || 'category' == $tax )
				continue;
			if ( is_tax( $tax ) )
			{
				$obj = get_queried_object();
				$term = get_term( $obj->term_id, $tax );
				if( isset( $term->meta['_ss_sidebar'] ) && $sidebar_id == $term->meta['_ss_sidebar'] ) return true;
				break;
			}
		}
	}
	return false;
}

/**
 * Enable Shortcodes in Text Widgets.
 */
add_filter( 'widget_text', 'do_shortcode' );

/**
 * Hook the Feature Top Structure function into the 'wp_head' Hook.
 */
add_action( 'wp_head', 'child_feature_top' );

/**
 * Determine where NOT to display the Feature Top section before hooking it in.
 */
function child_feature_top() {
	/**
	 * Add conditional tags to control where the Feature Top Widget Area displays.
	 */
	if ( is_page_template( 'landing.php' ) ) { return; }
	 if ( is_single() ) { return; } if ( ( is_page() || is_404() ) && ! is_front_page() && ! is_page_template( 'page_blog.php' ) ) { return; } if ( is_archive() || is_search() ) { return; } if ( is_page_template( 'page_blog.php' ) ) { return; }
	
	/**
	 * Hook the Feature Top Structure function into the appropriate Genesis Hook.
	 */
	add_action( 'genesis_after_header', 'ez_feature_top' );
}

/**
 * Hook the Fat Footer Structure function into the 'wp_head' Hook.
 */
add_action( 'wp_head', 'child_fat_footer' );

/**
 * Determine where NOT to display the Fat Footer section before hooking it in.
 */
function child_fat_footer() {
	/**
	 * Add conditional tags to control where the Fat Footer Widget Area displays.
	 */
	if ( is_page_template( 'landing.php' ) ) { return; }
	    
	/**
	 * Hook the Fat Footer Structure function into the appropriate Genesis Hook.
	 */
	add_action( 'genesis_before_footer', 'ez_fat_footer' );
}
 
/**
 * Register EZ Widget Areas
 */
genesis_register_sidebar( array (
	'name'	=>	'EZ Feature Top 1',
	'id' 	=> 	'dynamik_ez_feature_top_1'
) );
		
genesis_register_sidebar( array (
	'name'	=>	'EZ Feature Top 2',
	'id' 	=> 	'dynamik_ez_feature_top_2'
) );
		
genesis_register_sidebar( array (
	'name'	=>	'EZ Fat Footer 1',
	'id' 	=> 	'dynamik_ez_fat_footer_1'
) );
		
genesis_register_sidebar( array (
	'name'	=>	'EZ Fat Footer 2',
	'id' 	=> 	'dynamik_ez_fat_footer_2'
) );
		
genesis_register_sidebar( array (
	'name'	=>	'EZ Fat Footer 3',
	'id' 	=> 	'dynamik_ez_fat_footer_3'
) );
		
genesis_register_sidebar( array (
	'name'	=>	'EZ Fat Footer 4',
	'id' 	=> 	'dynamik_ez_fat_footer_4'
) );
		
/**
 * Build the EZ Feature Top HTML.
 */
function ez_feature_top() { ?>
	<div id="ez-feature-top-container-wrap" class="clearfix">
		<div id="ez-feature-top-container" class="clearfix">
			<div id="ez-feature-top-1" class="widget-area ez-widget-area two-thirds first">
				<?php if ( ! dynamic_sidebar( 'EZ Feature Top #1' ) ) { ?>
					<div class="widget">
						<h4><?php _e( 'EZ Feature Top #1', 'dynamik' ); ?></h4>
						<p><?php printf( __( 'This is Dynamik Widget Area. You can add content to this area by going to <a href="%s">Appearance > Widgets</a> in your WordPress Dashboard and adding new widgets to this area.', "dynamik" ), admin_url( "widgets.php" ) ); ?></p>
					</div>			
				<?php } ?>
			</div><!-- end #feature-top-1 -->
			<div id="ez-feature-top-2" class="widget-area ez-widget-area one-third">
				<?php if ( ! dynamic_sidebar( 'EZ Feature Top #2' ) ) { ?>
					<div class="widget">
						<h4><?php _e( 'EZ Feature Top #2', 'dynamik' ); ?></h4>
						<p><?php printf( __( 'This is Dynamik Widget Area. You can add content to this area by going to <a href="%s">Appearance > Widgets</a> in your WordPress Dashboard and adding new widgets to this area.', "dynamik" ), admin_url( "widgets.php" ) ); ?></p>
					</div>			
				<?php } ?>
			</div><!-- end #feature-top-2 -->		
		</div><!-- end #feature-top-container -->		
	</div><!-- end #feature-top-container-wrap -->
<?php
}

/**
 * Build the EZ Fat Footer HTML.
 */
function ez_fat_footer() { ?>
	<div id="ez-fat-footer-container-wrap" class="clearfix">
		<div id="ez-fat-footer-container" class="clearfix">
			<div id="ez-fat-footer-1" class="widget-area ez-widget-area one-fourth first">
				<?php if ( ! dynamic_sidebar( 'EZ Fat Footer #1' ) ) { ?>
					<div class="widget">
						<h4><?php _e( 'EZ Fat Footer #1', 'dynamik' ); ?></h4>
						<p><?php printf( __( 'This is Dynamik Widget Area. You can add content to this area by going to <a href="%s">Appearance > Widgets</a> in your WordPress Dashboard and adding new widgets to this area.', "dynamik" ), admin_url( "widgets.php" ) ); ?></p>
					</div>			
				<?php } ?>
			</div><!-- end #fat-footer-1 -->
			<div id="ez-fat-footer-2" class="widget-area ez-widget-area one-fourth">
				<?php if ( ! dynamic_sidebar( 'EZ Fat Footer #2' ) ) { ?>
					<div class="widget">
						<h4><?php _e( 'EZ Fat Footer #2', 'dynamik' ); ?></h4>
						<p><?php printf( __( 'This is Dynamik Widget Area. You can add content to this area by going to <a href="%s">Appearance > Widgets</a> in your WordPress Dashboard and adding new widgets to this area.', "dynamik" ), admin_url( "widgets.php" ) ); ?></p>
					</div>			
				<?php } ?>
			</div><!-- end #fat-footer-2 -->
			<div id="ez-fat-footer-3" class="widget-area ez-widget-area one-fourth">
				<?php if ( ! dynamic_sidebar( 'EZ Fat Footer #3' ) ) { ?>
					<div class="widget">
						<h4><?php _e( 'EZ Fat Footer #3', 'dynamik' ); ?></h4>
						<p><?php printf( __( 'This is Dynamik Widget Area. You can add content to this area by going to <a href="%s">Appearance > Widgets</a> in your WordPress Dashboard and adding new widgets to this area.', "dynamik" ), admin_url( "widgets.php" ) ); ?></p>
					</div>			
				<?php } ?>
			</div><!-- end #fat-footer-3 -->
			<div id="ez-fat-footer-4" class="widget-area ez-widget-area one-fourth">
				<?php if ( ! dynamic_sidebar( 'EZ Fat Footer #4' ) ) { ?>
					<div class="widget">
						<h4><?php _e( 'EZ Fat Footer #4', 'dynamik' ); ?></h4>
						<p><?php printf( __( 'This is Dynamik Widget Area. You can add content to this area by going to <a href="%s">Appearance > Widgets</a> in your WordPress Dashboard and adding new widgets to this area.', "dynamik" ), admin_url( "widgets.php" ) ); ?></p>
					</div>			
				<?php } ?>
			</div><!-- end #fat-footer-4 -->		
		</div><!-- end #fat-footer-container -->	
	</div><!-- end #fat-footer-container-wrap -->
<?php
}

/**
 * Register Custom Widget Areas.
 */
/**
 * Build and Hook-In Custom Widget Areas.
 */
/**
 * Build and Hook-In Custom Hook Boxes.
 */

/**
 * Filter in specific body classes based on option values.
 */
add_filter( 'body_class', 'child_body_classes' );
/**
 * Determine which classes will be filtered into the body class.
 * @return array of all classes to be filtered into the body class.
 */
function child_body_classes( $classes ) {
	if ( is_front_page() ) {	
	}	
	$classes[] = "feature-top-outside";
	$classes[] = 'override';	
	return $classes;
}

add_filter( 'post_class', 'child_post_classes' );
/**
 * Create an array of useful post classes.
 * @return an array of child post classes.
 */
function child_post_classes( $classes )
{
	$classes[] = 'override';
	return $classes;
}

add_action( 'get_header', 'child_enqueue_responsive_scripts' );
/**
 * Enqueue Responsive Design javascript code.
 */
function child_enqueue_responsive_scripts() {	
	wp_enqueue_script( 'responsive', CHILD_URL . '/js/responsive.js', array( 'jquery' ), CHILD_THEME_VERSION, true );
}

//* Customize the author box title
add_filter( 'genesis_author_box_title', 'custom_author_box_title' );
function custom_author_box_title() {
	return '<strong>About the Author</strong>';
}

// move comment box above comments
remove_action('genesis_comment_form', 'genesis_do_comment_form');
add_action( 'genesis_before_comments', 'genesis_do_comment_form');
add_image_size( 'home-top', 350, 350, TRUE );
add_theme_support( 'custom-background' );

// Register Theme Features
function custom_theme_features()  {
 global $wp_version;

 // Add theme support for Custom Background
 $background_args = array(
  'default-color'          => '#7a7a7a',
  'default-image'          => get_template_directory_uri() . '/images/background.jpg',
  'wp-head-callback'       => '_custom_background_cb',
  'admin-head-callback'    => '',
  'admin-preview-callback' => '',
 );
 if ( version_compare( $wp_version, '3.4', '>=' ) ) :
  add_theme_support( 'custom-background', $background_args );
 else :
  add_custom_background();
 endif;
}

// Hook into the 'after_setup_theme' action
add_action( 'after_setup_theme', 'custom_theme_features' );

/** Add support for custom header **/
add_theme_support( 'genesis-custom-header', array( 'width' => 1150, 'height' => 300 ) );
add_theme_support( 'genesis-style-selector', array(
	'theme-blue'	=> __( 'Blue', 'themename' ),
	'theme-green'	=> __( 'Green', 'themename' ),
	'theme-orange'	=> __( 'Orange', 'themename' ),
	'theme-red'	=> __( 'Red', 'themename' )
) );

//* Customize the post info function
add_filter( 'genesis_post_info', 'sp_post_info_filter' );
function sp_post_info_filter($post_info) {
if ( !is_page() ) {
	$post_info = '[post_date] by [post_author_posts_link] [post_comments] [post_edit]';
	return $post_info;
}}

//* Create a shortcode to display our custom Go to top link
add_shortcode('footer_custombacktotop', 'set_footer_custombacktotop');
function set_footer_custombacktotop($atts) {
    return '
        <a href="#" class="top">Return to top of page</a>
    ';
}

//* Add smooth scrolling for any link having the class of "top"
add_action('wp_footer', 'go_to_top');
function go_to_top() { ?>
    <script type="text/javascript">
        jQuery(function($) {
            $('a.top').click(function() {
                $('html, body').animate({scrollTop:0}, 'slow');
                return false;
            });
        });
    </script>
<?php }
//end functions.php