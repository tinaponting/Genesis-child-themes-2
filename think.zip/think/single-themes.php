<?php
/**
 * The custom portfolio post type single post template
 */
 
 /** Force full width content layout */
add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );

/** Remove the post meta function **/
remove_action( 'genesis_entry_footer', 'genesis_post_meta' );

/** Remove the post info function **/
remove_action( 'genesis_entry_header', 'genesis_post_info', 12 );

/** Remove Author Box **/
remove_action( 'genesis_after_entry', 'genesis_do_author_box_single', 8 );

/** Remove the comments template */
remove_action( 'genesis_after_entry', 'genesis_get_comments_template' );
add_action( 'genesis_after_entry', 'genesis_prev_next_cpt_nav' );
add_filter( 'genesis_entry_footer', 'sharing_link', 99 );
function sharing_link(){
 ?>
 <div class="clearfix"></div>
<p><span st_url='<?php the_permalink(); ?>' st_title='<?php the_title(); ?>' class='st_facebook_hcount'></span>
<span st_via='pwdtechnology' st_username='pwdtechnology' st_url='<?php the_permalink(); ?>' st_title='<?php the_title(); ?>' class='st_twitter_hcount'></span>
<span st_url='<?php the_permalink(); ?>' st_title='<?php the_title(); ?>' class='st_linkedin_hcount'></span>
<span st_url='<?php the_permalink(); ?>' st_title='<?php the_title(); ?>' class='st_plusone_hcount'></span>
<span st_url='<?php the_permalink(); ?>' st_title='<?php the_title(); ?>' class='st_email_hcount'></span>
<span st_url='<?php the_permalink(); ?>' st_title='<?php the_title(); ?>' class='st_sharethis_hcount'></span></p>
<div class="clearfix"></div>
<?php
}

function genesis_prev_next_cpt_nav() {

	if ( ! is_singular( 'themes' ) )
		return;

	genesis_markup( array(
		'html5'   => '<div %s>',
		'xhtml'   => '<div class="navigation">',
		'context' => 'adjacent-entry-pagination',
	) );

	echo '<div class="pagination-previous alignleft">';
	previous_post_link();
	echo '</div>';

	echo '<div class="pagination-next alignright">';
	next_post_link();
	echo '</div>';

	echo '</div>';

}

//* Enqueue scripts and styles
add_action( 'wp_enqueue_scripts', 'think_enqueue_scripts' );
function think_enqueue_scripts() {  
  wp_enqueue_script( 'gumroad-js', 'https://gumroad.com/js/gumroad.js', array(), '1.0.0' ); 	
}

genesis();