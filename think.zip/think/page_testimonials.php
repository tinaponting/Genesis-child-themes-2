<?php
/**
 * Template Name: Feedback
 *
 * The portfolio page template displays your portfolio items with
 * a switcher to quickly filter between the various portfolio galleries. 
 *
 * @package Genesis Framework
 * @subpackage Template
 */
 
add_action( 'genesis_entry_content', 'pwd_theme_testimonails');
/** Add support for Genesis Magazine Loop **/
function pwd_theme_testimonails() {

  $paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1; 
  $query_args = array(
              				'post_type' => 'feedback', 
              				'paged' => $paged, 
              				'posts_per_page' => -1
              			);
  
  /* The Query. */			   
  $tm = new WP_Query( $query_args );
  if ( $tm->have_posts() ) { $count = 0;

	   while ( $tm->have_posts() ) { $tm->the_post(); 
        $count++;
        
        if($count % 2 == 0){
          $style = "blue";
        }else{
          $style = "grey";
        }
        
        $title = '<div class="author-name">~ ' .  get_post_meta( get_the_ID(), 'feedback_author', true) . '</div>';
        $content = get_the_content() . $title;
        //echo do_shortcode('[box title="' . $title .'" align="left" style="'.$style.'"]' . $content . '[/box]');
        echo do_shortcode('[box align="left" style="'.$style.'"]' . $content . '[/box]');
    }

  }
  wp_reset_query();             
}
genesis();