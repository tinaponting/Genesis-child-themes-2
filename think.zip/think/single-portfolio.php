<?php
/**
 * The custom portfolio post type single post template
 */
 
 /** Force full width content layout */
add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );
/** Remove the post meta function **/
remove_action( 'genesis_entry_header', 'genesis_do_post_title' );

/** Remove the post meta function **/
remove_action( 'genesis_entry_footer', 'genesis_post_meta' );

/** Remove the post info function **/
remove_action( 'genesis_entry_header', 'genesis_post_info', 12 );

/** Remove Author Box **/
remove_action( 'genesis_after_entry', 'genesis_do_author_box_single', 8 );

/** Remove the comments template */
remove_action( 'genesis_after_entry', 'genesis_get_comments_template' );

add_action( 'genesis_entry_content', 'genesis_do_portfolio_image', 8 );
function genesis_do_portfolio_image(){
  $img = genesis_get_image( array(
  			'format'  => 'html',
  			'size'    => 'full',
  			'context' => 'archive',
  			'attr'    => array ( 'class' => 'aligncenter portfolio-feat-image' )
  		) );
      
  if($img){
    echo '<div class="two-thirds first">' . "\n";
      echo $img;
    echo '</div>' . "\n";
    echo '<div class="portfolio-details one-third">' . "\n";
    genesis_do_post_title();
    echo '<div class="mini-content">' . "\n";
    if(genesis_get_custom_field('_portfolio_excerpt')) echo '<p>' . esc_attr( genesis_get_custom_field('_portfolio_excerpt') ) . '</p>' . "\n";                        
    if(genesis_get_custom_field('_client')) echo '<div class="authorStuff"><strong><i class="fa fa-user"></i> Client:</strong><span class="client">'.genesis_get_custom_field('_client').'</span></div>' . "\n";
    if(genesis_get_custom_field('_project_time')) echo '<div class="dateStuff"><strong><i class="fa fa-clock-o"></i> Date:</strong><span>'.genesis_get_custom_field('_project_time').'</span></div>' . "\n";
    echo '<div class="categoryStuff"><strong><i class="fa fa-tag"></i> Category:</strong> '.get_the_term_list( $post->ID, 'portfolio-gallery', '', ', ', '' ).'</div>' . "\n";
    if(genesis_get_custom_field('_team')) echo '<div class="stuff"><strong><i class="fa fa-group"></i> Developer:</strong> '. esc_attr( genesis_get_custom_field('_team') ).'</div>' . "\n";
    
    echo '<div class="projectStuff">' . "\n";
      
      if(genesis_get_custom_field('url')) echo '<a href="'.genesis_get_custom_field('url').'" class="btn button" target="_blank"><i class="fa fa-globe"></i> Visit Website</a>'. "\n";
    
     echo previous_post_link('%link', '<i class="fa fa-chevron-right"></i>') . next_post_link('%link', '<i class="fa fa-chevron-left"></i>');
      
    echo '</div>' . "\n";
                    
    echo '</div>' . "\n";
    echo '</div>' . "\n";
    echo do_shortcode('[divider]');
  }
}

genesis();