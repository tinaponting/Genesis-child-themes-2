<?php
 /****
  * Portfolio Items on Home Page
  ****/   
?>
<!--
<section class="latest-work" id="showcase">
  <div class="wrap">
   <div class="one-half first"><h2 class="section-title">Latest Work</h2></div>
   <div class="one-half"><a href="<?php home_url('/')?>portfolio/" class="button btn">View All</a></div> 
  
  <?php 
   /* $args = array('post_type' => 'portfolio', 'posts_per_page' => 8);
    query_posts($args);
    if( have_posts() ){
      $counter = 0;*/
  ?>
  <div class="portfolio-items">
    <ul>
  <?php //while( have_posts() ) { the_post(); ?>
   
    <li>
		  <div <?php post_class(); ?>>
  		<?php
        //if( $bestSelling == "yes") echo '<div class="top-product"></div>' . "\n";
  
  			/*$image = genesis_get_image( array(
                                    			'format'  => 'html',
                                    			'size'    => "theme-thumb",
                                    			'context' => 'archive',
                                    			'attr'    => array ( 'class' => 'alignnone post-image' )
                                    		) );
  			
  			if ( $image != '' ) {*/
  		?>
  			<a rel="permalink" title="<?php //the_title(); ?>" href="<?php //echo get_permalink( get_the_ID() ); ?>" class="thumb">
  				<?php echo $image; ?>
        </a>
        <div class="over">
  	      <h2><?php //the_title() ?></h2>
          <p><?php //echo get_post_meta(get_the_ID(), '_portfolio_excerpt', true); ?></p>
          <center><a href="<?php //echo get_permalink( get_the_ID() ); ?>" class="css3_btn">View Details</a></center>
        </div>
      <?php //} ?>
  		</div>
    </li>
    
  <?php //$counter++; } ?>
  
    </ul>
  </div>
  
  <?php //} wp_reset_query(); ?>
  
  </div>
  
</section>--><!-- /.latest-work -->

<?php //echo do_shortcode('[divider_flat]'); ?>

<section class="top-products" id="showcase">
  <div class="wrap">
   <div class="one-half first"><h2 class="section-title">Wordpress Themes</h2></div>
   <div class="one-half"><a href="<?php home_url('/')?>products/" class="button btn">View All</a></div> 
  
  <?php 
    $args = array('post_type' => 'themes', 'posts_per_page' => 8);
    $themes = new WP_Query($args);
    if( $themes->have_posts() ){
      $counter = 0;
  ?>
  <div class="portfolio-items">
    <ul>
  <?php while( $themes->have_posts() ) { $themes->the_post(); ?>
   
    <li>
		  <div <?php post_class(); ?>>
  		<?php
        $title = (get_post_meta( get_the_ID(), '_title', true)) ? get_post_meta( get_the_ID(), '_title', true) : get_post_meta( get_the_ID(), 'title', true);
        $short_desc = (get_post_meta( get_the_ID(), '_short_desc', true)) ? get_post_meta( get_the_ID(), '_short_desc', true) : get_post_meta( get_the_ID(), 'short_desc', true);
  
  			$image = genesis_get_image( array(
                                    			'format'  => 'html',
                                    			'size'    => "theme-thumb",
                                    			'context' => 'archive',
                                    			'attr'    => array ( 'class' => 'alignnone post-image' )
                                    		) );
  			
  			if ( $image != '' ) {
  		?>
  			<a rel="permalink" title="<?php the_title(); ?>" href="<?php echo get_permalink( get_the_ID() ); ?>" class="thumb">
  				<?php echo $image; ?>
        </a>
        <div class="over">
  	      <h2><?php echo $title; ?></h2>
               <p><?php echo $short_desc; ?></p>
          <center><a href="<?php echo get_permalink( get_the_ID() ); ?>" class="css3_btn">View Details</a></center>
        </div>
      <?php } ?>
  		</div><!--/.group .post .portfolio-img-->
    </li>
    
  <?php $counter++; } ?>
  
    </ul>
  </div>
  
  <?php } wp_reset_query(); ?>
  
  </div><!-- /.wrap -->
  
</section><!-- /.top-prducts -->

<?php echo do_shortcode('[divider_flat]'); ?>