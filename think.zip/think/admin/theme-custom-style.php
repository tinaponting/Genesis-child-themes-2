<?php
add_action( 'wp_head', 'pwd_custom_styling', 90 );			// Generate custom styles - Dynamic CSS.
add_action( 'wp_head', 'google_webfonts', 92); // Initialize the Google Font

/*-----------------------------------------------------------------------------------*/
/* Generate dynamic CSS */
/*-----------------------------------------------------------------------------------*/
function pwd_custom_styling(){
	global $pwd_options;
  
  $css = $body = $header = $sdbm = $primary_nav = $widget_title ='';
  $bg = $pwd_options['pwd_style_bg'];
	$bg_image = $pwd_options['pwd_style_bg_image'];
	$bg_image_repeat = $pwd_options['pwd_style_bg_image_repeat'];
	$bg_image_pos = $pwd_options['pwd_style_bg_image_pos'];
	$bg_image_attach = $pwd_options['pwd_style_bg_image_attach'];
  $bgtop = $pwd_options['pwd_border_top'];
  
  if($pwd_options['pwd_logo']){
    $css .= '.header-image .site-header .wrap{background: url('.$pwd_options['pwd_logo'].') no-repeat left;}' . "\n";
    add_filter( 'body_class', 'add_body_class_header_image' );
  }
  
  if ($bg)
		$body .= 'background-color:'.$bg.';';
	if ($bg_image)
		$body .= 'background-image:url('.$bg_image.');';
	if ($bg_image_repeat)
		$body .= 'background-repeat:'.$bg_image_repeat.';';
	if ($bg_image_pos)
		$body .= 'background-position:'.$bg_image_pos.';';
	if ($bg_image_attach)
		$body .= 'background-attachment:'.$bg_image_attach.';';
  if((int)$bgtop['width'] > 0 )
    $body .= 'border-top:' . $bgtop['width'] . 'px '. $bgtop['style'] .' ' . $bgtop['color'];
  
  if( isset($pwd_options['pwd_body_pattern_show']) && $pwd_options['pwd_body_pattern_show'] == 'true' ){
    $bg_pattern = $pwd_options['pwd_select_body_pattern'];
    $css .= 'body {background: url("'. CHILD_URL . '/images/patterns/' . $bg_pattern . '.png") repeat; border-top:' . $bgtop['width'] . 'px '. $bgtop['style'] .' ' . $bgtop['color'] .'}'. "\n";
  }elseif($body != ''){
    $css .= 'body{'.$body.'}' . "\n";
  }
  
  $link_color = $pwd_options['pwd_link_color'];
	$hover_color = $pwd_options['pwd_link_hover_color'];
  if ($link_color)
		$css .= 'a:link, a:visited, .entry-content a:link, .fet-post a.more-link:link, .entry-content a:visited {color:'.$link_color.'}' . "\n";
	if ($hover_color)
		$css .= 'a:hover, a.more-link:hover, .fet-post a.more-link:hover, .entry-content a:hover, .entry-title a:hover, .widget_nav_menu li a:hover, .widget_categories li a:hover, 
            .widget_categories li.current-cat a, .fet-post h3.entry-title a:hover,
            .widget_archive li a:hover, .pwd-shortcode-tabs.boxed ul.tab_titles li.ui-state-active a, .pwd-shortcode-tabs.boxed ul.tab_titles li.ui-state-active a:hover,
            .pwd-shortcode-tabs.boxed ul.tab_titles li a:hover, .shortcode-tabs ul.tab_titles li.nav-tab a:hover, .site-footer a:hover {color:'.$hover_color.'}' . "\n";
  
  $hd_bg = $pwd_options['pwd_header_bg'];
	$hd_bg_image = $pwd_options['pwd_header_bg_image'];
	$hd_bg_image_repeat = $pwd_options['pwd_header_bg_image_repeat'];
  $hd_margin_top = $pwd_options['pwd_header_margin_top'];
  $hd_margin_botm = $pwd_options['pwd_header_margin_bottom'];
  
  if ($hd_bg)
		$header .= 'background-color:'.$hd_bg.';';
	if ($hd_bg_image)
		$header .= 'background-image:url('.$hd_bg_image.');';
	if ($hd_bg_image_repeat)
		$header .= 'background-repeat:'.$hd_bg_image_repeat.';';
  if ($hd_margin_top)
		$header .= 'margin-top:'.$hd_margin_top.'px; margin-top:'. ( $hd_margin_top / 10 ) .'rem;';
  if ($hd_margin_botm)
		$header .= 'margin-bottom:'.$hd_margin_botm.'px; margin-bottom:' . ($hd_margin_botm / 10) . 'rem;';
    
  if ( $header )
			$css .= '.site-header { ' . $header . ' }' . "\n";  
  // General Typography		
		$font_text = $pwd_options['pwd_font_text'];	
		$font_h1 = $pwd_options['pwd_font_h1'];	
		$font_h2 = $pwd_options['pwd_font_h2'];	
		$font_h3 = $pwd_options['pwd_font_h3'];	
		$font_h4 = $pwd_options['pwd_font_h4'];	
		$font_h5 = $pwd_options['pwd_font_h5'];	
		$font_h6 = $pwd_options['pwd_font_h6'];	
	
		if ( $font_text )
			$css .= 'body, p, .pwd-shortcode-tabs ul.tab_titles li.nav-tab a { ' . generate_font( $font_text, 1.4 ) . ' }' . "\n";	
		if ( $font_h1 )
			$css .= 'h1 { ' . generate_font( $font_h1, 1.2 ) . ' }' . "\n";	
		if ( $font_h2 )
			$css .= 'h2 { ' . generate_font( $font_h2, 1.2 ) . ' }' . "\n";	
		if ( $font_h3 )
			$css .= 'h3 { ' . generate_font( $font_h3, 1.3 ) . ' }'. "\n";	
		if ( $font_h4 )
			$css .= 'h4 { ' . generate_font( $font_h4, 1.3 ) . ' }' . "\n";	
		if ( $font_h5 )
			$css .= 'h5 { ' . generate_font( $font_h5, 1.3 ) . ' }' . "\n";	
		if ( $font_h6 )
			$css .= 'h6 { ' . generate_font( $font_h6, 1.3 ) . ' }' . "\n";
  $nav_bg = $pwd_options['pwd_nav_bg'];     
  $nav_border_top = $pwd_options['pwd_nav_border_top'];
  $nav_border_bot = $pwd_options['pwd_nav_border_bot'];
  if($nav_bg)
    $primary_nav .= 'background-color: '. $nav_bg . ';'. "\n";
  if($nav_border_top['width'] > 0)
    $primary_nav .= 'border-top: ' . $nav_border_top['width'] .'px '. $nav_border_top['style'] . ' '. $nav_border_top['color'] .';' . "\n";
  if($nav_border_bot['width'] > 0)
    $primary_nav .= 'border-bottom: ' . $nav_border_bot['width'] .'px '. $nav_border_bot['style'] . ' '. $nav_border_bot['color'] .';' . "\n";
  if( $pwd_options['pwd_nav_border_radius'] != "0px" )
     $primary_nav .= 'border-radius: '. $pwd_options['pwd_nav_border_radius'] . '; -webkit-border-radius: '. $pwd_options['pwd_nav_border_radius'] . '; -moz-border-radius: '. $pwd_options['pwd_nav_border_radius'] . ';'. "\n";  
  if($primary_nav)
    $css .= '.nav-primary { ' . $primary_nav . '}' . "\n";    
  if( $pwd_options['pwd_nav_font'] )
     $css .= '.nav-primary .genesis-nav-menu > li a, .genesis-nav-menu > .right {'. generate_font($pwd_options['pwd_nav_font'], 1.2) . ';}'. "\n";
  if( $pwd_options['pwd_nav_hover'] )
     $css .= '.nav-primary .genesis-nav-menu > li a:hover, .nav-primary .genesis-nav-menu > li:hover a {color: '. $pwd_options['pwd_nav_hover'] . ';}'. "\n";
  if( $pwd_options['pwd_nav_hover_bg'] )
     $css .= '.nav-primary .genesis-nav-menu > li a:hover, .nav-primary .genesis-nav-menu > li:hover { background-color: '. $pwd_options['pwd_nav_hover_bg'] . ';}'. "\n";
  $nav_currentitem = $pwd_options['pwd_nav_currentitem'];
  $nav_currentitem_bg = $pwd_options['pwd_nav_currentitem_bg'];
  $nav_current ='';     
  if( $nav_currentitem )
     $nav_current .= 'color: '. $nav_currentitem . ';'. "\n";
  if( $nav_currentitem_bg )
     $nav_current .= 'background-color: '. $nav_currentitem_bg . ';'. "\n";
  if( $nav_current )   
    $css .='.nav-primary .genesis-nav-menu > li.current-menu-item > a, .nav-primary .genesis-nav-menu > li.current-menu-ancestor > a{'. $nav_current .'}' . "\n";
  if( $pwd_options['pwd_sub_item_bg'] )
     $css .= '.nav-primary .genesis-nav-menu .sub-menu {background-color: '. $pwd_options['pwd_sub_item_bg'] . ';}'. "\n"; 
  if( $pwd_options['pwd_nav_sub_item_font'] )
     $css .= '.nav-primary .genesis-nav-menu .sub-menu > li a {color: '. generate_font($pwd_options['pwd_nav_sub_item_font'], 1.2) . ';}'. "\n";
  if( $pwd_options['pwd_sub_item_hover'] )
     $css .= '.nav-primary .genesis-nav-menu .sub-menu li > a:hover, .nav-primary .genesis-nav-menu .sub-menu li:hover > a {color: '. $pwd_options['pwd_sub_item_hover'] . ';}'. "\n";
  if( $pwd_options['pwd_sub_item_hover_bg'] )
     $css .= '.nav-primary .genesis-nav-menu .sub-menu li > a:hover, .nav-primary .genesis-nav-menu .sub-menu > li:hover { background-color: '. $pwd_options['pwd_sub_item_hover_bg'] . ';}'. "\n";
  $sub_nav_currentitem = $pwd_options['pwd_sub_currentitem'];
  $sub_nav_currentitem_bg = $pwd_options['pwd_sub_currentitem_bg'];
  $sub_nav_current ='';     
  if( $sub_nav_currentitem )
     $sub_nav_current .= 'color: '. $sub_nav_currentitem . ';'. "\n";
  if( $sub_nav_currentitem_bg )
     $sub_nav_current .= 'background-color: '. $sub_nav_currentitem_bg . ';'. "\n";
  if( $sub_nav_current )   
    $css .='.nav-primary .genesis-nav-menu .sub-menu li.current-menu-item > a, 
            .nav-primary .genesis-nav-menu .sub-menu li.current-menu-ancestor > a{'. $sub_nav_current .'}' . "\n";
  
  $sbitem_border_top = $pwd_options['pwd_nav_si_border_top'];
  $sbitem_border_botm = $pwd_options['pwd_nav_si_border_bot'];
  $sbitem_border_lt = $pwd_options['pwd_nav_si_border_lr'];
  if($sbitem_border_top['width'] > 0)
    $css .= '.nav-primary .genesis-nav-menu .sub-menu a{border-top: ' . $sbitem_border_top['width'] .'px '. $sbitem_border_top['style'] . ' '. $sbitem_border_top['color'] .';}' . "\n";
  if($sbitem_border_botm['width'] > 0)
    $css .= '.nav-primary .genesis-nav-menu .sub-menu a{border-bottom: ' . $sbitem_border_botm['width'] .'px '. $sbitem_border_botm['style'] . ' '. $sbitem_border_botm['color'] .';}' . "\n";
  if($pwd_sec_nav_border_lr['width'] > 0)
    $css .= '.nav-primary .genesis-nav-menu .sub-menu a{border-right: ' . $pwd_sec_nav_border_lr['width'] .'px '. $pwd_sec_nav_border_lr['style'] . ' '. $pwd_sec_nav_border_lr['color'] .'; 
              border-left: ' . $pwd_sec_nav_border_lr['width'] .'px '. $pwd_sec_nav_border_lr['style'] . ' '. $pwd_sec_nav_border_lr['color'] .';}' . "\n";
      
  if( isset($pwd_options['pwd_sec_nav_bg']) && ( $pwd_options['pwd_sec_nav_bg'] != '' ) && ( $pwd_options['pwd_sec_nav_bg'] != 'none' ) )
     $css .= '.nav-secondary {background-color: '. $pwd_options['pwd_sec_nav_bg'] . '}'. "\n";  
  if( $pwd_options['pwd_sec_nav_border_radius'] != "0px" )
     $css .= '.nav-secondary {border-radius: '. $pwd_options['pwd_sec_nav_border_radius'] . '; -webkit-border-radius: '. $pwd_options['pwd_sec_nav_border_radius'] . '; -moz-border-radius: '. $pwd_options['pwd_sec_nav_border_radius'] . ';}'. "\n";      
  if( $pwd_options['pwd_sec_nav_font'] )
     $css .= '.nav-secondary .genesis-nav-menu > li a {'. generate_font($pwd_options['pwd_sec_nav_font'], 1.2) . ';}'. "\n";
  if( $pwd_options['pwd_sec_nav_hover'] )
     $css .= '.nav-secondary .genesis-nav-menu > li a:hover, .nav-secondary .genesis-nav-menu > li:hover a {color: '. $pwd_options['pwd_sec_nav_hover'] . ';}'. "\n";
  if( $pwd_options['pwd_sec_nav_hover_bg'] )
     $css .= '.nav-secondary .genesis-nav-menu > li a:hover, .nav-secondary .genesis-nav-menu > li:hover { background-color: '. $pwd_options['pwd_sec_nav_hover_bg'] . ';}'. "\n"; 
  $nav_current_item = $pwd_options['pwd_sec_nav_currentitem'];
  $nav_current_item_bg = $pwd_options['pwd_sec_nav_nav_currentitem_bg'];
  $nav_current ='';     
  if( $nav_current_item )
     $nav_current .= 'color: '. $nav_current_item . ';'. "\n";
  if( $nav_current_item_bg )
     $nav_current .= 'background-color: '. $nav_current_item_bg . ';'. "\n";
  if( $nav_current )   
    $css .='.nav-secondary .genesis-nav-menu > li.current-menu-item > a, .nav-secondary .genesis-nav-menu > li.current-menu-ancestor > a{'. $nav_current .'}' . "\n";
  
  if( $pwd_options['pwd_sec_nav_sub_item_bg'] )
     $css .= '.nav-secondary .genesis-nav-menu .sub-menu {background-color: '. $pwd_options['pwd_sec_nav_sub_item_bg'] . ';}'. "\n"; 
  if( $pwd_options['pwd_sec_nav_sub_item_font'] )
     $css .= '.nav-secondary .genesis-nav-menu .sub-menu > li a {color: '. generate_font($pwd_options['pwd_sec_nav_sub_item_font'], 1.2) . ';}'. "\n";
  if( $pwd_options['pwd_sec_nav_sub_item_hover'] )
     $css .= '.nav-secondary .genesis-nav-menu .sub-menu li > a:hover, .nav-secondary .genesis-nav-menu .sub-menu li:hover > a {color: '. $pwd_options['pwd_sec_nav_sub_item_hover'] . ';}'. "\n";
  if( $pwd_options['pwd_sec_nav_sub_item_hover_bg'] )
     $css .= '.nav-secondary .genesis-nav-menu .sub-menu li > a:hover, .nav-secondary .genesis-nav-menu .sub-menu > li:hover { background-color: '. $pwd_options['pwd_sec_nav_sub_item_hover_bg'] . ';}'. "\n";
  $sub_nav_current_item = $pwd_options['pwd_sec_nav_sub_currentitem'];
  $sub_nav_current_item_bg = $pwd_options['pwd_sec_nav_sub_currentitem_bg'];
  $sub_nav_current ='';     
  if( $sub_nav_current_item )
     $sub_nav_current .= 'color: '. $sub_nav_current_item . ';'. "\n";
  if( $sub_nav_current_item_bg )
     $sub_nav_current .= 'background-color: '. $sub_nav_current_item_bg . ';'. "\n";
  if( $sub_nav_current )   
    $css .='.nav-secondary .genesis-nav-menu .sub-menu li.current-menu-item > a, 
            .nav-secondary .genesis-nav-menu .sub-menu li.current-menu-ancestor > a{'. $sub_nav_current .'}' . "\n";
  
  $sbitem_border_top = $pwd_options['pwd_sec_nav_border_top'];
  $sbitem_border_botm = $pwd_options['pwd_sec_nav_border_bot'];
  $sbitem_border_lt = $pwd_options['pwd_sec_nav_border_lr'];
  if($sbitem_border_top['width'] > 0)
    $css .= '.nav-secondary .genesis-nav-menu .sub-menu a{border-top: ' . $sbitem_border_top['width'] .'px '. $sbitem_border_top['style'] . ' '. $sbitem_border_top['color'] .';}' . "\n";
  if($sbitem_border_botm['width'] > 0)
    $css .= '.nav-secondary .genesis-nav-menu .sub-menu a{border-bottom: ' . $sbitem_border_botm['width'] .'px '. $sbitem_border_botm['style'] . ' '. $sbitem_border_botm['color'] .';}' . "\n";
  if($pwd_sec_nav_border_lr['width'] > 0)
    $css .= '.nav-secondary .genesis-nav-menu .sub-menu a{border-right: ' . $pwd_sec_nav_border_lr['width'] .'px '. $pwd_sec_nav_border_lr['style'] . ' '. $pwd_sec_nav_border_lr['color'] .'; 
              border-left: ' . $pwd_sec_nav_border_lr['width'] .'px '. $pwd_sec_nav_border_lr['style'] . ' '. $pwd_sec_nav_border_lr['color'] .';}' . "\n";
  
  // Post/Page Style
  if($pwd_options['pwd_font_post_title'])  
    $css .='.entry-title, .entry-title a{'. generate_font($pwd_options['pwd_font_post_title'], 1.25) . '}' . "\n";
  if($pwd_options['pwd_font_post_text'])  
    $css .='.entry-content ol, .entry-content p, .entry-content ul{'. generate_font($pwd_options['pwd_font_post_text'], 1.4) . '}' . "\n";  
  if($pwd_options['pwd_font_post_meta'])  
    $css .='.entry-meta, .entry-meta a:link, .entry-meta a:visited{'. generate_font($pwd_options['pwd_font_post_meta'], 1.2) . '}' . "\n";  
  if($pwd_options['pwd_font_post_more'])  
    $css .='a.more-link:link, a.more-link:visited{border:none; '. generate_font($pwd_options['pwd_font_post_more'], 1.4) . '}' . "\n";
    
  $pwd_pagenav_font = $pwd_options['pwd_pagenav_font'];
  $pwd_pagenav_bg = $pwd_options['pwd_pagenav_bg'];
  $pwd_pagenav_font_hover_color = $pwd_options['pwd_pagenav_font_hover_color'];
  $pwd_pagenav_hover_bg = $pwd_options['pwd_pagenav_hover_bg'];
  if($pwd_pagenav_font_hover_color)
    $css .= '.archive-pagination li a:hover, .archive-pagination li.active a {color: ' . $pwd_pagenav_font_hover_color . ';}' . "\n";
  if($pwd_pagenav_hover_bg)  
    $css .= '.archive-pagination li a:hover, .archive-pagination li.active a {background-color: ' . $pwd_pagenav_hover_bg . ';}' . "\n";
  if($pwd_pagenav_font)
    $css .= '.archive-pagination li a {'.generate_font($pwd_pagenav_font).'}' . "\n";
  if($pwd_pagenav_bg)
    $css .= '.archive-pagination li a { background-color: '. $pwd_pagenav_bg . ';}' . "\n";
    
  
  $sdbm_bg = $pwd_options['pwd_sidebar_bg'];   
  if($sdbm_bg)
    $css .= '.sidebar-primary{background-color: '.$sdbm_bg.';}' . "\n";
    
  $sdbm_wdgts_bg = $pwd_options['pwd_widget_bg'];
  $sdbm_wdgts_border = $pwd_options['pwd_widget_border'];
  $sdbm_wdgts_ptb = $pwd_options['pwd_widget_padding_tb'];
  $sdbm_wdgts_plr = $pwd_options['pwd_widget_padding_lr'];
  $sdbm_wdgts_ttl_font = $pwd_options['pwd_widget_font_title'];
  $sdbm_wdgts_ttl_bg = $pwd_options['pwd_widget_title_bg'];
  $sdbm_wdgts_ttl_bbm = $pwd_options['pwd_widget_title_border'];
  $sdbm_wdgts_text_font = $pwd_options['pwd_widget_font_text'];
  $sdbm_wdgts_border_radius = $pwd_options['pwd_widget_border_radius'] ;
  if($sdbm_wdgts_bg)
    $sdbm .= 'background-color: ' . $sdbm_wdgts_bg .';' . "\n";
  if($sdbm_wdgts_border)
    $sdbm .= 'border: ' . $sdbm_wdgts_border['width'] .'px '. $sdbm_wdgts_border['style'] . ' '. $sdbm_wdgts_border['color'] .';' . "\n";  
  if($sdbm_wdgts_ptb)
    $sdbm .= 'padding-top: ' . $sdbm_wdgts_ptb .'px; padding-top: '. ($sdbm_wdgts_ptb/10). 'rem; '. 'padding-bottom: ' . $sdbm_wdgts_ptb .'px; padding-bottom: '. ($sdbm_wdgts_ptb/10). 'rem; '. "\n";
  if($sdbm_wdgts_plr)
    $sdbm .= 'padding-left: ' . $sdbm_wdgts_plr .'px; padding-left: '. ($sdbm_wdgts_plr/10). 'rem; '. 'padding-right: ' . $sdbm_wdgts_plr .'px; padding-right: '. ($sdbm_wdgts_plr/10). 'rem; '. "\n";
  if($sdbm_wdgts_border_radius)
    $sdbm .= 'border-radius: ' . $sdbm_wdgts_border_radius . ';-moz-border-radius: ' . $sdbm_wdgts_border_radius . ';-webkit-border-radius: ' . $sdbm_wdgts_border_radius . ';' ."\n";  
  if($sdbm)
    $css .='.sidebar .widget { '. $sdbm .'}' . "\n";
  
  if($sdbm_wdgts_ttl_font)
    $widget_title .= generate_font( $sdbm_wdgts_ttl_font, 1.2 ) . "\n";
  if($sdbm_wdgts_ttl_bg)
    $widget_title .= 'background-color: ' . $sdbm_wdgts_ttl_bg . ';' . "\n";    
  if($sdbm_wdgts_ttl_bbm)
    $widget_title .= 'border-bottom: ' . $sdbm_wdgts_ttl_bbm['width'] .'px '. $sdbm_wdgts_ttl_bbm['style'] . ' '. $sdbm_wdgts_ttl_bbm['color'] .';' . "\n";
  if($widget_title)
    $css .= '.sidebar .widget-title{'.$widget_title.'}' . "\n";
  if($sdbm_wdgts_text_font)
    $css .= '.sidebar, .sidebar .widget p, .sidebar .widget .textwidget, .widget_archive li a, .widget_categories li a, .widget_nav_menu li a{' . generate_font( $sdbm_wdgts_text_font, 1.625 ) . '}' . "\n";   
  // Customizing footer-widgets Style
  $footer_wgt = $fw_wdgts_ttl_css = $fw_wdgts = '';   
  $fw_bg = $pwd_options['pwd_fw_wrapper_bg'];
  $fw_border_top = $pwd_options['pwd_fw_border_top'];
  $fw_border_bottom = $pwd_options['pwd_fw_border_bottom'];
  $fw_border_lr = $pwd_options['pwd_fw_border_lr'];
  $fw_font_title = $pwd_options['pwd_fw_widget_font_title'];
  $fw_font_txt = $pwd_options['pwd_fw_widget_font_text'];
  $fw_wdgts_bg = $pwd_options['pwd_fw_widget_bg'];
  $fw_wdgts_pd_tb = $pwd_options['pwd_fw_widget_padding_tb'];
  $fw_wdgts_pd_lr = $pwd_options['pwd_fw_widget_padding_lr'];
  $fw_wdgts_border = $pwd_options['pwd_fw_widget_border'];
  $fw_wdgts_title_bg = $pwd_options['pwd_fw_widget_title_bg'];
  $fw_wdgts_title_border = $pwd_options['pwd_fw_widget_title_border'];
  $fw_wdgts_border_radius = $pwd_options['pwd_fw_widget_border_radius'];
  
  if($fw_bg)
    $footer_wgt .= 'background-color: ' . $fw_bg . ";\n";
  if((int)$fw_border_top['width'] > 0) 
    $footer_wgt .= 'border-top: ' . $fw_border_top['width'] . 'px ' . $fw_border_top['style'] . ' ' . $fw_border_top['color'] . ";\n"; 
  if((int)$fw_border_bottom['width'] > 0) 
    $footer_wgt .= 'border-bottom: ' . $fw_border_bottom['width'] . 'px ' . $fw_border_bottom['style'] . ' ' . $fw_border_bottom['color'] . ";\n";
  if((int)$fw_border_lr['width'] > 0) {
    $footer_wgt .= 'border-left: ' . $fw_border_lr['width'] . 'px ' . $fw_border_lr['style'] . ' ' . $fw_border_lr['color'] . ";\n";
    $footer_wgt .= 'border-right: ' . $ft_border_lr['width'] . 'px ' . $fw_border_lr['style'] . ' ' . $fw_border_lr['color'] . ";\n";
  }
  if($footer_wgt != '')
    $css .='.footer-widgets{'.$footer_wgt.'}' . "\n";
    
  if($fw_wdgts_bg)
    $fw_wdgts .='background: ' . $fw_wdgts_bg .';' . "\n";
  if($fw_wdgts_pd_tb)
    $fw_wdgts .='padding-top: ' . $fw_wdgts_pd_tb .'px; padding-bottom: '. $fw_wdgts_pd_tb .'px;' . "\n";
  if($fw_wdgts_pd_lr)
    $fw_wdgts .='padding-left: ' . $fw_wdgts_pd_lr .'px; padding-right: '. $fw_wdgts_pd_lr .'px;' . "\n";
  if($fw_wdgts_border_radius)
    $fw_wdgts .='border-radius: ' . $fw_wdgts_border_radius .'; -moz-border-radius: '. $fw_wdgts_border_radius .';-webkit-border-radius: '. $fw_wdgts_border_radius .';' . "\n";
  if($fw_wdgts_border['width'])
    $fw_wdgts .= 'border: ' . $fw_wdgts_border['width'] . 'px ' . $fw_wdgts_border['style'] . ' ' . $fw_wdgts_border['color'] . ";\n";
    
  if($fw_wdgts)
    $css .='.footer-widgets .widget{'.$fw_wdgts.'}' . "\n";
                                                        
  if($fw_font_title)
    $fw_wdgts_ttl_css .= generate_font( $fw_font_title, 1.2 );
  if($fw_wdgts_title_bg)
    $fw_wdgts_ttl_css .= 'background-color: ' . $fw_wdgts_title_bg . "; padding: 5px 10px;\n";
  if($fw_wdgts_title_border['width'] > 0)
    $fw_wdgts_ttl_css .= 'border-bottom: ' . $fw_wdgts_title_border['width'] . 'px ' . $fw_wdgts_title_border['style'] . ' ' . $fw_wdgts_title_border['color'] . ";padding-bottom: 5px;\n";
    
  if($fw_wdgts_ttl_css != '')
    $css.='.footer-widgets .widget-title{'.$fw_wdgts_ttl_css.'}' . "\n";
  if($fw_font_txt)  
    $css .='.footer-widgets a, .footer-widgets, .footer-widgets p, .footer-widgets .textwidget{ ' . generate_font( $fw_font_txt, 1.425 ) . '}' ."\n";
    
  // Customizing footer Style
  $footer = '';   
  $ft_bg = $pwd_options['pwd_footer_bg'];
  $ft_border_top = $pwd_options['pwd_footer_border_top'];
  $ft_border_bottom = $pwd_options['pwd_footer_border_bottom'];
  $ft_border_lr = $pwd_options['pwd_footer_border_lr'];
  $footer_font = $pwd_options['pwd_footer_font'];
  if($ft_bg)
    $footer .= 'background-color: ' . $ft_bg . ";\n";
  if((int)$ft_border_top['width'] > 0) 
    $footer .= 'border-top: ' . $ft_border_top['width'] . 'px ' . $ft_border_top['style'] . ' ' . $ft_border_top['color'] . ";\n"; 
  if((int)$ft_border_bottom['width'] > 0) 
    $footer .= 'border-bottom: ' . $ft_border_bottom['width'] . 'px ' . $ft_border_bottom['style'] . ' ' . $ft_border_bottom['color'] . ";\n";
  if((int)$ft_border_lr['width'] > 0) {
    $footer .= 'border-left: ' . $ft_border_lr['width'] . 'px ' . $ft_border_lr['style'] . ' ' . $ft_border_lr['color'] . ";\n";
    $footer .= 'border-right: ' . $ft_border_lr['width'] . 'px ' . $ft_border_lr['style'] . ' ' . $ft_border_lr['color'] . ";\n";
  }
  if($footer_font)
    $css .= '.site-footer p, .site-footer a{'. generate_font( $footer_font, 1.625 ) .'}' . "\n";
    
  if($footer !='')
    $css .= '.site-footer{'.$footer.'}' . "\n";
    
  if(isset($css) && $css !='') {
    $output = "\n<style type=\"text/css\">\n" . $css . "</style>\n\n";
    echo $output;
  }
}

/*-----------------------------------------------------------------------------------*/
/* Reposition the Secondary Navigation */
/*-----------------------------------------------------------------------------------*/
if( get_option('pwd_sec_nav_bg_pos') == 'Top' ){
  remove_action('genesis_after_header', 'genesis_do_subnav');
  add_action('genesis_before_header', 'genesis_do_subnav');
}else{
  add_action('genesis_after_header', 'genesis_do_subnav');
}

// Returns proper font css output
if ( ! function_exists( 'generate_font' ) ) {
	function generate_font( $option, $em = '1' ) {

		// Test if font-face is a Google font
		global $google_fonts;
		foreach ( $google_fonts as $google_font ) {

			// Add single quotation marks to font name and default arial sans-serif ending
			if ( $option['face'] == $google_font['name'] )
				$option['face'] = "'" . $option['face'] . "', arial, sans-serif";

		} // END foreach

		if ( !@$option['style'] && !@$option['size'] && !@$option['unit'] && !@$option['color'] )
			return 'font-family: '.stripslashes($option["face"]).';';
		else {
      if($option['unit'] == "px"){
         $rem = $option['size'] / 10;
         $font_px = 'font:'.$option['style'].' '.$option['size'].$option['unit'].'/'.$em.' '.stripslashes($option['face']).';color:'.$option['color'].';';
         $font_rem = 'font:'.$option['style'].' '.$rem.'rem/'.$em.' '.stripslashes($option['face']).';';         
         return $font_px . "\n" . $font_rem;
      }else{
			   return 'font:'.$option['style'].' '.$option['size'].$option['unit'].'/'.$em.' '.stripslashes($option['face']).';color:'.$option['color'].';';
      }
    }
	} // End generate_font()
}

if ( ! function_exists( 'google_webfonts' ) ) {
	function google_webfonts() {
		global $google_fonts;
		$fonts = '';
		$output = '';

		// Setup Woo Options array
		global $pwd_options;

		// Go through the options
		if ( !empty($pwd_options) ) {
      sort($pwd_options);
			foreach ( $pwd_options as $option ) {
				// Check if option has "face" in array
				if ( is_array($option) && isset($option['face']) ) {

					// Go through the google font array
					foreach ($google_fonts as $font) {

						// Check if the google font name exists in the current "face" option
						if ( $option['face'] == $font['name'] AND !strstr($fonts, $font['name']) ) {

							// Add google font to output
							$fonts .= $font['name'].$font['variant']."|";
						
						} // End If Statement
						
					} // End Foreach Loop
					
				} // End If Statement

			} // End Foreach Loop

			// Output google font css in header
			if ( $fonts ) {
				$fonts = str_replace( " ","+",$fonts);
				$output .= "\n<!-- Google Webfonts -->\n";
				$output .= '<link href="http'. ( is_ssl() ? 's' : '' ) .'://fonts.googleapis.com/css?family=' . $fonts .'" rel="stylesheet" type="text/css" />'."\n";
				$output = str_replace( '|"','"',$output);

				echo $output;
			}
		}
	} // End google_webfonts()
}
?>