<?php
// File Security Check
if ( ! defined( 'ABSPATH' ) ) exit;
if ( is_admin() ) {
	//add_action( 'init', 'pwdthemes_mlu_init' );
	add_action( 'admin_print_scripts', 'pwdthemes_mlu_insidepopup' );
	add_filter( 'gettext', 'pwdthemes_mlu_change_button_text', null, 2 );
	
	$is_posts_page = 0;

	// Sanitize value.
	$_current_url =  strtolower( strip_tags( trim( $_SERVER['REQUEST_URI'] ) ) );

	if ( ( substr( basename( $_current_url ), 0, 8 ) == 'post.php' ) || substr( basename( $_current_url ), 0, 12 ) == 'post-new.php' ) {
		$is_posts_page = 1;
	}

	$_page = '';

	if ( ( isset( $_REQUEST['page'] ) ) ) {
		// Sanitize value.
		$_page = strtolower( strip_tags( trim( $_REQUEST['page'] ) ) );
	}

		if ( ( $_page != '' && substr( $_page, 0, 4 ) == 'site' ) || $is_posts_page ) {
			add_action( 'admin_print_styles', 'pwdthemes_mlu_css', 0 );
			add_action( 'admin_print_scripts', 'pwdthemes_mlu_js', 0 );
		}
}

if ( ! function_exists( 'pwdthemes_mlu_css' ) ) {
	function pwdthemes_mlu_css () {
		$_html = '';
		$_html .= '<link rel="stylesheet" href="' . includes_url() . 'js/thickbox/thickbox.css" type="text/css" media="screen" />' . "\n";
		$_html .= '<script type="text/javascript">
          		  var tb_pathToImage = "' . includes_url() . 'js/thickbox/loadingAnimation.gif";
          	    var tb_closeImage = "' . includes_url() . 'js/thickbox/tb-close.png";
          	    </script>' . "\n";
	    
	    echo $_html;
	} // End pwdthemes_mlu_css()
}

if ( ! function_exists( 'pwdthemes_mlu_js' ) ) {
	function pwdthemes_mlu_js () {
		// Register custom scripts for the Media Library AJAX uploader.
		wp_register_script( 'pwd-medialibrary-uploader', CHILD_URL . '/admin/js/medialibrary-uploader.js', array( 'jquery', 'thickbox' ) );
		wp_enqueue_script( 'pwd-medialibrary-uploader' );
		wp_enqueue_script( 'media-upload' );
	} // End pwdthemes_mlu_js()
}

if ( ! function_exists( 'pwdthemes_medialibrary_uploader' ) ) {
	function pwdthemes_medialibrary_uploader ( $_id, $_value, $_mode = 'full', $_desc = '', $_postid = 0 ) {
    global $themename;
		$output = '';

		$id = '';
		$class = '';
		$int = '';
		$value = '';

		$id = strip_tags( strtolower( $_id ) );

		// If a post id is present, use it. Otherwise, search for one based on the $_id.
		if ( $_postid != 0 ) {
			$int = $_postid;
		}

		// If we're on a post add/edit screen, call the post meta value.
		if ( $_mode == 'postmeta' ) {
			$value = get_post_meta( $_postid, $id, true );
		} else {
			$value = get_option( $id );
		}

		// If a value is passed and we don't have a stored value, use the value that's passed through.
		if ( $_value != '' && $value == '' ) {
			$value = $_value;
		}

		if ( $value ) { $class = ' has-file'; } // End IF Statement

		// Hide the input field for "minimal" upload fields.
		$field_type = 'text';
		if ( $_mode == 'min' ) { $field_type = 'hidden'; }

		$output .= '<input type="' . $field_type . '" name="' . $id . '" id="' . $id . '" value="' . esc_attr( $value ) . '" class="upload' . $class . '" />' . "\n";
		$output .= '<input id="upload_' . $id . '" class="upload_button button" type="button" value="' . __( 'Upload', $themename ) . '" rel="' . $int . '" />' . "\n";

		if ( $_desc != '' ) {
			$output .= '<span class="pwd_metabox_desc">' . $_desc . '</span>' . "\n";
		}
		
		$output .= '<div class="screenshot" id="' . $id . '_image">' . "\n";

		if ( $value != '' ) {
			$remove = '<a href="javascript:(void);" class="mlu_remove button">Remove</a>';

			$image = preg_match( '/(^.*\.jpg|jpeg|png|gif|ico*)/i', $value );

			if ( $image ) {
				$output .= '<img src="' . esc_url( $value ) . '" alt="" />'.$remove.'';
			} else {
				$parts = explode( "/", $value );

				for( $i = 0; $i < sizeof( $parts ); ++$i ) {
					$title = $parts[$i];
				} // End FOR Loop

				// No output preview if it's not an image.
				$output .= '';

				// Standard generic output if it's not an image.
				$title = __( 'View File', $themename );

				$output .= '<div class="no_image"><span class="file_link"><a href="' . esc_url( $value ) . '" target="_blank" rel="external">'.$title.'</a></span>' . $remove . '</div>';

			} // End IF Statement
		} // End IF Statement

		$output .= '</div>' . "\n";

		return $output;
	}
}

if ( ! function_exists( 'pwdthemes_mlu_insidepopup' ) ) {
	function pwdthemes_mlu_insidepopup () {
		if ( isset( $_REQUEST['is_pwdthemes'] ) && $_REQUEST['is_pwdthemes'] == 'yes' ) {
			add_action( 'admin_head', 'pwdthemes_mlu_js_popup' );
			add_filter( 'media_upload_tabs', 'pwdthemes_mlu_modify_tabs' );
		}
	} // End pwdthemes_mlu_insidepopup()
}

if ( ! function_exists( 'pwdthemes_mlu_js_popup' ) ) {
	function pwdthemes_mlu_js_popup () {
		$_pwd_title = 'file';

		if ( isset( $_REQUEST['pwd_title'] ) ) { $_pwd_title = $_REQUEST['pwd_title']; } // End IF Statement
?>
	<script type="text/javascript">
	<!--
	jQuery(function($) {
		jQuery.noConflict();

		// Change the title of each tab to use the custom title text instead of "Media File".
		$( 'h3.media-title' ).each ( function () {
			var current_title = $( this ).html();

			var new_title = current_title.replace( 'media file', '<?php echo $_pwd_title; ?>' );

			$( this ).html( new_title )
		} );

		// Hide the "Insert Gallery" settings box on the "Gallery" tab.
		$( 'div#gallery-settings' ).hide();

		// Preserve the "is_pwdthemes" parameter on the "delete" confirmation button.
		$( '.savesend a.del-link' ).click ( function () {
			var continueButton = $( this ).next( '.del-attachment' ).children( 'a.button[id*="del"]' );

			var continueHref = continueButton.attr( 'href' );

			continueHref = continueHref + '&is_pwdthemes=yes';

			continueButton.attr( 'href', continueHref );
		} );
	});
	-->
	</script>
<?php

	} // End pwdthemes_mlu_js_popup()
}

if ( ! function_exists( 'pwdthemes_mlu_modify_tabs' ) ) {
	function pwdthemes_mlu_modify_tabs ( $tabs ) {
    global $themename;
		if ( isset( $tabs['gallery'] ) ) { $tabs['gallery'] = str_replace( __( 'Gallery', $themename ), __( 'Previously Uploaded', $themename ), $tabs['gallery'] ); }
		return $tabs;
	} // End pwdthemes_mlu_modify_tabs()
} // End IF Statement

if ( ! function_exists( 'pwdthemes_mlu_change_button_text' ) ) {
	function pwdthemes_mlu_change_button_text( $translation, $original ) {
		  global $themename;
	    if ( isset( $_REQUEST['type'] ) ) { return $translation; }
	    
	    if( $original == 'Insert into Post' ) {
	    	$translation = __( 'Use this Image', $themename );
			if ( isset( $_REQUEST['title'] ) && $_REQUEST['title'] != '' ) { $translation = sprintf( __( 'Use as %s', $themename ), esc_attr( $_REQUEST['title'] ) ); }
	    }
	
	    return $translation;
	}
}
?>