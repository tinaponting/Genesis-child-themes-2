<?php
if( !function_exists('pwdthemes_options') ){
  function pwdthemes_options(){
    // THEME VARIABLES
    $themename = "Think Theme";
    $themeslug = "think";
    $shortname = "pwd";
    $options_pixels = array("0px","1px","2px","3px","4px","5px","6px","7px","8px","9px","10px","11px","12px","13px","14px","15px","16px","17px","18px","19px","20px");
    $other_entries = array("Select a number:","0","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19");
    $other_entries_2 = array("Select a number:","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19");
    $imgSizes = list_thumbnail_sizes();

    // Below are the various theme options.
    /* General Settings */
    $options = array(); 
    $options[] = array( "name" => __( 'General Settings', 'genesis' ),
					              "icon" => "general",
                        "type" => "heading");
                        
    $options[] = array( "name" => __( 'Site Logo', 'genesis' ),
              					"desc" => __( 'Upload a logo for your site, or specify an image URL directly.', 'genesis' ),
              					"id" => $shortname."_logo",
              					"std" => "",
              					"type" => "upload"); 
                        
    $options[] = array( "name" => __( 'Site Favicon', 'genesis' ),
              					"desc" => __( 'Upload a 16px x 16px Png/Gif image that will represent your website\'s favicon.', 'genesis' ),
              					"id" => $shortname."_custom_favicon",
              					"std" => "",
              					"type" => "upload"); 
                                               
    $options[] = array( "name" => __( 'Google Analytics Code', 'genesis' ),
              					"desc" => __( 'Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme.', 'genesis' ),
              					"id" => $shortname."_google_analytics",
              					"std" => "",
              					"type" => "textarea");        
    $options[] = array( "name" =>  __( 'Background Color', 'genesis' ),
              					"desc" => __( 'Pick a custom color for site background or add a hex color code e.g. #e6e6e6', 'genesis' ),
              					"id" => $shortname."_style_bg",
              					"std" => "",
              					"type" => "color");
    
    $options[] = array( "name" => __( 'Background Image', 'genesis' ),
              					"desc" => __( 'Upload a background image, or specify the image address of your image.', 'genesis' ),
              					"id" => $shortname."_style_bg_image",
              					"std" => "",
              					"type" => "upload");
    
    $options[] = array( "name" => __( 'Background Image Repeat', 'genesis' ),
              					"desc" => __( 'Select how you want your background image to display.', 'genesis' ),
              					"id" => $shortname."_style_bg_image_repeat",
              					"type" => "select",
              					"options" => array( "No Repeat" => "no-repeat", "Repeat" => "repeat","Repeat Horizontally" => "repeat-x", "Repeat Vertically" => "repeat-y" ) );
    
    $options[] = array( 'name' => __( 'Background image position', 'genesis' ),
              					'desc' => __( 'Select how you would like to position the background', 'genesis' ),
              					'id' => $shortname . '_style_bg_image_pos',
              					'std' => 'top left',
              					'type' => 'select',
              					'options' => array( "top left", "top center", "top right", "center left", "center center", "center right", "bottom left", "bottom center", "bottom right" ) );
    
    $options[] = array( "name" => __( 'Background Attachment', 'genesis' ),
                    		"desc" => __( 'Select whether the background should be fixed or move when the user scrolls', 'genesis' ),
                    		"id" => $shortname."_style_bg_image_attach",
                    		"std" => "scroll",
                    		"type" => "select",
                    		"options" => array( "scroll","fixed" ) );
    
    $options[] = array( "name" => __( 'Use Background Pattern?', 'genesis' ),
              					"desc" => __( 'If yes, select the pattern from below.', 'genesis' ),
              					"id" => $shortname."_body_pattern_show",
              					"std" => "false",
              					"type" => "checkbox");
    $patterns_url =  CHILD_THEME_ADMIN_URL . '/images/patterns/';
                        
    $options[] = array( "name" => __('Select a Background Pattern','genesis'),
                  			"id" => $shortname."_select_body_pattern",
                  			"std" => "",
                  			"type" => "images",
                  			"options" => array(
                  				'classy_fabric' => $patterns_url . 'classy-fabric.png',
                  				'low_contrast_linen' => $patterns_url . 'low-contrast-linen.png',
                  				'dark_wall' => $patterns_url . 'dark-wall.png',
                  				'darkdenim3' => $patterns_url . 'darkdenim3.png',		
                  				'pinstriped_suit' => $patterns_url . 'pinstriped_suit.png',
                  				'connect' => $patterns_url . 'connect.png',
                  				'escheresque' => $patterns_url . 'escheresque.png',
                  				'gplaypattern' => $patterns_url . 'gplaypattern.png',
                  				'grey-subtle-noise' => $patterns_url . 'grey-subtle-noise.png',
                  				'grey' => $patterns_url . 'grey.png',
                  				'grid_noise' => $patterns_url . 'grid_noise.png',
                  				'grid' => $patterns_url . 'grid.png',
                  				'hexellence' => $patterns_url . 'hexellence.png',
                  				'lghtmesh' => $patterns_url . 'lghtmesh.png',
                  				'noise_lines' => $patterns_url . 'noise_lines.png',
                  				'noisy_grid' => $patterns_url . 'noisy_grid.png',
                          'pw_pattern' => $patterns_url . 'pw_pattern.png',
                  				'rough_diagonal' => $patterns_url . 'rough_diagonal.png',
                  				'shattered' => $patterns_url . 'shattered.png',
                  				'subtle_dots' => $patterns_url . 'subtle_dots.png',
                  				'tiny_grid' => $patterns_url . 'tiny_grid.png'
                  				));
    
    $options[] = array( "name" => __( 'Top Border', 'genesis' ),
              					"desc" => __( 'Specify border properties for the top border.', 'genesis' ),
              					"id" => $shortname."_border_top",
              					"std" => array('width' => '0','style' => 'solid','color' => '#000000'),
              					"type" => "border");
                        
    $options[] = array( "name" => __( 'Link Color', 'genesis' ),
              					"desc" => __( 'Choose a custom color for links or add a hex color code e.g. #697e09', 'genesis' ),
              					"id" => $shortname."_link_color",
              					"std" => "",
              					"type" => "color");
    
    $options[] = array( "name" => __( 'Link Hover Color', 'genesis' ),
              					"desc" => __( 'Choose a custom color for links hover or add a hex color code e.g. #697e09', 'genesis' ),
              					"id" => $shortname."_link_hover_color",
              					"std" => "",
              					"type" => "color");
    
    /* Header Settings */
    $options[] = array( 'name' => __( 'Header', 'genesis' ),
                        "icon" => "header",
    					          'type' => 'heading' );
    
    $options[] = array( "name" => __( 'Header Background Color', 'genesis' ),
              					"desc" => __( 'Pick a custom color for header background or add a hex color code e.g. #666666', 'genesis' ),
              					"id" => $shortname."_header_bg",
              					"std" => "",
              					"type" => "color");
    
    $options[] = array( "name" => __( 'Header Background Image', 'genesis' ),
              					"desc" => __( 'Upload a background image, or specify the image address of your image. <br/>Image should be same width as your site width.', 'genesis' ),
              					"id" => $shortname."_header_bg_image",
              					"std" => "",
              					"type" => "upload");
    
    $options[] = array( "name" => __( 'Header Background Image Repeat', 'genesis' ),
              					"desc" => __( 'Select how you want your background image to display.', 'genesis' ),
              					"id" => $shortname."_header_bg_image_repeat",
              					"type" => "select",
              					"options" => array("No Repeat" => "no-repeat", "Repeat" => "repeat","Repeat Horizontally" => "repeat-x", "Repeat Vertically" => "repeat-y",) );
    
    $options[] = array( "name" => __( 'Header Margin Top/Bottom', 'genesis' ),
              					"desc" => __( 'Enter an integer value i.e. 10 for the desired header margin.', 'genesis' ),
              					"id" => $shortname."_header_margin_tb",
              					"std" => "",
              					"type" => array(
              									array(  'id' => $shortname. '_header_margin_top',
              											'type' => 'text',
              											'std' => '0',
              											'meta' => __( 'Top', 'genesis' ) ),
              									array(  'id' => $shortname. '_header_margin_bottom',
              											'type' => 'text',
              											'std' => '0',
              											'meta' => __( 'Bottom', 'genesis' ) )
              								  ));
    $options[] = array( "name" => __( 'Header Padding Top/Bottom', 'genesis' ),
              					"desc" => __( 'Enter an integer value i.e. 10 for the desired header padding.', 'genesis' ),
              					"id" => $shortname."_header_padding_tb",
              					"std" => "",
              					"type" => array(
              									array(  'id' => $shortname. '_header_padding_top',
              											'type' => 'text',
              											'std' => '40',
              											'meta' => __( 'Top', 'genesis' ) ),
              									array(  'id' => $shortname. '_header_padding_bottom',
              											'type' => 'text',
              											'std' => '40',
              											'meta' => __( 'Bottom', 'genesis' ) )
              								  ));
    
    $options[] = array( "name" => __( 'Header Padding Left/Right', 'genesis' ),
              					"desc" => __( 'Enter an integer value i.e. 10 for the desired header padding.', 'genesis' ),
              					"id" => $shortname."_header_padding_lr",
              					"std" => "",
              					"type" => array(
              									array(  'id' => $shortname. '_header_padding_left',
              											'type' => 'text',
              											'std' => '',
              											'meta' => __( 'Left', 'genesis' ) ),
              									array(  'id' => $shortname. '_header_padding_right',
              											'type' => 'text',
              											'std' => '',
              											'meta' => __( 'Right', 'genesis' ) )
              								  ));

    $options[] = array( "name" => __( 'Site Title Font Style', 'genesis' ),
    					"desc" => __( 'Select typography for site title.', 'genesis' ),
    					"id" => $shortname."_font_logo",
    					"std" => array('size' => '40','unit' => 'px', 'face' => 'Lato','style' => 'bold','color' => '#222222'),
    					"type" => "typography");
    
    $options[] = array( "name" => __( 'Site Description Font Style', 'genesis' ),
    					"desc" => __( 'Select typography for site description.', 'genesis' ),
    					"id" => $shortname."_font_desc",
    					"std" => array('size' => '13','unit' => 'px', 'face' => 'Roboto Slab','style' => 'thin','color' => '#999999'),
    					"type" => "typography");
                
    /* Primary Navigation Styling */
    $options[] = array( 'name' => __( 'Primary Navigation', 'genesis' ),
                        "icon" => "primary-nav",
    					          'type' => 'heading' );
                        
    $options[] = array( "name" => __( 'Background Color', 'genesis' ),
              					"desc" => __( 'Pick a custom color for the navigation background or add a hex color code e.g. #cccccc', 'genesis' ),
              					"id" => $shortname."_nav_bg",
              					"std" => "#DDDDDD",
              					"type" => "color");
    
    $options[] = array( "name" => __( 'Border Top', 'genesis' ),
              					"desc" => __( 'Specify border properties for the navigation.', 'genesis' ),
              					"id" => $shortname."_nav_border_top",
              					"std" => array('width' => '4','style' => 'solid','color' => '#AAAAAA'),
              					"type" => "border");

    $options[] = array( "name" => __( 'Border Bottom', 'genesis' ),
              					"desc" => __( 'Specify border properties for the navigation.', 'genesis' ),
              					"id" => $shortname."_nav_border_bot",
              					"std" => array('width' => '4','style' => 'solid','color' => '#AAAAAA'),
              					"type" => "border");
    
    $options[] = array( "name" => __( 'Navigation Font Style', 'genesis' ),
              					"desc" => __( 'Select typography for navigation.', 'genesis' ),
              					"id" => $shortname."_nav_font",
              					"std" => array('size' => '16','unit' => 'px', 'face' => 'Roboto Slab','style' => 'thin','color' => '#7A7A7A'),
              					"type" => "typography");                        
                        
    $options[] = array( "name" => __( 'Hover Text Color', 'genesis' ),
              					"desc" => __( 'Pick a custom color for the navigation hover text color or add a hex color code e.g. #eeeeee', 'genesis' ),
              					"id" => $shortname."_nav_hover",
              					"std" => "#FFFFFF",
              					"type" => "color");
    
    $options[] = array( "name" => __( 'Hover Background Color', 'genesis' ),
              					"desc" => __( 'Pick a custom color for the navigation hover background color or add a hex color code e.g. #eeeeee', 'genesis' ),
              					"id" => $shortname."_nav_hover_bg",
              					"std" => "#C4C4C4",
              					"type" => "color");
    
    $options[] = array( "name" => __( 'Current Item Text Color', 'genesis' ),
              					"desc" => __( 'Pick a custom color for the text color of the current menu item in the navigation, or add a hex color code e.g. #eeeeee', 'genesis' ),
              					"id" => $shortname."_nav_currentitem",
              					"std" => "#FFFFFF",
              					"type" => "color");
    
    $options[] = array( "name" => __( 'Current Item Background Color', 'genesis' ),
              					"desc" => __( 'Pick a custom color for the background of the current menu item in the navigation, or add a hex color code e.g. #eeeeee', 'genesis' ),
              					"id" => $shortname."_nav_currentitem_bg",
              					"std" => "#aaaaaa",
              					"type" => "color");

    $options[] = array( "name" => __( 'Sub Item Background Color', 'genesis' ),
              					"desc" => __( 'Pick a custom color for the item background or add a hex color code e.g. #cccccc', 'genesis' ),
              					"id" => $shortname."_sub_item_bg",
              					"std" => "",
              					"type" => "color");
    
    $options[] = array( "name" => __( 'Sub Item Font Style', 'genesis' ),
              					"desc" => __( 'Select typography for sub navigation.', 'genesis' ),
              					"id" => $shortname."_nav_sub_item_font",
              					"std" => array('size' => '14','unit' => 'px', 'face' => 'Roboto Slab','style' => 'thin','color' => '#666666'),
              					"type" => "typography");
                        
    $options[] = array( "name" => __( 'Sub Item Hover Text Color', 'genesis' ),
              					"desc" => __( 'Pick a custom color for the sub item hover text color or add a hex color code e.g. #eeeeee', 'genesis' ),
              					"id" => $shortname."_sub_item_hover",
              					"std" => "#d10123",
              					"type" => "color");
    
    $options[] = array( "name" => __( 'Sub Item Hover Background Color', 'genesis' ),
              					"desc" => __( 'Pick a custom color for the sub item hover background color or add a hex color code e.g. #eeeeee', 'genesis' ),
              					"id" => $shortname."_sub_item_hover_bg",
              					"std" => "#FFFFFF",
              					"type" => "color");
    
    $options[] = array( "name" => __( 'Current Sub Item Text Color', 'genesis' ),
              					"desc" => __( 'Pick a custom color for the text color of the current sub menu item in the navigation, or add a hex color code e.g. #eeeeee', 'genesis' ),
              					"id" => $shortname."_sub_currentitem",
              					"std" => "#f15123",
              					"type" => "color");
    
    $options[] = array( "name" => __( 'Current Sub Item Background Color', 'genesis' ),
              					"desc" => __( 'Pick a custom color for the background of the current sub menu item in the navigation, or add a hex color code e.g. #eeeeee', 'genesis' ),
              					"id" => $shortname."_sub_currentitem_bg",
              					"std" => "#000000",
              					"type" => "color");
                        
    $options[] = array( "name" => __( 'Border Top', 'genesis' ),
              					"desc" => __( 'Specify border properties for the sub item.', 'genesis' ),
              					"id" => $shortname."_nav_si_border_top",
              					"std" => array('width' => '0','style' => 'solid','color' => '#EEEEEE'),
              					"type" => "border");

    $options[] = array( "name" => __( 'Border Bottom', 'genesis' ),
              					"desc" => __( 'Specify border properties for the sub item.', 'genesis' ),
              					"id" => $shortname."_nav_si_border_bot",
              					"std" => array('width' => '1','style' => 'solid','color' => '#EEEEEE'),
              					"type" => "border");

    $options[] = array( "name" => __( 'Border Left/Right', 'genesis' ),
              					"desc" => __( 'Specify border properties for the sub item.', 'genesis' ),
              					"id" => $shortname."_nav_si_border_lr",
              					"std" => array('width' => '1','style' => 'solid','color' => '#EEEEEE'),
              					"type" => "border");
    
    $options[] = array( "name" => __( 'Navigation Rounded Corners', 'genesis' ),
              					"desc" => __( 'Set amount of pixels for border radius (rounded corners). Will only show in CSS3 compatible browser.', 'genesis' ),
              					"id" => $shortname."_nav_border_radius",
              					"type" => "select",
              					"std" => "0px",
              					"options" => $options_pixels); 
                                            
    /* Secondary Navigation Styling */
    $options[] = array( 'name' => __( 'Secondary Navigation', 'genesis' ),
                        "icon" => "secondary-nav",
    					          'type' => 'heading' );
                        
    $options[] = array( "name" => __( 'Navigation Position', 'genesis' ),
              					"desc" => __( 'Select the position for secondary nav.', 'genesis' ),
              					"id" => $shortname."_sec_nav_bg_pos",
              					"std" => "top",
              					"type" => "select",
                        "options" => array('none' => "None","top" => "Top", "below-nav" => "Below the primary nav"));
    
    $options[] = array( "name" => __( 'Background Color', 'genesis' ),
              					"desc" => __( 'Pick a custom color for the navigation background or add a hex color code e.g. #cccccc', 'genesis' ),
              					"id" => $shortname."_sec_nav_bg",
              					"std" => "#000000",
              					"type" => "color");
    
    $options[] = array( "name" => __( 'Navigation Font Style', 'genesis' ),
              					"desc" => __( 'Select typography for navigation.', 'genesis' ),
              					"id" => $shortname."_sec_nav_font",
              					"std" => array('size' => '16','unit' => 'px', 'face' => 'Roboto Slab','style' => 'normal','color' => '#F15123'),
              					"type" => "typography");
                        
    $options[] = array( "name" => __( 'Hover Text Color', 'genesis' ),
              					"desc" => __( 'Pick a custom color for the navigation hover text color or add a hex color code e.g. #eeeeee', 'genesis' ),
              					"id" => $shortname."_sec_nav_hover",
              					"std" => "#FFFFFF",
              					"type" => "color");
    
    $options[] = array( "name" => __( 'Hover Background Color', 'genesis' ),
              					"desc" => __( 'Pick a custom color for the navigation hover background color or add a hex color code e.g. #eeeeee', 'genesis' ),
              					"id" => $shortname."_sec_nav_hover_bg",
              					"std" => "#333333",
              					"type" => "color");
    
    $options[] = array( "name" => __( 'Current Item Text Color', 'genesis' ),
              					"desc" => __( 'Pick a custom color for the text color of the current menu item in the navigation, or add a hex color code e.g. #eeeeee', 'genesis' ),
              					"id" => $shortname."_sec_nav_currentitem",
              					"std" => "#FFFFFF",
              					"type" => "color");
    
    $options[] = array( "name" => __( 'Current Item Background Color', 'genesis' ),
              					"desc" => __( 'Pick a custom color for the background of the current menu item in the navigation, or add a hex color code e.g. #eeeeee', 'genesis' ),
              					"id" => $shortname."_sec_nav_nav_currentitem_bg",
              					"std" => "#d01c1c",
              					"type" => "color");

    $options[] = array( "name" => __( 'Sub Item Background Color', 'genesis' ),
              					"desc" => __( 'Pick a custom color for the item background or add a hex color code e.g. #cccccc', 'genesis' ),
              					"id" => $shortname."_sec_nav_sub_item_bg",
              					"std" => "",
              					"type" => "color");
    
    $options[] = array( "name" => __( 'Sub Item Font Style', 'genesis' ),
              					"desc" => __( 'Select typography for sub navigation.', 'genesis' ),
              					"id" => $shortname."_sec_nav_sub_item_font",
              					"std" => array('size' => '14','unit' => 'px', 'face' => 'Roboto Slab','style' => '','color' => '#212121'),
              					"type" => "typography");
                        
    $options[] = array( "name" => __( 'Sub Item Hover Text Color', 'genesis' ),
              					"desc" => __( 'Pick a custom color for the sub item hover text color or add a hex color code e.g. #eeeeee', 'genesis' ),
              					"id" => $shortname."_sec_nav_sub_item_hover",
              					"std" => "#d01c1c",
              					"type" => "color");
    
    $options[] = array( "name" => __( 'Sub Item Hover Background Color', 'genesis' ),
              					"desc" => __( 'Pick a custom color for the sub item hover background color or add a hex color code e.g. #eeeeee', 'genesis' ),
              					"id" => $shortname."_sec_nav_sub_item_hover_bg",
              					"std" => "#FFFFFF",
              					"type" => "color");
    
    $options[] = array( "name" => __( 'Current Sub Item Text Color', 'genesis' ),
              					"desc" => __( 'Pick a custom color for the text color of the current sub menu item in the navigation, or add a hex color code e.g. #eeeeee', 'genesis' ),
              					"id" => $shortname."_sec_nav_sub_currentitem",
              					"std" => "#FFFFFF",
              					"type" => "color");
    
    $options[] = array( "name" => __( 'Current Sub Item Background Color', 'genesis' ),
              					"desc" => __( 'Pick a custom color for the background of the current sub menu item in the navigation, or add a hex color code e.g. #eeeeee', 'genesis' ),
              					"id" => $shortname."_sec_nav_sub_currentitem_bg",
              					"std" => "#000000",
              					"type" => "color");
                        
    $options[] = array( "name" => __( 'Border Top', 'genesis' ),
              					"desc" => __( 'Specify border properties for the sub menu.', 'genesis' ),
              					"id" => $shortname."_sec_nav_border_top",
              					"std" => array('width' => '0','style' => 'solid','color' => '#EEEEEE'),
              					"type" => "border");

    $options[] = array( "name" => __( 'Border Bottom', 'genesis' ),
              					"desc" => __( 'Specify border properties for the sub menu.', 'genesis' ),
              					"id" => $shortname."_sec_nav_border_bot",
              					"std" => array('width' => '1','style' => 'solid','color' => '#EEEEEE'),
              					"type" => "border");

    $options[] = array( "name" => __( 'Border Left/Right', 'genesis' ),
              					"desc" => __( 'Specify border properties for the sub menu.', 'genesis' ),
              					"id" => $shortname."_sec_nav_border_lr",
              					"std" => array('width' => '1','style' => 'solid','color' => '#EEEEEE'),
              					"type" => "border");
    
    $options[] = array( "name" => __( 'Navigation Rounded Corners', 'genesis' ),
              					"desc" => __( 'Set amount of pixels for border radius (rounded corners). Will only show in CSS3 compatible browser.', 'genesis' ),
              					"id" => $shortname."_sec_nav_border_radius",
              					"type" => "select",
              					"std" => "0px",
              					"options" => $options_pixels);
                        
    /* Sidebar Widget Styling */
    $options[] = array( 'name' => __( 'Sidebar Widgets', 'genesis' ),
                        "icon" => "sidebar-widgets",
    					          'type' => 'heading' );
    
    $options[] = array( "name" => __( 'Sidebar Background Color', 'genesis' ),
              					"desc" => __( 'Pick a custom color for the sidebar background or add a hex color code e.g. #FFFFFF', 'genesis' ),
              					"id" => $shortname."_sidebar_bg",
              					"std" => "",
              					"type" => "color");
                        
    $options[] = array( "name" => __( 'Widget Background Color', 'genesis' ),
              					"desc" => __( 'Pick a custom color for the widget background or add a hex color code e.g. #FFFFFF', 'genesis' ),
              					"id" => $shortname."_widget_bg",
              					"std" => "#ffffff",
              					"type" => "color");

    $options[] = array( "name" => __( 'Widget Border', 'genesis' ),
              					"desc" => __( 'Specify border properties for widgets.', 'genesis' ),
              					"id" => $shortname."_widget_border",
              					"std" => array('width' => '0','style' => 'solid','color' => '#dbdbdb'),
              					"type" => "border");
    
    $options[] = array( "name" => __( 'Widget Padding', 'genesis' ),
              					"desc" => __( 'Enter an integer value i.e. 20 for the desired widget padding.', 'genesis' ),
              					"id" => $shortname."_widget_padding",
              					"std" => "",
              					"type" => array(
              									array(  'id' => $shortname. '_widget_padding_tb',
              											'type' => 'text',
              											'std' => '',
              											'meta' => __( 'Top/Bottom', 'genesis' ) ),
              									array(  'id' => $shortname. '_widget_padding_lr',
              											'type' => 'text',
              											'std' => '',
              											'meta' => __( 'Left/Right', 'genesis' ) )
              								  ));
    
    $options[] = array( "name" => __( 'Widget Title Typography', 'genesis' ),
              					"desc" => __( 'Select the typography you want for the widget title.', 'genesis' ),
              					"id" => $shortname."_widget_font_title",
              					"std" => array('size' => '22','unit' => 'px', 'face' => 'Abel','style' => 'bold','color' => '#d01c1c'),
              					"type" => "typography");
    
    $options[] = array( "name" => __( 'Widget Title Background', 'genesis' ),
              					"desc" => __( 'Select background or add a hex color code for the widget title background.', 'genesis' ),
              					"id" => $shortname."_widget_title_bg",
              					"std" => '',
              					"type" => "color");
    
    $options[] = array( "name" => __( 'Widget Title Bottom Border', 'genesis' ),
              					"desc" => __( 'Specify border property for the widget title.', 'genesis' ),
              					"id" => $shortname."_widget_title_border",
              					"std" => array('width' => '0','style' => 'solid','color' => ''),
              					"type" => "border");
    
    $options[] = array( "name" => __( 'Widget Text', 'genesis' ),
              					"desc" => __( 'Select the typography you want for the widget text.', 'genesis' ),
              					"id" => $shortname."_widget_font_text",
              					"std" => array('size' => '16','unit' => 'px', 'face' => 'Roboto Slab','style' => 'thin','color' => '#696769'),
              					"type" => "typography");
    
    $options[] = array( "name" => __( 'Widget Rounded Corners', 'genesis' ),
              					"desc" => __( 'Set amount of pixels for border radius (rounded corners). Will only show in CSS3 compatible browser.', 'genesis' ),
              					"id" => $shortname."_widget_border_radius",
              					"type" => "select",
                        "std" => '3px',
              					"options" => $options_pixels);

    $options[] = array( 'name' => __( 'Footer Widgets', 'genesis' ),
                        "icon" => "footer-widgets",
					              'type' => 'heading' );
                        
    $options[] = array( "name" => __( 'Background Color', 'genesis' ),
              					"desc" => __( 'Select the background color for your footer widgets wrapper.', 'genesis' ),
              					"id" => $shortname."_fw_wrapper_bg",
              					"std" => "#2e2e2e",
              					"type" => "color");
                        
    $url =  CHILD_THEME_ADMIN_URL . '/images/';
    $options[] = array( "name" => __( 'Footer Widget Areas', 'genesis' ),
    					"desc" => __( 'Select how many footer widget areas you want to display.', 'genesis' ),
    					"id" => $shortname."_footer_sidebars",
    					"std" => "3",
    					"type" => "images",
    					"options" => array(
    						'0' => $url . 'footer-widgets-0.png',
    						'1' => $url . 'footer-widgets-1.png',
    						'2' => $url . 'footer-widgets-2.png',
    						'3' => $url . 'footer-widgets-3.png',
    						'4' => $url . 'footer-widgets-4.png')
    					);
              
    $options[] = array( "name" => __( 'Footer Widgets Wrapper Border Top', 'genesis' ),
              					"desc" => __( 'Specify top border properties for the Footer Widgets Wrapper.', 'genesis' ),
              					"id" => $shortname."_fw_border_top",
              					"std" => array('width' => '5','style' => 'solid','color' => '#B0B0B0'),
              					"type" => "border");
    
    $options[] = array( "name" => __( 'Footer Widgets Wrapper Border Bottom', 'genesis' ),
              					"desc" => __( 'Specify bottom border properties for the Footer Widgets Wrapper.', 'genesis' ),
              					"id" => $shortname."_fw_border_bottom",
              					"std" => array('width' => '1','style' => 'solid','color' => '#111111'),
              					"type" => "border");
    
    $options[] = array( "name" => __( 'Footer Widgets Wrapper Border Left/Right', 'genesis' ),
              					"desc" => __( 'Specify left/right border properties for the Footer Widgets Wrapper.', 'genesis' ),
              					"id" => $shortname."_fw_border_lr",
              					"std" => array('width' => '0','style' => 'solid','color' => ''),
              					"type" => "border");
    
    $options[] = array( "name" => __( 'Widget Background Color', 'genesis' ),
              					"desc" => __( 'Pick a custom color for the widget background or add a hex color code e.g. #FFFFFF', 'genesis' ),
              					"id" => $shortname."_fw_widget_bg",
              					"std" => "",
              					"type" => "color");

    $options[] = array( "name" => __( 'Widget Border', 'genesis' ),
              					"desc" => __( 'Specify border properties for widgets.', 'genesis' ),
              					"id" => $shortname."_fw_widget_border",
              					"std" => array('width' => '0','style' => 'solid','color' => '#dbdbdb'),
              					"type" => "border");
    
    $options[] = array( "name" => __( 'Widget Padding', 'genesis' ),
              					"desc" => __( 'Enter an integer value i.e. 20 for the desired widget padding.', 'genesis' ),
              					"id" => $shortname."_fw_widget_padding",
              					"std" => "",
              					"type" => array(
                      									array(  'id' => $shortname. '_fw_widget_padding_tb',
                      											'type' => 'text',
                      											'std' => '',
                      											'meta' => __( 'Top/Bottom', 'genesis' ) ),
                      									array(  'id' => $shortname. '_fw_widget_padding_lr',
                      											'type' => 'text',
                      											'std' => '',
                      											'meta' => __( 'Left/Right', 'genesis' ) )
                      								  ));
    
    $options[] = array( "name" => __( 'Widget Title Typography', 'genesis' ),
              					"desc" => __( 'Select the typography you want for the widget title.', 'genesis' ),
              					"id" => $shortname."_fw_widget_font_title",
              					"std" => array('size' => '22','unit' => 'px', 'face' => 'Abel','style' => 'normal','color' => '#ffffff'),
              					"type" => "typography");
    
    $options[] = array( "name" => __( 'Widget Title Background', 'genesis' ),
              					"desc" => __( 'Select background or add a hex color code for the widget title background.', 'genesis' ),
              					"id" => $shortname."_fw_widget_title_bg",
              					"std" => '',
              					"type" => "color");
    
    $options[] = array( "name" => __( 'Widget Title Bottom Border', 'genesis' ),
              					"desc" => __( 'Specify border property for the widget title.', 'genesis' ),
              					"id" => $shortname."_fw_widget_title_border",
              					"std" => array('width' => '1','style' => 'solid','color' => '#737373'),
              					"type" => "border");
    
    $options[] = array( "name" => __( 'Widget Text', 'genesis' ),
              					"desc" => __( 'Select the typography you want for the widget text.', 'genesis' ),
              					"id" => $shortname."_fw_widget_font_text",
              					"std" => array('size' => '16','unit' => 'px', 'face' => 'Roboto Slab','style' => 'thin','color' => '#949294'),
              					"type" => "typography");
    
    $options[] = array( "name" => __( 'Widget Rounded Corners', 'genesis' ),
              					"desc" => __( 'Set amount of pixels for border radius (rounded corners). Will only show in CSS3 compatible browser.', 'genesis' ),
              					"id" => $shortname."_fw_widget_border_radius",
              					"type" => "select",
              					"options" => $options_pixels);
                        
    $options[] = array( 'name' => __( 'Footer', 'genesis' ),
                        "icon" => "footer",
					              'type' => 'heading' );
                        
    $options[] = array( "name" => __( 'Footer Background', 'genesis' ),
              					"desc" => __( 'Select the background color for your footer.', 'genesis' ),
              					"id" => $shortname."_footer_bg",
              					"std" => "#222222",
              					"type" => "color");

    $options[] = array( "name" => __( 'Footer Border Top', 'genesis' ),
              					"desc" => __( 'Specify top border properties for the footer.', 'genesis' ),
              					"id" => $shortname."_footer_border_top",
              					"std" => array('width' => '1','style' => 'solid','color' => '#333333'),
              					"type" => "border");
    
    $options[] = array( "name" => __( 'Footer Border Bottom', 'genesis' ),
              					"desc" => __( 'Specify bottom border properties for the footer.', 'genesis' ),
              					"id" => $shortname."_footer_border_bottom",
              					"std" => array('width' => '0','style' => 'solid','color' => ''),
              					"type" => "border");
    
    $options[] = array( "name" => __( 'Footer Border Left/Right', 'genesis' ),
              					"desc" => __( 'Specify left/right border properties for the footer.', 'genesis' ),
              					"id" => $shortname."_footer_border_lr",
              					"std" => array('width' => '0','style' => 'solid','color' => ''),
              					"type" => "border");
                        
    $options[] = array( "name" => __( 'Footer Text (Left)', 'genesis' ),
              					"desc" => __( 'Custom HTML and Text that will appear in the footer of your theme.', 'genesis' ),
              					"id" => $shortname."_footer_left_text",
              					"std" => '<p>[footer_copyright before="Copyright "] &#x000B7; [footer_childtheme_link before="" after=" on"] [footer_genesis_link url="http://www.studiopress.com/" before=""]</p>',
              					"type" => "textarea");

    $options[] = array( "name" => __( 'Footer Text (Right)', 'genesis' ),
              					"desc" => __( 'Custom HTML and Text that will appear in the footer of your theme.', 'genesis' ),
              					"id" => $shortname."_footer_right_text",
              					"std" => "<p>Powered By [footer_wordpress_link]</p>",
              					"type" => "textarea");
                        
    $options[] = array( "name" => __( 'Footer Text Font Style', 'genesis' ),
              					"desc" => __( 'Select typography for footer.', 'genesis' ),
              					"id" => $shortname."_footer_font",
              					"std" => array('size' => '19','unit' => 'px', 'face' => 'Roboto Slab','style' => 'thin','color' => '#DDDDDD'),
              					"type" => "typography");

    /* Post Styling */
    $options[] = array( 'name' => __( 'Posts / Pages', 'genesis' ), 'type' => 'heading' );
    
    $options[] = array( "name" => __( 'Post/Page Title Font Style', 'genesis' ),
              					"desc" => __( 'Specify typography for post/page title text.', 'genesis' ),
              					"id" => $shortname."_font_post_title",
              					"std" => array('size' => '40','unit' => 'px', 'face' => 'Abel','style' => 'bold','color' => '#0f0e0f'),
              					"type" => "typography");
    
    $options[] = array( "name" => __( 'Post Meta Font Style', 'genesis' ),
              					"desc" => __( 'Specify typography for post meta.', 'genesis' ),
              					"id" => $shortname."_font_post_meta",
              					"std" => array('size' => '15','unit' => 'px', 'face' => 'Roboto Slab','style' => 'thin','color' => '#db721c'),
              					"type" => "typography");
    
    $options[] = array( "name" => __( 'Post/Page Text Font Style', 'genesis' ),
              					"desc" => __( 'Specify typography for post/page content text.', 'genesis' ),
              					"id" => $shortname."_font_post_text",
              					"std" => array('size' => '19','unit' => 'px', 'face' => 'Roboto Slab','style' => '300','color' => '#555555'),
              					"type" => "typography");
                        
    $options[] = array( "name" => __( 'Post More (bottom) Font Style', 'genesis' ),
              					"desc" => __( 'Specify typography for post bottom text.', 'genesis' ),
              					"id" => $shortname."_font_post_more",
              					"std" => array('size' => '21','unit' => 'px', 'face' => 'Roboto Slab','style' => 'thin','color' => '#F15123'),
              					"type" => "typography");
                        
    $options[] = array( "name" => __( 'Page Navigation Font Style', 'genesis' ),
              					"desc" => __( 'Select typography for Page Navigation text.', 'genesis' ),
              					"id" => $shortname."_pagenav_font",
              					"std" => array('size' => '14','unit' => 'px', 'face' => 'Roboto Slab','style' => 'thin','color' => '#fcfcfc'),
              					"type" => "typography");

    $options[] = array( "name" => __( 'Page Navigation Font Hover Color', 'genesis' ),
              					"desc" => __( 'Select the color for Page Navigation Hover text color.', 'genesis' ),
              					"id" => $shortname."_pagenav_font_hover_color",
              					"std" => '',
              					"type" => "color");
                        
    $options[] = array( "name" => __( 'Page Navigation Background Color', 'genesis' ),
              					"desc" => __( 'Pick a custom color for the Page Navigation background or add a hex color code e.g. #fafafa', 'genesis' ),
              					"id" => $shortname."_pagenav_bg",
              					"std" => "",
              					"type" => "color");

    $options[] = array( "name" => __( 'Page Navigation Hover Background Color', 'genesis' ),
              					"desc" => __( 'Pick a custom color for the Page Navigation background or add a hex color code e.g. #fafafa', 'genesis' ),
              					"id" => $shortname."_pagenav_hover_bg",
              					"std" => "",
              					"type" => "color");
    
    $options[] = array( 'name' => __( 'Magazine/Grid view', 'genesis' ),
                        "icon" => "grid-tpl",
					              'type' => 'heading' );

    $options[] = array( "name" => __( 'Number Of Featured Posts', 'genesis' ),
            						"desc" => __( 'Select how many featured (full width) posts you would like to show before your two-column posts. Set total number of posts in Settings > Reading.', 'genesis' ),
            						"id" => $shortname."_grid_feat_posts",
            						"type" => "select",
            						"options" => $other_entries);

  	$options[] = array( "name" => __( 'Content Limit for "Featured" Posts', 'genesis' ),
              					"desc" => __( '', 'genesis' ),
              					"id" => $shortname."_grid_featured_post_content_limit",
              					"std" => '100',
              					"type" => "text",
              				 );
                       
    $options[] = array( "name" => __( 'Image Size', 'genesis' ),
            						"desc" => __( 'Select your featured image size.', 'genesis' ),
            						"id" => $shortname."_feat_image_size",
            						"std" => "featured",
            						"type" => "radio",
            						"options" => $imgSizes);
  
  	$options[] = array( "name" => __( 'Featured Post Image Alignment', 'genesis' ),
            						"desc" => __( 'Select how to align your featured post images.', 'genesis' ),
            						"id" => $shortname."_grid_f_align",
            						"std" => "aligncenter",
            						"type" => "radio",
            						"options" => array("alignleft" => "Left","alignright" => "Right","aligncenter" => "Center"));
                        
    $options[] = array( "name" => __( 'Content Limit for "Grid" Posts', 'genesis' ),
              					"desc" => __( '', 'genesis' ),
              					"id" => $shortname."_grid_post_content_limit",
              					"std" => '150',
              					"type" => "text",
              				 );
    
    $options[] = array( "name" => __( 'Image Size', 'genesis' ),
            						"desc" => __( 'Select your grid image size.', 'genesis' ),
            						"id" => $shortname."_grid_image_size",
            						"std" => "grid-featured",
            						"type" => "radio",
            						"options" => $imgSizes);

  	$options[] = array( "name" => __( 'Post Image Alignment', 'genesis' ),
            						"desc" => __( 'Select how to align your grid post images.', 'genesis' ),
            						"id" => $shortname."_grid_b_align",
            						"std" => "aligncenter",
            						"type" => "radio",
            						"options" => array("alignleft" => "Left","alignright" => "Right","aligncenter" => "Center"));

    /* Misc Typography */
    $options[] = array( 'name' => __( 'Misc Typography', 'genesis' ),
    					'type' => 'heading' );
    
    $options[] = array( "name" => __( 'General Text Font Style', 'genesis' ),
    					"desc" => __( 'Select typography for general text.', 'genesis' ),
    					"id" => $shortname."_font_text",
    					"std" => array('size' => '14','unit' => 'px', 'face' => 'Roboto Slab','style' => 'thin','color' => '#555555'),
    					"type" => "typography");
    
    $options[] = array( "name" => __( 'H1 Font Style', 'genesis' ),
    					"desc" => __( 'Select the typography you want for header H1.', 'genesis' ),
    					"id" => $shortname."_font_h1",
    					"std" => array('size' => '28','unit' => 'px', 'face' => 'Roboto Slab','style' => 'bold','color' => '#222222'),
    					"type" => "typography");
    
    $options[] = array( "name" => __( 'H2 Font Style', 'genesis' ),
    					"desc" => __( 'Select the typography you want for header H2.', 'genesis' ),
    					"id" => $shortname."_font_h2",
    					"std" => array('size' => '24','unit' => 'px', 'face' => 'Roboto Slab','style' => 'bold','color' => '#222222'),
    					"type" => "typography");
    
    $options[] = array( "name" => __( 'H3 Font Style', 'genesis' ),
    					"desc" => __( 'Select the typography you want for header H3.', 'genesis' ),
    					"id" => $shortname."_font_h3",
    					"std" => array('size' => '20','unit' => 'px', 'face' => 'Roboto Slab','style' => 'bold','color' => '#222222'),
    					"type" => "typography");
    
    $options[] = array( "name" => __( 'H4 Font Style', 'genesis' ),
    					"desc" => __( 'Select the typography you want for header H4.', 'genesis' ),
    					"id" => $shortname."_font_h4",
    					"std" => array('size' => '16','unit' => 'px', 'face' => 'Roboto Slab','style' => 'bold','color' => '#222222'),
    					"type" => "typography");
    
    $options[] = array( "name" => __( 'H5 Font Style', 'genesis' ),
    					"desc" => __( 'Select the typography you want for header H5.', 'genesis' ),
    					"id" => $shortname."_font_h5",
    					"std" => array('size' => '14','unit' => 'px', 'face' => 'Roboto Slab','style' => 'bold','color' => '#222222'),
    					"type" => "typography");
    
    $options[] = array( "name" => __( 'H6 Font Style', 'genesis' ),
    					"desc" => __( 'Select the typography you want for header H6.', 'genesis' ),
    					"id" => $shortname."_font_h6",
    					"std" => array('size' => '12','unit' => 'px', 'face' => 'Roboto Slab','style' => 'bold','color' => '#222222'),
    					"type" => "typography");
              
    /* Social Links */
    $options[] = array( 'name' => __( 'Social Network', 'genesis' ),'type' => 'heading' );
    
    $options[] = array( "name" => __( 'RSS', 'genesis' ),
              					"desc" => __( 'Place the link you want and feed icon will appear. To remove it, just leave it blank.', 'genesis' ),
              					"id" => $shortname."_rss",
              					"std" => "",
              					"type" => "text");
    
    $options[] = array( "name" => __( 'E-Mail', 'genesis' ),
              					"desc" => __( 'Place the link you want and mail icon will appear. To remove it, just leave it blank.', 'genesis' ),
              					"id" => $shortname."_mail",
              					"std" => "",
              					"type" => "text");
                        
    $options[] = array( "name" => __( 'Facebook', 'genesis' ),
              					"desc" => __( 'Place the link you want and FB icon will appear. To remove it, just leave it blank.', 'genesis' ),
              					"id" => $shortname."_facebook",
              					"std" => "",
              					"type" => "text");
    
    $options[] = array( "name" => __( 'Twitter', 'genesis' ),
              					"desc" => __( 'Place the link you want and twitter icon will appear. To remove it, just leave it blank.', 'genesis' ),
              					"id" => $shortname."_twitter",
              					"std" => "",
              					"type" => "text");
                        
    $options[] = array( "name" => __( 'Linkedin', 'genesis' ),
              					"desc" => __( 'Place the link you want and linkedin icon will appear. To remove it, just leave it blank.', 'genesis' ),
              					"id" => $shortname."_linkedin",
              					"std" => "",
              					"type" => "text");
                        
    $options[] = array( "name" => __( 'Google Plus', 'genesis' ),
              					"desc" => __( 'Place the link you want and gplus icon will appear. To remove it, just leave it blank.', 'genesis' ),
              					"id" => $shortname."_gplus",
              					"std" => "",
              					"type" => "text");
                        
    $options[] = array( "name" => __( 'Pinterest', 'genesis' ),
              					"desc" => __( 'Place the link you want and pinterest icon will appear. To remove it, just leave it blank.', 'genesis' ),
              					"id" => $shortname."_pinterest",
              					"std" => "",
              					"type" => "text");
                        
    $options[] = array( "name" => __( 'Youtube', 'genesis' ),
              					"desc" => __( 'Place the link you want and youtube icon will appear. To remove it, just leave it blank.', 'genesis' ),
              					"id" => $shortname."_youtube",
              					"std" => "",
              					"type" => "text");
                    
    if ( get_option('pwd_template') != $options) update_option('pwd_template',$options);
    if ( get_option('pwd_themename') != $themename) update_option('pwd_themename',$themename);   
    if ( get_option('pwd_shortname') != $shortname) update_option('pwd_shortname',$shortname);
  }
}
// Add options to admin_head
add_action( 'admin_head', 'pwdthemes_options' );
/*-----------------------------------------------------------------------------------*/
/* Google Webfonts Array */
/* Documentation:
/*
/* name: The name of the Google Font.
/* variant: The Google Font API variants available for the font.
/*-----------------------------------------------------------------------------------*/

// Available Google webfont names     
$google_fonts = array(array( 'name' => "ABeeZee", 'variant' => ':300,400'),
                      array( 'name' => "Abel", 'variant' => ':300,400'),
                      array( 'name' => "Abril Fatface", 'variant' => ':300,400'),
                      array( 'name' => "Aclonica", 'variant' => ':300,400'),
                      array( 'name' => "Acme", 'variant' => ':300,400'),
                      array( 'name' => "Actor", 'variant' => ':300,400'),
                      array( 'name' => "Adamina", 'variant' => ':300,400'),
                      array( 'name' => "Advent Pro", 'variant' => ':300,400'),
                      array( 'name' => "Aguafina Script", 'variant' => ':300,400'),
                      array( 'name' => "Akronim", 'variant' => ':300,400'),
                      array( 'name' => "Aladin", 'variant' => ':300,400'),
                      array( 'name' => "Aldrich", 'variant' => ':300,400'),
                      array( 'name' => "Alef", 'variant' => ':300,400'),
                      array( 'name' => "Alegreya", 'variant' => ':300,400'),
                      array( 'name' => "Alegreya SC", 'variant' => ':300,400'),
                      array( 'name' => "Alegreya Sans", 'variant' => ':300,400'),
                      array( 'name' => "Alegreya Sans SC", 'variant' => ':300,400'),
                      array( 'name' => "Alex Brush", 'variant' => ':300,400'),
                      array( 'name' => "Alfa Slab One", 'variant' => ':300,400'),
                      array( 'name' => "Alice", 'variant' => ':300,400'),
                      array( 'name' => "Alike", 'variant' => ':300,400'),
                      array( 'name' => "Alike Angular", 'variant' => ':300,400'),
                      array( 'name' => "Allan", 'variant' => ':300,400'),
                      array( 'name' => "Allerta", 'variant' => ':300,400'),
                      array( 'name' => "Allerta Stencil", 'variant' => ':300,400'),
                      array( 'name' => "Allura", 'variant' => ':300,400'),
                      array( 'name' => "Almendra", 'variant' => ':300,400'),
                      array( 'name' => "Almendra Display", 'variant' => ':300,400'),
                      array( 'name' => "Almendra SC", 'variant' => ':300,400'),
                      array( 'name' => "Amarante", 'variant' => ':300,400'),
                      array( 'name' => "Amaranth", 'variant' => ':300,400'),
                      array( 'name' => "Amatic SC", 'variant' => ':300,400'),
                      array( 'name' => "Amethysta", 'variant' => ':300,400'),
                      array( 'name' => "Anaheim", 'variant' => ':300,400'),
                      array( 'name' => "Andada", 'variant' => ':300,400'),
                      array( 'name' => "Andika", 'variant' => ':300,400'),
                      array( 'name' => "Angkor", 'variant' => ':300,400'),
                      array( 'name' => "Annie Use Your Telescope", 'variant' => ':300,400'),
                      array( 'name' => "Anonymous Pro", 'variant' => ':300,400'),
                      array( 'name' => "Antic", 'variant' => ':300,400'),
                      array( 'name' => "Antic Didone", 'variant' => ':300,400'),
                      array( 'name' => "Antic Slab", 'variant' => ':300,400'),
                      array( 'name' => "Anton", 'variant' => ':300,400'),
                      array( 'name' => "Arapey", 'variant' => ':r,i'),
                      array( 'name' => "Arbutus", 'variant' => ':300,400'),
                      array( 'name' => "Arbutus Slab", 'variant' => ':300,400'),
                      array( 'name' => "Architects Daughter", 'variant' => ':300,400'),
                      array( 'name' => "Archivo Black", 'variant' => ':300,400'),
                      array( 'name' => "Archivo Narrow", 'variant' => ':300,400'),
                      array( 'name' => "Arimo", 'variant' => ':r,b,i,bi'),
                      array( 'name' => "Arizonia", 'variant' => ':300,400'),
                      array( 'name' => "Armata", 'variant' => ':300,400'),
                      array( 'name' => "Artifika", 'variant' => ':300,400'),
                      array( 'name' => "Arvo", 'variant' => ':r,b,i,bi'),
                      array( 'name' => "Asap", 'variant' => ':400,700,400italic,700italic'),
                      array( 'name' => "Asset", 'variant' => ':300,400'),
                      array( 'name' => "Astloch", 'variant' => ':300,400'),
                      array( 'name' => "Asul", 'variant' => ':300,400'),
                      array( 'name' => "Atomic Age", 'variant' => ':300,400'),
                      array( 'name' => "Aubrey", 'variant' => ':300,400'),
                      array( 'name' => "Audiowide", 'variant' => ':300,400'),
                      array( 'name' => "Autour One", 'variant' => ':300,400'),
                      array( 'name' => "Average", 'variant' => ':300,400'),
                      array( 'name' => "Average Sans", 'variant' => ':300,400'),
                      array( 'name' => "Averia Gruesa Libre", 'variant' => ':300,400'),
                      array( 'name' => "Averia Libre", 'variant' => ':300,400'),
                      array( 'name' => "Averia Sans Libre", 'variant' => ':300,400'),
                      array( 'name' => "Averia Serif Libre", 'variant' => ':300,400'),
                      array( 'name' => "Bad Script", 'variant' => ':300,400'),
                      array( 'name' => "Balthazar", 'variant' => ':300,400'),
                      array( 'name' => "Bangers", 'variant' => ':300,400'),
                      array( 'name' => "Basic", 'variant' => ':300,400'),
                      array( 'name' => "Battambang", 'variant' => ':300,400'),
                      array( 'name' => "Baumans", 'variant' => ':300,400'),
                      array( 'name' => "Bayon", 'variant' => ':300,400'),
                      array( 'name' => "Belgrano", 'variant' => ':300,400'),
                      array( 'name' => "Belleza", 'variant' => ':300,400'),
                      array( 'name' => "BenchNine", 'variant' => ':300,400'),
                      array( 'name' => "Bentham", 'variant' => ':300,400'),
                      array( 'name' => "Berkshire Swash", 'variant' => ':300,400'),
                      array( 'name' => "Bevan", 'variant' => ':300,400'),
                      array( 'name' => "Bigelow Rules", 'variant' => ':300,400'),
                      array( 'name' => "Bigshot One", 'variant' => ':300,400'),
                      array( 'name' => "Bilbo", 'variant' => ':300,400'),
                      array( 'name' => "Bilbo Swash Caps", 'variant' => ':300,400'),
                      array( 'name' => "Bitter", 'variant' => ':r,i,b'),
                      array( 'name' => "Black Ops One", 'variant' => ':300,400'),
                      array( 'name' => "Bokor", 'variant' => ':300,400'),
                      array( 'name' => "Bonbon", 'variant' => ':300,400'),
                      array( 'name' => "Boogaloo", 'variant' => ':300,400'),
                      array( 'name' => "Bowlby One", 'variant' => ':300,400'),
                      array( 'name' => "Bowlby One SC", 'variant' => ':300,400'),
                      array( 'name' => "Brawler", 'variant' => ':300,400'),
                      array( 'name' => "Bree Serif", 'variant' => ':300,400'),
                      array( 'name' => "Bubblegum Sans", 'variant' => ':300,400'),
                      array( 'name' => "Bubbler One", 'variant' => ':300,400'),
                      array( 'name' => "Buda", 'variant' => ':300,400'),
                      array( 'name' => "Buenard", 'variant' => ':300,400'),
                      array( 'name' => "Butcherman", 'variant' => ':300,400'),
                      array( 'name' => "Butterfly Kids", 'variant' => ':300,400'),
                      array( 'name' => "Cabin", 'variant' => ':300,400'),
                      array( 'name' => "Cabin Condensed", 'variant' => ':r,b'),
                      array( 'name' => "Cabin Sketch", 'variant' => ':r,b:300,400'),
                      array( 'name' => "Caesar Dressing", 'variant' => ':300,400'),
                      array( 'name' => "Cagliostro", 'variant' => ':300,400'),
                      array( 'name' => "Calligraffitti", 'variant' => ':300,400'),
                      array( 'name' => "Cambo", 'variant' => ':300,400'),
                      array( 'name' => "Candal", 'variant' => ':300,400'),
                      array( 'name' => "Cantarell", 'variant' => ':r,b,i,bi'),
                      array( 'name' => "Cantata One", 'variant' => ':300,400'),
                      array( 'name' => "Cantora One", 'variant' => ':300,400'),
                      array( 'name' => "Capriola", 'variant' => ':300,400'),
                      array( 'name' => "Cardo", 'variant' => ':300,400'),
                      array( 'name' => "Carme", 'variant' => ':300,400'),
                      array( 'name' => "Carrois Gothic", 'variant' => ':300,400'),
                      array( 'name' => "Carrois Gothic SC", 'variant' => ':300,400'),
                      array( 'name' => "Carter One", 'variant' => ':300,400'),
                      array( 'name' => "Caudex", 'variant' => ':r,b,i,bi'),
                      array( 'name' => "Cedarville Cursive", 'variant' => ':300,400'),
                      array( 'name' => "Ceviche One", 'variant' => ':300,400'),
                      array( 'name' => "Changa One", 'variant' => ':300,400'),
                      array( 'name' => "Chango", 'variant' => ':300,400'),
                      array( 'name' => "Chau Philomene One", 'variant' => ':300,400'),
                      array( 'name' => "Chela One", 'variant' => ':300,400'),
                      array( 'name' => "Chelsea Market", 'variant' => ':300,400'),
                      array( 'name' => "Chenla", 'variant' => ':300,400'),
                      array( 'name' => "Cherry Cream Soda", 'variant' => ':300,400'),
                      array( 'name' => "Cherry Swash", 'variant' => ':300,400'),
                      array( 'name' => "Chewy", 'variant' => ':300,400'),
                      array( 'name' => "Chicle", 'variant' => ':300,400'),
                      array( 'name' => "Chivo", 'variant' => ':300,400'),
                      array( 'name' => "Cinzel", 'variant' => ':300,400'),
                      array( 'name' => "Cinzel Decorative", 'variant' => ':300,400'),
                      array( 'name' => "Clicker Script", 'variant' => ':300,400'),
                      array( 'name' => "Coda", 'variant' => ':300,400'),
                      array( 'name' => "Coda Caption", 'variant' => ':300,400'),
                      array( 'name' => "Codystar", 'variant' => ':300,400'),
                      array( 'name' => "Combo", 'variant' => ':300,400'),
                      array( 'name' => "Comfortaa", 'variant' => ':r,b'),
                      array( 'name' => "Coming Soon", 'variant' => ':300,400'),
                      array( 'name' => "Concert One", 'variant' => ':300,400'),
                      array( 'name' => "Condiment", 'variant' => ':300,400'),
                      array( 'name' => "Content", 'variant' => ':300,400'),
                      array( 'name' => "Contrail One", 'variant' => ':300,400'),
                      array( 'name' => "Convergence", 'variant' => ':300,400'),
                      array( 'name' => "Cookie", 'variant' => ':300,400'),
                      array( 'name' => "Copse", 'variant' => ':300,400'),
                      array( 'name' => "Corben", 'variant' => ':300,400'),
                      array( 'name' => "Courgette", 'variant' => ':300,400'),
                      array( 'name' => "Cousine", 'variant' => ':300,400'),
                      array( 'name' => "Coustard", 'variant' => ':r,b'),
                      array( 'name' => "Covered By Your Grace", 'variant' => ':300,400'),
                      array( 'name' => "Crafty Girls", 'variant' => ':300,400'),
                      array( 'name' => "Creepster", 'variant' => ':300,400'),
                      array( 'name' => "Crete Round", 'variant' => ':300,400'),
                      array( 'name' => "Crimson Text", 'variant' => ':300,400'),
                      array( 'name' => "Croissant One", 'variant' => ':300,400'),
                      array( 'name' => "Crushed", 'variant' => ':300,400'),
                      array( 'name' => "Cuprum", 'variant' => ':300,400'),
                      array( 'name' => "Cutive", 'variant' => ':300,400'),
                      array( 'name' => "Cutive Mono", 'variant' => ':300,400'),
                      array( 'name' => "Damion", 'variant' => ':300,400'),
                      array( 'name' => "Dancing Script", 'variant' => ':300,400'),
                      array( 'name' => "Dangrek", 'variant' => ':300,400'),
                      array( 'name' => "Dawning of a New Day", 'variant' => ':300,400'),
                      array( 'name' => "Days One", 'variant' => ':300,400'),
                      array( 'name' => "Delius", 'variant' => ':300,400'),
                      array( 'name' => "Delius Swash Caps", 'variant' => ':300,400'),
                      array( 'name' => "Delius Unicase", 'variant' => ':300,400'),
                      array( 'name' => "Della Respira", 'variant' => ':300,400'),
                      array( 'name' => "Denk One", 'variant' => ':300,400'),
                      array( 'name' => "Devonshire", 'variant' => ':300,400'),
                      array( 'name' => "Didact Gothic", 'variant' => ':300,400'),
                      array( 'name' => "Diplomata", 'variant' => ':300,400'),
                      array( 'name' => "Diplomata SC", 'variant' => ':300,400'),
                      array( 'name' => "Domine", 'variant' => ':300,400'),
                      array( 'name' => "Donegal One", 'variant' => ':300,400'),
                      array( 'name' => "Doppio One", 'variant' => ':300,400'),
                      array( 'name' => "Dorsa", 'variant' => ':300,400'),
                      array( 'name' => "Dosis", 'variant' => ':300,400'),
                      array( 'name' => "Dr Sugiyama", 'variant' => ':300,400'),
                      array( 'name' => "Droid Sans", 'variant' => ':r,b'),
                      array( 'name' => "Droid Sans Mono", 'variant' => ':300,400'),
                      array( 'name' => "Droid Serif", 'variant' => ':r,b,i,bi'),
                      array( 'name' => "Duru Sans", 'variant' => ':300,400'),
                      array( 'name' => "Dynalight", 'variant' => ':300,400'),
                      array( 'name' => "EB Garamond", 'variant' => ':300,400'),
                      array( 'name' => "Eagle Lake", 'variant' => ':300,400'),
                      array( 'name' => "Eater", 'variant' => ':300,400'),
                      array( 'name' => "Economica", 'variant' => ':300,400'),
                      array( 'name' => "Electrolize", 'variant' => ':300,400'),
                      array( 'name' => "Elsie", 'variant' => ':300,400'),
                      array( 'name' => "Elsie Swash Caps", 'variant' => ':300,400'),
                      array( 'name' => "Emblema One", 'variant' => ':300,400'),
                      array( 'name' => "Emilys Candy", 'variant' => ':300,400'),
                      array( 'name' => "Engagement", 'variant' => ':300,400'),
                      array( 'name' => "Englebert", 'variant' => ':300,400'),
                      array( 'name' => "Enriqueta", 'variant' => ':300,400'),
                      array( 'name' => "Erica One", 'variant' => ':300,400'),
                      array( 'name' => "Esteban", 'variant' => ':300,400'),
                      array( 'name' => "Euphoria Script", 'variant' => ':300,400'),
                      array( 'name' => "Ewert", 'variant' => ':300,400'),
                      array( 'name' => "Exo", 'variant' => ':300,400'),
                      array( 'name' => "Exo 2", 'variant' => ':300,400'),
                      array( 'name' => "Expletus Sans", 'variant' => ':300,400'),
                      array( 'name' => "Fanwood Text", 'variant' => ':300,400'),
                      array( 'name' => "Fascinate", 'variant' => ':300,400'),
                      array( 'name' => "Fascinate Inline", 'variant' => ':300,400'),
                      array( 'name' => "Faster One", 'variant' => ':300,400'),
                      array( 'name' => "Fasthand", 'variant' => ':300,400'),
                      array( 'name' => "Fauna One", 'variant' => ':300,400'),
                      array( 'name' => "Federant", 'variant' => ':300,400'),
                      array( 'name' => "Federo", 'variant' => ':300,400'),
                      array( 'name' => "Felipa", 'variant' => ':300,400'),
                      array( 'name' => "Fenix", 'variant' => ':300,400'),
                      array( 'name' => "Finger Paint", 'variant' => ':300,400'),
                      array( 'name' => "Fjalla One", 'variant' => ':300,400'),
                      array( 'name' => "Fjord One", 'variant' => ':300,400'),
                      array( 'name' => "Flamenco", 'variant' => ':300,400'),
                      array( 'name' => "Flavors", 'variant' => ':300,400'),
                      array( 'name' => "Fondamento", 'variant' => ':300,400'),
                      array( 'name' => "Fontdiner Swanky", 'variant' => ':300,400'),
                      array( 'name' => "Forum", 'variant' => ':300,400'),
                      array( 'name' => "Francois One", 'variant' => ':300,400'),
                      array( 'name' => "Freckle Face", 'variant' => ':300,400'),
                      array( 'name' => "Fredericka the Great", 'variant' => ':300,400'),
                      array( 'name' => "Fredoka One", 'variant' => ':300,400'),
                      array( 'name' => "Freehand", 'variant' => ':300,400'),
                      array( 'name' => "Fresca", 'variant' => ':300,400'),
                      array( 'name' => "Frijole", 'variant' => ':300,400'),
                      array( 'name' => "Fruktur", 'variant' => ':300,400'),
                      array( 'name' => "Fugaz One", 'variant' => ':300,400'),
                      array( 'name' => "GFS Didot", 'variant' => ':300,400'),
                      array( 'name' => "GFS Neohellenic", 'variant' => ':300,400'),
                      array( 'name' => "Gabriela", 'variant' => ':300,400'),
                      array( 'name' => "Gafata", 'variant' => ':300,400'),
                      array( 'name' => "Galdeano", 'variant' => ':300,400'),
                      array( 'name' => "Galindo", 'variant' => ':300,400'),
                      array( 'name' => "Gentium Basic", 'variant' => ':300,400'),
                      array( 'name' => "Gentium Book Basic", 'variant' => ':300,400'),
                      array( 'name' => "Geo", 'variant' => ':300,400'),
                      array( 'name' => "Geostar", 'variant' => ':300,400'),
                      array( 'name' => "Geostar Fill", 'variant' => ':300,400'),
                      array( 'name' => "Germania One", 'variant' => ':300,400'),
                      array( 'name' => "Gilda Display", 'variant' => ':300,400'),
                      array( 'name' => "Give You Glory", 'variant' => ':300,400'),
                      array( 'name' => "Glass Antiqua", 'variant' => ':300,400'),
                      array( 'name' => "Glegoo", 'variant' => ':300,400'),
                      array( 'name' => "Gloria Hallelujah", 'variant' => ':300,400'),
                      array( 'name' => "Goblin One", 'variant' => ':300,400'),
                      array( 'name' => "Gochi Hand", 'variant' => ':300,400'),
                      array( 'name' => "Gorditas", 'variant' => ':300,400'),
                      array( 'name' => "Goudy Bookletter 1911", 'variant' => ':300,400'),
                      array( 'name' => "Graduate", 'variant' => ':300,400'),
                      array( 'name' => "Grand Hotel", 'variant' => ':300,400'),
                      array( 'name' => "Gravitas One", 'variant' => ':300,400'),
                      array( 'name' => "Great Vibes", 'variant' => ':300,400'),
                      array( 'name' => "Griffy", 'variant' => ':300,400'),
                      array( 'name' => "Gruppo", 'variant' => ':300,400'),
                      array( 'name' => "Gudea", 'variant' => ':300,400'),
                      array( 'name' => "Habibi", 'variant' => ':300,400'),
                      array( 'name' => "Hammersmith One", 'variant' => ':300,400'),
                      array( 'name' => "Hanalei", 'variant' => ':300,400'),
                      array( 'name' => "Hanalei Fill", 'variant' => ':300,400'),
                      array( 'name' => "Handlee", 'variant' => ':300,400'),
                      array( 'name' => "Hanuman", 'variant' => ':300,400'),
                      array( 'name' => "Happy Monkey", 'variant' => ':300,400'),
                      array( 'name' => "Headland One", 'variant' => ':300,400'),
                      array( 'name' => "Henny Penny", 'variant' => ':300,400'),
                      array( 'name' => "Herr Von Muellerhoff", 'variant' => ':300,400'),
                      array( 'name' => "Holtwood One SC", 'variant' => ':300,400'),
                      array( 'name' => "Homemade Apple", 'variant' => ':300,400'),
                      array( 'name' => "Homenaje", 'variant' => ':300,400'),
                      array( 'name' => "IM Fell DW Pica", 'variant' => ':300,400'),
                      array( 'name' => "IM Fell DW Pica SC", 'variant' => ':300,400'),
                      array( 'name' => "IM Fell Double Pica", 'variant' => ':300,400'),
                      array( 'name' => "IM Fell Double Pica SC", 'variant' => ':300,400'),
                      array( 'name' => "IM Fell English", 'variant' => ':r,i:300,400'),
                      array( 'name' => "IM Fell English SC", 'variant' => ':300,400'),
                      array( 'name' => "IM Fell French Canon", 'variant' => ':300,400'),
                      array( 'name' => "IM Fell French Canon SC", 'variant' => ':300,400'),
                      array( 'name' => "IM Fell Great Primer", 'variant' => ':300,400'),
                      array( 'name' => "IM Fell Great Primer SC", 'variant' => ':300,400'),
                      array( 'name' => "Iceberg", 'variant' => ':300,400'),
                      array( 'name' => "Iceland", 'variant' => ':300,400'),
                      array( 'name' => "Imprima", 'variant' => ':300,400'),
                      array( 'name' => "Inconsolata", 'variant' => ':300,400'),
                      array( 'name' => "Inder", 'variant' => ':300,400'),
                      array( 'name' => "Indie Flower", 'variant' => ':300,400'),
                      array( 'name' => "Inika", 'variant' => ':300,400'),
                      array( 'name' => "Irish Grover", 'variant' => ':300,400'),
                      array( 'name' => "Istok Web", 'variant' => ':r,b,i,bi'),
                      array( 'name' => "Italiana", 'variant' => ':300,400'),
                      array( 'name' => "Italianno", 'variant' => ':300,400'),
                      array( 'name' => "Jacques Francois", 'variant' => ':300,400'),
                      array( 'name' => "Jacques Francois Shadow", 'variant' => ':300,400'),
                      array( 'name' => "Jim Nightshade", 'variant' => ':300,400'),
                      array( 'name' => "Jockey One", 'variant' => ':300,400'),
                      array( 'name' => "Jolly Lodger", 'variant' => ':300,400'),
                      array( 'name' => "Josefin Sans", 'variant' => ':400,400italic,700,700italic'),
                      array( 'name' => "Josefin Slab", 'variant' => ':r,b,i,bi'),
                      array( 'name' => "Joti One", 'variant' => ':300,400'),
                      array( 'name' => "Judson", 'variant' => ':r,ri,b'),
                      array( 'name' => "Julee", 'variant' => ':300,400'),
                      array( 'name' => "Julius Sans One", 'variant' => ':300,400'),
                      array( 'name' => "Junge", 'variant' => ':300,400'),
                      array( 'name' => "Jura", 'variant' => ':300,400'),
                      array( 'name' => "Just Another Hand", 'variant' => ':300,400'),
                      array( 'name' => "Just Me Again Down Here", 'variant' => ':300,400'),
                      array( 'name' => "Kameron", 'variant' => ':300,400'),
                      array( 'name' => "Kantumruy", 'variant' => ':300,400'),
                      array( 'name' => "Karla", 'variant' => ':400,400italic,700,700italic'),
                      array( 'name' => "Kaushan Script", 'variant' => ':300,400'),
                      array( 'name' => "Kavoon", 'variant' => ':300,400'),
                      array( 'name' => "Kdam Thmor", 'variant' => ':300,400'),
                      array( 'name' => "Keania One", 'variant' => ':300,400'),
                      array( 'name' => "Kelly Slab", 'variant' => ':300,400'),
                      array( 'name' => "Kenia", 'variant' => ':300,400'),
                      array( 'name' => "Khmer", 'variant' => ':300,400'),
                      array( 'name' => "Kite One", 'variant' => ':300,400'),
                      array( 'name' => "Knewave", 'variant' => ':300,400'),
                      array( 'name' => "Kotta One", 'variant' => ':300,400'),
                      array( 'name' => "Koulen", 'variant' => ':300,400'),
                      array( 'name' => "Kranky", 'variant' => ':300,400'),
                      array( 'name' => "Kreon", 'variant' => ':300,400'),
                      array( 'name' => "Kristi", 'variant' => ':300,400'),
                      array( 'name' => "Krona One", 'variant' => ':300,400'),
                      array( 'name' => "La Belle Aurore", 'variant' => ':300,400'),
                      array( 'name' => "Lancelot", 'variant' => ':300,400'),
                      array( 'name' => "Lato", 'variant' => ':300,400'),
                      array( 'name' => "League Script", 'variant' => ':300,400'),
                      array( 'name' => "Leckerli One", 'variant' => ':300,400'),
                      array( 'name' => "Ledger", 'variant' => ':300,400'),
                      array( 'name' => "Lekton", 'variant' => ':300,400'),
                      array( 'name' => "Lemon", 'variant' => ':300,400'),
                      array( 'name' => "Libre Baskerville", 'variant' => ':300,400'),
                      array( 'name' => "Life Savers", 'variant' => ':300,400'),
                      array( 'name' => "Lilita One", 'variant' => ':300,400'),
                      array( 'name' => "Lily Script One", 'variant' => ':300,400'),
                      array( 'name' => "Limelight", 'variant' => ':300,400'),
                      array( 'name' => "Linden Hill", 'variant' => ':300,400'),
                      array( 'name' => "Lobster", 'variant' => ':300,400'),
                      array( 'name' => "Lobster Two", 'variant' => ':r,b,i,bi'),
                      array( 'name' => "Londrina Outline", 'variant' => ':300,400'),
                      array( 'name' => "Londrina Shadow", 'variant' => ':300,400'),
                      array( 'name' => "Londrina Sketch", 'variant' => ':300,400'),
                      array( 'name' => "Londrina Solid", 'variant' => ':300,400'),
                      array( 'name' => "Lora", 'variant' => ':300,400'),
                      array( 'name' => "Love Ya Like A Sister", 'variant' => ':300,400'),
                      array( 'name' => "Loved by the King", 'variant' => ':300,400'),
                      array( 'name' => "Lovers Quarrel", 'variant' => ':300,400'),
                      array( 'name' => "Luckiest Guy", 'variant' => ':300,400'),
                      array( 'name' => "Lusitana", 'variant' => ':300,400'),
                      array( 'name' => "Lustria", 'variant' => ':300,400'),
                      array( 'name' => "Macondo", 'variant' => ':300,400'),
                      array( 'name' => "Macondo Swash Caps", 'variant' => ':300,400'),
                      array( 'name' => "Magra", 'variant' => ':300,400'),
                      array( 'name' => "Maiden Orange", 'variant' => ':300,400'),
                      array( 'name' => "Mako", 'variant' => ':300,400'),
                      array( 'name' => "Marcellus", 'variant' => ':300,400'),
                      array( 'name' => "Marcellus SC", 'variant' => ':300,400'),
                      array( 'name' => "Marck Script", 'variant' => ':300,400'),
                      array( 'name' => "Margarine", 'variant' => ':300,400'),
                      array( 'name' => "Marko One", 'variant' => ':300,400'),
                      array( 'name' => "Marmelad", 'variant' => ':300,400'),
                      array( 'name' => "Marvel", 'variant' => ':r,b,i,bi'),
                      array( 'name' => "Mate", 'variant' => ':r,i:300,400'),
                      array( 'name' => "Mate SC", 'variant' => ':300,400'),
                      array( 'name' => "Maven Pro", 'variant' => ':400,500,700'),
                      array( 'name' => "McLaren", 'variant' => ':300,400'),
                      array( 'name' => "Meddon", 'variant' => ':300,400'),
                      array( 'name' => "MedievalSharp", 'variant' => ':300,400'),
                      array( 'name' => "Medula One", 'variant' => ':300,400'),
                      array( 'name' => "Megrim", 'variant' => ':300,400'),
                      array( 'name' => "Meie Script", 'variant' => ':300,400'),
                      array( 'name' => "Merienda", 'variant' => ':300,400'),
                      array( 'name' => "Merienda One", 'variant' => ':300,400'),
                      array( 'name' => "Merriweather", 'variant' => ':300,400'),
                      array( 'name' => "Merriweather Sans", 'variant' => ':300,400'),
                      array( 'name' => "Metal", 'variant' => ':300,400'),
                      array( 'name' => "Metal Mania", 'variant' => ':300,400'),
                      array( 'name' => "Metamorphous", 'variant' => ':300,400'),
                      array( 'name' => "Metrophobic", 'variant' => ':300,400'),
                      array( 'name' => "Michroma", 'variant' => ':300,400'),
                      array( 'name' => "Milonga", 'variant' => ':300,400'),
                      array( 'name' => "Miltonian", 'variant' => ':300,400'),
                      array( 'name' => "Miltonian Tattoo", 'variant' => ':300,400'),
                      array( 'name' => "Miniver", 'variant' => ':300,400'),
                      array( 'name' => "Miss Fajardose", 'variant' => ':300,400'),
                      array( 'name' => "Modern Antiqua", 'variant' => ':300,400'),
                      array( 'name' => "Molengo", 'variant' => ':300,400'),
                      array( 'name' => "Molle", 'variant' => ':300,400'),
                      array( 'name' => "Monda", 'variant' => ':300,400'),
                      array( 'name' => "Monofett", 'variant' => ':300,400'),
                      array( 'name' => "Monoton", 'variant' => ':300,400'),
                      array( 'name' => "Monsieur La Doulaise", 'variant' => ':300,400'),
                      array( 'name' => "Montaga", 'variant' => ':300,400'),
                      array( 'name' => "Montez", 'variant' => ':300,400'),
                      array( 'name' => "Montserrat", 'variant' => ':300,400'),
                      array( 'name' => "Montserrat Alternates", 'variant' => ':300,400'),
                      array( 'name' => "Montserrat Subrayada", 'variant' => ':300,400'),
                      array( 'name' => "Moul", 'variant' => ':300,400'),
                      array( 'name' => "Moulpali", 'variant' => ':300,400'),
                      array( 'name' => "Mountains of Christmas", 'variant' => ':300,400'),
                      array( 'name' => "Mouse Memoirs", 'variant' => ':300,400'),
                      array( 'name' => "Mr Bedfort", 'variant' => ':300,400'),
                      array( 'name' => "Mr Dafoe", 'variant' => ':300,400'),
                      array( 'name' => "Mr De Haviland", 'variant' => ':300,400'),
                      array( 'name' => "Mrs Saint Delafield", 'variant' => ':300,400'),
                      array( 'name' => "Mrs Sheppards", 'variant' => ':300,400'),
                      array( 'name' => "Muli", 'variant' => ':300,400'),
                      array( 'name' => "Mystery Quest", 'variant' => ':300,400'),
                      array( 'name' => "Neucha", 'variant' => ':300,400'),
                      array( 'name' => "Neuton", 'variant' => ':300,400'),
                      array( 'name' => "New Rocker", 'variant' => ':300,400'),
                      array( 'name' => "News Cycle", 'variant' => ':300,400'),
                      array( 'name' => "Niconne", 'variant' => ':300,400'),
                      array( 'name' => "Nixie One", 'variant' => ':300,400'),
                      array( 'name' => "Nobile", 'variant' => ':300,400'),
                      array( 'name' => "Nokora", 'variant' => ':300,400'),
                      array( 'name' => "Norican", 'variant' => ':300,400'),
                      array( 'name' => "Nosifer", 'variant' => ':300,400'),
                      array( 'name' => "Nothing You Could Do", 'variant' => ':300,400'),
                      array( 'name' => "Noticia Text", 'variant' => ':300,400'),
                      array( 'name' => "Noto Sans", 'variant' => ':300,400'),
                      array( 'name' => "Noto Serif", 'variant' => ':300,400'),
                      array( 'name' => "Nova Cut", 'variant' => ':300,400'),
                      array( 'name' => "Nova Flat", 'variant' => ':300,400'),
                      array( 'name' => "Nova Mono", 'variant' => ':300,400'),
                      array( 'name' => "Nova Oval", 'variant' => ':300,400'),
                      array( 'name' => "Nova Round", 'variant' => ':300,400'),
                      array( 'name' => "Nova Script", 'variant' => ':300,400'),
                      array( 'name' => "Nova Slim", 'variant' => ':300,400'),
                      array( 'name' => "Nova Square", 'variant' => ':300,400'),
                      array( 'name' => "Numans", 'variant' => ':300,400'),
                      array( 'name' => "Nunito", 'variant' => ':300,400'),
                      array( 'name' => "Odor Mean Chey", 'variant' => ':300,400'),
                      array( 'name' => "Offside", 'variant' => ':300,400'),
                      array( 'name' => "Old Standard TT", 'variant' => ':300,400'),
                      array( 'name' => "Oldenburg", 'variant' => ':300,400'),
                      array( 'name' => "Oleo Script", 'variant' => ':300,400'),
                      array( 'name' => "Oleo Script Swash Caps", 'variant' => ':300,400'),
                      array( 'name' => "Open Sans", 'variant' => ':r,i,b,bi'),
                      array( 'name' => "Open Sans Condensed", 'variant' => ':300italic,400italic,700italic,400,300,700'),
                      array( 'name' => "Oranienbaum", 'variant' => ':300,400'),
                      array( 'name' => "Orbitron", 'variant' => ':300,400'),
                      array( 'name' => "Oregano", 'variant' => ':300,400'),
                      array( 'name' => "Orienta", 'variant' => ':300,400'),
                      array( 'name' => "Original Surfer", 'variant' => ':300,400'),
                      array( 'name' => "Oswald", 'variant' => ':400,300,700'),
                      array( 'name' => "Over the Rainbow", 'variant' => ':300,400'),
                      array( 'name' => "Overlock", 'variant' => ':300,400'),
                      array( 'name' => "Overlock SC", 'variant' => ':300,400'),
                      array( 'name' => "Ovo", 'variant' => ':300,400'),
                      array( 'name' => "Oxygen", 'variant' => ':300,400'),
                      array( 'name' => "Oxygen Mono", 'variant' => ':300,400'),
                      array( 'name' => "PT Mono", 'variant' => ':300,400'),
                      array( 'name' => "PT Sans", 'variant' => ':r,b,i,bi'),
                      array( 'name' => "PT Sans Caption", 'variant' => ':r,b'),
                      array( 'name' => "PT Sans Narrow", 'variant' => ':r,b'),
                      array( 'name' => "PT Serif", 'variant' => ':300,400'),
                      array( 'name' => "PT Serif Caption", 'variant' => ':300,400'),
                      array( 'name' => "Pacifico", 'variant' => ':300,400'),
                      array( 'name' => "Paprika", 'variant' => ':300,400'),
                      array( 'name' => "Parisienne", 'variant' => ':300,400'),
                      array( 'name' => "Passero One", 'variant' => ':300,400'),
                      array( 'name' => "Passion One", 'variant' => ':300,400'),
                      array( 'name' => "Pathway Gothic One", 'variant' => ':300,400'),
                      array( 'name' => "Patrick Hand", 'variant' => ':300,400'),
                      array( 'name' => "Patrick Hand SC", 'variant' => ':300,400'),
                      array( 'name' => "Patua One", 'variant' => ':300,400'),
                      array( 'name' => "Paytone One", 'variant' => ':300,400'),
                      array( 'name' => "Peralta", 'variant' => ':300,400'),
                      array( 'name' => "Permanent Marker", 'variant' => ':300,400'),
                      array( 'name' => "Petit Formal Script", 'variant' => ':300,400'),
                      array( 'name' => "Petrona", 'variant' => ':300,400'),
                      array( 'name' => "Philosopher", 'variant' => ':300,400'),
                      array( 'name' => "Piedra", 'variant' => ':300,400'),
                      array( 'name' => "Pinyon Script", 'variant' => ':300,400'),
                      array( 'name' => "Pirata One", 'variant' => ':300,400'),
                      array( 'name' => "Plaster", 'variant' => ':300,400'),
                      array( 'name' => "Play", 'variant' => ':r,b'),
                      array( 'name' => "Playball", 'variant' => ':300,400'),
                      array( 'name' => "Playfair Display", 'variant' => ':300,400'),
                      array( 'name' => "Playfair Display SC", 'variant' => ':300,400'),
                      array( 'name' => "Podkova", 'variant' => ':300,400'),
                      array( 'name' => "Poiret One", 'variant' => ':300,400'),
                      array( 'name' => "Poller One", 'variant' => ':300,400'),
                      array( 'name' => "Poly", 'variant' => ':300,400'),
                      array( 'name' => "Pompiere", 'variant' => ':300,400'),
                      array( 'name' => "Pontano Sans", 'variant' => ':300,400'),
                      array( 'name' => "Port Lligat Sans", 'variant' => ':300,400'),
                      array( 'name' => "Port Lligat Slab", 'variant' => ':300,400'),
                      array( 'name' => "Prata", 'variant' => ':300,400'),
                      array( 'name' => "Preahvihear", 'variant' => ':300,400'),
                      array( 'name' => "Press Start 2P", 'variant' => ':300,400'),
                      array( 'name' => "Princess Sofia", 'variant' => ':300,400'),
                      array( 'name' => "Prociono", 'variant' => ':300,400'),
                      array( 'name' => "Prosto One", 'variant' => ':300,400'),
                      array( 'name' => "Puritan", 'variant' => ':300,400'),
                      array( 'name' => "Purple Purse", 'variant' => ':300,400'),
                      array( 'name' => "Quando", 'variant' => ':300,400'),
                      array( 'name' => "Quantico", 'variant' => ':300,400'),
                      array( 'name' => "Quattrocento", 'variant' => ':300,400'),
                      array( 'name' => "Quattrocento Sans", 'variant' => ':300,400'),
                      array( 'name' => "Questrial", 'variant' => ':300,400'),
                      array( 'name' => "Quicksand", 'variant' => ':300,400'),
                      array( 'name' => "Quintessential", 'variant' => ':300,400'),
                      array( 'name' => "Qwigley", 'variant' => ':300,400'),
                      array( 'name' => "Racing Sans One", 'variant' => ':300,400'),
                      array( 'name' => "Radley", 'variant' => ':300,400'),
                      array( 'name' => "Raleway", 'variant' => ':300,400'),
                      array( 'name' => "Raleway Dots", 'variant' => ':300,400'),
                      array( 'name' => "Rambla", 'variant' => ':300,400'),
                      array( 'name' => "Rammetto One", 'variant' => ':300,400'),
                      array( 'name' => "Ranchers", 'variant' => ':300,400'),
                      array( 'name' => "Rancho", 'variant' => ':300,400'),
                      array( 'name' => "Rationale", 'variant' => ':300,400'),
                      array( 'name' => "Redressed", 'variant' => ':300,400'),
                      array( 'name' => "Reenie Beanie", 'variant' => ':300,400'),
                      array( 'name' => "Revalia", 'variant' => ':300,400'),
                      array( 'name' => "Ribeye", 'variant' => ':300,400'),
                      array( 'name' => "Ribeye Marrow", 'variant' => ':300,400'),
                      array( 'name' => "Righteous", 'variant' => ':300,400'),
                      array( 'name' => "Risque", 'variant' => ':300,400'),
                      array( 'name' => "Roboto", 'variant' => ':400,300,700'),
                      array( 'name' => "Roboto Condensed", 'variant' => ':400,300,700'),
                      array( 'name' => "Roboto Slab", 'variant' => ':400,300,700'),
                      array( 'name' => "Rochester", 'variant' => ':300,400'),
                      array( 'name' => "Rock Salt", 'variant' => ':300,400'),
                      array( 'name' => "Rokkitt", 'variant' => ':400,700'),
                      array( 'name' => "Romanesco", 'variant' => ':300,400'),
                      array( 'name' => "Ropa Sans", 'variant' => ':300,400'),
                      array( 'name' => "Rosario", 'variant' => ':300,400'),
                      array( 'name' => "Rosarivo", 'variant' => ':300,400'),
                      array( 'name' => "Rouge Script", 'variant' => ':300,400'),
                      array( 'name' => "Ruda", 'variant' => ':300,400'),
                      array( 'name' => "Rufina", 'variant' => ':300,400'),
                      array( 'name' => "Ruge Boogie", 'variant' => ':300,400'),
                      array( 'name' => "Ruluko", 'variant' => ':300,400'),
                      array( 'name' => "Rum Raisin", 'variant' => ':300,400'),
                      array( 'name' => "Ruslan Display", 'variant' => ':300,400'),
                      array( 'name' => "Russo One", 'variant' => ':300,400'),
                      array( 'name' => "Ruthie", 'variant' => ':300,400'),
                      array( 'name' => "Rye", 'variant' => ':300,400'),
                      array( 'name' => "Sacramento", 'variant' => ':300,400'),
                      array( 'name' => "Sail", 'variant' => ':300,400'),
                      array( 'name' => "Salsa", 'variant' => ':300,400'),
                      array( 'name' => "Sanchez", 'variant' => ':300,400'),
                      array( 'name' => "Sancreek", 'variant' => ':300,400'),
                      array( 'name' => "Sansita One", 'variant' => ':300,400'),
                      array( 'name' => "Sarina", 'variant' => ':300,400'),
                      array( 'name' => "Satisfy", 'variant' => ':300,400'),
                      array( 'name' => "Scada", 'variant' => ':300,400'),
                      array( 'name' => "Schoolbell", 'variant' => ':300,400'),
                      array( 'name' => "Seaweed Script", 'variant' => ':300,400'),
                      array( 'name' => "Sevillana", 'variant' => ':300,400'),
                      array( 'name' => "Seymour One", 'variant' => ':300,400'),
                      array( 'name' => "Shadows Into Light", 'variant' => ':300,400'),
                      array( 'name' => "Shadows Into Light Two", 'variant' => ':300,400'),
                      array( 'name' => "Shanti", 'variant' => ':300,400'),
                      array( 'name' => "Share", 'variant' => ':300,400'),
                      array( 'name' => "Share Tech", 'variant' => ':300,400'),
                      array( 'name' => "Share Tech Mono", 'variant' => ':300,400'),
                      array( 'name' => "Shojumaru", 'variant' => ':300,400'),
                      array( 'name' => "Short Stack", 'variant' => ':300,400'),
                      array( 'name' => "Siemreap", 'variant' => ':300,400'),
                      array( 'name' => "Sigmar One", 'variant' => ':300,400'),
                      array( 'name' => "Signika", 'variant' => ':300,400'),
                      array( 'name' => "Signika Negative", 'variant' => ':300,400'),
                      array( 'name' => "Simonetta", 'variant' => ':300,400'),
                      array( 'name' => "Sintony", 'variant' => ':300,400'),
                      array( 'name' => "Sirin Stencil", 'variant' => ':300,400'),
                      array( 'name' => "Six Caps", 'variant' => ':300,400'),
                      array( 'name' => "Skranji", 'variant' => ':300,400'),
                      array( 'name' => "Slackey", 'variant' => ':300,400'),
                      array( 'name' => "Smokum", 'variant' => ':300,400'),
                      array( 'name' => "Smythe", 'variant' => ':300,400'),
                      array( 'name' => "Sniglet", 'variant' => ':300,400'),
                      array( 'name' => "Snippet", 'variant' => ':300,400'),
                      array( 'name' => "Snowburst One", 'variant' => ':300,400'),
                      array( 'name' => "Sofadi One", 'variant' => ':300,400'),
                      array( 'name' => "Sofia", 'variant' => ':300,400'),
                      array( 'name' => "Sonsie One", 'variant' => ':300,400'),
                      array( 'name' => "Sorts Mill Goudy", 'variant' => ':300,400'),
                      array( 'name' => "Source Code Pro", 'variant' => ':300,400'),
                      array( 'name' => "Source Sans Pro", 'variant' => ':300,400'),
                      array( 'name' => "Special Elite", 'variant' => ':300,400'),
                      array( 'name' => "Spicy Rice", 'variant' => ':300,400'),
                      array( 'name' => "Spinnaker", 'variant' => ':300,400'),
                      array( 'name' => "Spirax", 'variant' => ':300,400'),
                      array( 'name' => "Squada One", 'variant' => ':300,400'),
                      array( 'name' => "Stalemate", 'variant' => ':300,400'),
                      array( 'name' => "Stalinist One", 'variant' => ':300,400'),
                      array( 'name' => "Stardos Stencil", 'variant' => ':300,400'),
                      array( 'name' => "Stint Ultra Condensed", 'variant' => ':300,400'),
                      array( 'name' => "Stint Ultra Expanded", 'variant' => ':300,400'),
                      array( 'name' => "Stoke", 'variant' => ':300,400'),
                      array( 'name' => "Strait", 'variant' => ':300,400'),
                      array( 'name' => "Sue Ellen Francisco", 'variant' => ':300,400'),
                      array( 'name' => "Sunshiney", 'variant' => ':300,400'),
                      array( 'name' => "Supermercado One", 'variant' => ':300,400'),
                      array( 'name' => "Suwannaphum", 'variant' => ':300,400'),
                      array( 'name' => "Swanky and Moo Moo", 'variant' => ':300,400'),
                      array( 'name' => "Syncopate", 'variant' => ':300,400'),
                      array( 'name' => "Tangerine", 'variant' => ':300,400'),
                      array( 'name' => "Taprom", 'variant' => ':300,400'),
                      array( 'name' => "Tauri", 'variant' => ':300,400'),
                      array( 'name' => "Telex", 'variant' => ':300,400'),
                      array( 'name' => "Tenor Sans", 'variant' => ':300,400'),
                      array( 'name' => "Text Me One", 'variant' => ':300,400'),
                      array( 'name' => "The Girl Next Door", 'variant' => ':300,400'),
                      array( 'name' => "Tienne", 'variant' => ':300,400'),
                      array( 'name' => "Tinos", 'variant' => ':300,400'),
                      array( 'name' => "Titan One", 'variant' => ':300,400'),
                      array( 'name' => "Titillium Web", 'variant' => ':300,400'),
                      array( 'name' => "Trade Winds", 'variant' => ':300,400'),
                      array( 'name' => "Trocchi", 'variant' => ':300,400'),
                      array( 'name' => "Trochut", 'variant' => ':300,400'),
                      array( 'name' => "Trykker", 'variant' => ':300,400'),
                      array( 'name' => "Tulpen One", 'variant' => ':300,400'),
                      array( 'name' => "Ubuntu", 'variant' => ':300,400,500,700,300italic,400italic,500italic,700italic'),
                      array( 'name' => "Ubuntu Condensed", 'variant' => ':300,400,500,700,300italic,400italic,500italic,700italic'),
                      array( 'name' => "Ubuntu Mono", 'variant' => ':300,400'),
                      array( 'name' => "Ultra", 'variant' => ':300,400'),
                      array( 'name' => "Uncial Antiqua", 'variant' => ':300,400'),
                      array( 'name' => "Underdog", 'variant' => ':300,400'),
                      array( 'name' => "Unica One", 'variant' => ':300,400'),
                      array( 'name' => "UnifrakturCook", 'variant' => ':300,400'),
                      array( 'name' => "UnifrakturMaguntia", 'variant' => ':300,400'),
                      array( 'name' => "Unkempt", 'variant' => ':300,400'),
                      array( 'name' => "Unlock", 'variant' => ':300,400'),
                      array( 'name' => "Unna", 'variant' => ':300,400'),
                      array( 'name' => "VT323", 'variant' => ':300,400'),
                      array( 'name' => "Vampiro One", 'variant' => ':300,400'),
                      array( 'name' => "Varela", 'variant' => ':300,400'),
                      array( 'name' => "Varela Round", 'variant' => ':300,400'),
                      array( 'name' => "Vast Shadow", 'variant' => ':300,400'),
                      array( 'name' => "Vibur", 'variant' => ':300,400'),
                      array( 'name' => "Vidaloka", 'variant' => ':300,400'),
                      array( 'name' => "Viga", 'variant' => ':300,400'),
                      array( 'name' => "Voces", 'variant' => ':300,400'),
                      array( 'name' => "Volkhov", 'variant' => ':300,400'),
                      array( 'name' => "Vollkorn", 'variant' => ':300,400'),
                      array( 'name' => "Voltaire", 'variant' => ':300,400'),
                      array( 'name' => "Waiting for the Sunrise", 'variant' => ':300,400'),
                      array( 'name' => "Wallpoet", 'variant' => ':300,400'),
                      array( 'name' => "Walter Turncoat", 'variant' => ':300,400'),
                      array( 'name' => "Warnes", 'variant' => ':300,400'),
                      array( 'name' => "Wellfleet", 'variant' => ':300,400'),
                      array( 'name' => "Wendy One", 'variant' => ':300,400'),
                      array( 'name' => "Wire One", 'variant' => ':300,400'),
                      array( 'name' => "Yanone Kaffeesatz", 'variant' => ':300,400'),
                      array( 'name' => "Yellowtail", 'variant' => ':300,400'),
                      array( 'name' => "Yeseva One", 'variant' => ':300,400'),
                      array( 'name' => "Yesteryear", 'variant' => ':300,400'),
                      array( 'name' => "Zeyada", 'variant' => ':300,400')
                    );
                    
//Global options setup
add_action( 'init','pwd_global_options' );
function pwd_global_options(){
	// Populate Themes option in array for use in theme
	global $pwd_options;
	$pwd_options = get_option( 'pwd_options' );
}