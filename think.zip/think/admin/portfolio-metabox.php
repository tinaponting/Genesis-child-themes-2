<?php
wp_nonce_field( 'portfolio_metabox_save', 'portfolio_metabox_nonce' );

echo '<div style="width: 100%; float: left">';

	printf( '<p><label>%s<textarea class="large-text" id="summary" name="pf[_portfolio_excerpt]" rows="3">%s</textarea></label></p>', __( 'Summary: ', 'portfolio' ), esc_attr( genesis_get_custom_field('_portfolio_excerpt') ) );
	printf( '<p><span class="description">%s</span></p>', __( 'This is short description about your project which text will display below the title', 'portfolio' ) );

echo '</div><br style="clear: both;" />';

echo '<div style="width: 45%; float: left; margin-right: 5%;">';

	printf( '<p><label>%s<input type="text" name="pf[_client]" id="client" class="large-text" value="%s" /></label></p>', __( 'Client: ', 'portfolio' ), esc_attr( genesis_get_custom_field('_client') ) );
	printf( '<p><span class="description">%s</span></p>', __( 'Enter the client name', 'portfolio' ) );

echo '</div>';

echo '<div style="width: 45%; float: left">';

	printf( '<p><label>%s<input type="text" name="pf[_project_time]" id="project_time" class="large-text" value="%s" /></label></p>', __( 'Date: ', 'portfolio' ), esc_attr( genesis_get_custom_field('_project_time') ) );
	printf( '<p><span class="description">%s</span></p>', __( 'Enter project period like Dec 01, 2013 - Present', 'portfolio' ) );

echo '</div>';

echo '<div style="width: 45%; float: left; margin-right: 5%;">';

	printf( '<p><label>%s<textarea name="pf[_team]" id="project_time" class="large-text" rows="4">%s</textarea></label></p>', __( 'Team Details: ', 'portfolio' ), esc_attr( genesis_get_custom_field('_team') ) );

echo '</div>';

echo '<div style="width: 45%; float: left">';

	printf( '<p><label>%s<input type="text" name="pf[url]" id="website" class="large-text" value="%s" /></label></p>', __( 'Website URL: ', 'portfolio' ), esc_attr( genesis_get_custom_field('url') ) );
	printf( '<p><span class="description">%s</span></p>', __( 'Link of Projects Website', 'portfolio' ) );

echo '</div><br style="clear: both;" />';   
