<?php
// File Security Check
if ( ! defined( 'ABSPATH' ) ) exit;

// PWDThemes Admin Interface
add_action( 'admin_menu', 'pwdthemes_add_admin', 99 );

function pwdthemes_add_admin(){
  global $current_user;
	$current_user_id = $current_user->user_login;

	$themename =  get_option( 'pwd_themename' );
	$shortname =  get_option( 'pwd_shortname' );
  
  if ( isset( $_REQUEST['page'] ) ) {

			// Sanitize page being requested.
			$_page = '';

			$_page = mysql_real_escape_string( strtolower( trim( strip_tags( $_REQUEST['page'] ) ) ) );

			// Sanitize action being requested.
			$_action = '';

			if ( isset( $_REQUEST['pwd_save'] ) ) {

				$_action = mysql_real_escape_string( strtolower( trim( strip_tags( $_REQUEST['pwd_save'] ) ) ) );

			} // End IF Statement
      
      if ( $_action == 'reset' ) {

				// Add nonce security check.
				if ( function_exists( 'check_ajax_referer' ) ) {
						check_ajax_referer( 'pwd-theme-options-reset', '_ajax_nonce' );
				} // End IF Statement
        
        $options =  get_option( 'pwd_template' );
				pwd_reset_options( $options, 'site-options' );
				header( "Location: admin.php?page=site-options&reset=true" );
				die;
          
     } // End IF Statement   
  } // End IF Statement
    
  $sitepage = add_submenu_page( 'genesis', $themename, __( 'Theme Options', 'genesis' ), 'manage_options', 'site-options', 'pwdthemes_options_page' );
  
	add_action( "admin_print_scripts-$sitepage", 'scripts_load_only' );
  // Load CSS Files
	add_action( "admin_print_styles-$sitepage", 'admin_interface_load_css' );
}

/*-----------------------------------------------------------------------------------*/
/* Themes options panel - pwdthemes_options_page */
/*-----------------------------------------------------------------------------------*/

function pwdthemes_options_page(){
    global $pagenow;
    
    $options   =  get_option( 'pwd_template' );
		$themename =  get_option( 'pwd_themename' );
		$shortname =  get_option( 'pwd_shortname' );
?>
<div class="wrap" id="pwdthemes_container">
  <div id="pwd-popup-save" class="pwd-save-popup"><div class="pwd-save-save"><?php _e( 'Options Updated', 'genesis' ); ?></div></div>
  <div id="pwd-popup-reset" class="pwd-save-popup"><div class="pwd-save-reset"><?php _e( 'Options Reset', 'genesis' ); ?></div></div>
  <form action="" enctype="multipart/form-data" id="pwdthemesform" method="post">
    <?php
		// Add nonce for added security.
		if ( function_exists( 'wp_nonce_field' ) ) { wp_nonce_field( 'pwd-theme-options-update' ); } // End IF Statement

		$pwd_nonce = '';

		if ( function_exists( 'wp_create_nonce' ) ) { $pwd_nonce = wp_create_nonce( 'pwd-theme-options-update' ); } // End IF Statement

		if ( $pwd_nonce == '' ) {} else {

   ?>
        <input type="hidden" name="_ajax_nonce" value="<?php echo $pwd_nonce; ?>" />
    <?php
		} // End IF Statement
  ?>
    <div id="header">
      <div class="logo">
        <h2>Site Options</h2>
      </div>
      <div class="theme-info">
        <?php 
        		if ( function_exists( 'wp_get_theme' ) ) {
        			$theme_data = wp_get_theme();
        			$local_version = $theme_data->Version;
        			if ( is_child_theme() ) {
        				$local_version = $theme_data->parent()->Version;
        			}
        		} else {
        			$theme_data = get_theme_data( get_stylesheet_directory_uri() . '/style.css' );
        			$local_version = $theme_data['Version'];
        		}
        ?>
				<span class="theme"><?php echo $theme_data->Name . ' ' . $theme_data->Version; ?></span>
        <span class="framework">Framework: <?php echo $theme_data->parent()->Name . ' ' . $theme_data->parent()->Version; ?></span>
      </div>
      <div class="clear"></div>
    </div>
    <div id="support-links">
			<ul>
        <li class="forum"><a href="mailto:info@pwdtechnology.com"><?php _e( 'Support', 'genesis' ); ?></a></li>
				<li class="theme-site"><a title="PWD Technology" href="http://pwdtechnology.com" target="_blank"><?php _e( 'View Theme\'s Site', 'genesis' ); ?></a></li>
				<li class="docs"><a title="Theme Documentation" href="http://demo.pwdtechnology.com/anu/documentation/" target="_blank"><?php _e( 'View Theme Documentation', 'genesis' ); ?></a></li>
        <li class="right"><img style="display:none" src="<?php echo esc_url( get_template_directory_uri() . '/functions/images/loading-top.gif' ); ?>" class="ajax-loading-img ajax-loading-img-top" alt="Saving..." /><a href="#" id="expand_options">[+]</a> <input type="submit" value="Save All Changes" class="button submit-button" /></li>
			</ul>
		</div>
    <div id="main">
    <?php
      // Rev up the Options Machine
		  $return = of_machine( $options );
      if ( is_array( $return ) ) { 
    ?>
  	  <div id="of-nav">
			<?php if ( isset( $return[1] ) ) { ?>
				<ul>
					<?php echo $return[1]; ?>
				</ul>
			<?php } ?>  
      </div>  
      <div id="content">
	    	<?php if ( isset( $return[0] ) ) { echo $return[0]; } /* Settings */ ?>
	    </div>
	    <div class="clear"></div>     
     <?php } ?> 
    </div><!-- /#main -->
    <div class="clear"></div>
    <div class="save_bar_top">
    <img style="display:none" src="<?php echo CHILD_THEME_ADMIN_URL; ?>/images/loading-bottom.gif" class="ajax-loading-img ajax-loading-img-bottom" alt="Processing..." />
    <input type="hidden" name="pwd_save" value="save" />
    <input type="submit" value="Save All Changes" class="button submit-button" />
    </form>
    
    <form action="" method="post" style="display: inline;" id="pwdthemesform-reset">
<?php
		// Add nonce for added security.
		if ( function_exists( 'wp_nonce_field' ) ) { wp_nonce_field( 'pwd-theme-options-reset' ); } // End IF Statement

		$pwd_nonce = '';

		if ( function_exists( 'wp_create_nonce' ) ) { $pwd_nonce = wp_create_nonce( 'pwd-theme-options-reset' ); } // End IF Statement

		if ( $pwd_nonce == '' ) {} else {

?>
	    	<input type="hidden" name="_ajax_nonce" value="<?php echo $pwd_nonce; ?>" />
	    <?php

		} // End IF Statement
?>
            <span class="submit-footer-reset">
            <input name="reset" type="submit" value="Reset All Theme Options" class="button submit-button reset-button" onclick="return confirm( 'Click OK to reset all theme options. All settings will be lost!' );" />
            <input type="hidden" name="pwd_save" value="reset" />
            </span>
        </form>

    </div>
        
  <div style="clear:both;"></div>
</div><!--wrap-->

 <?php
}

/* woo_admin_head()
--------------------------------------------------------------------------------*/

function pwd_admin_head() {
?>
		<script type="text/javascript">
			jQuery(document).ready( function() {
<?php

        	$is_reset = 'false';
        
        	if( isset( $_REQUEST['reset'] ) ) {
        
        		$is_reset = $_REQUEST['reset'];
        
        		$is_reset = strtolower( strip_tags( trim( $is_reset ) ) );
        
        	} else {
        
        		$is_reset = 'false';
        
        	} // End IF Statement

?>
			if( '<?php echo esc_js( $is_reset ); ?>' == 'true' ) {

				var reset_popup = jQuery( '#pwd-popup-reset' );
				reset_popup.fadeIn();
				window.setTimeout(function() {
					   reset_popup.fadeOut();
					}, 2000);
			}

			//Update Message popup
			jQuery.fn.center = function () {
				this.animate({"top":( jQuery(window).height() - this.height() - 200 ) / 2+jQuery(window).scrollTop() + "px"},100);
				this.css( "left", 250 );
				return this;
			}

			jQuery( '#pwd-popup-save' ).center();
			jQuery( '#pwd-popup-reset' ).center();
			
      jQuery(window).scroll(function() {

				jQuery( '#pwd-popup-save' ).center();
				jQuery( '#pwd-popup-reset' ).center();

			});

			//Save everything else
			jQuery( '#pwdthemesform' ).submit(function() {

					function newValues() {
					  var serializedValues = jQuery( "#pwdthemesform *").not( '.pwd-ignore').serialize();
					  return serializedValues;
					}
					jQuery( ":checkbox, :radio").click(newValues);
					jQuery( "select").change(newValues);
					jQuery( '.ajax-loading-img').fadeIn();
					var serializedReturn = newValues();
					var data = {
						type: 'options',
						action: 'pwd_ajax_post_action',
						data: serializedReturn,

						<?php if ( function_exists( 'wp_create_nonce' ) ) { $pwd_nonce = wp_create_nonce( 'pwd-theme-options-update' ); }  ?>

						_ajax_nonce: '<?php echo $pwd_nonce; ?>'
					};

					jQuery.post(ajaxurl, data, function(response) {

						var success = jQuery( '#pwd-popup-save' );
						var loading = jQuery( '.ajax-loading-img' );
						loading.fadeOut();
						success.fadeIn();
						window.setTimeout(function() {
						   success.fadeOut();
						}, 2000);
					});

					return false;

				});

			});
		</script>
<?php } // End pwd_admin_head()

/*-----------------------------------------------------------------------------------*/
/* scripts_load_only */
/*-----------------------------------------------------------------------------------*/

function scripts_load_only(){

    add_action( 'admin_head', 'pwd_admin_head', 10 );

    wp_enqueue_script(  'jquery-ui-core' );
    wp_register_script( 'jquery-input-mask', CHILD_THEME_ADMIN_URL . '/js/jquery.maskedinput.js', array( 'jquery' ) );
		wp_register_script( 'colourpicker', CHILD_THEME_ADMIN_URL . '/js/colorpicker.js', array( 'jquery' ) );
    wp_register_script( 'admin-interface', CHILD_THEME_ADMIN_URL . '/js/admin-interface.js', array( 'jquery' ) );

		wp_enqueue_script( 'jquery-input-mask' );
		wp_enqueue_script( 'colourpicker' );
    wp_enqueue_script( 'admin-interface' );
}

/*-----------------------------------------------------------------------------------*/
/* admin_interface_load_css */
/*-----------------------------------------------------------------------------------*/
function admin_interface_load_css(){
    wp_enqueue_style('admin-style', CHILD_THEME_ADMIN_URL . '/css/admin-styles.css');
	  wp_enqueue_style('color-picker', CHILD_THEME_ADMIN_URL . '/css/colorpicker.css');
}

/*-----------------------------------------------------------------------------------*/
/* Generates The Options - of_machine */
/*-----------------------------------------------------------------------------------*/

if ( ! function_exists( 'of_machine' ) ) {
	function of_machine( $options ) {
    $counter = 0;
		$menu = '';
		$output = '';
    
    // Loop through the options.
		foreach ( $options as $k => $value ) {

			$counter++;
			$val = '';
			//Start Heading
			if ( $value['type'] != 'heading' && $value['type'] != 'subheading' ) {
				$class = ''; if( isset( $value['class'] ) ) { $class = ' ' . $value['class']; }
				$output .= '<div class="section section-' . esc_attr( $value['type'] ) . esc_attr( $class ) .'">'."\n";
				$output .= '<h3 class="heading">'. esc_html( $value['name'] ) .'</h3>'."\n";
				$output .= '<div class="option">'."\n" . '<div class="controls">'."\n";

			}
			//End Heading
			
			$select_value = '';
			switch ( $value['type'] ) {
      
        case 'text':
				$val = $value['std'];
				$std = esc_html( get_option( $value['id'] ) );
				if ( $std != "" ) { $val = $std; }
				$val = stripslashes( $val ); // Strip out unwanted slashes.
				$output .= '<input class="pwd-input" name="'. esc_attr( $value['id'] ) .'" id="'. esc_attr( $value['id'] ) .'" type="'. esc_attr( $value['type'] ) .'" value="'. esc_attr( $val ) .'" />';
				break;

			case 'select':
				$output .= '<div class="select_wrapper"><select class="pwd-input" name="'. esc_attr( $value['id'] ) .'" id="'. esc_attr( $value['id'] ) .'">';

				$select_value = stripslashes( get_option( $value['id'] ) );

				foreach ( $value['options'] as $option ) {

					$selected = '';

					if( $select_value != '' ) {
						if ( $select_value == $option ) { $selected = ' selected="selected"';}
					} else {
						if ( isset( $value['std'] ) )
							if ( $value['std'] == $option ) { $selected = ' selected="selected"'; }
					}

					$output .= '<option'. $selected .'>';
					$output .= esc_html( $option );
					$output .= '</option>';

				}
				$output .= '</select></div>';

				break;
			
			case 'select2':
				$output .= '<div class="select_wrapper">' . "\n";

				if ( is_array( $value['options'] ) ) {
					$output .= '<select class="pwd-input" name="'. esc_attr( $value['id'] ) .'" id="'. esc_attr( $value['id'] ) .'">';

					$select_value = stripslashes( get_option( $value['id'] ) );


					foreach ( $value['options'] as $option => $name ) {

						$selected = '';

						if( $select_value != '' ) {
							if ( $select_value == $option ) { $selected = ' selected="selected"';}
						} else {
							if ( isset( $value['std'] ) )
								if ( $value['std'] == $option ) { $selected = ' selected="selected"'; }
						}

						$output .= '<option'. $selected .' value="'.esc_attr( $option ).'">';
						$output .= esc_html( $name );
						$output .= '</option>';

					}
					$output .= '</select>' . "\n";
				}

				$output .= '</div>';

				break;      
      
        case 'textarea':
				$cols = '8';
				$ta_value = '';

				if( isset( $value['std'] ) ) {

					$ta_value = $value['std'];

					if( isset( $value['options'] ) ) {
						$ta_options = $value['options'];
						if( isset( $ta_options['cols'] ) ) {
							$cols = $ta_options['cols'];
						} else { $cols = '8'; }
					}

				}
				$std = get_option( $value['id'] );
				if( $std != "" ) { $ta_value = stripslashes( $std ); }
				$output .= '<textarea ' . ( ! current_user_can( 'unfiltered_html' ) && in_array( $value['id'], pwd_disabled_if_not_unfiltered_html_option_keys() ) ? 'disabled="disabled" ' : '' ) . 'class="pwd-input" name="'. esc_attr( $value['id'] ) .'" id="'. esc_attr( $value['id'] ) .'" cols="'. esc_attr( $cols ) .'" rows="8">'.esc_textarea( $ta_value ).'</textarea>';
        break;
        
        case "radio":
				$select_value = get_option( $value['id'] );

				if ( is_array( $value['options'] ) ) {
					foreach ( $value['options'] as $key => $option ) {

						$checked = '';
						if( $select_value != '' ) {
							if ( $select_value == $key ) { $checked = ' checked'; }
						} else {
							if ( $value['std'] == $key ) { $checked = ' checked'; }
						}
						$output .= '<div class="radio-wrapper"><input class="pwd-input pwd-radio" type="radio" name="'. esc_attr( $value['id'] ) .'" value="'. esc_attr( $key ) .'" '. $checked .' /><label>' . esc_html( $option ) .'</label></div>';

					}
				}

				break;
				
			case "checkbox":
				$std = $value['std'];

				$saved_std = get_option( $value['id'] );

				$checked = '';

				if( ! empty( $saved_std ) ) {
					if( $saved_std == 'true' ) {
						$checked = 'checked="checked"';
					} else {
						$checked = '';
					}
				}
				elseif( $std == 'true' ) {
					$checked = 'checked="checked"';
				}
				else {
					$checked = '';
				}
				$output .= '<input type="checkbox" class="checkbox pwd-input" name="'.  esc_attr( $value['id'] ) .'" id="'. esc_attr( $value['id'] ) .'" value="true" '. $checked .' />';

				break;
				
			case "multicheck":
				$std =  $value['std'];

				if ( is_array( $value['options'] ) ) {
					foreach ( $value['options'] as $key => $option ) {

						$pwd_key = $value['id'] . '_' . $key;
						$saved_std = get_option( $pwd_key );

						if ( ! empty( $saved_std ) ) {
							if ( $saved_std == 'true' ) {
								$checked = 'checked="checked"';
							} else {
								$checked = '';
							}
						} elseif ( $std == $key ) {
							$checked = 'checked="checked"';
						} else {
							$checked = '';
						}
						$output .= '<input type="checkbox" class="checkbox pwd-input" name="'. esc_attr( $pwd_key ) .'" id="'. esc_attr( $pwd_key ) .'" value="true" '. $checked .' /><label for="'. esc_attr( $pwd_key ) .'">'. esc_html( $option ) .'</label><br />';

					}
				}
				break;
			
			case "multicheck2":
				$std =  explode( ',', $value['std'] );

				if ( is_array( $value['options'] ) ) {
					foreach ( $value['options'] as $key => $option ) {

						$pwd_key = $value['id'] . '_' . $key;
						$saved_std = get_option( $pwd_key );

						if( ! empty( $saved_std ) )
						{
							if( $saved_std == 'true' ) {
								$checked = 'checked="checked"';
							} else {
								$checked = '';
							}
						}
						elseif ( in_array( $key, $std ) ) {
							$checked = 'checked="checked"';
						} else {
							$checked = '';
						}
						$output .= '<input type="checkbox" class="checkbox pwd-input" name="'. esc_attr( $pwd_key ) .'" id="'. esc_attr( $pwd_key ) .'" value="true" '. $checked .' /><label for="'. esc_attr( $pwd_key ) .'">'. esc_html( $option ) .'</label><br />';

					}
				}
				break;
        
        case "upload":
  				$output .= pwdthemes_medialibrary_uploader( $value['id'], $value['std'], null ); // New AJAX Uploader using Media Library
  				break;
				
  			case "upload_min":
  				$output .= pwdthemes_medialibrary_uploader( $value['id'], $value['std'], 'min' ); // New AJAX Uploader using Media Library
  				break;
        
        case "color":
    				$val = $value['std'];
    				$stored  = get_option( $value['id'] );
    				if ( $stored != "" ) { $val = $stored; }
    				$output .= '<div id="' . esc_attr( $value['id'] ) . '_picker" class="colorSelector"><div></div></div>';
    				$output .= '<input class="pwd-color" name="'. esc_attr( $value['id'] ) .'" id="'. esc_attr( $value['id'] ) .'" type="text" value="'. esc_attr( $val ) .'" />';
    				break;
        
        case "border":
				$default = $value['std'];
				$border_stored = get_option( $value['id'] );

				/* Border Width */
				$val = $default['width'];
				if ( $border_stored['width'] != "" ) { $val = $border_stored['width']; }
				$output .= '<select class="pwd-border pwd-border-width" name="'. esc_attr( $value['id'].'_width' ) . '" id="'. esc_attr( $value['id'].'_width' ) . '">';
				for ( $i = 0; $i < 21; $i++ ) {
					if( $val == $i ) { $active = 'selected="selected"'; } else { $active = ''; }
					$output .= '<option value="'. esc_attr( $i ) .'" ' . $active . '>'. esc_html( $i ) .'px</option>'; }
				$output .= '</select>';

				/* Border Style */
				$val = $default['style'];
				if ( $border_stored['style'] != "" ) { $val = $border_stored['style']; }
				$solid = ''; $dashed = ''; $dotted = '';
				if( $val == 'solid' ) { $solid = 'selected="selected"'; }
				if( $val == 'dashed' ) { $dashed = 'selected="selected"'; }
				if( $val == 'dotted' ) { $dotted = 'selected="selected"'; }

				$output .= '<select class="pwd-border pwd-border-style" name="'. esc_attr( $value['id'].'_style' ) . '" id="'. esc_attr( $value['id'].'_style' ) . '">';
				$output .= '<option value="solid" '. $solid .'>Solid</option>';
				$output .= '<option value="dashed" '. $dashed .'>Dashed</option>';
				$output .= '<option value="dotted" '. $dotted .'>Dotted</option>';
				$output .= '</select>';

				/* Border Color */
				$val = $default['color'];
				if ( $border_stored['color'] != "" ) { $val = $border_stored['color']; }
				$output .= '<div id="' . esc_attr( $value['id'] . '_color_picker' ) . '" class="colorSelector"><div></div></div>';
				$output .= '<input class="pwd-color pwd-border pwd-border-color" name="'. esc_attr( $value['id'] .'_color' ) . '" id="'. esc_attr( $value['id'] .'_color' ) . '" type="text" value="'. esc_attr( $val ) .'" />';

				break;

			case "images":
				$i = 0;
				$select_value = get_option( $value['id'] );

				foreach ( $value['options'] as $key => $option ) {
					$i++;

					$checked = '';
					$selected = '';
					if( $select_value != '' ) {
						if ( $select_value == $key ) { $checked = ' checked'; $selected = 'pwd-radio-img-selected'; }
					} else {
						if ( $value['std'] == $key ) { $checked = ' checked'; $selected = 'pwd-radio-img-selected'; }
						elseif ( $i == 1  && !isset( $select_value ) ) { $checked = ' checked'; $selected = 'pwd-radio-img-selected'; }
						elseif ( $i == 1  && $value['std'] == '' ) { $checked = ' checked'; $selected = 'pwd-radio-img-selected'; }
						else { $checked = ''; }
					}

					$output .= '<span>';
					$output .= '<input type="radio" id="pwd-radio-img-' . $value['id'] . $i . '" class="checkbox pwd-radio-img-radio" value="'. esc_attr( $key ) .'" name="'. esc_attr( $value['id'] ).'" '.$checked.' />';
					$output .= '<span class="pwd-radio-img-label">'. esc_html( $key ) .'</span>';
					$output .= '<img src="'.esc_attr( $option ).'" alt="" class="pwd-radio-img-img '. $selected .'" onClick="document.getElementById(\'pwd-radio-img-'. $value['id'] . $i.'\').checked = true;" />';
					$output .= '</span>';

				}

				break;
        
        case "typography":
				$default = $value['std'];
				$typography_stored = get_option( $value['id'] );

				if ( ! is_array( $typography_stored ) || empty( $typography_stored ) ) {
					$typography_stored = $default;
				}

				/* Font Size */
				$val = $default['size'];
				if ( $typography_stored['size'] != '' ) {
					$val = $typography_stored['size'];
				}
				if ( $typography_stored['unit'] == 'px' ) {
					$show_px = '';
					$show_em = ' style="display:none" ';
					$name_px = ' name="'. esc_attr( $value['id'].'_size') . '" ';
					$name_em = '';
				} else if ( $typography_stored['unit'] == 'em' ) {
					$show_em = '';
					$show_px = 'style="display:none"';
					$name_em = ' name="'. esc_attr( $value['id'].'_size') . '" ';
					$name_px = '';
				} else {
					$show_px = '';
					$show_em = ' style="display:none" ';
					$name_px = ' name="'. esc_attr( $value['id'].'_size') . '" ';
					$name_em = '';
				}
				$output .= '<select class="pwd-typography pwd-typography-size pwd-typography-size-px"  id="'. esc_attr( $value['id'].'_size_px') . '" '. $name_px . $show_px .'>';
				for ( $i = 9; $i < 71; $i++ ) {
					if( $val == strval( $i ) ) { $active = 'selected="selected"'; } else { $active = ''; }
					$output .= '<option value="'. esc_attr( $i ) .'" ' . $active . '>'. esc_html( $i ) .'</option>'; }
				$output .= '</select>';

				$output .= '<select class="pwd-typography pwd-typography-size pwd-typography-size-em" id="'. esc_attr( $value['id'].'_size_em' ) . '" '. $name_em . $show_em.'>';
				$em = 0.5;
				for ( $i = 0; $i < 39; $i++ ) {
					if ( $i <= 24 )   // up to 2.0em in 0.1 increments
						$em = $em + 0.1;
					elseif ( $i >= 14 && $i <= 24 )  // Above 2.0em to 3.0em in 0.2 increments
						$em = $em + 0.2;
					elseif ( $i >= 24 )  // Above 3.0em in 0.5 increments
						$em = $em + 0.5;
					if( $val == strval( $em ) ) { $active = 'selected="selected"'; } else { $active = ''; }
					//echo ' '. $value['id'] .' val:'.floatval($val). ' -> ' . floatval($em) . ' $<br />' ;
					$output .= '<option value="'. esc_attr( $em ) .'" ' . $active . '>'. esc_html( $em ) .'</option>'; }
				$output .= '</select>';

				/* Font Unit */
				$val = $default['unit'];
				if ( $typography_stored['unit'] != '' ) { $val = $typography_stored['unit']; }
				$em = ''; $px = '';
				if( $val == 'em' ) { $em = 'selected="selected"'; }
				if( $val == 'px' ) { $px = 'selected="selected"'; }
				$output .= '<select class="pwd-typography pwd-typography-unit" name="'. esc_attr( $value['id'] ) .'_unit" id="'. esc_attr( $value['id'].'_unit' ) . '">';
				$output .= '<option value="px" '. $px .'">px</option>';
				$output .= '<option value="em" '. $em .'>em</option>';
				$output .= '</select>';

				/* Font Face */
				$val = $default['face'];
				if ( $typography_stored['face'] != "" )
					$val = $typography_stored['face'];

				$font01 = '';
				$font02 = '';
				$font03 = '';
				$font04 = '';
				$font05 = '';
				$font06 = '';
				$font07 = '';
				$font08 = '';
				$font09 = '';
				$font10 = '';
				$font11 = '';
				$font12 = '';
				$font13 = '';
				$font14 = '';
				$font15 = '';
				$font16 = '';
				$font17 = '';

				if ( strpos( $val, 'Arial, sans-serif' ) !== false ) { $font01 = 'selected="selected"'; }
				if ( strpos( $val, 'Verdana, Geneva' ) !== false ) { $font02 = 'selected="selected"'; }
				if ( strpos( $val, 'Trebuchet' ) !== false ) { $font03 = 'selected="selected"'; }
				if ( strpos( $val, 'Georgia' ) !== false ) { $font04 = 'selected="selected"'; }
				if ( strpos( $val, 'Times New Roman' ) !== false ) { $font05 = 'selected="selected"'; }
				if ( strpos( $val, 'Tahoma, Geneva' ) !== false ) { $font06 = 'selected="selected"'; }
				if ( strpos( $val, 'Palatino' ) !== false ) { $font07 = 'selected="selected"'; }
				if ( strpos( $val, 'Helvetica' ) !== false ) { $font08 = 'selected="selected"'; }
				if ( strpos( $val, 'Calibri' ) !== false ) { $font09 = 'selected="selected"'; }
				if ( strpos( $val, 'Myriad' ) !== false ) { $font10 = 'selected="selected"'; }
				if ( strpos( $val, 'Lucida' ) !== false ) { $font11 = 'selected="selected"'; }
				if ( strpos( $val, 'Arial Black' ) !== false ) { $font12 = 'selected="selected"'; }
				if ( strpos( $val, 'Gill' ) !== false ) { $font13 = 'selected="selected"'; }
				if ( strpos( $val, 'Geneva, Tahoma' ) !== false ) { $font14 = 'selected="selected"'; }
				if ( strpos( $val, 'Impact' ) !== false ) { $font15 = 'selected="selected"'; }
				if ( strpos( $val, 'Courier' ) !== false ) { $font16 = 'selected="selected"'; }
				if ( strpos( $val, 'Century Gothic' ) !== false ) { $font17 = 'selected="selected"'; }

				$output .= '<select class="pwd-typography pwd-typography-face" name="'. esc_attr( $value['id'].'_face' ) . '" id="'. esc_attr( $value['id'].'_face') . '">';
				$output .= '<option value="Arial, sans-serif" '. $font01 .'>Arial</option>';
				$output .= '<option value="Verdana, Geneva, sans-serif" '. $font02 .'>Verdana</option>';
				$output .= '<option value="&quot;Trebuchet MS&quot;, Tahoma, sans-serif"'. $font03 .'>Trebuchet</option>';
				$output .= '<option value="Georgia, serif" '. $font04 .'>Georgia</option>';
				$output .= '<option value="&quot;Times New Roman&quot;, serif"'. $font05 .'>Times New Roman</option>';
				$output .= '<option value="Tahoma, Geneva, Verdana, sans-serif"'. $font06 .'>Tahoma</option>';
				$output .= '<option value="Palatino, &quot;Palatino Linotype&quot;, serif"'. $font07 .'>Palatino</option>';
				$output .= '<option value="&quot;Helvetica Neue&quot;, Helvetica, sans-serif" '. $font08 .'>Helvetica*</option>';
				$output .= '<option value="Calibri, Candara, Segoe, Optima, sans-serif"'. $font09 .'>Calibri*</option>';
				$output .= '<option value="&quot;Myriad Pro&quot;, Myriad, sans-serif"'. $font10 .'>Myriad Pro*</option>';
				$output .= '<option value="&quot;Lucida Grande&quot;, &quot;Lucida Sans Unicode&quot;, &quot;Lucida Sans&quot;, sans-serif"'. $font11 .'>Lucida</option>';
				$output .= '<option value="&quot;Arial Black&quot;, sans-serif" '. $font12 .'>Arial Black</option>';
				$output .= '<option value="&quot;Gill Sans&quot;, &quot;Gill Sans MT&quot;, Calibri, sans-serif" '. $font13 .'>Gill Sans*</option>';
				$output .= '<option value="Geneva, Tahoma, Verdana, sans-serif" '. $font14 .'>Geneva*</option>';
				$output .= '<option value="Impact, Charcoal, sans-serif" '. $font15 .'>Impact</option>';
				$output .= '<option value="Courier, &quot;Courier New&quot;, monospace" '. $font16 .'>Courier</option>';
				$output .= '<option value="&quot;Century Gothic&quot;, sans-serif" '. $font17 .'>Century Gothic</option>';

				// Google webfonts
				global $google_fonts;
				sort( $google_fonts );

				$output .= '<option value="">------- Google Fonts -------</option>';
				foreach ( $google_fonts as $key => $gfont ) :
					$font[$key] = '';
				if ( $val == $gfont['name'] ) { $font[$key] = 'selected="selected"'; }
				$name = $gfont['name'];
				$output .= '<option value="'.esc_attr( $name ).'" '. $font[$key] .'>'.esc_html( $name ).'</option>';
				endforeach;
        
        $output .= '</select>';
        
        /* Font Weight */
				$val = $default['style'];
				if ( $typography_stored['style'] != "" ) { $val = $typography_stored['style']; }
				$thin = ''; $thinitalic = ''; $normal = ''; $italic = ''; $bold = ''; $bolditalic = '';
				if( $val == '300' ) { $thin = 'selected="selected"'; }
				if( $val == '300 italic' ) { $thinitalic = 'selected="selected"'; }
				if( $val == 'normal' ) { $normal = 'selected="selected"'; }
				if( $val == 'italic' ) { $italic = 'selected="selected"'; }
				if( $val == 'bold' ) { $bold = 'selected="selected"'; }
				if( $val == 'bold italic' ) { $bolditalic = 'selected="selected"'; }

				$output .= '<select class="pwd-typography pwd-typography-style" name="'. esc_attr( $value['id'].'_style' ) . '" id="'. esc_attr( $value['id'].'_style' ) . '">';
				$output .= '<option value="300" '. $thin .'>Thin</option>';
				$output .= '<option value="300 italic" '. $thinitalic .'>Thin/Italic</option>';
				$output .= '<option value="normal" '. $normal .'>Normal</option>';
				$output .= '<option value="italic" '. $italic .'>Italic</option>';
				$output .= '<option value="bold" '. $bold .'>Bold</option>';
				$output .= '<option value="bold italic" '. $bolditalic .'>Bold/Italic</option>';
				$output .= '</select>';

				/* Font Color */
				$val = $default['color'];
				if ( $typography_stored['color'] != "" ) { $val = $typography_stored['color']; }
				$output .= '<div id="' . esc_attr( $value['id'] . '_color_picker' ) .'" class="colorSelector"><div></div></div>';
				$output .= '<input class="pwd-color pwd-typography pwd-typography-color" name="'. esc_attr( $value['id'] .'_color' ) . '" id="'. esc_attr( $value['id'] .'_color' ) . '" type="text" value="'. esc_attr( $val ) .'" />';

				break;

        case "heading":
  				if( $counter >= 2 ) {
  					$output .= '</div>'."\n";
  				}
  				$jquery_click_hook = preg_replace( '/[^a-zA-Z0-9\s]/', '', strtolower( $value['name'] ) );
  				$jquery_click_hook = str_replace( ' ', '', $jquery_click_hook );  
  				$jquery_click_hook = "pwd-option-" . $jquery_click_hook;
          $class = '';
  				if ( isset( $value['icon'] ) && ( $value['icon'] != '' ) ) {
  					$class = ' class="'.esc_attr( $value['icon'] ).'"';
  				}
  				$menu .= '<li'.$class.'>';
          if ( isset( $value['icon'] ) && ( $value['icon'] != '' ) )
					 $menu .= '<span class="icon"></span>';
          $menu .= '<a title="'. esc_attr( $value['name'] ) .'" href="#'.  $jquery_click_hook  .'">'.  esc_html( $value['name'] ) .'</a></li>';
  				$output .= '<div class="group" id="'. esc_attr( $jquery_click_hook ) .'"><h1 class="subtitle">'. esc_html( $value['name'] ) .'</h1>'."\n";
  				break;
      }
      
      // if TYPE is an array, formatted into smaller inputs... ie smaller values
			if ( is_array( $value['type'] ) ) {
				foreach( $value['type'] as $array ) {

					$id = $array['id'];
					$std = $array['std'];
					$saved_std = get_option( $id );
					if( $saved_std != $std ) {$std = $saved_std;}
					$meta = $array['meta'];

					if( $array['type'] == 'text' ) { // Only text at this point

						$output .= '<input class="input-text-small pwd-input" name="'. esc_attr( $id ) .'" id="'. esc_attr( $id ) .'" type="text" value="'. esc_attr( $std ) .'" />';
						$output .= '<span class="meta-two">'. esc_html( $meta ) .'</span>';
					}
				}
			}
      
      if ( $value['type'] != "heading" ) {
				if ( $value['type'] != "checkbox" )
				{
					$output .= '<br/>';
				}
				$explain_value = ( isset( $value['desc'] ) ) ? $value['desc'] : '';
				if ( !current_user_can( 'unfiltered_html' ) && isset( $value['id'] ) && in_array( $value['id'], pwd_disabled_if_not_unfiltered_html_option_keys() ) )
					$explain_value .= '<br /><br /><b>' . esc_html( __( 'You are not able to update this option because you lack the <code>unfiltered_html</code> capability.', 'genesis' ) ) . '</b>';
				$output .= '</div><div class="explain">'. $explain_value .'</div>'."\n";
				$output .= '<div class="clear"> </div></div></div>'."\n";
			}
    }
    
    return array( $output, $menu );
    
  }
}

/**
 * pwd_options_save()
 *
 * Save options to the database. Moved to a dedicated function.
 *
 * @since V1.2.0
 */

function pwd_options_save ( $type, $data ) {
	global $wpdb; // this is how you get access to the database

	$status = false; // We set this to true if the settings have saved successfully.

	$save_type = $type;

	if ( $save_type == 'options' ) {

		// $data = $_POST['data'];

		if ( is_array( $data ) ) {
			$output = $data; // $output variable used below during save.
		} else {
			parse_str( $data, $output );
		}

		// Remove the "pwd_save" item from the output array.
		if ( isset( $output['pwd_save'] ) && $output['pwd_save'] == 'reset' ) { unset( $output['pwd_save'] ); }

		//Pull options
		$options = get_option( 'pwd_template' );
    
		foreach( $options as $option_array ) {

			if( isset( $option_array['id'] ) ) {
				$id = $option_array['id'];
			} else { $id = null;}
			$old_value = get_option( $id );
			$new_value = '';
			
			if ( ! current_user_can( 'unfiltered_html' ) ) { continue; } // Skip over the theme option if it's not being passed through.
			
			if( isset( $output[$id] ) ) {
				$new_value = $output[$option_array['id']];
			}

			if( isset( $option_array['id'] ) ) { // Non - Headings...

				$type = $option_array['type'];

				if ( is_array( $type ) ) {
					foreach( $type as $array ) {
						if( $array['type'] == 'text' ) {
							$id = $array['id'];
							$std = $array['std'];
							$new_value = $output[$id];
							if( $new_value == '' ) { $new_value = $std; }

							update_option( $id, stripslashes( $new_value ) );
						}
					}
				}
				elseif( $new_value == '' && $type == 'checkbox' ) { // Checkbox Save

					update_option( $id, 'false' );
				}
				elseif ( $new_value == 'true' && $type == 'checkbox' ) { // Checkbox Save

					update_option( $id, 'true' );
				}
				elseif( $type == 'multicheck' ) { // Multi Check Save

					$option_options = $option_array['options'];

					foreach ( $option_options as $options_id => $options_value ) {

						$multicheck_id = $id . "_" . $options_id;

						if( !isset( $output[$multicheck_id] ) ) {
							update_option( $multicheck_id, 'false' );
						}
						else{
							update_option( $multicheck_id, 'true' );
						}
					}
				}
				elseif( $type == 'typography' ) {
					$typography_array = array();

					foreach ( array( 'size', 'unit', 'face', 'style', 'color' ) as $v  ) {
						$value = '';
						$value = $output[$option_array['id'] . '_' . $v];
						if ( $v == 'face' ) {
							$typography_array[$v] = stripslashes( $value );
						} else {
							$typography_array[$v] = $value;
						}
					}
					
					update_option( $id, $typography_array );

				}
				elseif( $type == 'border' ) {

					$border_array = array();

					$border_array['width'] = $output[$option_array['id'] . '_width'];
					$border_array['style'] = $output[$option_array['id'] . '_style'];
					$border_array['color'] = $output[$option_array['id'] . '_color'];

					update_option( $id, $border_array );

				} else {

					update_option( $id, stripslashes( $new_value ) );
				}
			}
		}

		// Assume that all has been completed and set $status to true.
		$status = true;
	}


	if( $save_type == 'options' ) {
		/* Create, Encrypt and Update the Saved Settings */
		$pwd_options = array();
		$data = array();
		$options = get_option( 'pwd_template' );
		$count = 0;
		foreach( $options as $option ) {
			if( isset( $option['id'] ) ) {
				$count++;
				$option_id = $option['id'];
				$option_type = $option['type'];

				if( is_array( $option_type ) ) {
					$type_array_count = 0;
					foreach( $option_type as $inner_option ) {
						$option_id = $inner_option['id'];
						if ( isset( $data[$option_id] ) )
							$data[$option_id] .= get_option( $option_id );
						else
							$data[$option_id] = get_option( $option_id );
					}
				}
				else {
					$data[$option_id] = get_option( $option_id );
				}
			}
		}

		$output = "<ul>";

		foreach ( $data as $name => $value ) {

			if( is_serialized( $value ) ) {

				$value = unserialize( $value );
				$pwd_array_option = $value;
				$temp_options = '';
				foreach( $value as $v ) {
					if( isset( $v ) )
						$temp_options .= $v . ',';

				}
				$value = $temp_options;
				$pwd_array[$name] = $pwd_array_option;
			} else {
				$pwd_array[$name] = $value;
			}

			$output .= '<li><strong>' . esc_html( $name ) . '</strong> - ' . esc_html( $value ) . '</li>';
		}
		$output .= "</ul>";

		update_option( 'pwd_options', $pwd_array );

		// Assume that all has been completed and set $status to true.
		$status = true;
	}

	return $status;
} // End pwd_options_save()

/*-----------------------------------------------------------------------------------*/
/* AJAX Save Action - pwd_ajax_callback() */
/*-----------------------------------------------------------------------------------*/

add_action( 'wp_ajax_pwd_ajax_post_action', 'pwd_ajax_callback' );

if ( ! function_exists( 'pwd_ajax_callback' ) ) {
	function pwd_ajax_callback() {
		// check security with nonce.
		if ( function_exists( 'check_ajax_referer' ) ) { check_ajax_referer( 'pwd-theme-options-update', '_ajax_nonce' ); } // End IF Statement

		$data = maybe_unserialize( $_POST['data'] );

		pwd_options_save( $_POST['type'], $data );

		die();
	} // End woo_ajax_callback()
}

/*-----------------------------------------------------------------------------------*/
/* Admin Messages */
/*-----------------------------------------------------------------------------------*/

function pwd_admin_message_success () {
	echo '<div class="updated fade" style="display: block !important;"><p>' . __( 'Options Saved Successfully', 'woothemes' ) . '</p></div><!--/.updated fade-->' . "\n";
} // End woo_admin_message_success()

function pwd_admin_message_error () {
	echo '<div class="error fade" style="display: block !important;"><p>' . __( 'There was an error while saving your options. Please try again.', 'woothemes' ) . '</p></div><!--/.error fade-->' . "\n";
} // End woo_admin_message_error()

function pwd_admin_message_reset () {
	echo '<div class="updated fade" style="display: block !important;"><p>' . __( 'Options Reset Successfully', 'woothemes' ) . '</p></div><!--/.updated fade-->' . "\n";
} // End woo_admin_message_reset()

/*-----------------------------------------------------------------------------------*/
/* Reset Function - pwd_reset_options */
/*-----------------------------------------------------------------------------------*/

if ( ! function_exists( 'pwd_reset_options' ) ) {
	function pwd_reset_options( $options, $page = '' ) {

		$excludes = array( 'blogname' , 'blogdescription' );

		foreach( $options as $option ) {

			if( isset( $option['id'] ) ) {
				$option_id = $option['id'];
				$option_type = $option['type'];

				//Skip assigned id's
				if( in_array( $option_id, $excludes ) ) { continue; }

				if( $option_type == 'multicheck' ) {
					foreach( $option['options'] as $option_key => $option_option ) {
						$del = $option_id . "_" . $option_key;
						delete_option( $del );
					}
				} else if( is_array( $option_type ) ) {
						foreach( $option_type as $inner_option ) {
							$option_id = $inner_option['id'];
							$del = $option_id;
							delete_option( $option_id );
						}
					} else {
					delete_option( $option_id );
				}
			}
		}
		//When Theme Options page is reset - Add the woo_options option
		if( $page == 'site-options' ) {
			delete_option( 'pwd_options' );
		}
	}
}