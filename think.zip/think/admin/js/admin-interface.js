/**
 * Admin Interface JavaScript
 *
 * All JavaScript logic for the theme options admin interface.
 * @since 1.0
 *
 */

(function ($) {

  pwdthemesAdminInterface = {
  
/**
 * toggle_nav_tabs()
 *
 * @since 4.8.0
 */
 
 	toggle_nav_tabs: function () {
 		var flip = 0;
	
		$( '#expand_options' ).click( function(){
			if( flip == 0 ){
				flip = 1;
				$( '#pwdthemes_container #of-nav' ).hide();
				$( '#pwdthemes_container #content' ).width( 739 );
        $( '#pwdthemes_container .group' ).show();
				$( '#pwdthemes_container .group' ).add( '#pwdthemes_container .group h1' ).show();

				$(this).text( '[-]' );

			} else {
				flip = 0;
				$( '#pwdthemes_container #of-nav' ).show();
				$( '#pwdthemes_container #content' ).width( 559 );
        $( '#pwdthemes_container .group' ).hide();
				$( '#pwdthemes_container .group' ).add( '#pwdthemes_container .group h1' ).hide();
				$( '#pwdthemes_container .group:first' ).show();
				$( '#pwdthemes_container #of-nav li' ).removeClass( 'current' );
				$( '#pwdthemes_container #of-nav li:first' ).addClass( 'current' );

				$(this).text( '[+]' );

			}

		});
 	}, // End toggle_nav_tabs()

/**
 * load_first_tab()
 *
 * @since 4.8.0
 */
 
 	load_first_tab: function () {
 		$( '.group' ).hide();
 		$( '.group:has(".section"):first' ).fadeIn(); // Fade in the first tab containing options (not just the first tab).
 	}, // End load_first_tab()
 	
/**
 * open_first_menu()
 *
 * @since 5.0.0
 */
 
 	open_first_menu: function () {
 		$( '#of-nav li.current.has-children:first ul.sub-menu' ).slideDown().addClass( 'open' ).children( 'li:first' ).addClass( 'active' ).parents( 'li.has-children' ).addClass( 'open' );
 	}, // End open_first_menu()
 	
/**
 * toggle_nav_menus()
 *
 * @since 5.0.0
 */
 
 	toggle_nav_menus: function () {
 		$( '#of-nav li.has-children > a' ).click( function ( e ) {
 			if ( $( this ).parent().hasClass( 'open' ) ) { return false; }
 			
 			$( '#of-nav li.top-level' ).removeClass( 'open' ).removeClass( 'current' );
 			$( '#of-nav li.active' ).removeClass( 'active' );
 			if ( $( this ).parents( '.top-level' ).hasClass( 'open' ) ) {} else {
 				$( '#of-nav .sub-menu.open' ).removeClass( 'open' ).slideUp().parent().removeClass( 'current' );
 				$( this ).parent().addClass( 'open' ).addClass( 'current' ).find( '.sub-menu' ).slideDown().addClass( 'open' ).children( 'li:first' ).addClass( 'active' );
 			}
 			
 			// Find the first child with sections and display it.
 			var clickedGroup = $( this ).parent().find( '.sub-menu li a:first' ).attr( 'href' );
 			
 			if ( clickedGroup != '' ) {
 				$( '.group' ).hide();
 				$( clickedGroup ).fadeIn();
 			}
 			return false;
 		});
 	}, // End toggle_nav_menus()
 	
/**
 * toggle_collapsed_fields()
 *
 * @since 4.8.0
 */
 
 	toggle_collapsed_fields: function () {
		$( '.group .collapsed' ).each(function(){
			$( this ).find( 'input:checked' ).parent().parent().parent().nextAll().each( function(){
				if ($( this ).hasClass( 'last' ) ) {
					$( this ).removeClass( 'hidden' );
					return false;
				}
				$( this ).filter( '.hidden' ).removeClass( 'hidden' );
				
				$( '.group .collapsed input:checkbox').click(function ( e ) {
					pwdthemesAdminInterface.unhide_hidden( $( this ).attr( 'id' ) );
				});

			});
		});
 	}, // End toggle_collapsed_fields()

/**
 * setup_nav_highlights()
 *
 * @since 4.8.0
 */
 
 	setup_nav_highlights: function () {
	 	// Highlight the first item by default.
	 	$( '#of-nav li:first' ).addClass( 'current' ).addClass( 'open' );
		
		// Default single-level logic.
		$( '#of-nav li' ).not( '.has-children' ).find( 'a' ).click( function ( e ) {
			var thisObj = $( this );
			var clickedGroup = thisObj.attr( 'href' );
			
			if ( clickedGroup != '' ) {
				$( '#of-nav .open' ).removeClass( 'open' );
				$( '.sub-menu' ).slideUp();
				$( '#of-nav .active' ).removeClass( 'active' );
				$( '#of-nav li.current' ).removeClass( 'current' );
				thisObj.parent().addClass( 'current' );
				
				$( '.group' ).hide();
				$( clickedGroup ).fadeIn();
				
				return false;
			}
		});
		
		$( '#of-nav li:not(".has-children") > a:first' ).click( function( evt ) {
			var parentObj = $( this ).parent( 'li' );
			var thisObj = $( this );
			
			var clickedGroup = thisObj.attr( 'href' );
			
			if ( $( this ).parents( '.top-level' ).hasClass( 'open' ) ) {} else {
				$( '#of-nav li.top-level' ).removeClass( 'current' ).removeClass( 'open' );
				$( '#of-nav .sub-menu' ).removeClass( 'open' ).slideUp();
				$( this ).parents( 'li.top-level' ).addClass( 'current' );
			}
		
			$( '.group' ).hide();
			$( clickedGroup ).fadeIn();
		
			evt.preventDefault();
			return false;
		});
		
		// Sub-menu link click logic.
		$( '.sub-menu a' ).click( function ( e ) {
			var thisObj = $( this );
			var parentMenu = $( this ).parents( 'li.top-level' );
			var clickedGroup = thisObj.attr( 'href' );
			
			if ( $( '.sub-menu li a[href="' + clickedGroup + '"]' ).hasClass( 'active' ) ) {
				return false;
			}
			
			if ( clickedGroup != '' ) {
				parentMenu.addClass( 'open' );
				$( '.sub-menu li, .flyout-menu li' ).removeClass( 'active' );
				$( this ).parent().addClass( 'active' );
				$( '.group' ).hide();
				$( clickedGroup ).fadeIn();
			}
			
			return false;
		});
 	}, // End setup_nav_highlights()

/**
 * setup_custom_typography()
 *
 * @since 4.8.0
 */
 
 	setup_custom_typography: function () {
	 	$( 'select.pwd-typography-unit' ).change( function(){
			var val = $( this ).val();
			var parent = $( this ).parent();
			var name = parent.find( '.pwd-typography-size-px' ).attr( 'name' );
			if( name == '' ) { var name = parent.find( '.pwd-typography-size-em' ).attr( 'name' ); }
			
			if( val == 'px' ) {
				var name = parent.find( '.pwd-typography-size-em' ).attr( 'name' );
				parent.find( '.pwd-typography-size-em' ).hide().removeAttr( 'name' );
				parent.find( '.pwd-typography-size-px' ).show().attr( 'name', name );
			}
			else if( val == 'em' ) {
				var name = parent.find( '.pwd-typography-size-px' ).attr( 'name' );
				parent.find( '.pwd-typography-size-px' ).hide().removeAttr( 'name' );
				parent.find( '.pwd-typography-size-em' ).show().attr( 'name', name );
			}
		
		});
 	}, // End setup_custom_typography()

/**
 * setup_custom_ui_slider()
 *
 * @since 5.3.5
 */
 
 	setup_custom_ui_slider: function () {

		$('div.ui-slide').each(function(i){

			if( $(this).attr('min') != undefined && $(this).attr('max') != undefined ) {

				$(this).slider( { 
								min: parseInt($(this).attr('min')), 
								max: parseInt($(this).attr('max')), 
								value: parseInt($(this).next("input").val()),
								step: parseInt($(this).attr('inc')) ,
								slide: function( event, ui ) {
									$( this ).next("input").val(ui.value);
								}
							});

				$(this).removeAttr('min').removeAttr('max').removeAttr('inc');

			}

		});

 	}, // End setup_custom_ui_slider()

/**
 * init_flyout_menus()
 *
 * @since 5.0.0
 */
 
 	init_flyout_menus: function () {
 		// Only trigger flyouts on menus with closed sub-menus.
 		$( '#of-nav li.has-children' ).each ( function ( i ) {
 			$( this ).hover(
	 			function () {
	 				if ( $( this ).find( '.flyout-menu' ).length == 0 ) {
		 				var flyoutContents = $( this ).find( '.sub-menu' ).html();
		 				var flyoutMenu = $( '<div />' ).addClass( 'flyout-menu' ).html( '<ul>' + flyoutContents + '</ul>' );
		 				$( this ).append( flyoutMenu );
	 				}
	 			}, 
	 			function () {
	 				// $( '#of-nav .flyout-menu' ).remove();
	 			}
	 		);
 		});
 		
 		// Add custom link click logic to the flyout menus, due to custom logic being required.
 		$( '.flyout-menu a' ).live( 'click', function ( e ) {
 			var thisObj = $( this );
 			var parentObj = $( this ).parent();
 			var parentMenu = $( this ).parents( '.top-level' );
 			var clickedGroup = $( this ).attr( 'href' );
 			
 			if ( clickedGroup != '' ) {
	 			$( '.group' ).hide();
	 			$( clickedGroup ).fadeIn();
	 			
	 			// Adjust the main navigation menu.
	 			$( '#of-nav li' ).removeClass( 'open' ).removeClass( 'current' ).find( '.sub-menu' ).slideUp().removeClass( 'open' );
	 			parentMenu.addClass( 'open' ).addClass( 'current' ).find( '.sub-menu' ).slideDown().addClass( 'open' );
	 			$( '#of-nav li.active' ).removeClass( 'active' );
	 			$( '#of-nav a[href="' + clickedGroup + '"]' ).parent().addClass( 'active' );
 			}
 			
 			return false;
 		});
 	}, // End init_flyout_menus()


/**
 * setup_image_selectors()
 *
 * @since 4.8.0
 */
 
 	setup_image_selectors: function () {
 		if ( $( '.pwd-meta-radio-img-img, .pwd-radio-img-img' ).length ) {
	 		$( '.pwd-meta-radio-img-img, .pwd-radio-img-img' ).click( function() {
				
				$( this ).parent().parent().find( '.pwd-meta-radio-img-img' ).removeClass( 'pwd-meta-radio-img-selected' );
				$( this ).parent().parent().find( '.pwd-radio-img-img' ).removeClass( 'pwd-radio-img-selected' );
				$( this ).addClass( 'pwd-meta-radio-img-selected' ).addClass( 'pwd-radio-img-selected' );

			});
			$( '.pwd-meta-radio-img-label, .pwd-meta-radio-img-radio, .pwd-radio-img-label, .pwd-radio-img-radio' ).hide();
			$( '.pwd-meta-radio-img-img, .pwd-radio-img-img' ).show();
		}
 	}, // End setup_image_selectors()
 	
/**
 * setup_colourpickers()
 *
 * @since 4.8.0
 */
 
 	setup_colourpickers: function () {
 		if ( jQuery().ColorPicker && $( '.section-typography, .section-border, .section-color' ).length ) {
 			$( '.section-typography, .section-border, .section-color' ).each( function () {
 				
 				var option_id = $( this ).find( '.pwd-color' ).attr( 'id' );
				var color = $( this ).find( '.pwd-color' ).val();
				var picker_id = option_id += '_picker';
 				
 				if ( $( this ).hasClass( 'section-typography' ) || $( this ).hasClass( 'section-border' ) ) {
					option_id += '_color';
				}
 				
	 			$( '#' + picker_id ).children( 'div' ).css( 'backgroundColor', color );
				$( '#' + picker_id ).ColorPicker({
					color: color,
					onShow: function ( colpkr ) {
						jQuery( colpkr ).fadeIn( 200 );
						return false;
					},
					onHide: function ( colpkr ) {
						jQuery( colpkr ).fadeOut( 200 );
						return false;
					},
					onChange: function ( hsb, hex, rgb ) {
						$( '#' + picker_id ).children( 'div' ).css( 'backgroundColor', '#' + hex );
						$( '#' + picker_id ).next( 'input' ).attr( 'value', '#' + hex );
					
					}
				});
 			});
 		}
 	}, // End setup_colourpickers()
  
/**
 * unhide_hidden()
 *
 * @since 4.8.0
 * @see toggle_collapsed_fields()
 */
 
 	unhide_hidden: function ( obj ) {
 		obj = $( '#' + obj ); // Get the jQuery object.
 		
		if ( obj.attr( 'checked' ) ) {
			obj.parent().parent().parent().nextAll().slideDown().removeClass( 'hidden' ).addClass( 'visible' );
		} else {
			obj.parent().parent().parent().nextAll().each( function(){
				if ( $( this ).filter( '.last' ).length ) {
					$( this ).slideUp().addClass( 'hidden' );
				return false;
				}
				$( this ).slideUp().addClass( 'hidden' );
			});
		}
 	} // End unhide_hidden()
  
  }; // End AdminInterface Object // Don't remove this, or the sky will fall on your head.

/**
 * Execute the above methods in the AdminInterface object.
 *
 * @since 4.8.0
 */
	$(document).ready(function () {
	
		pwdthemesAdminInterface.toggle_nav_tabs();
		pwdthemesAdminInterface.load_first_tab();
		pwdthemesAdminInterface.toggle_collapsed_fields();
		pwdthemesAdminInterface.setup_nav_highlights();
		pwdthemesAdminInterface.toggle_nav_menus();
		pwdthemesAdminInterface.init_flyout_menus();
		pwdthemesAdminInterface.open_first_menu();
    pwdthemesAdminInterface.setup_image_selectors();
		pwdthemesAdminInterface.setup_colourpickers();
		pwdthemesAdminInterface.setup_custom_typography();
		pwdthemesAdminInterface.setup_custom_ui_slider();
	
	});
  
})(jQuery);