<?php
/*-----------------------------------------------------------------------------------*/
/* Custom Post Type - Testimonials */
/*-----------------------------------------------------------------------------------*/

if ( ! function_exists( 'pwd_add_testimonials' ) ) {
	function pwd_add_testimonials() {		
		$labels = array(
			'name' => _x( 'Testimonials', 'post type general name', 'genesis' ),
			'singular_name' => _x( 'Testimonial', 'post type singular name', 'genesis' ),
			'add_new' => _x( 'Add New', 'slide', 'genesis' ),
			'add_new_item' => __( 'Add New Testimonial', 'genesis' ),
			'edit_item' => __( 'Edit Testimonial', 'genesis' ),
			'new_item' => __( 'New Testimonial', 'genesis' ),
			'view_item' => __( 'View Testimonial', 'genesis' ),
			'search_items' => __( 'Search Testimonials', 'genesis' ),
			'not_found' =>  __( 'No Testimonials found', 'genesis' ),
			'not_found_in_trash' => __( 'No Testimonials found in Trash', 'genesis' ), 
			'parent_item_colon' => ''
		);
		
		$args = array(
			'labels' => $labels,
			'public' => false,
			'publicly_queryable' => true,
			'exclude_from_search' => true, 
			'_builtin' => false,
			'show_ui' => true, 
			'query_var' => true,
			'rewrite' => true,
			'capability_type' => 'post',
			'hierarchical' => false,
			'menu_icon' => CHILD_THEME_ADMIN_URL .'/images/testimonials-icon.png',
			'menu_position' => null,
			'supports' => array( 'title', 'editor', 'thumbnail' ),
		);
		
		register_post_type( 'feedback', $args );

	} // End pwd_add_testimonials()
}

add_action( 'init', 'pwd_add_testimonials', 10 );

/*-----------------------------------------------------------------------------------*/
/* Custom Post Type - Portfolio Item */
/*-----------------------------------------------------------------------------------*/

if ( ! function_exists( 'pwd_add_portfolio' ) ) {
	function pwd_add_portfolio() {
	
		// "Portfolio Item" Custom Post Type
		$labels = array(
			'name' => _x( 'Portfolio', 'post type general name', 'genesis' ),
			'singular_name' => _x( 'Portfolio Item', 'post type singular name', 'genesis' ),
			'add_new' => _x( 'Add New', 'slide', 'genesis' ),
			'add_new_item' => __( 'Add New Portfolio Item', 'genesis' ),
			'edit_item' => __( 'Edit Portfolio Item', 'genesis' ),
			'new_item' => __( 'New Portfolio Item', 'genesis' ),
			'view_item' => __( 'View Portfolio Item', 'genesis' ),
			'search_items' => __( 'Search Portfolio Items', 'genesis' ),
			'not_found' =>  __( 'No portfolio items found', 'genesis' ),
			'not_found_in_trash' => __( 'No portfolio items found in Trash', 'genesis' ), 
			'parent_item_colon' => ''
		);
		
 		$portfolioitems_rewrite = 'portfolio-item'; 
		
		$args = array(
			'labels' => $labels,
			'public' => true,
			'publicly_queryable' => true,
			'show_ui' => true, 
			'query_var' => true,
			'rewrite' => array( 'slug' => $portfolioitems_rewrite ),
			'capability_type' => 'post',
			'hierarchical' => false,      
			'menu_icon' => CHILD_THEME_ADMIN_URL .'/images/portfolio.png',
			'menu_position' => null, 
			'has_archive' => true, 
			'taxonomies' => array( 'portfolio-gallery' ), 
			'supports' => array( 'title','editor','thumbnail' )
		);
		
		
		$args['exclude_from_search'] = true;
		
		register_post_type( 'portfolio', $args );
		
		// "Portfolio Galleries" Custom Taxonomy
		$labels = array(
			'name' => _x( 'Portfolio Galleries', 'taxonomy general name', 'genesis' ),
			'singular_name' => _x( 'Portfolio Gallery', 'taxonomy singular name','genesis' ),
			'search_items' =>  __( 'Search Portfolio Galleries', 'genesis' ),
			'all_items' => __( 'All Portfolio Galleries', 'genesis' ),
			'parent_item' => __( 'Parent Portfolio Gallery', 'genesis' ),
			'parent_item_colon' => __( 'Parent Portfolio Gallery:', 'genesis' ),
			'edit_item' => __( 'Edit Portfolio Gallery', 'genesis' ), 
			'update_item' => __( 'Update Portfolio Gallery', 'genesis' ),
			'add_new_item' => __( 'Add New Portfolio Gallery', 'genesis' ),
			'new_item_name' => __( 'New Portfolio Gallery Name', 'genesis' ),
			'menu_name' => __( 'Portfolio Galleries', 'genesis' )
		); 	
		
		$args = array(
			'hierarchical' => true,
			'labels' => $labels,
			'show_ui' => true,
			'query_var' => true,
      'show_admin_column' => true,
			'rewrite' => array( 'slug' => 'portfolio-gallery' )
		);
		
		register_taxonomy( 'portfolio-gallery', array( 'portfolio' ), $args );
	}
	
	add_action( 'init', 'pwd_add_portfolio' );
}

add_action( 'add_meta_boxes', 'pwd_add_custom_box' );
add_action( 'save_post', 'metabox_save', 1, 2 );
function pwd_add_custom_box(){
  add_meta_box('testimonials_details', __( 'Extra Settings', 'genesis' ), 'testimonails_meta_box', 'feedback', 'normal', 'high');
  add_meta_box('portfolio_details', __( 'Portfolio Settings', 'genesis' ), 'portfolio_meta_box', 'portfolio', 'normal', 'high');
}
function testimonails_meta_box(){
  include( dirname( __FILE__ ) . '/testimonials-metabox.php' );
}

function portfolio_meta_box(){
  include( dirname( __FILE__ ) . '/portfolio-metabox.php' );
}

function metabox_save( $post_id, $post ) {
  /** Run only on testimonials post type save */
	if ( 'feedback' == $post->post_type ) {
		/** Verify the nonce */
	    if ( ! wp_verify_nonce( $_POST['testimonials_metabox_nonce'], 'testimonials_metabox_save' ) )
	        return;

	    /** Don't try to save the data under autosave, ajax, or future post */
	    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
	    if ( defined( 'DOING_AJAX' ) && DOING_AJAX ) return;
	    if ( defined( 'DOING_CRON' ) && DOING_CRON ) return;

	    /** Check permissions */
	    if ( ! current_user_can( 'edit_post', $post_id ) )
	        return;

	    $tm_details = $_POST['tm'];

	    /** Store the custom fields */
	    foreach ( (array) $tm_details as $key => $value ) {
	        /** Save/Update/Delete */
	        if ( $value ) {
	            update_post_meta($post->ID, $key, $value);
	        } else {
	            delete_post_meta($post->ID, $key);
	        }
	    }
  }
  
   /** Run only on portfolio post type save */
	if ( 'portfolio' == $post->post_type ) {
		/** Verify the nonce */
	    if ( ! wp_verify_nonce( $_POST['portfolio_metabox_nonce'], 'portfolio_metabox_save' ) )
	        return;

	    /** Don't try to save the data under autosave, ajax, or future post */
	    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
	    if ( defined( 'DOING_AJAX' ) && DOING_AJAX ) return;
	    if ( defined( 'DOING_CRON' ) && DOING_CRON ) return;

	    /** Check permissions */
	    if ( ! current_user_can( 'edit_post', $post_id ) )
	        return;

	    $pf_details = $_POST['pf'];

	    /** Store the custom fields */
	    foreach ( (array) $pf_details as $key => $value ) {
	        /** Save/Update/Delete */
	        if ( $value ) {
	            update_post_meta($post->ID, $key, $value);
	        } else {
	            delete_post_meta($post->ID, $key);
	        }
	    }
  }
}  

/* Custom Post Type - Themes */
/*-----------------------------------------------------------------------------------*/

if ( ! function_exists( 'cpt_premium_theme' ) ) {
	function cpt_premium_theme() {
		
		$labels = array(
			'name' => _x( 'Themes', 'post type general name', 'pwd' ),
			'singular_name' => _x( 'Theme', 'post type singular name', 'pwd' ),
			'add_new' => _x( 'Add New', 'themes', 'pwd' ),
			'add_new_item' => __( 'Add New Theme', 'pwd' ),
			'edit_item' => __( 'Edit theme', 'pwd' ),
			'new_item' => __( 'New theme', 'pwd' ),
			'view_item' => __( 'View theme', 'pwd' ),
			'search_items' => __( 'Search themes', 'pwd' ),
			'not_found' =>  __( 'No themes found', 'pwd' ),
			'not_found_in_trash' => __( 'No themes found in Trash', 'pwd' ), 
			'parent_item_colon' => ''
		);
		
		$args = array(
			'labels' => $labels,
			'public' => true,
			'publicly_queryable' => true,
			'exclude_from_search' => false, 
			'_builtin' => false,
			'show_ui' => true, 
			'query_var' => true,
			'rewrite' => true,
			'capability_type' => 'post',
			'hierarchical' => false,
			'menu_icon' => CHILDTHEME_URL .'/images/layout-content-icon.png',
			'menu_position' => 10,
			'supports' => array( 'title', 'editor', 'thumbnail', 'custom-fields'/*, 'author', 'thumbnail', 'excerpt', 'comments'*/ ),
		);
		
		register_post_type( 'themes', $args );

	} // End cpt_premium_theme()
}
add_action( 'init', 'cpt_premium_theme', 10 );
add_action( 'init', 'cpt_premium_plugins', 15 );
/*-----------------------------------------------------------------------------------*/
/* Custom Post Type - PWD Plugins */
/*-----------------------------------------------------------------------------------*/

if ( ! function_exists( 'cpt_premium_plugins' ) ) {
	function cpt_premium_plugins() {
		
		$labels = array(
			'name' => _x( 'PWD Plugins', 'post type general name', 'pwd' ),
			'singular_name' => _x( 'PWD Plugin', 'post type singular name', 'pwd' ),
			'add_new' => _x( 'Add New', 'plugins', 'pwd' ),
			'add_new_item' => __( 'Add New Plugin', 'pwd' ),
			'edit_item' => __( 'Edit Plugin', 'pwd' ),
			'new_item' => __( 'New Plugin', 'pwd' ),
			'view_item' => __( 'View Plugins', 'pwd' ),
			'search_items' => __( 'Search Plugins', 'pwd' ),
			'not_found' =>  __( 'No plugins found', 'pwd' ),
			'not_found_in_trash' => __( 'No plugins found in Trash', 'pwd' ), 
			'parent_item_colon' => ''
		);
		
		$args = array(
			'labels' => $labels,
			'public' => false,
			'publicly_queryable' => true,
			'exclude_from_search' => true, 
			'_builtin' => false,
			'show_ui' => true, 
			'query_var' => true,
			'rewrite' => true,
			'capability_type' => 'post',
			'hierarchical' => false,
			'menu_position' => 10,
			'supports' => array( 'title', 'custom-fields', 'thumbnail'/*, 'author', 'thumbnail', 'excerpt', 'comments'*/ ),
		);
		
		register_post_type( 'plugins', $args );

	} // End indv_add_testimonials()
}
?>