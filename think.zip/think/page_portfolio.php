<?php
/**
 * Template Name: Portfolio
 *
 * The portfolio page template displays your portfolio items with
 * a switcher to quickly filter between the various portfolio galleries. 
 *
 * @package Genesis Framework
 * @subpackage Template
 */
 
add_action( 'genesis_entry_content', 'pwd_theme_portfolio');
/** Add support for Portfolio Loop **/
function pwd_theme_portfolio() {

  $args = array('post_type' => 'portfolio', 'posts_per_page' => -1);
  $prtf = new WP_Query($args);
    if( $prtf->have_posts() ){
      $counter = 0;
  ?>
  <div class="portfolio-items" id="showcase">
    <ul>
  <?php while( $prtf->have_posts() ) { $prtf->the_post(); ?>
   
    <li>
		  <div <?php post_class(); ?>>
  		<?php
        //if( $bestSelling == "yes") echo '<div class="top-product"></div>' . "\n";
  
  			$image = genesis_get_image( array(
                                    			'format'  => 'html',
                                    			'size'    => "theme-thumb",
                                    			'context' => 'archive',
                                    			'attr'    => array ( 'class' => 'alignnone post-image' )
                                    		) );
  			
  			if ( $image != '' ) {
  		?>
  			<a rel="permalink" title="<?php the_title(); ?>" href="<?php echo get_permalink( get_the_ID() ); ?>" class="thumb">
  				<?php echo $image; ?>
        </a>
        <div class="over">
  	      <h2><?php the_title() ?></h2>
          <p><?php echo get_post_meta(get_the_ID(), '_portfolio_excerpt', true); ?></p>
          <center><a href="<?php echo get_permalink( get_the_ID() ); ?>" class="css3_btn">View Details</a></center>
        </div>
      <?php } ?>
  		</div><!--/.group .post .portfolio-img-->
    </li>
    
  <?php $counter++; } ?>
  
    </ul>
  </div>
  
<?php 
  } 
  wp_reset_query();         
}
genesis();