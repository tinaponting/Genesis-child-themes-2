<?php
//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );

//* Child theme (do not remove)
define( 'CHILD_THEME_NAME', 'Think - HTML5 Responsive Child Theme' );
define( 'CHILD_THEME_URL', 'http://demo.pwdtechnology.com/think' );
define( 'CHILD_THEME_VERSION', '1.0' );
define( 'CHILD_THEME_ADMIN_DIR', CHILD_DIR . '/admin');
define( 'CHILD_THEME_ADMIN_URL', CHILD_URL . '/admin');

// Load Theme Options
require_once('admin/theme-options.php');

// Load admin
//require_once(CHILD_THEME_ADMIN_DIR . '/admin-functions.php');
require_once('admin/admin-interface.php');
require_once('admin/admin-medialibrary-uploader.php');
// Theme Custom Style
include_once( 'admin/theme-custom-style.php' );

// Theme Custom Post Types
include_once( 'admin/custom-post-types.php' );

/** Load Shortcode */
include( 'shortcodes/shortcodes.php' );  

//* Add HTML5 markup structure
add_theme_support( 'html5' );

//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

add_post_type_support( 'themes', 'genesis-layouts' );

/** Add support for footer widgets */
add_theme_support( 'genesis-footer-widgets', ( get_option('pwd_footer_sidebars') ? get_option('pwd_footer_sidebars') : 3) );

add_filter( 'genesis_post_meta', 'pwd_post_meta_filter' );
function pwd_post_meta_filter($post_meta) {
    $post_meta = '[post_tags before="<i class=\'fa fa-tags\'><\/i> Tagged: "]';
    return $post_meta;
}

//* Modify the comment link text in comments
add_filter( 'genesis_post_info', 'post_info_filter' );
function post_info_filter( $post_info ) {     
   global $post;

   if ( 'page' === get_post_type( $post->ID ) )
     return;

     return '[post_date before="<i class=\'fa fa-clock-o\'><\/i> "] [post_author before="<i class=\'fa fa-user\'><\/i> "] [post_categories before="<i class=\'fa fa-inbox\'><\/i> &nbsp;"] [post_comments before="<i class=\'fa fa-comment-o\'><\/i> " zero="0 Comment" one="1 Comment" more="% Comments" hide_if_off="disabled"]';
}

function custom_excerpt_more( $more ) {
	return '...<a href="'.get_permalink().'" title="Read More" class="read-more">Read More &rarr;</a>';
}
add_filter( 'excerpt_more', 'custom_excerpt_more' );
add_filter( 'get_the_content_more_link', 'custom_excerpt_more' );

add_action( 'genesis_entry_footer', 'genesis_prev_next_post_nav');

// Customize the footer text
remove_action( 'genesis_footer', 'genesis_do_footer' );
add_action( 'genesis_footer', 'genesis_child_theme_do_footer' );

function genesis_child_theme_do_footer(){
  $left_text = get_option('pwd_footer_left_text');
  $right_text = get_option('pwd_footer_right_text');
  
  if(($left_text != '<p></p>') && ($left_text != '') ) $left_text = '<div class="footer-left">' . $left_text . '</div>' . "\n";
  if(($right_text != '<p></p>') && ($right_text != '') )$right_text = '<div class="footer-right">' . $right_text . '</div>' . "\n";
  
  $output = $left_text . $right_text;
  
  if( ($left_text == '<p></p>') && ($right_text == '<p></p>')){
    $creds_text     = sprintf( '[footer_copyright before="%s "] &#x000B7; [footer_childtheme_link before="" after=" %s"] [footer_genesis_link url="http://www.studiopress.com/" before=""] &#x000B7; [footer_wordpress_link]', __( 'Copyright', 'genesis' ), __( 'on', 'genesis' ) );
    $creds_text     = apply_filters( 'genesis_footer_creds_text', $creds_text );
    
    $creds          = $creds_text ? sprintf( '<div class="creds"><p>%s</p></div>', $creds_text ) : '';
  
  	//* Only use credits if HTML5
  	if ( genesis_html5() )
  		$output = '<p>' . $creds_text . '</p>';
  }
  
  echo apply_filters( 'genesis_footer_output', $output, $left_text, $right_text );
}

add_filter('genesis_favicon_url', 'customFavicon');
function customFavicon($favicon){
   if( get_option('pwd_custom_favicon') != '' )
    $favicon = get_option('pwd_custom_favicon');
    
  return $favicon;
}

function add_body_class_header_image( $classes ) {
		$classes[] = 'header-image';
		return $classes;
}

/** Change the number of Portfolio items to be displayed */
add_action( 'pre_get_posts', 'pwd_portfolio_items' );
function pwd_portfolio_items( $query ) {

	if( $query->is_main_query() && !is_admin() && is_post_type_archive( 'portfolio' ) ) {
		$query->set( 'posts_per_page', '8' );
	}

}

//* Add new image size
add_image_size( 'featured', 740, 400, TRUE );
add_image_size( 'widget-featured', 300, 200, TRUE );
add_image_size( 'square-thumb', 400, 400, TRUE );
add_image_size( 'grid-featured', 360, 170, TRUE );
add_image_size( 'plugin-thumb', 210, 210, TRUE );
add_image_size( 'theme-thumb', 255, 255, TRUE );

/** Register widget areas */
genesis_register_sidebar( array(
    'id'            => 'home-top',
    'name'          => __( 'Home Top', 'think' ),
    'description'   => __( 'This is a widget area that can be shown above the headre on Home Page', 'think' ),
) );

genesis_register_sidebar( array(
    'id'            => 'home-middle',
    'name'          => __( 'Home Middle', 'think' ),
    'description'   => __( 'This is a widget area that can be shown below the navigation bar on Home Page', 'think' ),
) );

genesis_register_sidebar( array(
    'id'            => 'home-bottom',
    'name'          => __( 'Home Bottom', 'think' ),
    'description'   => __( '', 'think' ),
) );

genesis_register_sidebar( array(
    'id'            => 'single-post-bottom',
    'name'          => __( 'Single Post', 'think' ),
    'description'   => __( 'This is a widget area that can be shown below the single post content on Single Post Page', 'think' ),
) );

genesis_register_sidebar( array(
    'id'            => 'theme-info',
    'name'          => __( 'Theme Info', 'think' ),
    'description'   => __( 'This is a widget area that can be shown below the theme details page.', 'think' ),
) );

add_action('wp_footer', 'footer_items');
function footer_items(){
  //echo '<a id="gotop" href="#site-container">Top of Page</a>';
  echo '<link type="text/css" rel="stylesheet" href="' . CHILD_THEME_ADMIN_URL . '/font-awesome/css/font-awesome.min.css"/>' . "\n";
  if( get_option('pwd_google_analytics') != "" )
    echo get_option('pwd_google_analytics');
  wp_register_script( 'hcsticky', get_bloginfo('stylesheet_directory') . '/js/jquery.hcsticky-min.js', array( 'jquery' ) );    
  wp_register_script( 'think', get_bloginfo('stylesheet_directory') . '/js/think.js', array( 'jquery' ) );
  wp_enqueue_script( 'hcsticky' );
  wp_enqueue_script( 'think' );
}

add_action('genesis_entry_footer', 'singlePostSidebar');
function singlePostSidebar(){
  if( is_active_sidebar('single-post-bottom') && ( is_single() && ( get_post_type() == "post" ) ) ){
    echo '<div class="single_post_sidebar">' . "\n";
    dynamic_sidebar('single-post-bottom');
    echo '</div>' . "\n";
  }
}

add_action('genesis_entry_footer', 'themeInfo', 16);
function themeInfo(){
  if( is_active_sidebar('theme-info') && ( is_single() && ( get_post_type() == "themes" ) ) ){
    echo '<div class="theme-info clearfix">' . "\n";
    dynamic_sidebar('theme-info');
    echo '</div>' . "\n";
  }
}

function list_thumbnail_sizes(){
    global $_wp_additional_image_sizes;
    $sizes = $img_sizes =array();
 		foreach( get_intermediate_image_sizes() as $s ){
 			$sizes[ $s ] = array( 0, 0 );
 			if( in_array( $s, array( 'thumbnail', 'medium', 'large' ) ) ){
 				$sizes[ $s ][0] = get_option( $s . '_size_w' );
 				$sizes[ $s ][1] = get_option( $s . '_size_h' );
 			}else{
 				if( isset( $_wp_additional_image_sizes ) && isset( $_wp_additional_image_sizes[ $s ] ) )
 					$sizes[ $s ] = array( $_wp_additional_image_sizes[ $s ]['width'], $_wp_additional_image_sizes[ $s ]['height'], );
 			}
 		}
 
 		foreach( $sizes as $size => $atts ){
      $size_title = ucwords(str_replace("-"," ", $size));
      $img_sizes[$size] =  $size_title . ' (' . implode( 'x', $atts ) . ')';
 		}
    
    return $img_sizes;
}
//* Enqueue scripts and styles
add_action( 'wp_enqueue_scripts', 'pwd_enqueue_scripts' );
function pwd_enqueue_scripts() {  
  if( is_singular('post') )
     wp_enqueue_script( 'gumroad-js', 'https://gumroad.com/js/gumroad.js', array(), '1.0.0' ); 	
}