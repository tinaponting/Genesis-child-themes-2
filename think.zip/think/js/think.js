jQuery(document).ready( function(){    
    
    jQuery("header .genesis-nav-menu").addClass("responsive-menu").before('<div id="responsive-menu-icon"><i class="fa fa-bars"></i></div>');
    jQuery(".nav-primary .genesis-nav-menu").addClass("responsive-menu").before('<div id="responsive-menu-primary-icon"><i class="fa fa-bars"></i> Primary Navigation</div>');
	
  	jQuery("#responsive-menu-icon").click(function(){
  		jQuery("header .genesis-nav-menu").slideToggle();
  	});
    
    jQuery("#responsive-menu-primary-icon").click(function(){
  		jQuery(".nav-primary .genesis-nav-menu").slideToggle();
  	});
    
    if ( window.innerWidth > 1023 ) {
      //leftPanelHeight();
      // Fixed Header
  		jQuery('.site-header').hcSticky({
  			className: 'stuck'
  		});
    }
        
    jQuery(window).resize(function() {
    	if ( window.innerWidth > 1023 ) {
        //leftPanelHeight();
        // Fixed Header
    		jQuery('.site-header').hcSticky({
    			className: 'stuck'
    		});
      }
      
      if(window.innerWidth > 768) {
  			jQuery("header .genesis-nav-menu, .nav-primary .genesis-nav-menu").removeAttr("style");
  		}
    });

    function leftPanelHeight(){
    	setTimeout(function(){
    		jQuery('.sidebar').css('height','');
    		jQuery('.content').css('height','');
    		var pan  = jQuery('.sidebar').innerHeight();
    		var con  = jQuery('.content').innerHeight();
    		//var serp = jQuery('.search-panel').height();
    		var res;
    
    		/*if (pan < serp) {
    			jQuery('#sidebar').height(serp+78+con)
    		}
    		else {*/
    			if (pan < con) {
    				jQuery('.sidebar').height(con);
    			}
    			else {
    				jQuery('.content').height(pan);
    			}
    		//}
    	},0);
    }
    
    jQuery('.over').stop().animate({ "opacity": 0 }, 0);
   	function over() {
  		jQuery('.over').hover(function() {
  			jQuery(this).stop().animate({ "opacity": .98 }, 250);
  		}, function() {
  			jQuery(this).stop().animate({ "opacity": 0 }, 250);
  		});	
  	}
  	
  	over();

});