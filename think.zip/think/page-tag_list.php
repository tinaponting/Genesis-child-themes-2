<?php
/*
Template Name: Tag Index
 */

//* Remove standard post content output
/*remove_action( 'genesis_post_content', 'genesis_do_post_content' );
remove_action( 'genesis_entry_content', 'genesis_do_post_content' );

add_action( 'genesis_entry_content', 'sk_page_archive_content' );
add_action( 'genesis_post_content', 'sk_page_archive_content' );*/

add_filter( 'the_content', 'sk_page_archive_content'); 
/**
 * This function outputs posts grouped by year and then by months in descending order.
 *
 */
function sk_page_archive_content($content) {

     global $post;
     // Make an array from A to Z.
$characters = range('A','Z');

// Retrieve all tags
$getTags = get_tags( array( 'order' => 'ASC') );

// Retrieve first letter from tag name
$isFirstCharLetter = ctype_alpha(substr($getTags[0]->name, 0, 1));

// Special Character and Number Loop
// Run a check to see if the first tag starts with a letter
// If it does not, run this
if ( $isFirstCharLetter == false ){

     // Print a number container
     $html .= "<div class='tag-group'>";
     $html .= "<h3 class='tag-title'>#</h3>";
     $html .= "<ul class='tag-list'>";

     // Special Character/Number Loop
     while( $isFirstCharLetter == false ){

          // Get the current tag
          $tag = array_shift($getTags);

          // Get the current tag link
          $tag_link = get_tag_link($tag->term_id);

          // Print List Item
          $html .= "<li class='tag-item'>";

          // Check to see how many tags exist for the current letter then print appropriate code
        if ( $tag->count > 1 ) {
            $html .= "<p><a href='{$tag_link}' title='View all {$tag->count} articles with the tag of {$tag->name}' class='{$tag->slug}'>";
        } else {
            $html .= "<p><a href='{$tag_link}' title='View the article tagged {$tag->name}' class='{$tag->slug}'>";
        }

        // Print tag name and count then close the list item
          $html .= "<span class='tag-name'>{$tag->name}</span></a><span class='tag-count'>({$tag->count})</span></p>";
          $html .= "</li>";

          // Retrieve first letter from tag name
          // Need to redefine the global variable since we are shifting the array
          $isFirstCharLetter = ctype_alpha(substr($getTags[0]->name, 0, 1));

     }

     // Close the containers
     $html .= "</ul>";
     $html .= "</div>";
}

// Letter Loop
do {

     // Get the right letter
     $currentLetter = array_shift($characters);

     // Print stuff
     $html .= "<div class='tag-group'>";
     $html .= "<div class='tag-title' id='{$currentLetter}'>{$currentLetter}</div>";
     $html .= "<ul class='tag-list'>";

     // While we have tags, run this loop
     while($getTags){

          // Retrieve first letter from tag name
          $firstChar = substr($getTags[0]->name, 0, 1);

          // Does the first letter match the current letter?
          // Check both upper and lowercase characters for true
          if ( strcasecmp($currentLetter, $firstChar) == 0 ){

               // Get the current tag
               $tag = array_shift($getTags);

               // Get the current tag link
               $tag_link = get_tag_link($tag->term_id);

               // Print stuff
               $html .= "<li class='tag-item'>";

               // Check to see how many tags exist for the current letter then print appropriate code
            if ( $tag->count > 1 ) {
                $html .= "<p><a href='{$tag_link}' title='View all {$tag->count} articles with the tag of {$tag->name}' class='{$tag->slug}'>";
            } else {
                $html .= "<p><a href='{$tag_link}' title='View the article tagged {$tag->name}' class='{$tag->slug}'>";
            }

            // Print more stuff
               $html .= "<span class='tag-name'>{$tag->name}</span></a><span class='tag-count'>({$tag->count})</span></p>";
               $html .= "</li>";

          } else {
               break 1;
          }
     }

     $html .= "</ul>";
     $html .= "</div>";
} while ( $characters ); // Will loop over each character in the array

  // Let's see what we got:
  if( $html )
   $content .= $html;

  return $content;
}

remove_action( 'genesis_entry_footer', 'genesis_entry_footer_markup_open', 5 );
remove_action( 'genesis_entry_footer', 'genesis_post_meta' );
remove_action( 'genesis_entry_footer', 'genesis_entry_footer_markup_close', 15 );

genesis();