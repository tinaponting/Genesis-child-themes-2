<?php
/** 
 * Template Name: Grid Layout
 * @author: PWDTechnology 
 **/
 
remove_action( 'genesis_loop', 'genesis_do_loop' );
add_action( 'genesis_loop', 'pwd_grid_layout');

/** Add support for Genesis Grid Loop **/
function pwd_grid_layout() {

	if ( function_exists( 'genesis_grid_loop' ) ) {
		//remove_action( 'genesis_before_post_content', 'generate_post_image', 5 );
    $paged   = get_query_var( 'paged' ) ? get_query_var( 'paged' ) : 1;
    $query_args = wp_parse_args(
        			             genesis_get_custom_field( 'query_args' ),
                           array('post_type' => 'post', 'paged' => $paged)
                         );
    $grid_args = array(
            			'features' => 0,
            			'feature_image_size' => 'featured',
            			'feature_image_class' => get_option('pwd_grid_f_align') .' post-image',
            			'feature_content_limit' => get_option('pwd_grid_featured_post_content_limit'),
            			'grid_image_size' => (get_option('pwd_grid_image_size') ? get_option('pwd_grid_image_size') : 'grid-featured'),
            			'grid_image_class' => get_option('pwd_grid_b_align') . ' post-image',
            			'grid_content_limit' => get_option('pwd_grid_post_content_limit'),
            			'more' => __( 'Continue reading', 'genesis' ) . '&rarr;',
            		);
		//* Global vars
  	global $_genesis_loop_args;
  
  	//* Parse args
  	$args = apply_filters(
  		'genesis_grid_loop_args',
  		wp_parse_args(
  			$grid_args,
  			array(
  				'features'				=> 2,
  				'features_on_all'		=> false,
  				'feature_image_size'	=> 0,
  				'feature_image_class'	=> 'alignleft',
  				'feature_content_limit'	=> 0,
  				'grid_image_size'		=> 'thumbnail',
  				'grid_image_class'		=> 'alignleft',
  				'grid_content_limit'	=> 0,
  				'more'					=> __( 'Read more', 'genesis' ) . '&#x02026;',
  			)
  		)
  	);
  
  	//* If user chose more features than posts per page, adjust features
  	if ( get_option( 'posts_per_page' ) < $args['features'] ) {
  		$args['features'] = get_option( 'posts_per_page' );
  	}
  
  	//* What page are we on?
  	$paged = get_query_var( 'paged' ) ? get_query_var( 'paged' ) : 1;
  
  	//* Potentially remove features on page 2+
  	if ( ! $args['features_on_all'] && $paged > 1 )
  		$args['features'] = 0;
  
  	//* Set global loop args
  	$_genesis_loop_args = $args;
  
  	//* Remove some unnecessary stuff from the grid loop
  	remove_action( 'genesis_before_post_title', 'genesis_do_post_format_image' );
  	remove_action( 'genesis_post_content', 'genesis_do_post_image' );
  	remove_action( 'genesis_post_content', 'genesis_do_post_content' );
  	remove_action( 'genesis_post_content', 'genesis_do_post_content_nav' );
  	
  	remove_action( 'genesis_entry_header', 'genesis_do_post_format_image', 4 );
  	remove_action( 'genesis_entry_content', 'genesis_do_post_image', 8 );
  	remove_action( 'genesis_entry_content', 'genesis_do_post_content' );
  	remove_action( 'genesis_entry_content', 'genesis_do_post_content_nav', 12 );
  	remove_action( 'genesis_entry_content', 'genesis_do_post_permalink', 14 );  
  
  	//* Custom loop output
  	add_filter( 'post_class', 'genesis_grid_loop_post_class' );
  	add_action( 'genesis_post_content', 'genesis_grid_loop_content' );
  	add_action( 'genesis_entry_content', 'genesis_grid_loop_content' );
    
    remove_action( 'genesis_entry_header', 'genesis_post_info', 12 );
    remove_action( 'genesis_entry_footer', 'genesis_post_meta');
    add_action( 'genesis_entry_footer', 'genesis_post_info', 12 );
    remove_filter( 'genesis_post_info', 'post_info_filter' );
  
  	//* The loop
  	genesis_custom_loop($query_args);
  
  	//* Reset loops
  	genesis_reset_loops();
  	remove_filter( 'post_class', 'genesis_grid_loop_post_class' );
  	remove_action( 'genesis_post_content', 'genesis_grid_loop_content' );
  	remove_action( 'genesis_entry_content', 'genesis_grid_loop_content' );
    
    

	} else {
		genesis_standard_loop();
	}
}

add_filter( 'body_class', 'add_body_class' );

function add_body_class( $classes ) {
		$classes[] = 'custom_grid_layout';
		return $classes;
}

//* Modify the comment link text in comments
add_filter( 'genesis_post_info', 'gird_post_info_filter' );
function gird_post_info_filter( $post_info ) {          
  return '[post_date before="<i class=\'fa fa-clock-o\'><\/i> "] [post_categories before="<i class=\'fa fa-inbox\'><\/i> &nbsp;"]';
}

genesis();