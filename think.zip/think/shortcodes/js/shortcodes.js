jQuery(function($) {
	
/*-----------------------------------------------------------------------------------
  Tabs shortcode
-----------------------------------------------------------------------------------*/
	
	if ( jQuery( '.pwd-shortcode-tabs' ).length ) {	
		
		jQuery( '.pwd-shortcode-tabs' ).each( function () {
		
			var tabCount = 1;
		
			jQuery(this).children( '.tab' ).each( function ( index, element ) {
			
				var idValue = jQuery( this ).parents( '.pwd-shortcode-tabs' ).attr( 'id' );
			
				var newId = idValue + '-tab-' + tabCount;
			
				jQuery( this ).attr( 'id', newId );
				
				jQuery( this ).parents( '.pwd-shortcode-tabs' ).find( 'ul.tab_titles' ).children( 'li' ).eq( index ).find( 'a' ).attr( 'href', '#' + newId );
				
				tabCount++;
			
			});
		
			var thisID = jQuery( this ).attr( 'id' );
		
			var tabber = jQuery( this ).tabs( { fx: { opacity: 'toggle', duration: 400 } } );
		
			// Check for a matching hash and select that tab if one is found.
			var currentHash = window.location.hash;
			currentHash = currentHash.replace( '#', '' );
			if ( currentHash != '' ) {
				tabber.tabs( 'select', currentHash );
			}
		});


	} // End IF Statement
	
/*-----------------------------------------------------------------------------------
  Toggle shortcode
-----------------------------------------------------------------------------------*/
	jQuery(".toggle-container").hide();
  jQuery(".trigger").toggle(function(){
		jQuery(this).addClass("active");
		}, function () {
		jQuery(this).removeClass("active");
	}); 
	jQuery(".trigger").click(function(){
		jQuery(this).next(".toggle-container").slideToggle();
	});

	jQuery('.trigger a').hover(function() {
						jQuery(this).stop(true,false).animate({color: '#666'},50);
							}, function () {
							jQuery(this).stop(true,false).animate({color: '#888'},150);
	});

/*-----------------------------------------------------------------------------------
  Accordion shortcode
-----------------------------------------------------------------------------------*/  
  
  jQuery('.accordion').hide();
  jQuery('.trigger-button').click(function() {
      jQuery(".trigger-button").removeClass("active")
			jQuery('.accordion').slideUp('normal');
			if(jQuery(this).next().is(':hidden') == true) {
				jQuery(this).next().slideDown('normal');
				jQuery(this).addClass("active");
			 }
	});

  jQuery('.trigger-button').hover(function() {
		jQuery(this).stop(true,false).animate({color: '#666'},50);
			}, function () {
			jQuery(this).stop(true,false).animate({color: '#888'},150);
	});			
  
  jQuery('.testimonials_slider').bxSlider({
    mode: 'vertical',
    speed: 1200,
    minSlides: 1,
    maxSlides: 1,
    slideMargin: 10,
    pager: false,
    controls: true,
    auto: true,
		pause: 15000
  });
  
  var animate = $("#progress");
  animate.removeClass('display-none').addClass("display");
	
}); // jQuery()