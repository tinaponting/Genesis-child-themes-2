<?php
// File Security Check
if ( ! defined( 'ABSPATH' ) ) exit;
?>
<?php
// Enable shortcodes in WP Text widget
add_filter('widget_text', 'do_shortcode');

// Load Shortcode CSS
if ( ! function_exists( 'pwdtheme_shortcode_stylesheet' ) ) {
	function pwdtheme_shortcode_stylesheet() {
		echo "\n" . "<!-- Premium Genesis Child Theme Shortcodes CSS -->\n";
		echo '<link href="'. CHILD_URL . '/shortcodes/shortcodes.css" rel="stylesheet" type="text/css" />'."\n";
    echo '<link href="'. CHILD_URL . '/shortcodes/jquery.bxslider.css" rel="stylesheet" type="text/css" />'."\n";
	} // End woo_shortcode_stylesheet()
} 

add_action( 'wp_footer', 'pwdtheme_shortcode_stylesheet', 10 );
add_action( 'wp_print_scripts', 'pwdtheme_register_shortcode_js', 10 );

function pwdtheme_register_shortcode_js () {
	wp_register_script( 'pwdtheme-shortcodes', CHILD_URL . '/shortcodes/js/shortcodes.js', array( 'jquery', 'jquery-ui-tabs' ), '1.0.0' );
  wp_register_script( 'pwdtheme-shortcodes-bxslider', CHILD_URL . '/shortcodes/js/jquery.bxslider.js', array( 'jquery' ), '1.0.0' );
} // End pwdtheme_register_shortcode_js()


add_action( 'wp_footer', 'pwdtheme_enqueue_shortcode_js', 10 );

function pwdtheme_enqueue_shortcode_js () {
	if ( ! is_admin() && defined( 'PWD_SHORTCODE_JS' ) ) {
		wp_enqueue_script( 'pwdtheme-shortcodes' );
    wp_enqueue_script( 'pwdtheme-shortcodes-bxslider' );
	}
} // End woo_enqueue_shortcode_js()

// Replace WP autop formatting
if ( ! function_exists( 'pwdtheme_remove_wpautop' ) ) {
	function pwdtheme_remove_wpautop( $content ) {
		$content = do_shortcode( shortcode_unautop( $content ) );
		$content = preg_replace( '#^<\/p>|^<br \/>|<p>$#', '', $content );
		return $content;
	} // End pwdtheme_remove_wpautop()
}

/*-----------------------------------------------------------------------------------*/
/* 1. Boxes - box
/*-----------------------------------------------------------------------------------*/
/*

Optional arguments:
 - type: info, alert, tick, download, note
 - size: medium, large
 - style: rounded
 - border: none, full
 - icon: none OR full URL to a custom icon

*/
function pwdtheme_shortcode_box( $atts, $content = null ) {
   extract( shortcode_atts( array(	'type' => 'normal',
                   									'size' => '',
                   									'style' => '',
                   									'border' => '',
                   									'icon' => '' ), $atts ) );

   	$custom = '';
   	if ( $icon == 'none' )
   		$custom = ' style="padding-left:15px;background-image:none;"';
   	elseif ( $icon )
   		$custom = ' style="padding-left:50px;background-image:url( ' . esc_attr( esc_url( $icon ) ) . ' ); background-repeat:no-repeat; background-position:20px 45%;"';

   	return '<div class="pwdtheme-sc-box ' . esc_attr( $type ) . ' ' . esc_attr( $size ) . ' ' . esc_attr( $style ) . ' ' . esc_attr( $border ) . '"' . $custom . '>' . wp_kses_post( do_shortcode( woo_remove_wpautop( $content ) ) ) . '</div>';
} // End woo_shortcode_box()

add_shortcode( 'box', 'pwdtheme_shortcode_box' );

/*-----------------------------------------------------------------------------------*/
/* 2. Columns
/*-----------------------------------------------------------------------------------*/

/* ============= Two Columns ============= */

function pwdtheme_shortcode_one_half($atts, $content = null) {
   extract(shortcode_atts( array('first' => 'no'),$atts) );
   if($first == "no"){ $class = "one-half"; } else { $class = "one-half first"; }
   return '<div class="' . $class . '">' . pwdtheme_remove_wpautop($content) . '</div>';
}
add_shortcode( 'one_half', 'pwdtheme_shortcode_one_half' );

/* ============= Three Columns ============= */

function pwdtheme_shortcode_one_third($atts, $content = null) {
   extract(shortcode_atts( array('first' => 'no'),$atts) );
   if($first == "no"){ $class = "one-third"; } else { $class = "one-third first"; }
   
   return '<div class="' . $class . '">' . pwdtheme_remove_wpautop($content) . '</div>';
}
add_shortcode( 'one_third', 'pwdtheme_shortcode_one_third' );

function pwdtheme_shortcode_two_thirds($atts, $content = null) {
   extract(shortcode_atts( array('first' => 'no'),$atts) );
   if($first == "no"){ $class = "two-thirds"; } else { $class = "two-thirds first"; }
   
   return '<div class="' . $class . '">' . pwdtheme_remove_wpautop($content) . '</div>';
}
add_shortcode( 'two_thirds', 'pwdtheme_shortcode_two_thirds' );

/* ============= Four Columns ============= */

function pwdtheme_shortcode_one_fourth($atts, $content = null) {
   extract(shortcode_atts( array('first' => 'no'),$atts) );
   if($first == "no"){ $class = "one-fourth"; } else { $class = "one-fourth first"; }
   
   return '<div class="' . $class . '">' . pwdtheme_remove_wpautop($content) . '</div>';
}
add_shortcode( 'one_fourth', 'pwdtheme_shortcode_one_fourth' );

function pwdtheme_shortcode_two_fourths($atts, $content = null) {
   extract(shortcode_atts( array('first' => 'no'),$atts) );
   if($first == "no"){ $class = "two-fourths"; } else { $class = "two-fourths first"; }
   return '<div class="' . $class . '">' . pwdtheme_remove_wpautop($content) . '</div>';
}
add_shortcode( 'two_fourths', 'pwdtheme_shortcode_two_fourths' );

function pwdtheme_shortcode_three_fourths($atts, $content = null) {
   extract(shortcode_atts( array('first' => 'no'),$atts) );
   if($first == "no"){ $class = "three-fourths"; } else { $class = "three-fourths first"; }
   return '<div class="' . $class . '">' . pwdtheme_remove_wpautop($content) . '</div>';
}
add_shortcode( 'three_fourths', 'pwdtheme_shortcode_three_fourths' );

/* ============= Five Columns ============= */

function pwdtheme_shortcode_fivecol_one($atts, $content = null) {
   return '<div class="fivecol-one">' . pwdtheme_remove_wpautop($content) . '</div>';
}
add_shortcode( 'fivecol_one', 'pwdtheme_shortcode_fivecol_one' );

function pwdtheme_shortcode_fivecol_one_last($atts, $content = null) {
   return '<div class="fivecol-one last">' . pwdtheme_remove_wpautop($content) . '</div>';
}
add_shortcode( 'fivecol_one_last', 'pwdtheme_shortcode_fivecol_one_last' );

function pwdtheme_shortcode_fivecol_two($atts, $content = null) {
   return '<div class="fivecol-two">' . pwdtheme_remove_wpautop($content) . '</div>';
}
add_shortcode( 'fivecol_two', 'pwdtheme_shortcode_fivecol_two' );

function pwdtheme_shortcode_fivecol_two_last($atts, $content = null) {
   return '<div class="fivecol-two last">' . pwdtheme_remove_wpautop($content) . '</div>';
}
add_shortcode( 'fivecol_two_last', 'pwdtheme_shortcode_fivecol_two_last' );

function pwdtheme_shortcode_fivecol_three($atts, $content = null) {
   return '<div class="fivecol-three">' . pwdtheme_remove_wpautop($content) . '</div>';
}
add_shortcode( 'fivecol_three', 'pwdtheme_shortcode_fivecol_three' );

function pwdtheme_shortcode_fivecol_three_last($atts, $content = null) {
   return '<div class="fivecol-three last">' . pwdtheme_remove_wpautop($content) . '</div>';
}
add_shortcode( 'fivecol_three_last', 'pwdtheme_shortcode_fivecol_three_last' );

function pwdtheme_shortcode_fivecol_four($atts, $content = null) {
   return '<div class="fivecol-four">' . pwdtheme_remove_wpautop($content) . '</div>';
}
add_shortcode( 'fivecol_four', 'pwdtheme_shortcode_fivecol_four' );

function pwdtheme_shortcode_fivecol_four_last($atts, $content = null) {
   return '<div class="fivecol-four last">' . pwdtheme_remove_wpautop($content) . '</div>';
}
add_shortcode( 'fivecol_four_last', 'pwdtheme_shortcode_fivecol_four_last' );


/* ============= Six Columns ============= */

function pwdtheme_shortcode_one_sixth($atts, $content = null) {
   extract(shortcode_atts( array('first' => 'no'),$atts) );
   if($first == "no"){ $class = "one-sixth"; } else { $class = "one-sixth first"; }
   
   return '<div class="' . $class . '">' . pwdtheme_remove_wpautop($content) . '</div>';
}
add_shortcode( 'one_sixth', 'pwdtheme_shortcode_one_sixth' );

function pwdtheme_shortcode_two_sixths($atts, $content = null) {
   extract(shortcode_atts( array('first' => 'no'),$atts) );
   if($first == "no"){ $class = "two-sixths"; } else { $class = "two-sixths first"; }
   
   return '<div class="' . $class . '">' . pwdtheme_remove_wpautop($content) . '</div>';
}
add_shortcode( 'two_sixths', 'pwdtheme_shortcode_two_sixths' );

function pwdtheme_shortcode_three_sixths($atts, $content = null) {
   extract(shortcode_atts( array('first' => 'no'),$atts) );
   if($first == "no"){ $class = "three-sixths"; } else { $class = "three-sixths first"; }
   
   return '<div class="' . $class . '">' . pwdtheme_remove_wpautop($content) . '</div>';
}
add_shortcode( 'three_sixths', 'pwdtheme_shortcode_three_sixths' );

function pwdtheme_shortcode_four_sixths($atts, $content = null) {
   extract(shortcode_atts( array('first' => 'no'),$atts) );
   if($first == "no"){ $class = "four-sixths"; } else { $class = "four-sixths first"; }
   
   return '<div class="' . $class . '">' . pwdtheme_remove_wpautop($content) . '</div>';
}
add_shortcode( 'four_sixths', 'pwdtheme_shortcode_four_sixths' );

function pwdtheme_shortcode_five_sixths($atts, $content = null) {
   extract(shortcode_atts( array('first' => 'no'),$atts) );
   if($first == "no"){ $class = "five-sixths"; } else { $class = "five-sixths first"; }
   
   return '<div class="' . $class . '">' . pwdtheme_remove_wpautop($content) . '</div>';
}
add_shortcode( 'five_sixths', 'pwdtheme_shortcode_five_sixths' );

/*-----------------------------------------------------------------------------------*/
/* 3. Dropcap - [dropcap][/dropcap]
/*-----------------------------------------------------------------------------------*/

function pwdtheme_shortcode_dropcap ( $atts, $content = null ) {
	$defaults = array();

	extract( shortcode_atts( $defaults, $atts ) );

	return '<span class="dropcap">' . $content . '</span><!--/.dropcap-->';
} // End pwdtheme_shortcode_dropcap()

function pwdtheme_shortcode_dropcap_circle ( $atts, $content = null ) {
	$defaults = array();

	extract( shortcode_atts( $defaults, $atts ) );

	return '<span class="dropcap-circle">' . $content . '</span><!--/.dropcap-circle-->';
} // End pwdtheme_shortcode_dropcap()

add_shortcode( 'dropcap', 'pwdtheme_shortcode_dropcap' );
add_shortcode( 'dropcap_circle', 'pwdtheme_shortcode_dropcap_circle' );

/*-----------------------------------------------------------------------------------*/
/* 4. Highlight - [highlight][/highlight]
/*-----------------------------------------------------------------------------------*/

function pwdtheme_shortcode_highlight ( $atts, $content = null ) {
	$defaults = array();

	extract( shortcode_atts( $defaults, $atts ) );

	return '<span class="shortcode-highlight">' . $content . '</span><!--/.shortcode-highlight-->';
} // End pwdtheme_shortcode_highlight()

add_shortcode( 'highlight', 'pwdtheme_shortcode_highlight' );

/*-----------------------------------------------------------------------------------*/
/* 5. Horizontal Rule / Divider - hr - divider
/*-----------------------------------------------------------------------------------*/
/*
Description: Use to separate text.
*/
function pwdtheme_shortcode_hr($atts, $content = null) {
   return '<div class="pwdtheme-sc-hr"></div>';
} // End pwdtheme_shortcode_hr()
add_shortcode( 'hr', 'pwdtheme_shortcode_hr' );

function pwdtheme_shortcode_divider($atts, $content = null) {
   return '<div class="pwdtheme-sc-divider"></div>';
} // End pwdtheme_shortcode_divider()
add_shortcode( 'divider', 'pwdtheme_shortcode_divider' );

function pwdtheme_shortcode_divider_flat($atts, $content = null) {
   return '<div class="pwdtheme-sc-divider flat"></div>';
} // End pwdtheme_shortcode_divider_flat()
add_shortcode( 'divider_flat', 'pwdtheme_shortcode_divider_flat' );

function pwd_shortcode_button( $atts, $content = null ) {
   	extract( shortcode_atts( array(	'size' => '',
   									'style' => '',
   									'bg_color' => '',
   									'color' => '',
   									'border' => '',
   									'text' => '',
   									'class' => '',
   									'link' => '#',
   									'window' => '' ), $atts ) );


   	// Set custom background and border color
   	$color_output = '';
   	if ( $color ) {
   		$preset_colors = array( 'red', 'orange', 'green', 'aqua', 'teal', 'purple', 'pink', 'silver' );
   		if ( in_array( $color, $preset_colors ) ) {
	   		$class .= ' ' . $color;
   		} else {
		   	if ( $border ){
		   		$border_out = $border;
		   	} else {
		   		$border_out = $color;
		   	}

	   		$color_output = 'style="background:' . esc_attr( $color ) . ';border-color:' . esc_attr( $border_out ) . '"';

	   		// add custom class
	   		$class .= ' custom';
   		}
   	} else {
   		if ( $border )
		   		$border_out = $border;
		   	else
		   		$border_out = $bg_color;

	   		$color_output = 'style="background:' . esc_attr( $bg_color ) . ';border-color:' . esc_attr( $border_out ) . '"';

	   		// add custom class
	   		$class .= ' custom';
   	}

	$class_output = '';

	// Set text color
	if ( $text ) $class_output .= ' dark';
	// Set class
	if ( $class ) $class_output .= ' '.$class;
	// Set Size
	if ( $size ) $class_output .= ' '.$size;
	// Set window target
	if ( $window ) $window = 'target="_blank" ';

   	$output = '<a ' . $window . 'href="' . esc_attr( esc_url( $link ) ) . '" class="pwdtheme-sc-button' . esc_attr( $class_output ) . '" ' . $color_output . '><span class="woo-' . esc_attr( $style ) . '">' . wp_kses_post( shortcode_unautop( $content ) ) . '</span></a>';
   	return $output;
} // End woo_shortcode_button()

add_shortcode( 'button', 'pwd_shortcode_button' );

/*-----------------------------------------------------------------------------------*/
/* 6. jQuery Toggle
/*-----------------------------------------------------------------------------------*/

function pwdtheme_shortcode_toggle ( $atts, $content = null ) {
		// Instruct the shortcode JavaScript to load.
		if ( ! defined( 'PWD_SHORTCODE_JS' ) ) { define( 'PWD_SHORTCODE_JS', 'true' ); }
		$defaults = array( 'title' => ''	);

		extract( shortcode_atts( $defaults, $atts ) );

		return '<div class="pwd-shortcode-toggle toggle-unit clearfix">' . $title . do_shortcode( $content ) . '</div><!--/.toggle-content-->' . "\n";
} // End pwdtheme_shortcode_toggle()

add_shortcode( 'toggle', 'pwdtheme_shortcode_toggle', 70 );
add_shortcode( 'toggleitem', 'pwdtheme_shortcode_toggleitem', 70 );
function pwdtheme_shortcode_toggleitem ( $atts, $content = null ) {
  $defaults = array( 'title' => ''	);
  extract( shortcode_atts( $defaults, $atts ) );
  return '<div class="toggle-wrap"><span class="trigger"><span class="toogle_image"></span><a href="#" style="">'.$title.'</a></span>
          <div class="toggle-container">'. do_shortcode( $content ) . '</div>
        </div>' . "\n";
}

function pwdtheme_shortcode_accordion ( $atts, $content = null ) {
		// Instruct the shortcode JavaScript to load.
		if ( ! defined( 'PWD_SHORTCODE_JS' ) ) { define( 'PWD_SHORTCODE_JS', 'true' ); }
		$defaults = array( 'title' => ''	);

		extract( shortcode_atts( $defaults, $atts ) );

		return '<div class="pwd-shortcode-accordion accordion-unit clearfix">' . $title . do_shortcode( $content ) . '</div><!--/.accordion-unit-->' . "\n";
} // End pwdtheme_shortcode_toggle()

add_shortcode( 'accordion', 'pwdtheme_shortcode_accordion' );
add_shortcode( 'acrditem', 'pwdtheme_shortcode_acrditem' );
function pwdtheme_shortcode_acrditem ( $atts, $content = null ) {
  $defaults = array( 'title' => ''	);
  extract( shortcode_atts( $defaults, $atts ) );
  return '<div class="accordion_container">
            <span class="trigger-button" style="">
            <span class="accordion_image"></span><span>'.$title.'</span></span>
            <div class="accordion">'. do_shortcode( $content ) . '</div>
          </div>' . "\n";
}

/*-----------------------------------------------------------------------------------*/
/* 7. Tabs - [tabs][/tabs]
/*-----------------------------------------------------------------------------------*/

function pwdtheme_shortcode_tabs ( $atts, $content = null ) {
	// Instruct the shortcode JavaScript to load.
	if ( ! defined( 'PWD_SHORTCODE_JS' ) ) { define( 'PWD_SHORTCODE_JS', 'true' ); }

	$defaults = array( 'style' => 'default', 'title' => '', 'css' => '', 'id' => '' );

	extract( shortcode_atts( $defaults, $atts ) );

	// If no unique ID is set, set the ID as a random number between 1 and 100 (to make sure each tab group is unique).
	if ( $id == '' ) { $id = rand( 1, 100 ); }
	if ( $css != '' ) { $css = ' ' . $css; }

	// Extract the tab titles for use in the tabber widget.
	preg_match_all( '/tab title="([^\"]+)"/i', $content, $matches, PREG_OFFSET_CAPTURE );
  
  // Extract the tab title's icon for use in the tabber widget.
	preg_match_all( '/icon="([^\"]+)"/i', $content, $mat, PREG_OFFSET_CAPTURE );

	$tab_titles = array();
	$tabs_class = 'tab_titles';

	if ( isset( $matches[1] ) ) { $tab_titles = $matches[1]; } // End IF Statement

	$titles_html = $font_icon = '';

	if ( count( $tab_titles ) ) {
		if ( $title ) { $titles_html .= '<h4 class="tab_header"><span>' . esc_html( $title ) . '</span></h4>'; $tabs_class .= ' has_title'; } // End IF Statement

		$titles_html .= '<ul class="' . esc_attr( $tabs_class ) . '">' . "\n";

			$counter = 1;
      
			foreach ( $tab_titles as $t ) { 
        if($mat[1][$counter - 1][0] != '')
            $font_icon = '<i class="fa fa-'.$mat[1][$counter - 1][0].'"></i> ' ;
            
				$titles_html .= '<li class="nav-tab"><a href="#tab-' . esc_attr( $counter ) . '">' . $font_icon . esc_html( $t[0] ) . '</a></li>' . "\n";
				$counter++;
			} // End FOREACH Loop

		$titles_html .= '</ul>' . "\n";
	} // End IF Statement

	return '<div id="tabs-' . esc_attr( $id ) . '" class="pwd-shortcode-tabs ' . esc_attr( $style ) . esc_attr( $css ) . '">' . $titles_html . do_shortcode( $content ) . "\n" . '<div class="fix"></div><!--/.fix-->' . "\n" . '</div><!--/.tabs-->';
} // End pwdtheme_shortcode_tabs()

add_shortcode( 'tabs', 'pwdtheme_shortcode_tabs', 90 );

/*-----------------------------------------------------------------------------------*/
/* 7.1 A Single Tab - [tab title="The title goes here"][/tab]
/*-----------------------------------------------------------------------------------*/

function pwdtheme_shortcode_tab_single ( $atts, $content = null ) {
		$defaults = array( 'title' => 'Tab', 'icon' => '' );

		extract( shortcode_atts( $defaults, $atts ) );

		$class = '';

		if ( $title != 'Tab' ) {
			$class = ' tab-' . sanitize_title( $title );
		}
    
		return '<div class="tab' . esc_attr( $class ) . '">' . do_shortcode( $content ) . '</div><!--/.tab-->';
} // End pwdtheme_shortcode_tab_single()

add_shortcode( 'tab', 'pwdtheme_shortcode_tab_single', 99 );

/*-----------------------------------------------------------------------------------*/
/* 8. Call to Action box
/*-----------------------------------------------------------------------------------*/
add_shortcode('callout_box', 'callOutBox');
function callOutBox($atts, $content=null){
  extract( shortcode_atts( array('title' => '', 'btn_text' => 'Submit', 'btn_url' => '#', 'target' => '_self'), $atts ) );
  $btn = '<a href="'.$btn_url.'" class="button callout-btn" target="'.$target.'">'.$btn_text.'</a>';
  return '<div class="callout-box clearfix"><div class="callout-content three-fourths first"><h2>'.$title.'</h2><p>'.$content.'</p></div><div class="one-fourth">'.$btn.'</div></div>' . "\n";
}

/*-----------------------------------------------------------------------------------*/
/* 9. Progress Bar
/*-----------------------------------------------------------------------------------*/

add_shortcode('progress_bar', 'progress_bar');
function progress_bar($atts, $content=null){
  // Instruct the shortcode JavaScript to load.
	if ( ! defined( 'PWD_SHORTCODE_JS' ) ) { define( 'PWD_SHORTCODE_JS', 'true' ); }
  //extract( shortcode_atts( array('title' => '', 'btn_text' => 'Submit', 'btn_url' => '#', 'target' => '_self'), $atts ) );
  return '<div id="progress" class="display-none">' . do_shortcode($content) . '</div>' . "\n";
}

add_shortcode('field', 'field');
function field($atts){
  extract( shortcode_atts( array('name' => '', 'marks' => '55', 'animation_type' => 'bar-one'), $atts ) );
  $html ='<div class="progress-bar '.$animation_type.'">' . "\n" .
         '    <div class="progress">' . "\n" . 
         '        <span class="field">'.$name.'</span>' . "\n" .
         '        <span class="field-value fade-in">'.$marks.'%</span>' . "\n" .
         '        <div class="bar" style="width: '.$marks.'%;"></div>' . "\n" .
         '    </div>' . "\n" .
         '</div>' . "\n";
  return $html;
}

/*-----------------------------------------------------------------------------------*/
/* 10. Content Box
/*-----------------------------------------------------------------------------------*/

add_shortcode('content_box', 'contentBox');
function contentBox($atts, $content=null){
 extract( shortcode_atts( array('icon' => '', 'align' => 'left'), $atts ) );
 if($icon !=''){
  $fa = '<div class="hi-icon-wrap icon-align-'.$align.'"><i class="fa fa-'.$icon.'"></i></div>' . "\n";
 }
 $box = '<div class="content_box mar-top20 text-align-'.$align.'">' . $fa . $content. '<div class="clearfix"></div></div>';
 
 return $box;
}

/*-----------------------------------------------------------------------------------*/
/* 11. Box
/*-----------------------------------------------------------------------------------*/

add_shortcode('box', 'Box');
function Box($atts, $content=null){
 extract( shortcode_atts( array('title'=> '', 'style' => 'default', 'icon' => '', 'align' => 'center'), $atts ) );
 if($title != '') $ttl = '<h4>'.$title.'</h4>' . "\n";
 if($icon != '') $fa = '<div><i class="fa fa-'.$icon.'"></i></div>' . "\n";
 $box = '<div class="box clearfix box-'.$style.' cnt-' . $align . '">' . $ttl . $fa .'<p>'.$content.'</p></div>' . "\n";
 return $box;
}

/*-----------------------------------------------------------------------------------*/
/* 12. Message Box
/*-----------------------------------------------------------------------------------*/
add_shortcode('message_box', 'messageBox');
function messageBox($atts, $content=null){
 extract( shortcode_atts( array('title'=> '', 'type' => 'info'), $atts ) );
 $alert = '<div class="alert alert-'.$type.'"><h2>'.$title.'</h2><p>'.$content.'</p></div>' . "\n";
 
 return $alert;
}
/*-------------------------------------------------------------------------------------------*/
/* 13. Heading */
/*-------------------------------------------------------------------------------------------*/
add_shortcode('heading', 'heading');
function heading($atts){
 extract( shortcode_atts( array('title'=> '', 'htag' => '2', 'icon' => '', 'style' => "black"), $atts ) );
 if($icon != '') $fa = '<i class="fa fa-'.$icon.'"></i> ' . "\n"; 
 
 return '<h' . $htag .' class="pwdtheme-sc-heading '.$style.'"><span>' . $fa . $title .'</span></h' . $htag . '>' . "\n";
}

/*-------------------------------------------------------------------------------------------*/
/* 14. Panels */
/*-------------------------------------------------------------------------------------------*/

add_shortcode('panel', 'panel');
function panel($atts, $content=null){
 extract( shortcode_atts( array('title'=> '', 'style' => 'default', 'icon' => ''), $atts ) );
 if($icon != '') $fa = '<i class="fa fa-'.$icon.'"></i>' . "\n";
 if($title != '') $ttl = '<div class="panel-top"><h4>' . $fa . $title . ' </h4></div>' . "\n"; 
 $panel = '<div class="pwd-sc-panel clearfix panel-'.$style.'">' . $ttl .'<div class="panel-content"><p>'.$content.'</p></div></div>' . "\n";
 return $panel;
}

/*-------------------------------------------------------------------------------------------*/
/* 15. Recent Blog */
/*-------------------------------------------------------------------------------------------*/
add_shortcode('recent_blog', 'recentBlog');
function recentBlog($atts){
 extract( shortcode_atts( array('excerpt'=> '', 'content_limit' => 150, 'cols' => 3, 'items' => 3, 'cat' => '', 'thumb' => 'no', 'img_align' => 'center', 'thumb_size' => 'grid-featured'), $atts ) );
 $args = array('post_type' => 'post', 'posts_per_page' => $items);
 if($cat != '') $args['cat'] = $cat;
 $query_args = wp_parse_args( genesis_get_custom_field( 'query_args' ), $args);
 $wp_query = new WP_Query($query_args);
 $cls = ( (int) $cols > 4 ) ? ($cols % 3) : $cols ;
 $columns = array('one-half', 'one-half', 'one-half', 'one-third', 'one-fourth'); 
 if( $wp_query->have_posts() ){
  $counter = 0; $rc = '';
  while( $wp_query->have_posts() ){
    $wp_query->the_post();
    if($counter <= 0) {$first = ' first'; } else {$first = '';}  
    $rc .= '<div class="fet-post clearfix columns ' . $columns[$cls] . $first .'">' . "\n";
    $img = genesis_get_image( array(
                              			'format'  => 'html',
                              			'size'    => "{$thumb_size}",
                              			'context' => 'archive',
                              			'attr'    => array ( 'class' => 'align' . $img_align . ' post-image' )
                              		) );
                              
		if ( $img && $thumb != "no")
			$rc .= '<div class="featured-image align' . $img_align . '"><a href="'.get_permalink().'" title="'.the_title_attribute( 'echo=0' ).'">'.$img.'</a></div>' . "\n";
      
    $rc .= '<h3 class="entry-title"><a href="'.get_permalink().'" title="'.the_title_attribute( 'echo=0' ).'">'.the_title_attribute( 'echo=0' ).'</a></h3>' . "\n";
    $rc .= '<p class="entry-meta">'.do_shortcode('[post_date before="<i class=\'fa fa-clock-o\'></i> "]').do_shortcode('[post_comments before="<i class=\'fa fa-comment-o\'><\/i> " zero="0 Comment" one="1 Comment" more="% Comments"]').'</p>' . "\n";
    if ( 'excerpts' == "yes" ) {
  		$rc .= get_the_excerpt();
  	}
  	else {
  		if ( (int) $content_limit > 0 )
  			$rc .= get_the_content_limit( (int) $content_limit, __( '[Read more...]', 'genesis' ) );
  		else
  			$rc .= get_the_content( __( '[Read more...]', 'genesis' ) );
  	}
    $rc .= '</div>' . "\n";
    $counter++;
    
    if($counter == $cls){
      $counter = 0;
      $rc .= '<div class="clearfix"></div>' . "\n";
    }
  }
 }
 
 wp_reset_query(); 
 
 return $rc;
}

add_filter('the_content', 'shortcode_empty_paragraph_fix');
function shortcode_empty_paragraph_fix($content)
{   
    $array = array (
        '<p>[' => '[', 
        ']</p>' => ']', 
        ']<br />' => ']'
    );

    $content = strtr($content, $array);

    return $content;
}

/*-------------------------------------------------------------------------------------------*/
/* 16. Testimonials */
/*-------------------------------------------------------------------------------------------*/
add_shortcode('testimonials', 'testimonials');
function testimonials($atts){
   // Instruct the shortcode JavaScript to load.
  	if ( ! defined( 'PWD_SHORTCODE_JS' ) ) { define( 'PWD_SHORTCODE_JS', 'true' ); }
   extract( shortcode_atts( array('cols' => 3, 'items' => 3, 'slide' => 'no'), $atts ) );
   $args = array('post_type' => 'feedback', 'posts_per_page' => $items);
   $query_args = wp_parse_args( genesis_get_custom_field( 'query_args' ), $args);
   $wp_query = new WP_Query($query_args);
   $cls = ( (int) $cols > 4 ) ? ($cols % 3) : $cols ;
   $columns = array('full', 'full', 'one-half', 'one-third', 'one-fourth'); 
   if( $wp_query->have_posts() ){
    $counter = 0; $tm = '';
    if($slide == "yes") $tm .= '<div class="testimonials_slider">' . "\n";
    while( $wp_query->have_posts() ){
      $wp_query->the_post();
      if($counter <= 0) {$first = ' first'; } else {$first = '';}
      $img = genesis_get_image( array(
  			'format'  => 'html',
  			'size'    => 'full',
  			'context' => 'archive',
  			'attr'    => array ( 'class' => 'tm-image' )
  		) );
  
      if($slide == "yes") $tm .= '<div class="columns slide">' . "\n";
      if($slide == "no") $tm .= '<div class="testimonials clearfix columns ' . $columns[$cls] . $first . '">' . "\n";      
      $tm .= '<div class="testimonial-content">' . get_the_content() . '</div>' . "\n";
      $tm .= '<div class="testimonial-info">' . "\n"; 
      if ( $img ){ $tm .= $img; } else { $tm .= '<img src="'.CHILD_URL.'/shortcodes/images/ico-user.gif" class="tm-image">';} 
      $sub_title = get_post_meta( get_the_ID(), 'woothemes_feedback_author', true );
      $tm .= '<div class="testimonial-author">' . the_title( '','',false ) . ( ($sub_title !='') ? '<em>' . $sub_title . '</em>' : '') . '</div>' . "\n";
      $tm .= '</div>' . "\n";
      //if($slide == "yes") $tm .= '</div>' . "\n";
      $tm .= '</div>' . "\n";
      
      $counter++;
      if( ($counter == $cls) && ($slide == "no")){
        $counter = 0;
        $tm .= '<div class="clearfix"></div>' . "\n";
      }
    }
    if($slide == "yes") $tm .= '</div>' . "\n";
   }
   wp_reset_query();
   return $tm;
}

/*-------------------------------------------------------------------------------------------*/
/* 17. Order List */
/*-------------------------------------------------------------------------------------------*/
add_shortcode('order_list', 'orderList');
function orderList($atts, $content){
 extract( shortcode_atts(array('style' => 'grey'), $atts) );
 return '<ul class="pwd-sc-ul '.$style.'">' . do_shortcode($content) . '</ul>' . "\n";
}

add_shortcode('li', 'orderLi');
function orderLi($atts,$content=null){
   return '<li><i class="fa fa-angle-double-right"></i> ' . $content . '</li>' . "\n";
}

/*-------------------------------------------------------------------------------------------*/
/* 18. Social Links */
/*-------------------------------------------------------------------------------------------*/
add_shortcode('social_icons', 'socialIcons');
function socialIcons($atts){
  $pwd_options = get_option( 'pwd_options' );
  
  $sc = '';
  $rss = $pwd_options['pwd_rss'];
  $mail = $pwd_options['pwd_mail'];
  $facebook = $pwd_options['pwd_facebook'];
  $twitter = $pwd_options['pwd_twitter'];
  $linkedin = $pwd_options['pwd_linkedin'];
  $gplus = $pwd_options['pwd_gplus'];
  $pinterest = $pwd_options['pwd_pinterest'];
  $youtube = $pwd_options['pwd_youtube'];
  
  if($rss)
    $sc.= '<a href="'.$rss.'" target="_blank" title="RSS" alt="RSS"><i class="fa fa-rss"></i></a>' . "\n";
  
  if($mail)
    $sc.= '<a href="mailto:'.$mail.'" title="E-Mail" alt="E-Mail"><i class="fa fa-envelope-o"></i></a>' . "\n";
    
  if($facebook)
    $sc.= '<a href="'.$facebook.'" target="_blank" title="Follow on Facebook" alt="Follow on Facebook"><i class="fa fa-facebook"></i></a>' . "\n";
    
  if($twitter)
    $sc.= '<a href="'.$twitter.'" target="_blank" title="Follow on Twitter" alt="Follow on Twitter"><i class="fa fa-twitter"></i></a>' . "\n";
    
  if($linkedin)
    $sc.= '<a href="'.$linkedin.'" target="_blank" title="Linkedin" alt="Linkedin"><i class="fa fa-linkedin"></i></a>' . "\n";
    
  if($gplus)
    $sc.= '<a href="'.$gplus.'" target="_blank" title="Connect to Google Plus" alt="Connect to Google Plus"><i class="fa fa-google-plus"></i></a>' . "\n";
    
  if($pinterest)
    $sc.= '<a href="'.$linkedin.'" target="_blank" title="Connect to Pinterest" alt="Connect to Pinterest"><i class="fa fa-pinterest"></i></a>' . "\n";
    
  if($youtube)
    $sc.= '<a href="'.$linkedin.'" target="_blank" title="Youtube" alt="Youtube"><i class="fa fa-youtube"></i></a>' . "\n";
    
  return $sc;
 
}
add_shortcode('pricing_table', 'pricing_table');
function pricing_table($atts){
  extract(shortcode_atts( array('id' => null, 'theme' => 'Individuals', 'price' => 10), $atts));

  $tablee = '<div class="theme-right-box">
										<h4><span class="theme-title">'.$theme.' Theme</h4>
										<p class="price">$'.$price.'</p><p class="center buy-button">[wp_eStore_buy_now:product_id:'.$id.':end]</p>
                    <ul>
												<li>Excludes the <strong>Genesis Framework</strong></li>
												<li class="theme-title">Includes the '.$theme.' Theme</li>
            						<li><strong>Instant Download the Theme</strong></li>
            						<li>Unlimited Updates &amp; Support</li>
            						<li>Standard License</li>
            						<li class="last">One-time Purchase Fee</li>
    					</ul>
    				</div>';
   return do_shortcode($tablee);
}