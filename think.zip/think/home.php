<?php

add_action( 'genesis_meta', 'think_home_genesis_meta' );
remove_action( 'genesis_loop', 'genesis_do_loop' );
 /** Force full width content layout */
add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );
/**
 * Add widget support for homepage.
 *
 */
function think_home_genesis_meta() {
	if ( is_active_sidebar( 'home-top' )) {	
		add_action( 'genesis_before_header', 'think_home_header_feat_box' );
    add_action( 'genesis_after_header', 'think_home_service_box' );
	}
}

/**
 * Display widget content for home section
 *
 */
function think_home_header_feat_box() {

	if ( is_active_sidebar( 'home-top' )) {

		echo '<section id="header-container" class="header-container">';
		echo '<div class="wrap">';
		dynamic_sidebar( 'home-top' );
		echo '</div><!-- end .wrap -->';
	  echo '</section><!-- end #slider -->';

	}
  
}
function think_home_service_box() {  
  if ( is_active_sidebar( 'home-middle' )) {

		echo '<section id="home-middle" class="home-middle">';
		echo '<div class="wrap">';
		dynamic_sidebar( 'home-middle' );
		echo '</div><!-- end .wrap -->';
	  echo '</section><!-- end #home-middle -->';

	}
  include_once('home-portfolio.php');
  
  if ( is_active_sidebar( 'home-bottom' )) {
    echo '<section id="home-bottom">' . "\n";
    echo '<div class="wrap">' . "\n";
      dynamic_sidebar( 'home-bottom' );
    echo '</div><!-- end .wrap -->' . "\n";
  	echo '</section><!-- end #home-bottom -->' . "\n";
  }
}

genesis();