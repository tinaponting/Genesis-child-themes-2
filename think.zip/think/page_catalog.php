<?php
/**
 * Template Name: Themes catalog
 *
 * The portfolio page template displays your portfolio items with
 * a switcher to quickly filter between the various portfolio galleries. 
 *
 * @package Genesis Framework
 * @subpackage Template
 */
 
remove_action( 'genesis_loop', 'genesis_do_loop' );
add_action( 'genesis_loop', 'pwd_theme_catalog');
add_action( 'genesis_entry_header', 'genesis_do_post_title' );
/** Add support for Genesis Magazine Loop **/
function pwd_theme_catalog() {

  $paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1; 
  $query_args = array(
              				'post_type' => 'themes', 
              				'paged' => $paged, 
              				'posts_per_page' => 15
              			);
  
  /* The Query. */			   
  $themes = new WP_Query( $query_args );
if ( $themes->have_posts() ) { $count = 0;
?>
<div id="showcase">
  <header class="entry-header"><h1 itemprop="headline" class="entry-title">Themes</h1></header>

	<div class="portfolio-items">
    <ul>
    
<?php
	   while ( $themes->have_posts() ) { $themes->the_post(); $count++;
        $title = (get_post_meta( get_the_ID(), '_title', true)) ? get_post_meta( get_the_ID(), '_title', true) : get_post_meta( get_the_ID(), 'title', true);
        $bestSelling = (get_post_meta( get_the_ID(), '_best_selling', true)) ? get_post_meta( get_the_ID(), '_best_selling', true) : get_post_meta( get_the_ID(), 'best_selling', true);
        $short_desc = (get_post_meta( get_the_ID(), '_short_desc', true)) ? get_post_meta( get_the_ID(), '_short_desc', true) : get_post_meta( get_the_ID(), 'short_desc', true);
        $demo_link = ( get_post_meta( get_the_ID(), '_demo_link', true) ) ? get_post_meta( get_the_ID(), '_demo_link', true) : get_post_meta( get_the_ID(), 'demo_link', true);
        $buy_link = ( get_post_meta( get_the_ID(), '_buy_link', true) ) ? get_post_meta( get_the_ID(), '_buy_link', true) : get_post_meta( get_the_ID(), 'buy_link', true);
        $price = ( get_post_meta( get_the_ID(), '_price', true) ) ? get_post_meta( get_the_ID(), '_price', true) : get_post_meta( get_the_ID(), 'price', true);
        $purchase = (get_post_meta( get_the_ID(), '_download', true)) ? get_post_meta( get_the_ID(), '_download', true) : "0";
        $off = get_post_meta( get_the_ID(), 'off', true);
?>
  <li>
		<div <?php post_class(); ?>>
                <?php if( ! empty($off) ) { ?> <span class="off-<?php echo $off; ?>">offer</span><?php } ?>
		<?php
      //if( $bestSelling == "yes") echo '<div class="top-product"></div>' . "\n";

			$image = genesis_get_image( array(
                                  			'format'  => 'html',
                                  			'size'    => "theme-thumb",
                                  			'context' => 'archive',
                                  			'attr'    => array ( 'class' => 'alignnone post-image' )
                                  		) );
			
			if ( $image != '' ) {
		?>
			<a rel="permalink" title="<?php echo $title; ?>" href="<?php echo get_permalink( get_the_ID() ); ?>" class="thumb">
				<?php echo $image; ?>
      </a>
      <div class="over">
	      <h2><?php echo $title; ?></h2>
        <p><?php echo $short_desc; ?></p>
        <a href="<?php echo $demo_link; ?>" class="css3_btn" target="_blank">View Demo</a> <?php if( (int) $price > 0 ) { ?><a href="<?php echo $buy_link; ?>" class="css3_btn">View Details<?php //echo '$' . $price; ?></a><?php } else { ?><a href="<?php echo $buy_link; ?>" class="css3_btn">Download Now</a><?php } ?>
      </div>
    <?php } ?>
		</div><!--/.group .post .portfolio-img-->
    <!--<div class="col-left"><i class="icon-money icon-large"></i> $<?php //echo $price; ?></div>
    <div class="col-right"><i class="icon-shopping-cart icon-large"></i> <?php //echo $purchase; ?></div>-->
    </li>
<?php
	} // End WHILE Loop
?>
    </ul>
	</div><!--/.portfolio-items-->
</div><!--/#portfolio-->
<?php
}
  wp_reset_query();
  echo '<br/><br/>';
  echo '<div class="slogan"><h2 style="text-align:left;">Premium Wordpress Plugins</h2></div>' . "\n";
  $plugins = new WP_Query('post_type=plugins&posts_per_page=-1');
  if($plugins->have_posts()){
    echo '<ul class="plugins">' . "\n";
    while( $plugins->have_posts() ){
      $plugins->the_post();
?>
       <li class="plugin">
        <?php 
          $img = genesis_get_image( array(
                              			'format'  => 'html',
                              			'size'    => "full",
                              			'context' => 'archive',
                              			'attr'    => array ( 'class' => 'alignnone post-image' )
                              		) );
          
          if ( $img != '' ) { echo $img; }
        ?>
        <h3><?php the_title(); ?></h3>
        <a class="button" href="<?php echo get_post_meta(get_the_ID(), 'plugin_url', true);?>" rel="follow">View Details</a>
       </li>
<?php
      }
      echo '</ul>' . "\n";
    }
    wp_reset_query();              
}
genesis();