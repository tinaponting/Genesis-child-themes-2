<?php
/**
 * The custom portfolio post type taxonomy template
 */

/** Add the featured image after post title */
add_action( 'genesis_entry_header', 'think_portfolio_taxonomy_grid' );
/** Remove Author Box **/
remove_action( 'genesis_after_entry', 'genesis_do_author_box_single', 8 );

/** Remove Post Title **/
remove_action( 'genesis_entry_header', 'genesis_do_post_title' );

/** Remove the post meta function **/
remove_action( 'genesis_entry_footer', 'genesis_post_meta' );

/** Remove the post info function **/
remove_action( 'genesis_entry_header', 'genesis_post_info', 12 );

/** Force full width content layout */
add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );

/** Remove the post image */
remove_action( 'genesis_entry_content', 'genesis_do_post_image', 8 );

/** Remove the post content */
remove_action( 'genesis_entry_content', 'genesis_do_post_content' );

add_action( 'genesis_entry_footer', 'genesis_do_post_title' );

function think_portfolio_taxonomy_grid() {
    if ( has_post_thumbnail() ){
        echo '<div class="portfolio-featured-image">' . "\n";
        echo '<a href="' . get_permalink() .'" title="' . the_title_attribute( 'echo=0' ) . '">' . "\n";
        echo get_the_post_thumbnail($thumbnail->ID, 'widget-featured');
        echo '</a>' . "\n";
        echo '<div class="overlay-content">
                <a href="'. get_permalink() .'" title="'. the_title_attribute('echo=0') . '"><i class="fa fa-search"></i></a>
              </div>' . "\n";
        echo '</div>' . "\n";
    }
}

remove_action( 'genesis_loop', 'genesis_do_loop' );
add_action( 'genesis_loop', 'think_portfolio_taxonomy_helper' );
function think_portfolio_taxonomy_helper(){
  $taxonomy = 'portfolio-gallery'; //taxonomy
  $term = get_query_var( 'term' );
  $term_obj = get_term_by( 'slug' , $term , $taxonomy );
  $cpt = 'portfolio'; //custom post type
  $args = array(
                'posts_per_page' => 12,
          			'post_type' => $cpt,
          			'paged' => get_query_var('paged') ? get_query_var('paged') : 1,
          			'tax_query' => array(
                              				array(
                              					'taxonomy' => $taxonomy,
                              					'field' => 'slug',
                              					'terms' => array($term_obj->slug)
                              				)
                              			)
                );	
                
  genesis_custom_loop($args);
}

function portfolio_class($classes) {
  $classes[] = 'portfolio-grid';
  return $classes;
}
add_filter('post_class', 'portfolio_class');

genesis();