<?php 

/**
 * Display Options Class
 *
 *
 * @author  VSELLIS
 * @license GPL-2.0+
 * @link    http://vsellis.com
 */

add_action( 'genesis_meta', 'shoreline_home_meta' );

function shoreline_home_meta() {

	$sidebar_widget_areas = array(
		'home-top',
		'home-middle',
		'home-bottom'
	);

	if( ! shoreline_is_any_sidebar_active( $sidebar_widget_areas ) ) {
		return;
	}


	add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );
	
	add_filter( 'body_class', 'shoreline_home_body_class' );

	remove_action( 'genesis_loop', 'genesis_do_loop' );
	add_action( 'genesis_loop', 'shoreline_home_loop_helper' );

}

/**
 * Adds a custom class to our homepage 
 * used for styling.
 */
function shoreline_home_body_class( $classes ) {
	$classes[] = 'shoreline-home';
	return $classes;
}

/**
 * If widgets are active we will replace the 
 * default genesis loop with our widget areas.
 */

function shoreline_home_loop_helper() {
	
	genesis_widget_area( 'home-top', array( 
		'before' => '<section class="home-widget home-top" data-type="background" data-speed="10"><div class="wrap">',
		'after' => '</div></section>',

	) );

	genesis_widget_area( 'home-middle', array( 
		'before' => '<section class="home-widget home-middle" data-type="background" data-speed="10"><div class="wrap">',
		'after' => '</div></section>'

	) );

	genesis_widget_area( 'home-bottom', array( 
		'before' => '<section class="home-widget home-bottom" data-type="background" data-speed="10"><div class="wrap">',
		'after' => '</div>'

	) );

}

/**
 * Checks if any home widget is active 
 * @return bool
 */
function shoreline_is_any_sidebar_active( $sidebar_widget_areas ) {

	foreach( $sidebar_widget_areas as $sidebar ) {
		if ( is_active_sidebar( $sidebar ) )
			return true;
	}

	return false;

}

genesis();