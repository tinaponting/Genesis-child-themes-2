jQuery(document).ready(function($) {

	function updateTextareas( $, $textareas ) {
		"use strict";

		$textareas.each(function() {
			updateCount( $, $(this) );
			$(this).keyup(function() {
				updateCount( $, $(this) );
			});
		});
	}

	(function($) {
		"use strict";
		$(function () {
			updateTextareas( $, $('.wpz-column textarea') );
	    	jQuery( ".accordion" ).accordion({ heightStyle: "content" });
		});

		$(document).ajaxSuccess(function() {
			updateTextareas( $, $('.wpz-column textarea') );
			jQuery( ".accordion" ).accordion();
		})

	}(jQuery));

	var custom_uploader;

	$('.image-upload input[type=button]').click(function(e) {
			var btn = $(this);
	       e.preventDefault();
	
	       //If the uploader object has already been created, reopen the dialog
	       if (custom_uploader) {
	           custom_uploader.open();
	           return;
	       }
	
	       //Extend the wp.media object
	       custom_uploader = wp.media.frames.file_frame = wp.media({
	           title: 'Choose Image',
	           button: {
	               text: 'Choose Image'
	           },
	           multiple: false
	       });
	
	       //When a file is selected, grab the URL and set it as the text field's value
	       custom_uploader.on('select', function() {
	           attachment = custom_uploader.state().get('selection').first().toJSON();
	           btn.prev().val(attachment.url);
	       });
	
	       //Open the uploader dialog
	       custom_uploader.open();
	
	   });
});