jQuery(document).ready(function($) {


    var $window = $(window);
    if( $window .width() > 800) {
    
        $('section[data-type="background"]').each(function(){
        	var $bgobj = $(this); // assigning the object
        	$(window).scroll(function() {
        		var yPos = -($window.scrollTop() / $bgobj.data('speed'));
        		// Put together our final background position
        		var coords = '50% '+ yPos + 'px';
        		// Move the background
        		$bgobj.css({ backgroundPosition: coords });
        	});
        });
    
       $('article[data-type="fade-text"]').each(function () {
           var text = $(this); // assigning the object
           $(window).on('scroll', function () {
               var st = $(this).scrollTop();
               text.css({
                   'margin-top': -(st / 3) + "px",
                   'opacity': 1 - st / 205
               });
           });
       });
    }

});
