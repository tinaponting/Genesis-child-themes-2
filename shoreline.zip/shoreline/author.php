<?php

/**
 * This file controls the author's page.
 */

add_action( 'genesis_before_loop', 'shoreline_do_author_info' );
function shoreline_do_author_info() {

	$id = get_the_author_meta('ID');
	$curauth = ( isset($_GET['author_name']) ) ? get_user_by('slug', $author_name) : get_userdata(intval($id));
	$social_sites = array( 'twitter', 'facebook');

	$avatar = get_avatar( $curauth->user_email, 170 );
	echo '<div class="author-info-wrap"><div class="author-info">';
		echo '<div class="one-fourth first">';
			echo $avatar;
			printf( '<h3 class="author-name">%s</h3>', ucwords($curauth->display_name) );
		echo '</div>';
		echo '<div class="three-fourths">';
			echo wpautop($curauth->description);
			echo '<div class="author-networks">';
				foreach ( $social_sites as $site ) {
					printf( '<a href="%s">%s</a>', $curauth->$site, ucwords($site) );
				}
			echo '</div>';
		echo '</div>';
	echo '</div></div>';
}

function get_social_links() {

	$social = array(
		'googleplus',
		'twitter',
		'jabber',
		'aim',
		'yim'
	);

}

genesis();