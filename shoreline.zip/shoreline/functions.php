<?php
/**
 * functions.php
 */
/*
 * Loads the theme's customizer settings
 */
require get_stylesheet_directory() . '/lib/customize.php';
/**
 * Loads a Genesis setup file
 */
require get_stylesheet_directory() . '/lib/genesis-setup.php';
/*
 * Loads all theme assets
 */
require get_stylesheet_directory() . '/lib/load-assets.php';
/*
 * Loads footer specific functions
 */
require get_stylesheet_directory() . '/lib/footer.php';
/*
 * Loads hero unit
 */
require get_stylesheet_directory() . '/lib/hero.php';
/*
 * Loads custom widgets
 */
require get_stylesheet_directory() . '/lib/widgets.php';