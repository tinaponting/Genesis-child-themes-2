<?php 
/**
 * This view controls the view of the public facing view of the widget. 
 * @since 1.0
 */
?>

<h2 class="home-title grey">
	<?php if ( !empty( $instance['title'] ) )
    echo $before_title . apply_filters( 'widget_title',  $instance['title'], $instance, $this->id_base ) . $after_title; 
    ?>
</h2>
<section class="shoreline-columns">

	<?php  for ( $i = 1; $i <= $this->column_count; $i++ ) { 
			$col = ($i === 1 ) ? 'first fadeInLeft' : 'fadeInRight';
		?>
		<div class="one-half wow <?php echo $col ?> ">
			<div class="shoreline-column ">
				
				<?php 
					$img = $instance['image-' . $i ];
					if ( ! empty($img) )
						printf( '<img src="%s" />', $img );
					
					echo wpautop( $instance['content-' . $i] ); 

				?>

			</div>
		</div>
	<?php } ?>
</section>
