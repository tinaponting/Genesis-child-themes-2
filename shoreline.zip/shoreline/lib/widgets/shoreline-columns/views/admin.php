  <?php 

  $title = ! empty( $instance['title'] ) ? $instance['title'] : '';
      ?>
  <p>
    <label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:', 'shoreline' ); ?></label> 
    <input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
  </p>

  <div class="vse-columns accordion">
  <?php 

  for ( $i = 1; $i <= $this->column_count; $i++ ) { ?>

    <h4>Column <?php echo $i; ?> <i class="fa fa-columns"></i></h4>
    <div class="vse-col">
      
      <p class="image-upload">
        <label for="<?php echo $this->get_field_id( 'image-' . $i ); ?>"><?php _e('Image Source', 'shorline');?>:</label>
        <input type="text" class="widefat image-url" name="<?php echo $this->get_field_name( 'image-' . $i ); ?>" id="<?php echo $this->get_field_id( 'image-' . $i ); ?>" value="<?php echo $instance['image-' . $i]; ?>" />
        <input style="margin-top: 10px;" class="upload_image_button button button-primary" type="button" value="<?php _e('Upload Image','shoreline');?>" />
        <br>
        <small><em>e.g http://example.com/image/path</em></small>
      </p>

        <label for="<?php echo $this->get_field_id( 'content-' . $i  ); ?>"><?php _e( 'Content Area', 'shoreline' ); ?>:</label>
        <textarea name="<?php echo $this->get_field_name( 'content-' . $i  ); ?>" id="<?php echo $this->get_field_id( 'content-' . $i  ); ?>" class="widefat vse-textarea" rows="15" co><?php echo $instance['content-' . $i ]; ?></textarea>
        <p class="description"><?php _e('Add any contet you wish to display here. Some basic tags are allowed.', 'shoreline' );?> </p>

    </div>
  <?php }	?>
  </div>
  