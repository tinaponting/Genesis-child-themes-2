<?php
/**
 * Columns Widget
 * 
 * @author Juan Rangel<juan@vsellis.com>
 */

class Shoreline_Columns extends WP_Widget {

	/**
	 * Number of columns
	 * @var columns
	 */
	private $column_count = 2;

	private $widget_name = 'Shoreline Columns';

	private $fields = array(
		'content',
		'image'
	);

	private $column_fields;

	function __construct() {

		$this->colummn_fields = $this->vse_set_column_fields();

		parent::__construct(
			'shoreline-columns',
			__( 'Shoreline Columns', 'shoreline' ),
			array(
				'classname'   => 'shoreline',
				'description' => __( 'Add 2 columns to your homepage widget areas.', 'shoreline' )
			)
		);


	}

	function form( $instance ) {

		$instance = wp_parse_args( 
			(array)$instance, 
			array(
				'image-1' => '',
				'image-2' => '',
				'content-1' => '',
				'content-2' => '',
			)
		);

		include( plugin_dir_path(__FILE__) . '/views/admin.php' );
	
	}

	function update( $new_instance, $old_instance ) {

		foreach( $this->colummn_fields as $field ) {
			$old_instance[$field] = ( ! empty( $new_instance[$field] ) ) ? $new_instance[$field] : '';
		}
		$old_instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';

		return $old_instance; 
	} 

	function widget( $args, $instance ) {

		extract( $args, EXTR_SKIP );

		echo $before_widget;

			include( plugin_dir_path(__FILE__) . '/views/public.php' );

		echo $after_widget;

	}

	function vse_set_column_fields() {

		foreach ( $this->fields as $field ) {
			for ( $i = 1; $i <= $this->column_count; $i++ ) {
				$columns[] = $field . '-' . $i;
			}
		}
		return $this->column_fields = $columns;
	}

}
