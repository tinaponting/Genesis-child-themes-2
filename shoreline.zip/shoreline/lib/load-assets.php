<?php
/**
 * The file that loads all of our javaScript and CSS
 *
 * Register and enqueue our files in the front-end of our site 
 * and the admin area.
 *
 * @since      1.0.0
 *
 * @package    VSELLIS
 * @subpackage VSELLIS/lib
 */

// Load Stylesheets last so we can overwrite plugins styles if needed
add_action( 'wp_enqueue_scripts', 'shoreline_enqueue_css_js', 15 );
add_action( 'admin_enqueue_scripts', 'shoreline_admin_load' );
add_action( 'wp_enqueue_scripts', 'add_shoreline_fonts' );

function shoreline_enqueue_css_js() {
    $version = wp_get_theme()->Version;
    

    // CSS Files
    wp_enqueue_style( 'font-awesome', CHILD_URL . '/css/vendor/font-awesome.min.css' );
    wp_enqueue_style( 'font-awesome-anim', CHILD_URL . '/css/vendor/font-awesome-animation.min.css' );
    wp_enqueue_style( 'css-animation', CHILD_URL . '/css/vendor/animate.css' );
    
    $options = get_option('shoreline_theme_options');

    if ( $options['content_fade'] === true ) {
        wp_enqueue_script( 'wow', CHILD_URL . '/js/vendor/wow.js', $version );
    }

    if ( $options['parallax'] === true ) {
        wp_enqueue_script( 'shoreline-main', CHILD_URL . '/js/custom/main.js', array( 'jquery' ), $version );
    }

    // Javascript Files
    wp_enqueue_script( 'fitVids', CHILD_URL . '/js/vendor/fitvids.js', array('jquery'), $version );

    wp_enqueue_script( 'shoreline-responsive-menu', CHILD_URL . '/js/custom/responsive-menu.js', array('jquery'), $version, true );

}

function shoreline_admin_load($hook) {

    if( $hook == 'widgets.php' ) {
        wp_enqueue_style( 'font-awesome', CHILD_URL . '/css/vendor/font-awesome.min.css' );
        wp_enqueue_media();
        wp_enqueue_script( 'shoreline-admin-js', CHILD_URL . '/js/custom/widgets-admin.js', array( 'jquery', 'jquery-ui-accordion' ) );

        wp_enqueue_style( 'shoreline-admin', CHILD_URL . '/css/admin.css' );

        wp_enqueue_style( 'font-awesome' );

    }
    
}

function shoreline_fonts() {
    $fonts_url = '';
 
    /* Translators: If there are characters in your language that are not
    * supported by bitter, translate this to 'off'. Do not translate
    * into your own language.
    */
    $bitter = _x( 'on', 'Bitter font: on or off', 'shoreline' );
 
    /* Translators: If there are characters in your language that are not
    * supported by Open Sans, translate this to 'off'. Do not translate
    * into your own language.
    */
    $open_sans = _x( 'on', 'Open Sans font: on or off', 'shoreline' );
 
    if ( 'off' !== $bitter || 'off' !== $open_sans ) {
        $font_families = array();
 
        if ( 'off' !== $bitter ) {
            $font_families[] = 'Bitter:400,700,400italic';
        }
 
        if ( 'off' !== $open_sans ) {
            $font_families[] = 'Open Sans:700italic,400,800,600';
        }
 
        $query_args = array(
            'family' => urlencode( implode( '|', $font_families ) ),
            'subset' => urlencode( 'latin,latin-ext' ),
        );
 
        $fonts_url = add_query_arg( $query_args, '//fonts.googleapis.com/css' );
    }
 
    return esc_url_raw( $fonts_url );
}

function add_shoreline_fonts() {
    wp_enqueue_style( 'shoreline-fonts', shoreline_fonts(), array(), null );
}


function load_wow_js() {
    echo '<script>new WOW().init();</script>';
}
$options = get_option( 'shoreline_theme_options' );
if ( $options['content_fade'] === true ) {
    add_action( 'wp_footer', 'load_wow_js' );
}

function load_fitvids_js() {
    echo "<script>jQuery('.entry-content').fitVids();</script>";
}
add_action( 'wp_footer', 'load_fitvids_js' );

