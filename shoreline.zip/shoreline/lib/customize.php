<?php

/**
 * The file that creates our customizer settings
 *
 * Create settings, controls, and seection for the customizer. If the
 * settings have been changed, then add theme to our css.
 *
 * @since      1.0.0
 *
 * @package    VSELLIS
 * @subpackage VSELLIS/lib
 */

add_action( 'customize_register', 'shoreline_customizer' );
function shoreline_customizer( $wp_customize ) {

	// * Logo Image Customizer Settings
	$wp_customize->add_section( 'shoreline-theme-features', array(
		'title'       => __( 'Theme Features', 'shoreline' ),
		'description' => __( 'Enable/Disable theme effects.', 'shoreline' )
	) );

	$wp_customize->add_setting( 'shoreline_theme_options[parallax]', array(
		'default' => true,
		'type'    => 'option',
	) );

	$wp_customize->add_control( 'parallax', array(
		'settings' => 'shoreline_theme_options[parallax]',
		'label'    => __( 'Enable Parallax/Text Fade', 'shoreline' ),
		'section'  => 'shoreline-theme-features',
		'type'     => 'checkbox'
	) );

	$wp_customize->add_setting( 'shoreline_theme_options[content_fade]', array(
		'default' => true,
		'type'    => 'option',
	) );

	$wp_customize->add_control( 'parallax-fade', array(
		'settings' => 'shoreline_theme_options[content_fade]',
		'label'    => 'Enable Fade in effects',
		'section'  => 'shoreline-theme-features',
		'type'     => 'checkbox'
	) );

	$wp_customize->add_setting( 'site-logo', array(
		'default'           => sprintf( '%s/images/logo.png', get_stylesheet_directory_uri() ),
		'type'              => 'option',
		'sanitize_callback' => 'esc_url_raw'
	) );

	$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'site-logo', array(
		'label'       => __( 'Site Logo :', 'shoreline' ),
		'section'     => 'title_tagline',
		'settings'    => 'site-logo',
		'description' => 'Recommended logo size 204x80'
	) ) );

	//* Retina Logo Image Customizer Settings
	$wp_customize->add_setting( 'site-retina-logo', array(
		'default'           => sprintf( '%s/images/logo@2x.png', get_stylesheet_directory_uri() ),
		'type'              => 'option',
		'sanitize_callback' => 'esc_url_raw'
	) );

	$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'site-retina-logo', array(
		'label'       => __( 'Site Retina Logo :', 'shoreline' ),
		'section'     => 'title_tagline',
		'settings'    => 'site-retina-logo',
		'description' => 'Recommended Retina logo size 408x160'
	) ) );

	//* Hero Image Customier Settings
	$wp_customize->add_section( 'shoreline-settings', array(
		'title' => __( 'Hero Background', 'shoreline' )
	) );

	$wp_customize->add_setting( 'hero-image', array(
		'default'           => sprintf( '%s/images/hero-bg.jpg', get_stylesheet_directory_uri() ),
		'type'              => 'option',
		'sanitize_callback' => 'esc_url_raw'
	) );

	$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'hero-bg', array(
		'label'    => __( 'Hero Background Image:', 'shoreline' ),
		'section'  => 'shoreline-settings',
		'settings' => 'hero-image'
	) ) );

}

add_action( 'wp_enqueue_scripts', 'local_media_css' );
function local_media_css() {

	$handle = defined( 'CHILD_THEME_NAME' ) && CHILD_THEME_NAME ? sanitize_title_with_dashes( CHILD_THEME_NAME ) : 'child-theme';

	$settings['site_logo']        = get_option( 'site-logo', sprintf( '%s/images/logo.png', get_stylesheet_directory_uri() ) );
	$settings['site_retina_logo'] = get_option( 'site-retina-logo', sprintf( '%s/images/logo@2x.png', get_stylesheet_directory_uri() ) );
	$settings['hero_bg']          = get_option( 'hero-image', sprintf( '%s/images/hero-bg.jpg', get_stylesheet_directory_uri() ) );

	$css = '';

	$css .= sprintf( '.header-image .site-header .wrap { background-image: url(%s) }', $settings['site_logo'] );
	$css .= sprintf( '.hero-unit { background-image: url(%s); }', $settings['hero_bg'] );
	$css .= sprintf( '
		@media
		only screen and (-webkit-min-device-pixel-ratio: 2),
		only screen and (   min--moz-device-pixel-ratio: 2),
		only screen and (     -o-min-device-pixel-ratio: 2/1),
		only screen and (        min-device-pixel-ratio: 2),
		only screen and (                min-resolution: 192dpi),
		only screen and (                min-resolution: 2dppx) {
		    .header-image .site-header .wrap {
		        background-image: url(%s);
		    }
		}', $settings['site_retina_logo']
	);

	if ( $css ) {
		wp_add_inline_style( $handle, $css );
	}
}
