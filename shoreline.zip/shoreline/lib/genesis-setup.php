<?php

/**
 * The file that sets up our Genesis Child Theme
 *
 * Create settings, controls, and seection for the customizer. If the
 * settings have been changed, then add theme to our css.
 *
 * @since      1.0.0
 *
 * @package    VSELLIS
 * @subpackage VSELLIS/lib
 */

// Priority 15 ensures it runs after Genesis itself has setup.
add_action( 'genesis_setup', 'shoreline_genesis_setup', 15 );

function shoreline_genesis_setup() {
	//* Define Constants

	//* Child theme (do not remove)
	define( 'CHILD_THEME_NAME', 'Shoreline' );
	define( 'CHILD_THEME_URL', 'http://vsellis.com/themes/shoreline' );
	define( 'CHILD_THEME_VERSION', '1.0' );

	define( 'VSELLIS_LIB_DIR', CHILD_DIR . '/lib' );
	define( 'VSELLIS_WIDGETS_DIR', VSELLIS_LIB_DIR . '/widgets' );

	add_action( 'after_setup_theme', 'shoreline_text_domain' );

	//* Adds features
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list' ) );
	add_theme_support( 'genesis-responsive-viewport' );
	add_theme_support( 'genesis-footer-widgets', 3 );
	add_theme_support( 'custom-background' );

	// Removes the text for the breadcrumbs
	add_filter( 'genesis_breadcrumb_args', 'shoreline_breadcrumb_args' );

	// check for bradcrumbs if active add sidebar bumper
	remove_action( 'genesis_before_loop', 'genesis_do_breadcrumbs' );
	add_action( 'genesis_before_content', 'genesis_do_breadcrumbs' );
	add_filter( 'genesis_breadcrumb_args', 'sp_breadcrumb_args' );


	// Reposition the navigation into the header
	unregister_sidebar( 'header-right' );
	unregister_sidebar( 'sidebar-alt' );

	add_theme_support( 'genesis-menus', array( 'primary' => __( 'Primary Navigation Menu', 'shoreline' ) ) );
	remove_action( 'genesis_after_header', 'genesis_do_nav' );
	add_action( 'genesis_header_right', 'genesis_do_nav' );
	add_filter( 'genesis_do_nav', 'shoreline_modify_genesis_do_nav', 10, 3 );

	add_theme_support( 'genesis-style-selector', array(
		'theme-blue'   => __( 'Blue', 'shoreline' ),
		'theme-purple' => __( 'Purple', 'shoreline' ),
		'theme-green'  => __( 'Green', 'shoreline' ),
		'theme-dark'   => __( 'Dark', 'shoreline' ),
	) );

	//* Unregister three column layouts
	genesis_unregister_layout( 'content-sidebar-sidebar' );
	genesis_unregister_layout( 'sidebar-sidebar-content' );
	genesis_unregister_layout( 'sidebar-content-sidebar' );

	add_filter( 'post_class', 'shoreline_post_class' );
	add_action( 'init', 'shoreline_add_sidebars' );

	// Set image sizes
	set_post_thumbnail_size( 380, 270, true );
	add_image_size( 'shoreline-hero', 1800, 425, true );

	add_action( 'genesis_search_title_text', 'shoreline_search' );

	add_filter( 'user_contactmethods', 'shoreline_add_contactmethods', 10, 1 );

}

function shoreline_add_contactmethods( $contactmethods ) {

	$contactmethods['facebook'] = 'Facebook';
	$contactmethods['twitter']  = 'Twitter';
	$contactmethods['linkedin'] = 'Linkedin';
	$contactmethods['pintrest'] = 'Pintrest';

	return $contactmethods;
}

function shoreline_search() {
	$search = ( ! empty( $_GET['s'] ) ) ? $_GET['s'] : '""';

	return sprintf( 'Search Results for: %s', $search );
}

function shoreline_text_domain() {
	load_child_theme_textdomain( 'shoreline', get_stylesheet_directory() . '/languages' );
}


/**
 * Removes the "You are here" text
 * from the breadcrumbs.
 */
function shoreline_breadcrumb_args( $args ) {
	$args['labels']['prefix'] = ' ';

	return $args;
}

function sp_breadcrumb_args( $args ) {
	$args['prefix'] = '<div class="breadcrumb"><div class="wrap">';
	$args['suffix'] = '</div></div>';

	return $args;
}

function shoreline_modify_genesis_do_nav( $nav_output, $nav, $args ) {

	$class = 'menu genesis-nav-menu menu-primary';
	if ( genesis_superfish_enabled() ) {
		$class .= ' js-superfish';
	}

	$args = array(
		'theme_location' => 'primary',
		'container'      => '',
		'menu_class'     => $class,
		'echo'           => 0,
	);

	$nav = wp_nav_menu( $args );

	//* Do nothing if there is nothing to show
	if ( ! $nav ) {
		return;
	}

	$nav_markup_open = genesis_markup( array(
		'html5'   => '<nav %s id="primary-nav">',
		'xhtml'   => '<div id="nav">',
		'context' => 'nav-primary',
		'echo'    => false,
	) );

	$nav_markup_close = genesis_html5() ? '</nav>' : '</div>';
	$nav_output       = $nav_markup_open . $nav . $nav_markup_close;

	// return the modified result
	return sprintf( $nav_output, $nav, $args );
}

/**
 * Adds the wow class for css animation.
 * Also added the fadeInUp class to all posts.
 */

function shoreline_post_class( $classes ) {
	$options = get_option( 'shoreline_theme_options' );

	if ( $options['content_fade'] === true ) //* Add "entry" to the post class array
	{
		$classes[] = 'wow fadeInUp';
	}

	return $classes;

}

/**
 * Register our custom sidebars
 */

function shoreline_add_sidebars() {

	genesis_register_sidebar( array(
			'id'          => 'intro-text',
			'name'        => __( 'Intro Text', 'shoreline' ),
			'description' => __( 'You can drag a text widget here to add some text to your hero unit.', 'shoreline' )
		)
	);

	genesis_register_sidebar( array(
			'id'          => 'home-top',
			'name'        => __( 'Home Top', 'shoreline' ),
			'description' => __( 'Widget area for the top of the home page. Just below the slider area.', 'shoreline' )
		)
	);

	genesis_register_sidebar( array(
			'id'          => 'home-middle',
			'name'        => __( 'Home Middle', 'shoreline' ),
			'description' => __( 'Widget area for the middle(full width) of the home page.', 'shoreline' )
		)
	);
	genesis_register_sidebar( array(
			'id'          => 'home-bottom',
			'name'        => __( 'Home Bottom', 'shoreline' ),
			'description' => __( 'Widget area for the bottom of the home page.', 'shoreline' )
		)
	);

}
