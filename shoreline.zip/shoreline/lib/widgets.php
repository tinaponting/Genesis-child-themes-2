<?php

/**
 * The file that sets up our custom widgets
 *
 *
 * @since      1.0.0
 *
 * @package    VSELLIS
 * @subpackage VSELLIS/lib
 */

//* Include widget class files
require_once get_stylesheet_directory() . '/lib/widgets/shoreline-columns/shoreline-columns.php';

add_action( 'widgets_init', 'shoreline_load_widgets' );
/**
 * Register widgets for use in the Genesis theme.
 *
 * @since 1.7.0
 */
function shoreline_load_widgets() {
	register_widget( 'Shoreline_Columns' );
}