<?php

/**
 * The file that creates our themes hero unit
 *
 * @since      1.0.0
 *
 * @package    VSELLIS
 * @subpackage VSELLIS/lib
 */

add_action( 'genesis_after_header', 'shoreline_do_hero' );

function shoreline_do_hero() {

	// if is home/blog page
	if( is_home() ) {
		genesis_widget_area( 'intro-text', array( 
			'before' => '<section class="hero-unit" data-type="background" data-speed="10"><article data-type="fade-text" data-speed="slow" >',
			'after' => '</article></section>',
		) );	
	} elseif( is_single() || is_page() ) {
		$img = genesis_get_image( array( 'size' => 'shoreline-hero', 'format' => 'url' ) );
		$img = ( $img ) ? sprintf( 'background-image: url(%s);', $img ) : '';
		
		 printf( '<section class="hero-unit" style="%s" data-type="background" data-speed="fast"><div class="wrap">', esc_attr($img) );
			echo '<article data-type="fade-text" data-speed="slow">';
			printf( '<h2>%s</h2>',get_the_title() );
		echo '</article></div></section>';
	}


}