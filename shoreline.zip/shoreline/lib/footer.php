<?php
/**
 * The file modified our footer
 * @package    VSELLIS
 * @subpackage VSELLIS/lib
 */

add_action( 'genesis_footer_creds_text', 'shoreline_footer_creds' );
function shoreline_footer_creds() {
	$creds = sprintf(
	    /* Translators: 1 is copyright, 2 is child theme link, 3 is theme author link, 4 is parent theme link, 5 is WP link, 6 is log in/out link. */
	    __( 'Copyright %1$s &middot; %2$s by %3$s on %4$s &#x000B7; %5$s &#x000B7; %6$s', 'shoreline' ),
	    '[footer_copyright]',
	    '[footer_childtheme_link before=""]',
	    '<a target="_blank" href="http://exempel.se">EXEMPEL</a>',
	    '[footer_wordpress_link]',
	    '[footer_loginout]'
	);
	return $creds;
}