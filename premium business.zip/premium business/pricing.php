<?php
/*
Template Name: Pricing Table Page
*/


// Add custom body class to the head
add_filter( 'body_class', 'metro_add_body_class' );
function metro_add_body_class( $classes ) {
   $classes[] = 'pricingpage';
   return $classes;
}

// set full width layout
add_filter ( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );
remove_action( 'genesis_sidebar', 'genesis_do_sidebar' ); 
remove_action( 'genesis_entry_content', 'genesis_do_post_content' );
remove_action( 'genesis_loop', 'genesis_do_loop' );
add_action('genesis_before_content','before_content');

function before_content(){
?>
<div class="pricing_table_page_container wrap">
<?php
}

add_action('genesis_after_content','after_content');
function after_content(){
?>
</div>
<?php
}

add_action('genesis_before_content_sidebar_wrap','pricing_table',4);
function pricing_table(){
if (genesism_get_option('pricing_table_section')){
?>

<div class='pricingtable_contents'>
<div class='inner_pricing_table pricingtable_contents_inner wrap'>
<div class='title'><h3 class='center_header'>	<?php echo genesism_get_option('price_header_txt'); ?></h3></div>

<div class='pricingtable_cell_cont'>
<div class='pricingtable_cell'>
<div class='pricing_cell pricing_cell1'>		        	

<div class='price_hd'>
<div class='title'><h2><?php echo genesism_get_option('cell_one_title'); ?></h2></div>
<div class="divider"></div>
<div class="price"><h1><?php echo genesism_get_option('cell_one_price'); ?></h1></div>
<div class="duration"><?php echo genesism_get_option('cell_one_duration'); ?></div>
</div>
<ul>
<li><span ></span> <?php echo genesism_get_option('pricing_one_content1'); ?></li>
<li><span></span><?php echo genesism_get_option('pricing_one_content2'); ?></li>
<li><span></span><?php echo genesism_get_option('pricing_one_content3'); ?></li>
<li><span></span><?php echo genesism_get_option('pricing_one_content4'); ?></li>
<li><span></span><?php echo genesism_get_option('pricing_one_content5'); ?></li>
<li class='align-center'><a href='<?php echo genesism_get_option('pricing_one_url'); ?>'><?php echo genesism_get_option('pricing_read'); ?></a></li>
</ul>								
</div>
</div>


<div class='pricingtable_cell'>
<div class='pricing_cell pricing_cell2 center_cell'>		        	

<div class='price_hd'>
<div class='title'><h2><?php echo genesism_get_option('cell_two_title'); ?></h2></div>
<div class="divider"></div>
<div class="price"><h1><?php echo genesism_get_option('cell_two_price'); ?></h1></div>
<div class="duration"><?php echo genesism_get_option('cell_two_duration'); ?></div>
</div>
<ul>
<li><span ></span> <?php echo genesism_get_option('pricing_two_content1'); ?></li>
<li><span></span><?php echo genesism_get_option('pricing_two_content2'); ?></li>
<li><span></span><?php echo genesism_get_option('pricing_two_content3'); ?></li>
<li><span></span> <?php echo genesism_get_option('pricing_two_content4'); ?></li>
<li><span></span><?php echo genesism_get_option('pricing_two_content5'); ?></li>
<li class='align-center'><a href='<?php echo genesism_get_option('pricing_two_url'); ?>'><?php echo genesism_get_option('pricing_read'); ?></a></li>
</ul>								
</div>
</div>

<div class='pricingtable_cell last'>
<div class='pricing_cell pricing_cell3'>		        	

<div class='price_hd'>
<div class='title'><h2><?php echo genesism_get_option('cell_three_title'); ?></h2></div>
<div class="divider"></div>
<div class="price"><h1><?php echo genesism_get_option('cell_three_price'); ?></h1></div>
<div class="duration"><?php echo genesism_get_option('cell_three_duration'); ?></div>
</div>
<ul>
<li><span></span> <?php echo genesism_get_option('pricing_three_content1'); ?></li>
<li><span></span><?php echo genesism_get_option('pricing_three_content2'); ?></li>
<li><span></span><?php echo genesism_get_option('pricing_three_content3'); ?></li>
<li><span></span><?php echo genesism_get_option('pricing_three_content4'); ?></li>
<li><span></span><?php echo genesism_get_option('pricing_three_content5'); ?></li>
<li class='align-center'><a href='<?php echo genesism_get_option('pricing_three_url'); ?>'><?php echo genesism_get_option('pricing_read'); ?></a></li>
</ul>								
</div>
</div>

</div>

</div>

</div>

<?php
}
}


genesis();