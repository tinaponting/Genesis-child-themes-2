<?php
/*
Template Name: Front Page
*/


// Add custom body class to the head
add_filter( 'body_class', 'metro_add_body_class' );
function metro_add_body_class( $classes ) {
   $classes[] = 'frontpage woocommerce';
   return $classes;
}

// set full width layout
add_filter ( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );
remove_action( 'genesis_sidebar', 'genesis_do_sidebar' ); 
remove_action( 'genesis_entry_content', 'genesis_do_post_content' );
remove_action( 'genesis_loop', 'genesis_do_loop' );


add_action('genesis_before_content_sidebar_wrap','front_content_section',2);
function front_content_section(){


?>
<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Front content Widget') ) : ?>
<div class="widget">
<h4 itemprop="headline"><?php _e("Front Page Top #Widget", 'genesis'); ?></h4>
<p><?php _e("Displays Latest posts with thumbnails.", 'genesis'); ?></p>
</div><!-- end .widget -->
<?php endif; ?> 	
<?php

 }

add_action('genesis_before_content_sidebar_wrap','header_optin_box',1);
function header_optin_box(){
if (genesism_get_option('header_optin_section')){
?>

<div class="header_optin front_cont">
<div class="inner_header_optin wrap">
<div class="header_optin_left_img">
<img alt='<?php echo genesism_option('hdr_optin_title4'); ?>' src='<?php echo genesism_option('opt_img'); ?>'/>
</div>

<div class="header_optin_right">
<div class="optin_right_header">
	<h3><?php echo genesism_option('hdr_optin_title4'); ?></h3>
	<p><?php echo genesism_option('hdr_optin_para4'); ?></p>
</div>
<div class="landing_right_optin">
	<form method="post" class="form" action="<?php echo stripslashes(genesism_option('optin_url4')); ?>" target="_blank">
	<div class="names"><input class="name" type="text" name="<?php echo stripslashes(genesism_option('optin_name4')); ?>" placeholder="<?php echo stripslashes(genesism_option('name_text4')); ?>"><div class='admins'></div></div>					
	<div class="names"><input class="email" type="text" name="<?php echo stripslashes(genesism_option('optin_email4')); ?>" placeholder="<?php echo stripslashes(genesism_option('email_text4')); ?>"><div class='mails'></div></div>
	<?php echo stripslashes(genesism_option('optin_hidden4')); ?>
	<input name="submit" class="submit" type="submit" value="<?php echo stripslashes(genesism_option('submit_text4')); ?>"/>
	</form>
</div>

</div>

</div>
</div>
<?php
}
}



add_action('genesis_before_content_sidebar_wrap','front_optin_box',3);
function front_optin_box(){
if (genesism_get_option('front_optin_section')){
?>
<div class='front_optin' style='background-image:url(<?php echo genesism_option('frnt_opt_bg'); ?>)'>
<div class='front_optin_color'>
<div class="front_optin_content">
			<div class="front_btm_optin_title">
				<h3><?php echo genesism_option('opt_title2'); ?></h3>
				<p><?php echo genesism_option('opt_content2'); ?></p>	
			</div>	
			<form method="post" class="form" action="<?php echo stripslashes(genesism_option('optin_url2')); ?>" target="_blank">				
			<div class="names"><input class="email" type="text" name="<?php echo stripslashes(genesism_option('optin_email2')); ?>" placeholder="  <?php echo stripslashes(genesism_option('email_text2')); ?>"><div class='mails'></div></div>
			<?php echo stripslashes(genesism_option('optin_hidden2')); ?>
			<input name="submit" class="submit" type="submit" value="<?php echo stripslashes(genesism_option('submit_text2')); ?>"/>
			</form>
</div>
</div>
</div>
<?php
}
}

genesis();