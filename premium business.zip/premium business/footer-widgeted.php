<div class="footer-widgets" id="footer">
	<div class="wrap">
    	<div class="footer-widgets-1">
		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer Left') ) : ?>
    			<div class="widget">
            		<h4 itemprop="headline"><?php _e("Footer #Left", 'genesis'); ?></h4>
            		<p><?php _e("This is an example of a widget area that you can place text to describe a product or service. You can also use other WordPress widgets such as recent posts, recent comments, a tag cloud or more.", 'genesis'); ?></p>
	    		</div><!-- end .widget -->
	    	<?php endif; ?> 
		 </div>

   		<!-- end .footer-left -->
    
 
    	</div><!-- end .wrap -->
</div><!-- end #footer-widgets -->