<?php

/**
 * This function registers the default values for genesis theme settings
 */
 
function genesism_theme_settings_defaults() {
$defaults = array( // define our defaults
'style' => 'default',
'custom' => 0,
'shortcodes-css' => 1,

'header_logo' => 1,
'header_social' => 1,
'header_contact' => 1,
'btm_menu' => 1,
'read_more' => 1,
'header_optin_section' => 1,
'front_optin_section' => 1,
'single_social_share' => 1,
'landing_img_optin' => 1,
'landing_feature' => 1,
'postadcheck' => 1,
'footer1' => 1,

'f_img_width'=>'304',
'f_img_height'=>'206',

'header_logo_img' => 'http://premium.genesislovers.com/wp-content/uploads/2016/05/logo1.png',
'emil_addr' => 'Contact Email: mail@example.com',
'read_text' => 'Read more',
'name_text4' => 'Enter Your Name',
'email_text4' => 'Enter Your Email',
'submit_text4' => 'Subscribe Me',
'hdr_optin_title4' => 'labore velit occaecat tempor in nisi ullamco tempor.',
'hdr_optin_para4' => 'Lorem ipsum reprehenderit minim in cillum exercitation labore quis velit occaecat tempor in nisi ullamco tempor. Clean quality
code make it easy to use & costumize.',
'opt_img' => 'http://premium.genesislovers.com/wp-content/uploads/2016/05/manimg1.png',
'email_text2' => 'Type your email here...',
'submit_text2' => 'Subscribe now',
'opt_title2' => 'SUBSCRIBE NOW!',
'opt_content2' => 'LEAVE YOUR EMAIL BELOW AND WE WILL LET YOU KNOW:',
'frnt_opt_bg' => 'http://premium.genesislovers.com/wp-content/uploads/2016/05/btm_op_bg.jpg',

'share_title' => 'Social share',
'name_text1' => 'Enter Your Name',
'email_text1' => 'Enter Your Email',
'submit_text1' => 'Subscribe',
'opt_title' => 'This must have app will boost your personal productivity.',
'opt_content' => 'There are many variations of passages of Lorem Ipsum available',
'land_optin_img' => '<iframe width="560" height="315" src="https://www.youtube.com/embed/PITmXXF5Ukw" frameborder="0" allowfullscreen></iframe>',
'land_optin_bg' => 'http://premium.genesislovers.com/wp-content/uploads/2016/05/land-bg.jpg',

'landing_feature_title' => 'There are many variations of passages ',
'landing_feature_para' => 'If you are going to use a passage of Lorem Ipsum sure there isn"t anything embarrassing hidden in the middle of text.',
'land_ftr1_img' => 'http://premium.genesislovers.com/wp-content/uploads/2016/05/lf1.png',
'ftr1_title' => 'The standard chunk',
'feature1_para' => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore .',
'land_ftr2_img' => 'http://premium.genesislovers.com/wp-content/uploads/2016/05/lf2.png',
'ftr2_title' => 'Denouncing Pleasure',
'feature2_para' => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore .',
'land_ftr3_img' => 'http://premium.genesislovers.com/wp-content/uploads/2016/05/lf3.png',
'ftr3_title' => 'Temporibus autem',
'feature3_para' => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore .',
'land_ftr4_img' => 'http://premium.genesislovers.com/wp-content/uploads/2016/05/lf4.png',
'ftr4_title' => 'Voluptatem accusantium',
'feature4_para' => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore .',
'land_ftr5_img' => 'http://premium.genesislovers.com/wp-content/uploads/2016/05/lf5.png',
'ftr5_title' => 'Totam Rem aperiam',
'feature5_para' => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore .',
'land_ftr6_img' => 'http://premium.genesislovers.com/wp-content/uploads/2016/05/lf6.png',
'ftr6_title' => 'Sed ut perspiciatis',
'feature6_para' => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore .',
'float' => 'right',
'postad' => '',

'footer_text' => 'Copyright &copy;'.date('Y') .  ' <a href="'. get_bloginfo('url') .'">' . get_bloginfo('name') . '</a>'
	
	);
	
	return apply_filters('genesism_theme_settings_defaults', $defaults);

}



function genesism_theme_settings_boxes() {
	global $_genesism_theme_settings_pagehook;
	
	if (function_exists('add_screen_option')) { add_screen_option('layout_columns', array('max' => 2, 'default' => 2) ); }

add_meta_box('genesism-theme-settings-version', __('Theme Information', 'genesism'), 'genesism_theme_settings_info_box', $_genesism_theme_settings_pagehook, 'normal');	
 }
  
 function genesism_theme_settings_info_box() { 
?>

<p class="bolder"><strong><?php echo CHILD_THEME_NAME; ?></strong> by <a href="http://genesislovers.com">genesislovers.com</a></p>
<p><strong>
  <?php _e('Version:', 'genesism'); ?>
  </strong> <?php echo CHILD_THEME_VERSION; ?> <strong>
   </p>
<p><span class="description">
  <?php _e('For support, please visit <a href="http://genesislovers.com/contactus/">http://genesislovers.com/contactus/</a>', 'genesism'); ?>
  </span></p>

<div id="tabs">

	<ul>
		<li><a href="#tabs-1"><?php _e("Top Header Logo", 'genesism'); ?></a></li>	
		<li><a href="#tabs-2"><?php _e("Header Social", 'genesism'); ?></a></li>
		<li><a href="#tabs-3"><?php _e("Header contact", 'genesism'); ?></a></li>
		<li><a href="#tabs-4"><?php _e("Bottom Header Menu", 'genesism'); ?></a></li>	
		<li><a href="#tabs-5"><?php _e("Feature Image", 'genesism'); ?></a></li>
		<li><a href="#tabs-6"><?php _e("Read More Section", 'genesism'); ?></a></li>
		<li><a href="#tabs-7"><?php _e("Header Optin Section", 'genesism'); ?></a></li>	
		<li><a href="#tabs-8"><?php _e("Front Bottom	 Optin Section", 'genesism'); ?></a></li>
		
		<li><a href="#tabs-9"><?php _e("Single Page Social Share", 'genesism'); ?></a></li>
	
		<li><a href="#tabs-10"><?php _e("Landing Video Optin Box", 'genesism'); ?></a></li>
		<li><a href="#tabs-11"><?php _e("Landing Feature Box", 'genesism'); ?></a></li>
		<li><a href="#tabs-12"><?php _e("Footer Text section", 'genesism'); ?></a></li>
		
		<li><a href="#tabs-13"><?php _e("Custom CSS", 'genesism'); ?></a></li>
		<li><a href="#tabs-14"><?php _e("Single Post Ad", 'genesism'); ?></a></li>
	
	</ul>
	
	
	<div id="tabs-1">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[header_logo]" id="<?php echo PREMIUM_SETTINGS_FIELD; ?>[header_logo]" value="1" <?php checked(1, genesism_get_option('header_logo')); ?> />
				<label for="<?php echo PREMIUM_SETTINGS_FIELD; ?>[header_logo]">
				<?php _e("Enable Top Header Logo Section", 'genesism'); ?>
				</label>
			</li>
			<li class="second_list">
				<label>Enter the Top Header Logo Url Link here</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[header_logo_img]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('header_logo_img') ); ?></textarea>
			</li>	
		</ul>
	</div>	
	
	
	<div id="tabs-2">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[header_social]" id="<?php echo PREMIUM_SETTINGS_FIELD; ?>[header_social]" value="1" <?php checked(1, genesism_get_option(header_social)); ?> />
				<label for="<?php echo PREMIUM_SETTINGS_FIELD; ?>[header_social]">
				<?php _e("Enable Header Social follow", 'genesism'); ?>
				</label>
			</li>
			
			<li class="second_list">
				<label>Paste your Facebook URL Link</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[facebook_text1]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('facebook_text1') ); ?></textarea> 
			</li>
			
			<li class="second_list"><label>Paste your Twitter URL Link</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[twitter_text1]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('twitter_text1') ); ?></textarea> 
			</li>
			<li class="second_list"><label>Paste your Googleplus URL Link</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[googleplus_text1]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('googleplus_text1') ); ?></textarea> 
			</li>
			
			<li class="second_list"><label>Paste your Pinterest URL Link</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[pinterest_text1]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('pinterest_text1') ); ?></textarea>
			</li>
			
			<li class="second_list"><label>Paste your Linkedin URL Link</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[linkedin_text1]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('linkedin_text1') ); ?></textarea>
			</li>
			
			<li class="second_list"><label>Paste your Youtube URL Link</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[youtube_text1]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('youtube_text1') ); ?></textarea>
			</li>
			
			
		</ul>	
	</div>
	
	<div id="tabs-3">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[header_contact]" id="<?php echo PREMIUM_SETTINGS_FIELD; ?>[header_contact]" value="1" <?php checked(1, genesism_get_option('header_contact')); ?> />
				<label for="<?php echo PREMIUM_SETTINGS_FIELD; ?>[header_contact]">
				<?php _e("Enable Header Contact Box", 'genesism'); ?>
				</label>
			</li>
			
			<li class="second_list">
				<label>Enter the  Contact Email Address here</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[emil_addr]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('emil_addr') ); ?></textarea>
			</li>
		</ul>
	</div>
	
	<div id="tabs-4">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[btm_menu]" id="<?php echo PREMIUM_SETTINGS_FIELD; ?>[btm_menu]" value="1" <?php checked(1, genesism_get_option('btm_menu')); ?> />
				<label for="<?php echo PREMIUM_SETTINGS_FIELD; ?>[btm_menu]">
				<?php _e("Enable bottom Header Menu Section", 'genesism'); ?>
				</label>
			</li>
		</ul>
	</div>
		
	
	<div id="tabs-5">
		<ul>
			<li class="second_list"><label>Width of the Featured Image</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[f_img_width]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('f_img_width') ); ?></textarea> 
			</li>
			<li class="second_list"><label>Height of the Featured Image</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[f_img_height]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('f_img_height') ); ?></textarea> 
			</li>
		</ul>
	</div>
	
	<div id="tabs-6">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[read_more]" id="<?php echo PREMIUM_SETTINGS_FIELD; ?>[read_more]" value="1" <?php checked(1, genesism_get_option('read_more')); ?> />
				<label for="<?php echo PREMIUM_SETTINGS_FIELD; ?>[read_more]">
				<?php _e("Enable Read More Section", 'genesism'); ?>
				</label>
			</li>
			<li class="second_list">
				<label>Enter the Read More Text here</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[read_text]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('read_text') ); ?></textarea>
			</li>
		</ul>
	</div>
	
	<div id="tabs-7">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[header_optin_section]" id="<?php echo PREMIUM_SETTINGS_FIELD; ?>[header_optin_section]" value="1" <?php checked(1, genesism_get_option('header_optin_section')); ?> />
				<label for="<?php echo PREMIUM_SETTINGS_FIELD; ?>[header_optin_section]">
				<?php _e("Enable Front Page Header Optin Section", 'genesism'); ?>
				</label>
			</li>
			
			<li class="second_list">
				<label>Paste your Optin Code and Press Tab Button</label>
				<textarea id="optin_code4" name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[optin_code4]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_code4') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form name</label>
				<textarea id="optin_name4" name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[optin_name4]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('optin_name4') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form Email</label>
				<textarea id="optin_email4" name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[optin_email4]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('optin_email4') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form action url</label>
				<textarea id="optin_url4" name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[optin_url4]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_url4') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Hidden fields</label>
				<textarea id="optin_hidden4" name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[optin_hidden4]" rows="10" cols="70"><?php echo htmlspecialchars( genesism_get_option(optin_hidden4) ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Change your Optin Name Place holder text here</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[name_text4]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('name_text4') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Enter your Email Place holder text here</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[email_text4]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('email_text4') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Change your Subscribe me button text</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[submit_text4]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('submit_text4') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Enter the Optin Header Text here</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[hdr_optin_title4]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('hdr_optin_title4') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Enter the Optin Content Text here</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[hdr_optin_para4]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('hdr_optin_para4') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Header Optin Left Image link here</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[opt_img]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('opt_img') ); ?></textarea>
			</li>
						
			
		<script type="text/javascript">

	var $j = jQuery.noConflict();

	$j(document).ready(function(){

	$j("#optin_code4").blur(function(){

	var txt=$j(this).val();

	

	if(txt=="")

	{

	$j("#optin_url4").val("");

	$j("#optin_hidden4").val("");

	$j("#optin_name4").val("");

	$j("#optin_email4").val("");

	return false;

	}

	

	var pos1=0;

	var pos2=0;

	var i=1;

	var hidden="";

	while(1)

	{

	pos1=txt.indexOf("<input",pos1);

	if(pos1<0) break;

	pos2=txt.indexOf(">",pos1+1);

	var text=txt.substr(pos1,pos2-pos1);

	

	pp=text.indexOf('type="hidden"');

	pp1=text.indexOf('type="submit"');

	

	if(pp>0)

	{

	hidden+=text+">";

	}

	if(pp<0 && pp1<0){

	pp=text.indexOf('name="');

	pp=pp+6;

	pp1=text.indexOf('"',pp+1);

	var tt=text.substr(pp,pp1-pp);

	if(i==1) $j("#optin_name4").val(tt);

	else $j("#optin_email4").val(tt);

	i++;

	}

	

	pos1=pos2+1;

	}

	

	pos1=txt.indexOf("<form",0);

	pos2=txt.indexOf(">",pos1+1);

	text=txt.substr(pos1,pos2-pos1);

	pp=text.indexOf('action="');

	pp=pp+8;

	pp1=text.indexOf('"',pp+1);

	var tt=text.substr(pp,pp1-pp);

	$j("#optin_url4").val(tt);

	$j("#optin_hidden4").val(hidden);

	});

	});

</script> 
</ul>
</div>
	
<div id="tabs-8">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[front_optin_section]" id="<?php echo PREMIUM_SETTINGS_FIELD; ?>[front_optin_section]" value="1" <?php checked(1, genesism_get_option('front_optin_section')); ?> />
				<label for="<?php echo PREMIUM_SETTINGS_FIELD; ?>[front_optin_section]">
				<?php _e("Enable Front Page Bottom Optin Section", 'genesism'); ?>
				</label>
			</li>
			<li class="second_list">
				<label>Paste your Optin Code and Press Tab Button</label>
				<textarea id="optin_code2" name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[optin_code2]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_code2') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form name</label>
				<textarea id="optin_name2" name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[optin_name2]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('optin_name2') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form Email</label>
				<textarea id="optin_email2" name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[optin_email2]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('optin_email2') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form action url</label>
				<textarea id="optin_url2" name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[optin_url2]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_url2') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Hidden fields</label>
				<textarea id="optin_hidden2" name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[optin_hidden2]" rows="10" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_hidden2') ); ?></textarea>
			</li>
						
			<li class="second_list">
				<label>Enter your Email Place holder text here</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[email_text2]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('email_text2') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Change your Subscribe me button text</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[submit_text2]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('submit_text2') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Enter the Optin Header Text here</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[opt_title2]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('opt_title2') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Enter the Optin Content Text here</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[opt_content2]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('opt_content2') ); ?></textarea>
			</li>
						
			<li class="second_list">
				<label>Change the Front Page Bottom Optin Background Image URL link here</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[frnt_opt_bg]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('frnt_opt_bg') ); ?></textarea>
			</li>
			
			
			
		<script type="text/javascript">

	var $j = jQuery.noConflict();

	$j(document).ready(function(){

	$j("#optin_code2").blur(function(){

	var txt=$j(this).val();

	

	if(txt=="")

	{

	$j("#optin_url2").val("");

	$j("#optin_hidden2").val("");

	$j("#optin_name2").val("");

	$j("#optin_email2").val("");

	return false;

	}

	

	var pos1=0;

	var pos2=0;

	var i=1;

	var hidden="";

	while(1)

	{

	pos1=txt.indexOf("<input",pos1);

	if(pos1<0) break;

	pos2=txt.indexOf(">",pos1+1);

	var text=txt.substr(pos1,pos2-pos1);

	

	pp=text.indexOf('type="hidden"');

	pp1=text.indexOf('type="submit"');

	

	if(pp>0)

	{

	hidden+=text+">";

	}

	if(pp<0 && pp1<0){

	pp=text.indexOf('name="');

	pp=pp+6;

	pp1=text.indexOf('"',pp+1);

	var tt=text.substr(pp,pp1-pp);

	if(i==1) $j("#optin_name2").val(tt);

	else $j("#optin_email2").val(tt);

	i++;

	}

	

	pos1=pos2+1;

	}

	

	pos1=txt.indexOf("<form",0);

	pos2=txt.indexOf(">",pos1+1);

	text=txt.substr(pos1,pos2-pos1);

	pp=text.indexOf('action="');

	pp=pp+8;

	pp1=text.indexOf('"',pp+1);

	var tt=text.substr(pp,pp1-pp);

	$j("#optin_url2").val(tt);

	$j("#optin_hidden2").val(hidden);

	});

	});



</script> 
			
		</ul>
	</div>
	
	
	
	
	<div id="tabs-9">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[single_social_share]" id="<?php echo PREMIUM_SETTINGS_FIELD; ?>[single_social_share]" value="1" <?php checked(1, genesism_get_option('single_social_share')); ?> />
				<label for="<?php echo PREMIUM_SETTINGS_FIELD; ?>[single_social_share]">
				<?php _e("Enable Single Page Social Share Section", 'genesism'); ?>
				</label>
			</li>
			
			<li class="second_list">
				<label>Change the Single Page Social Share Header Text here</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[share_title]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('share_title') ); ?></textarea>
			</li>
			
		</ul>
	</div>
	
	
	
		
	<div id="tabs-10">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[landing_img_optin]" id="<?php echo PREMIUM_SETTINGS_FIELD; ?>[landing_img_optin]" value="1" <?php checked(1, genesism_get_option('landing_img_optin')); ?> />
				<label for="<?php echo PREMIUM_SETTINGS_FIELD; ?>[landing_img_optin]">
				<?php _e("Enable Landing Page Image & Optin Section", 'genesism'); ?>
				</label>
			</li>
			
			<li class="second_list">
				<label>Paste your Optin Code and Press Tab Button</label>
				<textarea id="optin_code1" name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[optin_code1]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_code1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form name</label>
				<textarea id="optin_name1" name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[optin_name1]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('optin_name1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form Email</label>
				<textarea id="optin_email1" name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[optin_email1]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('optin_email1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form action url</label>
				<textarea id="optin_url1" name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[optin_url1]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_url1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Hidden fields</label>
				<textarea id="optin_hidden1" name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[optin_hidden1]" rows="10" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_hidden1') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Change your Optin Name Place holder text here</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[name_text1]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('name_text1') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Enter your Email Place holder text here</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[email_text1]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('email_text1') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Change your Subscribe me button text</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[submit_text1]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('submit_text1') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Enter the Optin Header Text here</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[opt_title]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('opt_title') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Enter the Optin Content Text here</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[opt_content]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('opt_content') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Page Video link here</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[land_optin_img]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('land_optin_img') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Change the Landing Page Background Image URL link here</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[land_optin_bg]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('land_optin_bg') ); ?></textarea>
			</li>
			
			
			
		<script type="text/javascript">

	var $j = jQuery.noConflict();

	$j(document).ready(function(){

	$j("#optin_code1").blur(function(){

	var txt=$j(this).val();

	

	if(txt=="")

	{

	$j("#optin_url1").val("");

	$j("#optin_hidden1").val("");

	$j("#optin_name1").val("");

	$j("#optin_email1").val("");

	return false;

	}

	

	var pos1=0;

	var pos2=0;

	var i=1;

	var hidden="";

	while(1)

	{

	pos1=txt.indexOf("<input",pos1);

	if(pos1<0) break;

	pos2=txt.indexOf(">",pos1+1);

	var text=txt.substr(pos1,pos2-pos1);

	

	pp=text.indexOf('type="hidden"');

	pp1=text.indexOf('type="submit"');

	

	if(pp>0)

	{

	hidden+=text+">";

	}

	if(pp<0 && pp1<0){

	pp=text.indexOf('name="');

	pp=pp+6;

	pp1=text.indexOf('"',pp+1);

	var tt=text.substr(pp,pp1-pp);

	if(i==1) $j("#optin_name1").val(tt);

	else $j("#optin_email1").val(tt);

	i++;

	}

	

	pos1=pos2+1;

	}

	

	pos1=txt.indexOf("<form",0);

	pos2=txt.indexOf(">",pos1+1);

	text=txt.substr(pos1,pos2-pos1);

	pp=text.indexOf('action="');

	pp=pp+8;

	pp1=text.indexOf('"',pp+1);

	var tt=text.substr(pp,pp1-pp);

	$j("#optin_url1").val(tt);

	$j("#optin_hidden1").val(hidden);

	});

	});



</script> 
			
			
		</ul>
	</div>
	
	
	<div id="tabs-11">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[landing_feature]" id="<?php echo PREMIUM_SETTINGS_FIELD; ?>[landing_feature]" value="1" <?php checked(1, genesism_get_option('landing_feature')); ?> />
				<label for="<?php echo PREMIUM_SETTINGS_FIELD; ?>[landing_feature]">
				<?php _e("Enable Landing Feature Section", 'genesism'); ?>
				</label>
			</li>
			
			<li class="second_list">
				<label>Change the Landing Feature Header Text here</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[landing_feature_title]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_title') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Feature Content Text here</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[landing_feature_para]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_para') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Change the Landing Feature One Image URL Link here</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[land_ftr1_img]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('land_ftr1_img') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Change the Landing Feature One Title Text here</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[ftr1_title]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('ftr1_title') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Feature One Title Link here</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[ftr1_link]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('ftr1_link') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Feature One Para Text here</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[feature1_para]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('feature1_para') ); ?></textarea>
			</li>
			
			
			<li class="second_list">
				<label>Change the Landing Feature Two Image URL Link here</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[land_ftr2_img]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('land_ftr2_img') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Change the Landing Feature Two Title Text here</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[ftr2_title]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('ftr2_title') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Feature Two Title Link here</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[ftr2_link]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('ftr2_link') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Feature Two Para Text here</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[feature2_para]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('feature2_para') ); ?></textarea>
			</li>
			
			
			<li class="second_list">
				<label>Change the Landing Feature Three Image URL Link here</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[land_ftr3_img]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('land_ftr3_img') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Change the Landing Feature Three Title Text here</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[ftr3_title]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('ftr3_title') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Feature Three Title Link here</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[ftr3_link]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('ftr3_link') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Feature Three Para Text here</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[feature3_para]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('feature3_para') ); ?></textarea>
			</li>
			
			
			<li class="second_list">
				<label>Change the Landing Feature Four Image URL Link here</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[land_ftr4_img]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('land_ftr4_img') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Change the Landing Feature Four Title Text here</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[ftr4_title]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('ftr4_title') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Feature Four Title Link here</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[ftr4_link]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('ftr4_link') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Feature Four Para Text here</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[feature4_para]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('feature4_para') ); ?></textarea>
			</li>
			
			
			<li class="second_list">
				<label>Change the Landing Feature Five Image URL Link here</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[land_ftr5_img]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('land_ftr5_img') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Change the Landing Feature Five Title Text here</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[ftr5_title]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('ftr5_title') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Feature Five Title Link here</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[ftr5_link]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('ftr5_link') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Feature Five Para Text here</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[feature5_para]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('feature5_para') ); ?></textarea>
			</li>
						
			
			<li class="second_list">
				<label>Change the Landing Feature Six Image URL Link here</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[land_ftr6_img]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('land_ftr6_img') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Change the Landing Feature Six Title Text here</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[ftr6_title]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('ftr6_title') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Feature Six Title Link here</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[ftr6_link]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('ftr6_link') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Feature Six Para Text here</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[feature6_para]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('feature6_para') ); ?></textarea>
			</li>
			
			
		</ul>
	</div>
	
	<div id="tabs-12">	   
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[footer1]" id="<?php echo PREMIUM_SETTINGS_FIELD; ?>[footer1]" value="1" <?php checked(1, genesism_get_option('footer1')); ?> />
				<label for="<?php echo PREMIUM_SETTINGS_FIELD; ?>[footer1]">
				<?php _e("Enable Footer text", 'genesism'); ?>
				</label>
			</li>
			<li class="second_list"><label>Use custom footer text?</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[footer_text]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('footer_text') ); ?></textarea> 
			</li>
		</ul>
	</div>	
	
	
	
	 <div id="tabs-13">
		<ul>
		<li class="second_list">
				<label>Enter the Custom CSS here</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[custom_css]" rows="30" cols="70"><?php echo htmlspecialchars( genesism_get_option('custom_css') ); ?></textarea>
		</li>			
		</ul>
	</div>
	
	<div id="tabs-14">
		<ul>
			<li class="first_list chkbox">
			  <input type="checkbox" name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[postadcheck]" id="<?php echo PREMIUM_SETTINGS_FIELD; ?>[postadcheck]" value="1" <?php checked(1, genesism_get_option('postadcheck')); ?> />
				<label for="<?php echo PREMIUM_SETTINGS_FIELD; ?>[postadcheck]">
				<?php _e("Enable postad section", 'genesism'); ?>
			  </label>
			</li>
			<li class="second_list">
				<label>Enter the ad position ... left or right...</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[float]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('float') ); ?></textarea> 
			</li>
			<li class="second_list">
				<label>Enter the Post Advertisement Image url</label>
				<textarea name="<?php echo PREMIUM_SETTINGS_FIELD; ?>[postad]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('postad') ); ?></textarea> 
			 </li>
		</ul>
	</div>
	
	
</div>  
  
<?php
}
 
 

	