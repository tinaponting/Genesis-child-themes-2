<?php

function maktasty_customize_register( $wp_customize ) {
 /*******************************************
Color scheme
********************************************/
 
// add the section to contain the settings
$wp_customize->add_section( 'textcolors' , array(
    'title' =>  'Color Scheme',
) );

// 1.Background Color
$txtcolors[] = array(
    'slug'=>'body_bg_color', 
    'default' => '#F1F1F1',
    'label' => 'Background Color'
);

 
// 2.Body Text Color
$txtcolors[] = array(
    'slug'=>'body_txt_color', 
    'default' => '#888888',
    'label' => 'Body Text Color'
);


// 3.Header Text Color
$txtcolors[] = array(
    'slug'=>'header_txt_color', 
    'default' => '#222222',
    'label' => 'Header Text Color'
);

// 4.Top Header Background

$txtcolors[] = array(
    'slug'=>'top_header_bg', 
    'default' => '#FFFFFF',
    'label' => 'Top Header BG Color'
);


// 5.Bottom Header Background

$txtcolors[] = array(
    'slug'=>'btm_header_bg', 
    'default' => '#4C4C4C',
    'label' => 'Bottom Header BG Color'
);



// 6.Link color
$txtcolors[] = array(
    'slug'=>'link_color', 
    'default' => '#169FE6',
    'label' => 'Link Color'
);


// 7.Link Hover color
$txtcolors[] = array(
    'slug'=>'link_hover_color', 
    'default' => '#0965a0',
    'label' => 'Link Hover Color'
);

 
// 8.Border color 
$txtcolors[] = array(
    'slug'=>'border_color', 
    'default' => '#EEEEEE',
    'label' => 'Border Color '
);

//9.Pricing Cell BG
$txtcolors[] = array(
    'slug'=>'price_cell_bg', 
    'default' => '#f4f5f6',
    'label' => 'Pricing Cell BG Color '
);

//10.Cell One Header BG
$txtcolors[] = array(
    'slug'=>'price_cell1_hdr', 
    'default' => '#424a56',
    'label' => 'Cell One Header Color '
);

//11.Cell Two Header BG
$txtcolors[] = array(
    'slug'=>'price_cell2_hdr', 
    'default' => '#f87c45',
    'label' => 'Cell Two Header BG'
);

//12.Cell Three Header BG
$txtcolors[] = array(
    'slug'=>'price_cell3_hdr', 
    'default' => '#4FB4D9',
    'label' => 'Cell Three Header BG Color '
);

//13.Call Act Button 
$txtcolors[] = array(
    'slug'=>'call_act_button', 
    'default' => '#FF406C',
    'label' => 'Call Act Button Color '
);

//14.Call Act Button Hover
$txtcolors[] = array(
    'slug'=>'call_act_button_hover', 
    'default' => '#DA5675',
    'label' => 'Call Act Button HoverColor '
);

//15.Call Act BG
$txtcolors[] = array(
    'slug'=>'call_act_bg', 
    'default' => '#363F52',
    'label' => 'Call Act BG Color '
);

//16.Team Social BG
$txtcolors[] = array(
    'slug'=>'team_social_bg', 
    'default' => '#BBBBBB',
    'label' => 'Team Social BG Color '
);

//17.Footer Text
$txtcolors[] = array(
    'slug'=>'footer_text_clr', 
    'default' => '#CCCCCC',
    'label' => 'Footer Text Color '
);

//18.Top Footer BG
$txtcolors[] = array(
    'slug'=>'top_footer_bg', 
    'default' => '#424A56',
    'label' => 'Top Footer BG Color '
);

//19.site Footer BG
$txtcolors[] = array(
    'slug'=>'site_footer_bg', 
    'default' => '#566171',
    'label' => 'Site Footer BG Color '
);

//20.Sidebar BG
$txtcolors[] = array(
    'slug'=>'sidebar_bg', 
    'default' => '#F7F7F7',
    'label' => 'Sidebar BG Color '
);



// add the settings and controls for each color
foreach( $txtcolors as $txtcolor ) {
 
    // SETTINGS
    $wp_customize->add_setting(
        $txtcolor['slug'], array(
            'default' => $txtcolor['default'],
            'type' => 'option', 
            'capability' => 
            'edit_theme_options'
        )
    );
    // CONTROLS
    $wp_customize->add_control(
        new WP_Customize_Color_Control(
            $wp_customize,
            $txtcolor['slug'], 
            array('label' => $txtcolor['label'], 
            'section' => 'textcolors',
            'settings' => $txtcolor['slug'])
        )
    );
}
}
add_action( 'customize_register', 'maktasty_customize_register' );