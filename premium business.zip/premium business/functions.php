<?php
require_once(TEMPLATEPATH.'/lib/init.php'); // Start Genesis Engine
require_once(STYLESHEETPATH.'/lib/init.php'); // Start blog Options
require_once(STYLESHEETPATH.'/lib/updates.php'); // updates

include_once( 'lib/customizer.php' );
//* Add HTML5 markup structure
add_theme_support( 'html5' );


/** Support for various Image sizes */
add_theme_support('post-thumbnails');
//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Add support for custom background
//add_theme_support( 'custom-background' );

// Add widgeted footer section
add_action('genesis_before_footer', 'footer_bottom_widgets'); 
function footer_bottom_widgets() {
    require(CHILD_DIR.'/footer-widgeted.php');
}

 //* Display author box on archive pages
add_filter( 'get_the_author_genesis_author_box_archive', '__return_true' );

//* Customize the author box title
add_filter( 'genesis_author_box_title', 'custom_author_box_title' );
function custom_author_box_title() {
	return "<h3 itemscope=\"Name\"> " . get_the_author() . "</h3>";
}

function ea_default_term_title( $value, $term_id, $meta_key, $single ) {
	if( ( is_category() || is_tag() || is_tax() ) && 'headline' == $meta_key && ! is_admin() ) {
	
		// Grab the current value, be sure to remove and re-add the hook to avoid infinite loops
		remove_action( 'get_term_metadata', 'ea_default_term_title', 10 );
		$value = get_term_meta( $term_id, 'headline', true );
		add_action( 'get_term_metadata', 'ea_default_term_title', 10, 4 );
		// Use term name if empty
		if( empty( $value ) ) {
			$term = get_term_by( 'term_taxonomy_id', $term_id );
			$value = $term->name;
		}
	
	}
	return $value;		
}
add_filter( 'get_term_metadata', 'ea_default_term_title', 10, 4 );

/** Register widget areas */

genesis_register_sidebar( array(
	'id'			=> 'front_content_widget',
	'name'			=> __( 'Front content Widget', 'Premium Genesis Theme' ),
	'description'	=> __( 'This is the single page Content widget if you are using a two or three column site layout option.', 'Premium Genesis Theme' ),
	
) );

genesis_register_sidebar( array(
	'id'			=> 'single_post_related',
	'name'			=> __( 'Single Page Related Post Widget', 'Premium Genesis Theme' ),
	'description'	=> __( 'This is the Single Page Related Post widget if you are using a two or three column site layout option.', 'Premium Genesis Theme' ),
	
) );

genesis_register_sidebar( array(
	'id'			=> 'footer-left',
	'name'			=> __( 'Footer Left', 'Premium Genesis Theme' ),
	'description'	=> __( 'This is the footer left section.', 'Premium Genesis Theme' ),
) );

genesis_register_sidebar( array(
	'id'			=> 'footer-right',
	'name'			=> __( 'Footer Right', 'Premium Genesis Theme' ),
	'description'	=> __( 'This is the footer right section.', 'Premium Genesis Theme' ),
) );

//Remove Post  entry footer  Meta data 
remove_action( 'genesis_entry_footer', 'genesis_post_meta' );
//remove archive description
remove_action( 'genesis_before_content', 'genesis_do_taxonomy_title_description', 15 );

//placeholder for comment box in single page
add_filter('comment_form_default_fields','comment_form_placeholder');
function comment_form_placeholder($fields){ 
	$fields['author'] = '<p class="comment-form-author">' . '<label for="author">' . __( '', 'genesis' ) . '</label> ' . 	
	( $req ? '<span class="required">*</span>' : '' ) .                   
	'<input id="author" name="author" type="text" placeholder="Name *" value="' . 				
	esc_attr( $commenter['comment_author'] ) . '" size="30"' . $aria_req . ' /></p>';				
    $fields['email'] = '<p class="comment-form-email"><label for="email">' . __( '', 'genesis' ) . '</label> ' .
	( $req ? '<span class="required">*</span>' : '' ) .
	'<input id="email" name="email" type="text" placeholder="Email *" value="' . 	
	esc_attr(  $commenter['comment_author_email'] ) . '" size="30"' . $aria_req . ' /></p>';	
	$fields['url'] = '<p class="comment-form-url"><label for="url">' . __( '', 'genesis' ) . '</label>' .    
	'<input id="url" name="url" type="text" placeholder="URL *" value="' . 	
	esc_attr( $commenter['comment_author_url'] ) . '" size="30" /></p>';	
    return $fields;
}

 
// Customizes Footer Text (set in options) 
if (genesism_get_option('footer1')) { 
	add_filter('genesis_footer_creds_text', 'custom_footer_creds_text');
	function custom_footer_creds_text($creds) {
    	$creds = genesism_get_option('footer_text');
    return $creds;
	}
}



add_filter( 'genesis_before_header', 'search_box',2 );
function search_box( $text ) {
	return esc_attr( 'Go' );
}
remove_action( 'genesis_site_title', 'genesis_seo_site_title' );
remove_action( 'genesis_site_description', 'genesis_seo_site_description' );
/* BEGIN Custom User Contact Info */
function extra_contact_info($contactmethods) {

$contactmethods['facebook'] = 'Facebook';
$contactmethods['twitter'] = 'Twitter';

return $contactmethods;
}
add_filter('user_contactmethods', 'extra_contact_info');
/* END Custom User Contact Info */


add_action( 'genesis_before_comments', 'themeprefix_alt_author_box',2 );
function themeprefix_alt_author_box() {
if( is_single() ) {
 //echo"<div class='single_title'><h3>THIS ARTICLE WAS WRITTEN BY</h3></div>";
echo "<div class=\"about-author\"><div class=\"author-info\" itemscope=\"itemscope\" itemtype=\"http://schema.org/person\">" . get_avatar( get_the_author_meta( 'ID' ), '100' ) . "</div>
<div class='author_right_cnt'>"; ?>
<h3 class="author_name"><?php the_author_posts_link(); ?></h3> 
  <?php echo"<p itemprop=\"description\">" . get_the_author_meta( 'description' ) . 
 "</p>
 <div class=\"author_social\">"; 

 if ( get_the_author_meta( 'facebook' ) != '' ) {
 echo "<a class=\"afb  fa\" href=\"https://www.facebook.com/". get_the_author_meta( 'facebook' ) . "\"></a>";
 }
 if ( get_the_author_meta( 'googleplus' ) != '' ) {
 echo "<a class=\"agp fa\" href=\"https://plus.google.com/". get_the_author_meta( 'googleplus' ) . "\"></a>";
 }
 if ( get_the_author_meta( 'twitter' ) != '' ) {
 echo "<a class=\"atw fa\" href=\"https://twitter.com/". get_the_author_meta( 'twitter' ) . "\"></a>";
 }
 
echo "</div></div></div>";
 }
} 
//* Remove the entry meta in the entry header 
 

 add_filter( 'genesis_post_info', 'sp_post_info_filter' );
function sp_post_info_filter($post_info) {
if ( is_single() ) {
	$post_info = '[post_date] by [post_author_posts_link] [post_comments]';
	return $post_info;
}}
 

// Register Genesis Menus
add_action( 'init', 'register_additional_menu' );
function register_additional_menu() {
  
register_nav_menu( 'FirstMenu' ,__( 'Bottom Menu' ));
     
}

/** Remove Header */
remove_action( 'genesis_header', 'genesis_header_markup_open', 5 );
remove_action( 'genesis_header', 'genesis_do_header' );
remove_action( 'genesis_header', 'genesis_header_markup_close', 15 );

/** Add custom header support */
	  
		  
add_action('genesis_header','injectHeader');	  
function injectHeader(){ 

?>

<div class="top_header_cont">
<div class="top_inner_header wrap">
<div class="logo_section">
				<?php
				if (genesism_get_option('header_logo')){?>
					<a title="<?php bloginfo('name'); ?>" href="<?php bloginfo('wpurl'); ?>"><img src="<?php echo genesism_get_option('header_logo_img'); ?>" alt="<?php bloginfo('name'); ?>"/></a>
				<?php
				}
				else { ?>
					<h1 itemprop="headline"><a title="<?php bloginfo('name'); ?>" href="<?php bloginfo('wpurl'); ?>"><?php bloginfo('name');?> </a></h1>
					
				<?php } ?>
</div>
<div class="top_header_right">
<div class="header_social_box">
				<?php
				if (genesism_get_option('header_social')){?>
				<div class="social_icons">
					<a class="facebook" title="Facebook" href="<?php echo genesism_get_option('facebook_text1'); ?>" target="_blank">
						<i class="fa icon-facebook"></i>
					</a>
				</div>
				<div class="social_icons">
					<a class="twitter" title="Twitter" href="<?php echo genesism_get_option('twitter_text1'); ?>" target="_blank">
						<i class="fa icon-twitter"></i>
					</a>
				</div>
				<div class="social_icons">
					<a class="googleplus" title="google plus" href="<?php echo genesism_get_option('googleplus_text1'); ?>" target="_blank">
						<i class="fa icon-google-plus"></i>
					</a>
				</div>
				<div class="social_icons">
					<a class="pinterest" title="pinterest" href="<?php echo genesism_get_option('pinterest_text1'); ?>" target="_blank">
						<i class="fa icon-pinterest"></i>
					</a>
				</div>
				<div class="social_icons">
					<a class="linkedin" title="linkedin" href="<?php echo genesism_get_option('linkedin_text1'); ?>" target="_blank">
						<i class="fa icon-linkedin"></i>
					</a>
				</div>
				<div class="social_icons">
					<a class="youtube" title="youtube" href="<?php echo genesism_get_option('youtube_text1'); ?>" target="_blank">
						<i class="fa icon-youtube"></i>
					</a>
				</div>
			<?php 
		}
		?>

</div>
			<div class="header_contact_box">
			<?php
			if (genesism_get_option('header_contact')){?>
			<div class="contacts_address">
			
			<p class="contacts contact_email"><i class="fa fa-envelope"></i><?php echo genesism_get_option('emil_addr'); ?> </p>
			</div>
			<?php 
			}
			?>
			</div>
</div>

</div>
</div>

<div class="btm_header_cont">
 <div class="btm_inner_header wrap ">

			<?php 
			if (genesism_get_option('btm_menu')){
			?>
			<div class="btm_menu">
				<span class="menu_control">≡ Menu</span>
				<?php wp_nav_menu( array( 'theme_location' => 'FirstMenu','container' => false,'menu_id' => 'menu_btm_menu' ) );?>
			</div>
			<?php 
				echo"<script type=\"text/javascript\">\n".
				"(function(){\n".
				"var classes = document.getElementsByClassName('menu_control');\n".
				"for (i = 0; i < classes.length; i++) {\n".
				"classes[i].onclick = function() {\n".
				"var menu = this.nextElementSibling;\n".
				"if (/show_menu/.test(menu.className))\n".
				"menu.className = menu.className.replace('show_menu', '').trim();\n".
				"else\n".
				"menu.className += ' show_menu';\n".
				"};\n".
				"}\n".
				"})();\n".
				"</script>\n";
			?>
			<?php 
			}
			?>
		
 </div>
</div>


<?php 
}
 
add_action('genesis_before_header','before_header');	
function before_header() { ?>
<div class="header" itemscope="itemscope" itemtype="http://schema.org/WPHeader">
<?php
}
 
add_action('genesis_after_header','after_header');			
function after_header() { ?>

 </div>	

<?php
} 
 

// Add Post Feature image

add_action( 'genesis_entry_header', 'custom_post_featureimage');
function custom_post_featureimage() {
if(!is_page()&&!is_single()){  
?>
<div class="post_featured_img">
<?php

 if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
echo "<div class='featured_viedo_image'>";
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true);echo "</div>";	
} else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video

 // Defaults
         $f_img_width = genesism_get_option('f_img_width');
        $f_img_height = genesism_get_option('f_img_height');
        $default_img =  'Feature_image'; 

		// Auto feature image defaults
		$thumb = get_post_thumbnail_id(); 
		$img_url = wp_get_attachment_url( $thumb,'full' ); 
		$image = aq_resize( $img_url,$f_img_width,$f_img_height, true );
		// Catch the Image defaults
        $catch_img_url = catch_that_image( $thumb,'full' );
        $catch_image = aq_resize( $catch_img_url, $f_img_width, $f_img_height, true );
        // Default Image
        $default_image = aq_resize( $default_img, $f_img_width, $f_img_height, true );
		if(has_post_thumbnail())
		echo
		"<div class=\"featured_image\">\n".
		"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width . "\" height=\"" . $f_img_height . "\" alt=\"" . get_the_title() . "\"><div class='thumb_hover'></div></a>\n".
		"</div>\n";
		elseif (catch_that_image()){ 
		echo
		"<div class=\"featured_image\">\n".
		"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width . "\" height=\"" . $f_img_height . "\" alt=\"" . get_the_title() . "\"></a>\n".
		
		"</div>\n"; 
		} 
		}
		}

		/*featured image ends here*/
?>

</div>
<?php	
}      
}
 
 
 
add_action( 'genesis_post_info', 'post_info_filter');
function post_info_filter() {
if(!is_page()){ 
?>
<div class="byline">
<?php
		$category = get_the_category(); 
	?>
	<span class='author'><?php the_author() ?></span>
	<span class='date'><?php the_time('j M , Y') ?></span>
	<span class="cat"><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></span>
	
	<span class='info_comments'><a  href="<?php the_permalink(); ?>#comments" title="<?php comments_number(__('0 Comment','fb'),__('1 Comment','periodic'),__('% Comments','fb')); ?>"><?php comments_number(__('0 Comment','periodic'),__('1 Comment','periodic'),__('% Comments','fb')); ?> </a></span>
</div>								
<?php
}
}


add_action('genesis_entry_content','post_ad',2);
function post_ad(){
if(genesism_get_option('postadcheck')){
if ( is_single() ) {?>
		<div class="post-ad" style="float:<?php echo genesism_option('float');?>; padding-right:15px; padding-left:15px; padding-top: 10px;">
		<?php  echo stripslashes((genesism_get_option('postad')));?>
		</div>
        <?php
		}
	}
	}

	
add_action ('genesis_entry_content','post_read_more');
function post_read_more(){
if (genesism_get_option('read_more')){
if(!is_page()&&!is_single()){
?>
<div class="read_more">
	<a class="read_more_btn" href="<?php echo the_permalink(); ?>"><?php  echo (genesism_get_option('read_text'));?></a>
</div>
<?php 
}
}	
}	


add_action ('genesis_before_sidebar_widget_area','before_sidebar_widget_area');
function before_sidebar_widget_area(){

?>
<div class="sidebar_section">
<?php 
}



add_action ('genesis_before_sidebar_widget_area','sidebar_adv_optin',4);
function sidebar_adv_optin(){	
if (genesism_get_option('sidebar_optin_section')){
?>


<div class="sidebar_optin_cnt" style='background-image:url(<?php echo genesism_option('sb_opt_bg'); ?>)'>

<div class='sb_optin_bg sidebar_widget'>
<h2><?php echo genesism_get_option('optin_header_one'); ?></h2>
<p> <?php echo genesism_get_option('optin_header_para'); ?></p>
<form method="post" class="form" action="<?php echo stripslashes(genesism_get_option('optin_url3')); ?>" target="_blank">	

<div class="sb_input">
<input class="email" type="text" name="<?php echo stripslashes(genesism_get_option('optin_email3')); ?>" placeholder="<?php echo stripslashes(genesism_get_option('email_text3')); ?>"><div class='mails'></div>
<?php echo stripslashes(genesism_get_option('optin_hidden3')); ?>
<input name="submit" class="submit" type="submit" value="<?php echo stripslashes(genesism_get_option('submit_text3')); ?>"/>
</div>

</form>
</div>

</div>



<?php 
}
}




add_action ('genesis_after_sidebar_widget_area','after_sidebar_widget_area');
function after_sidebar_widget_area(){
?>
</div>
<?php 
}

// Customize the post meta function
add_filter('genesis_entry_footer', 'post_meta_filter',1);
function post_meta_filter() {
if ( is_single() ) {?>
<p class='post_tags'> 
	<?php // Tag
		$posttags = get_the_tags();
		if ($posttags) {
		foreach($posttags as $tag) {
		
		echo $tag->name .'  '; 
		}
		}
	?>
</p>
<?php
}
}


add_filter( 'genesis_term_meta_headline', 'be_default_category_title', 10, 2 );
function be_default_category_title( $headline, $term ) {
	if( ( is_category() || is_tag() || is_tax() ) && empty( $headline ) )
		$headline = $term->name;
		
	return $headline;
}
	
/** Genesis Previous/Next Post Post Navigation */
add_action ('genesis_entry_footer','prev_next_post_nav',3);
function prev_next_post_nav(){
if ( is_single() ) {
echo '<div class="prev-next-navigation">';
previous_post_link( '<div class="previous"><span>Previous article:</span> %link</div>', '%title' );
next_post_link( '<div class="next"><span>Next article:</span> %link</div>', '%title' );
echo '</div><!-- .prev-next-navigation -->';
}
}	






add_action( 'genesis_before_comments', 'single_page_socialshare',2);
function single_page_socialshare(){
if (genesism_get_option('single_social_share')){
if ( is_single() ) {?>
<div class="sharing group sharing_social_count">
<div class="single_title">
	<h3><?php  echo (genesism_get_option('share_title'));?></h3>
	<span class="sep"></span>
</div>
<ul class="social_share_count">
		<li class="share_tweet">
		<a href="http://twitter.com/share?text=<?php echo htmlspecialchars(urlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8')), ENT_COMPAT, 'UTF-8'); ?>&amp;url=<?php the_permalink(); ?>" target="_blank">
		<i class="icon-twitter icon"></i>
		<span>
		 Twitter
		</span>
		</a>
		</li>
		<li class="share_fb">
		<a href="http://www.facebook.com/sharer.php?u=<?php the_permalink(); ?>&amp;t=<?php echo htmlspecialchars(urlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8')), ENT_COMPAT, 'UTF-8'); ?>" target="_blank">
		<i class="icon-facebook icon"></i>
		<span>
		 Facebook
		</span>
		</a>
		</li>
		<li class="share_linkedin">
		<a target="_blank" href="http://www.linkedin.com/shareArticle?mini=true&amp;url=<?php the_permalink(); ?>">
		<i class="icon-linkedin icon"></i>
		<span>
		 Linkedin
		</span>
		</a> 
		</li>
		<li class="share_reddit">
		<a target="_blank" href="http://www.reddit.com/submit?url=<?php the_permalink(); ?>&amp;title=<?php echo htmlspecialchars(urlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8')), ENT_COMPAT, 'UTF-8'); ?>">
		<i class="icon-reddit icon"></i>
		<span>
		 Reddit
		</span>
		</a>
		</li>
		<li class="share_pintrest">
		<a target="_blank" href="http://pinterest.com/pinthis?url=<?php the_permalink(); ?>&amp;title=<?php echo htmlspecialchars(urlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8')), ENT_COMPAT, 'UTF-8'); ?>">
		<i class="icon-pinterest icon"></i>
		<span>
		 Pintrest
		</span>
		</a>
		</li>		
	</ul>
</div>
<?php
}
}
}
//Related Post Box

add_action( 'genesis_before_comments', 'related_posts',3);
function related_posts(){
?>

<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Single Page Related Post Widget') ) : ?>
<div class="widget">
<h4 itemprop="headline"><?php _e("Single Page Related Post #Widget", 'genesis'); ?></h4>
<p><?php _e("Displays Single Page Realated Post with thumbnails.", 'genesis'); ?></p>
</div><!-- end .widget -->
<?php endif; ?> 
<?php
}




add_action('wp_head','color_box');
function color_box(){

$body_bg_color = get_option('body_bg_color');
$body_txt_color = get_option('body_txt_color');
$header_txt_color = get_option('header_txt_color');
$top_header_bg =get_option('top_header_bg');
$btm_header_bg =get_option('btm_header_bg');
$link_color =get_option('link_color');
$link_hover_color =get_option('link_hover_color');
$border_color =get_option('border_color');

$price_cell_bg =get_option('price_cell_bg');
$price_cell1_hdr =get_option('price_cell1_hdr');
$price_cell2_hdr = get_option('price_cell2_hdr');
$price_cell3_hdr = get_option('price_cell3_hdr');
$call_act_button = get_option('call_act_button');
$call_act_button_hover =get_option('call_act_button_hover');
$call_act_bg =get_option('call_act_bg');

$team_social_bg =get_option('team_social_bg');
$footer_text_clr =get_option('footer_text_clr');
$top_footer_bg =get_option('top_footer_bg');
$site_footer_bg =get_option('site_footer_bg');
$sidebar_bg =get_option('sidebar_bg');

?>
<style type="text/css">

body {
background:<?php echo $body_bg_color; ?>;
}


body{
color:<?php echo $body_txt_color; ?>;
}

.social_icons a, .pricingtable_cell ul li, .team_content h4 span, .blog .byline .cat a, .archive .byline .cat a, .search .byline .cat a, .info_comments a{
color:<?php echo $body_txt_color; ?>;
}

.single .post .byline span, .single .post .byline span a{
color:<?php echo $body_txt_color; ?>;
}


a, .entry h1, .entry h2, .entry h3, .entry h4, .entry h5, .entry h6, h1,h2,h3,h4,h5,h6, .optin_right_header h3, .team_content h4 a{
color:<?php echo $header_txt_color; ?> ;
}
.align-center a:hover{
background:<?php echo $header_txt_color; ?>;
}

.align-center a:hover, .footer-widgets input{
border-color:<?php echo $header_txt_color; ?>;
}
.content .single_title h3, #reply-title{
color: <?php echo $header_txt_color; ?>;
}

.top_inner_header{
    background: <?php echo $top_header_bg; ?> ;
}

.btm_menu, .menu li .sub-menu{
background: <?php echo $btm_header_bg; ?> ;
}

a:hover, .last_updated ul li h3 a:hover, .read_more a:hover, .team_content h4 a:hover, .site-footer p a:hover, .portfolio_cnt_section h3 a:hover{
color: <?php echo $link_color; ?> ;
}

.archive-pagination li a:hover, .archive-pagination .active a, .menu a:hover, .menu .current-menu-item > a, .front_feature_col .ftr_read:hover,
 .align-center a, .wmuSliderNext, .wmuSliderPrev, .front_optin_content .form input[type="submit"], .aboutus_cnt_title_para a,
 .sidebar_optin_cnt input[type="submit"], .read_more a, .blog .entry-title:after, .archive .entry-title:after, .prev-next-navigation .previous:hover,
 .prev-next-navigation .next:hover, .comment-reply a, .related_post_cnt:hover, .footer-widgets-1 .tagcloud a:hover,.form-submit input[type="submit"]:hover   {
    background-color: <?php echo $link_color; ?>;
}

.top_inner_header, .front_feature_col .ftr_read:hover, .sidebar_widget, .sidebar_section .widget, .read_more a, .read_more a:hover, .about-author,.author-box{
border-color: <?php echo $link_color; ?>;
}

.single .post_tags{
background: <?php echo $link_color; ?>;
}


.header_optin_right .form  input[type="submit"]:hover, .right_side_optin .form input[type="submit"]:hover, .cl-effect-2 a span::before, .aboutus_cnt_title_para a:hover, .sidebar_optin_cnt input[type="submit"]:hover, .front_optin_content .form input[type="submit"]:hover{
background-color: <?php echo $link_hover_color; ?> ;
}

.entry-content blockquote:before {
 color: <?php echo $border_color; ?> ;
}

.pricingtable_contents, .b_testimonial .data, .entry blockquote, .border_line, .random, .front_feature_col .ftr_read{
border-color: <?php echo $border_color; ?>;
}

.landing_feature_box{
border-color: <?php echo $border_color; ?>;
}

.pricingtable_cell ul {
background: <?php echo $price_cell_bg; ?> ;

}

.pricing_cell1 .price_hd, .pricing_cell1 .align-center a{
background-color: <?php echo $price_cell1_hdr; ?>;
}

.pricing_cell2 .price_hd, .pricing_cell2 .align-center a{
background-color: <?php echo $price_cell2_hdr; ?>;
}


.pricing_cell3 .price_hd, .pricing_cell3 .align-center a{
background-color:  <?php echo $price_cell3_hdr; ?> ;
}

.callto_section .call_read, .portfolio_cnt_section .port_permalink a{
background-color:  <?php echo $call_act_button; ?>;
}

.data p:before, .data p:after, .portfolio_cnt_section .port_permalink a:hover{
color:  <?php echo $call_act_button; ?> ;
}

.callto_section .call_read:hover{
background:  <?php echo $call_act_button_hover; ?> ;
}

.call_to_action_content{
background:  <?php echo $call_act_bg; ?> ;

}
.social_follow a{
background:  <?php echo $team_social_bg; ?>;
}


.social_icons a, .header_optin_right .form  input[type="text"], .front_welcome_content, .front_feature_col, .inner_feature_content, .team_column, .clients, .front_optin_content .form input[type="text"], .sidebar li, .blog .byline, .blog .content .post, .archive .content .post, .search .content .post, .single .post .byline, li.comment, .content .single_title h3, #reply-title {
border-color:<?php echo $border_color; ?> ;
}


.last_updated ul li h3 span, .landing_optin_title p, .widget_recent_entries ul li a, .textwidget, .site-footer p, .site-footer p a, .portfolio_cnt_section p{
color: <?php echo $footer_text_clr; ?> ;
}



.footer-widgets .wrap, .archive-pagination li a {
background: <?php echo $top_footer_bg; ?> ;
}
.footer-widgets-1 .tagcloud a{
background: <?php echo $site_footer_bg; ?>;
}

.site-footer .wrap{
background-color: <?php echo $site_footer_bg; ?>;
}

.sidebar_widget, .sidebar_section .widget, .content .single_title h3, #reply-title {
    background: <?php echo $sidebar_bg; ?> ;
	}




<?php echo genesism_option('custom_css'); ?>

</style>
<?php
}

add_action( 'wp_enqueue_scripts', 'enqueue_script' );
function enqueue_script() {	

		wp_enqueue_script( 'jquery.wmuSlider', get_stylesheet_directory_uri() . '/scripts/jquery.wmuSlider.js', array( 'jquery' ), '', true );
	wp_enqueue_script( 'slider', get_stylesheet_directory_uri() . '/scripts/slider.js', array( 'jquery' ), '', true );		

	
	
}


add_action('wp_footer','script_box');
function script_box(){?>
<script type="text/javascript">
function loadScript(src) {
     var element = document.createElement("script");
     element.src = src;
     document.body.appendChild(element);
}
// Add a script element as a child of the body
function downloadJSAtOnload() {

			
	//loadScript("<?php bloginfo('stylesheet_directory'); ?>/scripts/slider.js");		
    //loadScript("<?php bloginfo('stylesheet_directory'); ?>/scripts/jquery.wmuSlider.js");
	
	
	
}
 // Check for browser support of event handling capability
 if (window.addEventListener)
     window.addEventListener("load", downloadJSAtOnload, false);
	 else if (window.attachEvent)
     window.attachEvent("onload", downloadJSAtOnload);
 else window.onload = downloadJSAtOnload; 
 (function() {
      function getScript(url,success){
        var script=document.createElement('script');
        script.src=url;
        var head=document.getElementsByTagName('head')[0],
            done=false;
        script.onload=script.onreadystatechange = function(){
          if ( !done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete') ) {
            done=true;
            success();
            script.onload = script.onreadystatechange = null;
            head.removeChild(script);
          }
        };
        head.appendChild(script);
      }
        getScript('https://ajax.googleapis.com/ajax/libs/jquery/2.0.0/jquery.min.js',function(){
        });
    })();
</script>
<?php
}

// Auto Resize Image

function aq_resize( $url, $width, $height = null, $crop = null, $single = true ) {

//validate inputs
if(!$url OR !$width ) return false;

//define upload path & dir
$upload_info = wp_upload_dir();
$upload_dir = $upload_info['basedir'];
$upload_url = $upload_info['baseurl'];

//check if $img_url is local
if(strpos( $url, $upload_url ) === false) return false;

//define path of image
$rel_path = str_replace( $upload_url, '', $url);
$img_path = $upload_dir . $rel_path;

//check if img path exists, and is an image indeed
if( !file_exists($img_path) OR !getimagesize($img_path) ) return false;

//get image info
$info = pathinfo($img_path);
$ext = $info['extension'];
list($orig_w,$orig_h) = getimagesize($img_path);

//get image size after cropping
$dims = image_resize_dimensions($orig_w, $orig_h, $width, $height, $crop);
$dst_w = $dims[4];
$dst_h = $dims[5];

//use this to check if cropped image already exists, so we can return that instead
$suffix = "{$dst_w}x{$dst_h}";
$dst_rel_path = str_replace( '.'.$ext, '', $rel_path);
$destfilename = "{$upload_dir}{$dst_rel_path}-{$suffix}.{$ext}";

if(!$dst_h) {
//can't resize, so return original url
$img_url = $url;
$dst_w = $orig_w;
$dst_h = $orig_h;
}
//else check if cache exists
elseif(file_exists($destfilename) && getimagesize($destfilename)) {
$img_url = "{$upload_url}{$dst_rel_path}-{$suffix}.{$ext}";
}
//else, we resize the image and return the new resized image url
else {

// Note: This pre-3.5 fallback check will edited out in subsequent version
if(function_exists('wp_get_image_editor')) {

$editor = wp_get_image_editor($img_path);

if ( is_wp_error( $editor ) || is_wp_error( $editor->resize( $width, $height, $crop ) ) )
return false;

$resized_file = $editor->save();

if(!is_wp_error($resized_file)) {
$resized_rel_path = str_replace( $upload_dir, '', $resized_file['path']);
$img_url = $upload_url . $resized_rel_path;
} else {
return false;
}

} else {

$resized_img_path = image_resize( $img_path, $width, $height, $crop ); // Fallback foo
if(!is_wp_error($resized_img_path)) {
$resized_rel_path = str_replace( $upload_dir, '', $resized_img_path);
$img_url = $upload_url . $resized_rel_path;
} else {
return false;
}

}

}

//return the output
if($single) {
//str return
$image = $img_url;
} else {
//array return
$image = array (
0 => $img_url,
1 => $dst_w,
2 => $dst_h
);
}

return $image;
}

function catch_that_image() {
        global $post, $posts;
        $first_img = '';
        ob_start();
        ob_end_clean();
        $output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
        if(count($matches [1]))$first_img = $matches [1] [0];
        return $first_img;
}


function limit_words($string, $word_limit)
{
  $words = explode(' ', $string, ($word_limit + 1));
  if(count($words) > $word_limit)
  array_pop($words);
  return implode(' ', $words);
}

function new_excerpt_length($length) {
    return 40;
}
add_filter('excerpt_length', 'new_excerpt_length');

function string_limit_words($string, $word_limit)
{
  $words = explode(' ', $string, ($word_limit + 1));
  if(count($words) > $word_limit)
  array_pop($words);
  return implode(' ', $words);
}   


function custom_pagination($numpages = '', $pagerange = '', $paged='') {

  if (empty($pagerange)) {
    $pagerange = 2;
  }

  /**
   * This first part of our function is a fallback
   * for custom pagination inside a regular loop that
   * uses the global $paged and global $wp_query variables.
   * 
   * It's good because we can now override default pagination
   * in our theme, and use this function in default quries
   * and custom queries.
   */
  global $paged;
  if (empty($paged)) {
    $paged = 1;
  }
  if ($numpages == '') {
    global $wp_query;
    $numpages = $wp_query->max_num_pages;
    if(!$numpages) {
        $numpages = 1;
    }
  }

  /** 
   * We construct the pagination arguments to enter into our paginate_links
   * function. 
   */
  $pagination_args = array(
    'base'            => get_pagenum_link(1) . '%_%',
    'format'          => 'page/%#%',
    'total'           => $numpages,
    'current'         => $paged,
    'show_all'        => False,
    'end_size'        => 1,
    'mid_size'        => $pagerange,
    'prev_next'       => True,
    'prev_text'       => __('&laquo;'),
    'next_text'       => __('&raquo;'),
    'type'            => 'plain',
    'add_args'        => false,
    'add_fragment'    => ''
  );

  $paginate_links = paginate_links($pagination_args);

  if ($paginate_links) {
    echo "<nav class='custom-pagination'>";
      echo "<span class='page-numbers page-num'>Page " . $paged . " of " . $numpages . "</span> ";
      echo $paginate_links;
    echo "</nav>";
  }

}


// Portfolio Post Type
add_action('init','bts_create_portfolio_init');
function bts_create_portfolio_init()  {
	$labels = array
	(
		'name' => _x('Portfolio', 'post type general name'),
		'singular_name' => _x('item', 'post type singular name'),
		'add_new' => _x('Add New', 'Portfolio Item'),
		'add_new_item' => __('Add New Portfolio Item'),
		'edit_item' => __('Edit Portfolio Item'),
		'new_item' => __('New Portfolio Item'),
		'view_item' => __('View Portfolio Item'),
		'search_items' => __('Search Portfolio'),
		'not_found' =>  __('No portfolio items found'),
		'not_found_in_trash' => __('No portfolio items found in Trash'), 
		'parent_item_colon' => ''
	);
	$support = array
	(
		'title',
		'editor',
		'author',
		'thumbnail',
		'custom-fields',
		'comments',
		'thesis-seo', 
		'thesis-layouts',
		'revisions'
	);
	$args = array
	(
		'labels' => $labels,
		'public' => TRUE,
		'rewrite' => array('slug'=>'portfolio'),
		'capability_type' => 'page',
		'hierarchical' => FALSE,
		'query_var' => true,
		'supports' => $support,
		'taxonomies' => array('portfolio_category'),
		'menu_position' => 5
	); 
	register_post_type('portfolio',$args);
	
	register_taxonomy(
        'portfolio_category',        
        'portfolio',
        array(
            'hierarchical' => TRUE,
            'label' => 'Categories',
            'query_var' => TRUE,
            'rewrite' => FALSE,
        )
    );  
}



//Testimonial
add_action('init','bts_create_testimonial_init');
function bts_create_testimonial_init()  {
	$labels = array
	(
		'name' => _x('Testimonial', 'post type general name'),
		'singular_name' => _x('item', 'post type singular name'),
		'add_new' => _x('Add New', 'Testimonial Item'),
		'add_new_item' => __('Add New Testimonial Item'),
		'edit_item' => __('Edit Testimonial Item'),
		'new_item' => __('New Testimonial Item'),
		'view_item' => __('View Testimonial Item'),
		'search_items' => __('Search Testimonial'),
		'not_found' =>  __('No Testimonial items found'),
		'not_found_in_trash' => __('No Testimonial items found in Trash'), 
		'parent_item_colon' => ''
	);
	$support = array
	(
		'title',
		'editor',
		'author',
		'thumbnail',
		'custom-fields',
		'revisions'
	);
	$args = array
	(
		'labels' => $labels,
		'public' => TRUE,
		'rewrite' => array('slug'=>'testimonial'),
		'capability_type' => 'page',
		'hierarchical' => FALSE,
		'query_var' => true,
		'supports' => $support,
		'taxonomies' => array('testimonial_category'),
		'menu_position' => 5
	); 
	register_post_type('testimonial',$args);
	
	register_taxonomy(          
        'testimonial',
        array(
            'hierarchical' => TRUE,
            'label' => 'Categories',
            'query_var' => TRUE,
            'rewrite' => FALSE,
        )
    );  
}




#-----------------------------------------------------------------
# Plugin Recommendations
#-----------------------------------------------------------------

require_once ('lib/class-tgm-plugin-activation.php');
add_action( 'tgmpa_register', 'premium_register_required_plugins' );

function premium_register_required_plugins() {
	
	$plugins = array(
		
		array(
			'name'     				=> 'Replace Featured Image with Video',
			'slug'     				=> 'eeplace-featured-image-with-video',
			'source'   				=> 'https://downloads.wordpress.org/plugin/replace-featured-image-with-video.zip',
			'required' 				=> true,
			'version' 				=> '2.1',
			'force_activation' 		=> false,
			'force_deactivation' 	=> false,
			'external_url' 			=> '',
		),
		
		

	);

	$config = array( 
		'domain'       		=> 'premium',
		'default_path' 		=> '',
		'parent_menu_slug' 	=> 'themes.php',
		'parent_url_slug' 	=> 'themes.php',
		'menu'         		=> 'install-required-plugins',
		'has_notices'      	=> true,
		'is_automatic'    	=> false,
		'message' 			=> '',
		'strings'      		=> array(
			'page_title'                       			=> __( 'Install Required Plugins', 'premium' ),
			'menu_title'                       			=> __( 'Install Plugins', 'premium' ),
			'installing'                       			=> __( 'Installing Plugin: %s', 'premium' ), // %1$s = plugin name
			'oops'                             			=> __( 'Something went wrong with the plugin API.', 'premium' ),
			'notice_can_install_required'     			=> _n_noop( 'This theme requires the following plugin: %1$s.', 'This theme requires the following plugins: %1$s.', 'premium' ), // %1$s = plugin name(s)
			'notice_can_install_recommended'			=> _n_noop( 'This theme recommends the following plugin: %1$s.', 'This theme recommends the following plugins: %1$s.', 'premium' ), // %1$s = plugin name(s)
			'notice_cannot_install'  					=> _n_noop( 'Sorry, but you do not have the correct permissions to install the %s plugin. Contact the administrator of this site for help on getting the plugin installed.', 'Sorry, but you do not have the correct permissions to install the %s plugins. Contact the administrator of this site for help on getting the plugins installed.', 'premium' ), // %1$s = plugin name(s)
			'notice_can_activate_required'    			=> _n_noop( 'The following required plugin is currently inactive: %1$s.', 'The following required plugins are currently inactive: %1$s.', 'premium' ), // %1$s = plugin name(s)
			'notice_can_activate_recommended'			=> _n_noop( 'The following recommended plugin is currently inactive: %1$s.', 'The following recommended plugins are currently inactive: %1$s.', 'premium' ), // %1$s = plugin name(s)
			'notice_cannot_activate' 					=> _n_noop( 'Sorry, but you do not have the correct permissions to activate the %s plugin. Contact the administrator of this site for help on getting the plugin activated.', 'Sorry, but you do not have the correct permissions to activate the %s plugins. Contact the administrator of this site for help on getting the plugins activated.', 'premium' ), // %1$s = plugin name(s)
			'notice_ask_to_update' 						=> _n_noop( 'The following plugin needs to be updated to its latest version to ensure maximum compatibility with this theme: %1$s.', 'The following plugins need to be updated to their latest version to ensure maximum compatibility with this theme: %1$s.', 'premium' ), // %1$s = plugin name(s)
			'notice_cannot_update' 						=> _n_noop( 'Sorry, but you do not have the correct permissions to update the %s plugin. Contact the administrator of this site for help on getting the plugin updated.', 'Sorry, but you do not have the correct permissions to update the %s plugins. Contact the administrator of this site for help on getting the plugins updated.', 'premium' ), // %1$s = plugin name(s)
			'install_link' 					  			=> _n_noop( 'Begin installing plugin', 'Begin installing plugins', 'premium'  ),
			'activate_link' 				  			=> _n_noop( 'Activate installed plugin', 'Activate installed plugins', 'premium'  ),
			'return'                           			=> __( 'Return to Required Plugins Installer', 'premium' ),
			'plugin_activated'                 			=> __( 'Plugin activated successfully.', 'premium' ),
			'complete' 									=> __( 'All plugins installed and activated successfully. %s', 'premium' ), // %1$s = dashboard link
			'nag_type'									=> 'updated'
		)
	);

	tgmpa( $plugins, $config );
}



// About Us Widget Starts Here

class gl_aboutus_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_aboutus_widget', 

__('Premium - About Us ', 'gl_aboutus_widget_domain'), 

array( 'description' => __( 'Displays About Us Content', 'gl_aboutus_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$sb_aboutus_title = apply_filters( 'sb_aboutus_title', $instance['sb_aboutus_title'] );
$sb_aboutus_name = apply_filters( 'sb_aboutus_name', $instance['sb_aboutus_name'] );
$about_us_img = apply_filters( 'about_us_img', $instance['about_us_img'] );
$sb_aboutus_cnt = apply_filters( 'sb_aboutus_cnt', $instance['sb_aboutus_cnt'] );
$sb_aboutus_read = apply_filters( 'sb_aboutus_read', $instance['sb_aboutus_read'] );
$sb_aboutus_read_link = apply_filters( 'sb_aboutus_read_link', $instance['sb_aboutus_read_link'] );

echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];


?>
<div class="sidebar_aboutus">
	<div class="aboutus_cnt">
			<img alt="<?php  echo $instance['sb_aboutus_title'];?>" src='<?php  echo $instance['about_us_img'];?>'/>
			
			<div class="aboutus_cnt_title_para">
			<h3><?php  echo $instance['sb_aboutus_title'];?></h3>
			<h4><?php  echo $instance['sb_aboutus_name'];?></h4>
			<div class="aboutus_cnt_main">
			<p><?php  echo $instance['sb_aboutus_cnt'];?></p>
			<a class='abt_sec' href="<?php  echo $instance['sb_aboutus_read_link'];?>" ><?php  echo $instance['sb_aboutus_read'];?></a>
			</div>
			</div>
			
		</div>
	
</div>

<?php
echo $args['after_widget'];
}
		
public function form( $instance ) {


if ( isset( $instance[ 'sb_aboutus_title' ] ) ) {
$sb_aboutus_title = $instance[ 'sb_aboutus_title' ];
}
else {
$sb_aboutus_title = __( 'ABOUT ME', 'gl_aboutus_widget_domain' );
}

if ( isset( $instance[ 'sb_aboutus_name' ] ) ) {
$sb_aboutus_name = $instance[ 'sb_aboutus_name' ];
}
else {
$sb_aboutus_name = __( 'Ruban Silva', 'gl_aboutus_widget_domain' );
}

 if ( isset( $instance[ 'about_us_img' ] ) ) {
$about_us_img = $instance[ 'about_us_img' ];
}
else {
$about_us_img = __( ' ', 'gl_aboutus_widget_domain' );
}

 if ( isset( $instance[ 'sb_aboutus_cnt' ] ) ) {
$sb_aboutus_cnt = $instance[ 'sb_aboutus_cnt' ];
}
else {
$sb_aboutus_cnt = __( 'About Us Content', 'gl_aboutus_widget_domain' );
}

 if ( isset( $instance[ 'sb_aboutus_read' ] ) ) {
$sb_aboutus_read = $instance[ 'sb_aboutus_read' ];
}
else {
$sb_aboutus_read = __( 'About Me', 'gl_aboutus_widget_domain' );
}

 if ( isset( $instance[ 'sb_aboutus_read_link' ] ) ) {
$sb_aboutus_read_link = $instance[ 'sb_aboutus_read_link' ];
}
else {
$sb_aboutus_read_link = __( '', 'gl_aboutus_widget_domain' );
}

?>


<p>
<label for="<?php echo $this->get_field_id( 'sb_aboutus_title' ); ?>"><?php _e( 'About Us Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'sb_aboutus_title' ); ?>" name="<?php echo $this->get_field_name( 'sb_aboutus_title' ); ?>" type="text" value="<?php echo esc_attr( $sb_aboutus_title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'sb_aboutus_name' ); ?>"><?php _e( 'About Us Name:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'sb_aboutus_name' ); ?>" name="<?php echo $this->get_field_name( 'sb_aboutus_name' ); ?>" type="text" value="<?php echo esc_attr( $sb_aboutus_name ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'about_us_img' ); ?>"><?php _e( 'About Us Image URL Link:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'about_us_img' ); ?>" name="<?php echo $this->get_field_name( 'about_us_img' ); ?>" type="text" value="<?php echo esc_attr( $about_us_img ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'sb_aboutus_cnt' ); ?>"><?php _e( 'About Us Content:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'sb_aboutus_cnt' ); ?>" name="<?php echo $this->get_field_name( 'sb_aboutus_cnt' ); ?>" type="text" value="<?php echo esc_attr( $sb_aboutus_cnt ); ?>"/>
</p>
<p>
<label for="<?php echo $this->get_field_id( 'sb_aboutus_read' ); ?>"><?php _e( 'About Us Readmore Text:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'sb_aboutus_read' ); ?>" name="<?php echo $this->get_field_name( 'sb_aboutus_read' ); ?>" type="text" value="<?php echo esc_attr( $sb_aboutus_read ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'sb_aboutus_read_link' ); ?>"><?php _e( 'About Us Readmore Text URL Link:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'sb_aboutus_read_link' ); ?>" name="<?php echo $this->get_field_name( 'sb_aboutus_read_link' ); ?>" type="text" value="<?php echo esc_attr( $sb_aboutus_read_link ); ?>" />
</p>
<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();

$instance['sb_aboutus_title'] = ( ! empty( $new_instance['sb_aboutus_title'] ) ) ? strip_tags( $new_instance['sb_aboutus_title'] ) : '';
$instance['sb_aboutus_name'] = ( ! empty( $new_instance['sb_aboutus_name'] ) ) ? strip_tags( $new_instance['sb_aboutus_name'] ) : '';
$instance['about_us_img'] = ( ! empty( $new_instance['about_us_img'] ) ) ? strip_tags( $new_instance['about_us_img'] ) : '';
$instance['sb_aboutus_cnt'] = ( ! empty( $new_instance['sb_aboutus_cnt'] ) ) ? strip_tags( $new_instance['sb_aboutus_cnt'] ) : '';
$instance['sb_aboutus_read'] = ( ! empty( $new_instance['sb_aboutus_read'] ) ) ? strip_tags( $new_instance['sb_aboutus_read'] ) : '';
$instance['sb_aboutus_read_link'] = ( ! empty( $new_instance['sb_aboutus_read_link'] ) ) ? strip_tags( $new_instance['sb_aboutus_read_link'] ) : '';
return $instance;
}
}
// About us post widget ends here

// Sidebar Search Widget Starts Here

class gl_search_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_search_widget', 

__('Premium - Sidebar Search Box ', 'gl_search_widget_domain'), 

array( 'description' => __( 'Displays Sidebar Search Content', 'gl_search_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {

$sb_search_text = apply_filters( 'sb_search_text', $instance['sb_search_text'] );


echo $args['before_widget'];
if ( ! empty( $title ) )
//echo $args['before_title'] . $title . $args['after_title'];


?>
<div class="widget_search">
<form method='get' action='<?php echo get_bloginfo('home'); ?>'>
<input class="search_text" type='text' placeholder='<?php echo $instance['sb_search_text']; ?>' name='s' id='s' />
<button type='submit' class='btn btn-success'>
<i class='fa fa-search'></i>
</button>			
</form>
</div>
<?php
echo $args['after_widget'];
}
		
public function form( $instance ) {

if ( isset( $instance[ 'sb_search_text' ] ) ) {
$sb_search_text = $instance[ 'sb_search_text' ];
}
else {
$sb_search_text = __( 'Search here...', 'gl_search_widget_domain' );
}


?>

<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'sb_search_text' ); ?>"><?php _e( 'Search Placeholder text:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'sb_search_text' ); ?>" name="<?php echo $this->get_field_name( 'sb_search_text' ); ?>" type="text" value="<?php echo esc_attr( $sb_search_text ); ?>" />
</p>


<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['sb_search_text'] = ( ! empty( $new_instance['sb_search_text'] ) ) ? strip_tags( $new_instance['sb_search_text'] ) : '';

return $instance;
}
}
// Sidebar Search widget ends here



// Popular Widget Starts Here

class gl_popular_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_popular_widget', 

__('Premium - Popular Post', 'gl_popular_widget_domain'), 

array( 'description' => __( 'Displays Popular Post', 'gl_popular_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );

echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];

?>

<div class="popular_post sidebar_widget_bg">
	
	<div class='popular_post_cnt sidebar_content'>
		<?php
			query_posts('post_type=post&posts_per_page='. $post_count .' &orderby=comment_count&order=DESC');
			while (have_posts()): the_post(); 
		?>
			<div class='popular_post_section border_line entry_cnt'>
				<div class='popular_img'>
					<?php
					if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
 echo "<div class='featured_viedo_image'>";
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true); echo "</div>";	
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video
						 $f_img_width2 = $instance['width_size'];
							$f_img_height2 =$instance['height_size'];
							$default_img =  'Feature_image'; 
						// Auto feature image defaults
						$thumb = get_post_thumbnail_id(); 
						$img_url = wp_get_attachment_url( $thumb,'full' ); 
						$image = aq_resize( $img_url, $f_img_width2, $f_img_height2, true );
						// Catch the Image defaults
						$catch_img_url = catch_that_image( $thumb,'full' );
						$catch_image = aq_resize( $catch_img_url, $f_img_width2, $f_img_height2, true );
						if(has_post_thumbnail())
						echo
						"<div class=\"featured_image\">\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width2 . "\" height=\"" . $f_img_height2 . "\" alt=\"" . get_the_title() . "\"></a><div class='thumb_hover'><a class=\"link\" href=\"" . get_permalink() . "\"></a></div>\n".
						"</div>\n";
						elseif (catch_that_image()){ 
						echo
						"<div class=\"featured_image\">\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width2 . "\" height=\"" . $f_img_height2 . "\" alt=\"" . get_the_title() . "\"></a><div class='thumb_hover'><a class=\"link\" href=\"" . get_permalink() . "\"></a></div>\n".
						"</div>\n";  
						} 
						}
						}
					?>
				</div>
				<div class="popular_cnt">
					<h3><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a></h3>
				
				<div class='pop_byline'>
				<span><?php the_time('M jS, Y'); ?></span>
				</div>
				</div>
			</div>
		<?php
			endwhile;
		?>
	</div>
</div>

<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Popular Posts', 'gl_popular_widget_domain' );
}

 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '4', 'gl_popular_widget_domain' );
}

 if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '112', 'gl_popular_widget_domain' );
}

 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '100', 'gl_popular_widget_domain' );
}

?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>
<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';
return $instance;
}
}

//Popular Post Widget Ends Here//

// Random Post Widget Starts Here

class gl_random_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_random_widget', 

__('Premium - Random Post', 'gl_random_widget_domain'), 

array( 'description' => __( 'Displays Random Post', 'gl_random_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );

echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];

?>

<div class="random_post sidebar_widget_bg sidebar_widget">
	
	<div class='random_post_cnt sidebar_content'>
		<?php
			query_posts('post_type=post&posts_per_page='. $post_count .' &orderby=rand&order=DESC');
			while (have_posts()): the_post(); 
		?>
			<div class='random'>
				<div class='random_img'>
					<?php
					if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
 echo "<div class='featured_viedo_image featured_image'>";
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true);echo "</div>";	
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video
			
					// Defaults
						$f_img_width4 = $instance['width_size'];
						$f_img_height4 = $instance['height_size'];
						// Auto feature image defaults
						$thumb = get_post_thumbnail_id(); 
						$img_url = wp_get_attachment_url( $thumb,'full' ); 
						$image = aq_resize( $img_url, $f_img_width4, $f_img_height4, true );
						// Catch the Image defaults
						$catch_img_url = catch_that_image( $thumb,'full' );
						$catch_image = aq_resize( $catch_img_url, $f_img_width4, $f_img_height4, true );
						if(has_post_thumbnail())
						echo
						"<div class=\"featured_image\">\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width4 . "\" height=\"" . $f_img_height4 . "\" alt=\"" . get_the_title() . "\"></a><div class='thumb_hover'><a class=\"link\" href=\"" . get_permalink() . "\"></a></div>\n".
						"</div>\n";
						elseif (catch_that_image()){ 
						echo
						"<div class=\"featured_image\">\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width4 . "\" height=\"" . $f_img_height4 . "\" alt=\"" . get_the_title() . "\"></a><div class='thumb_hover'><a class=\"link\" href=\"" . get_permalink() . "\"></a></div>\n".
						"</div>\n";  
						} 
						}
						}
					?>
				</div>
				<div class="random_cnt">
					<h3><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a></h3>
				</div>
			</div>
		<?php
			endwhile;
		?>
	</div>
</div>

<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Random Posts', 'gl_random_widget_domain' );
}

 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '4', 'gl_random_widget_domain' );
}

 if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '112', 'gl_random_widget_domain' );
}

 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '100', 'gl_random_widget_domain' );
}

?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>
<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';
return $instance;
}
}

//Random Post Widget Ends Here//


//Last Updated Post Widget Starts Here
class gl_last_update_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_last_update_widget', 

__('Premium - Last Updated Post', 'gl_last_update_widget_domain'), 

array( 'description' => __( 'Displays Last Updated Post', 'gl_last_update_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );

echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];

?>

<div class="last_updated_pst sidebar_widget_bg ">
	
	<div class="last_updated sidebar_content">
		<?php
			
			// Query Arguments
			$lastupdated_args = array(
			'orderby' => 'modified',
			);
			//Loop to display 5 recently updated posts
			$lastupdated_loop = new WP_Query( $lastupdated_args );
			$counter = 1;
			echo '<ul>';
			while( $lastupdated_loop->have_posts() && $counter <= $instance[ 'post_count' ] ) : $lastupdated_loop->the_post();
			echo '<li>';
			
			
echo"<div class='trend_img'>";
if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
 echo "<div class='featured_viedo_image featured_image'>";
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true);echo "</div>";	
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video
			
 // Defaults
        $f_img_width6 = $instance['width_size'];
        $f_img_height6 = $instance['height_size'];

		// Auto feature image defaults
		$thumb = get_post_thumbnail_id(); 
		$img_url = wp_get_attachment_url( $thumb,'full' ); 
		$image = aq_resize( $img_url,$f_img_width6,$f_img_height6, true );
		// Catch the Image defaults
        $catch_img_url = catch_that_image( $thumb,'full' );
        $catch_image = aq_resize( $catch_img_url, $f_img_width6, $f_img_height6, true );
        // Default Image
		if(has_post_thumbnail())
		echo
		"<div class=\"featured_image\">\n".
		"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width6 . "\" height=\"" . $f_img_height6 . "\" alt=\"" . get_the_title() . "\"><div class='thumb_hover'></div></a>\n".
		"</div>\n";
		elseif (catch_that_image()){ 
		echo
		"<div class=\"featured_image\">\n".
		"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width6 . "\" height=\"" . $f_img_height6 . "\" alt=\"" . get_the_title() . "\"></a>\n".
		"</div>\n"; 
		}
}
}		
		/*featured image ends here*/

echo "</div>".
'<h3><a href="' . get_permalink( $lastupdated_loop->post->ID ) . '"> ' .get_the_title( $lastupdated_loop->post->ID ) . '</a> ( '. get_the_modified_date() .')</h3> '.
'</li>';
			$counter++;
			endwhile; 
			echo '</ul>';
			wp_reset_postdata(); 
			
		?>
	</div>
</div>
<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Last Updated Posts', 'gl_last_update_widget_domain' );
}

 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '4', 'gl_last_update_widget_domain' );
}


 if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '112', 'gl_random_widget_domain' );
}

 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '100', 'gl_random_widget_domain' );
}

?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>
<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';
return $instance;
}
} 

//Last Updated Post Widget Ends Here//

//Single Page Related Post Widget starts Here


class gl_related_post_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_related_post_widget', 

__('Premium - Single Related Post', 'gl_related_post_widget_domain'), 

array( 'description' => __( 'Displays Single Related Post', 'gl_related_post_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$related_title = apply_filters( 'related_title', $instance['related_title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );


echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];

?>

<div class="thesis_related single_page_cnt">
<?php
global $post;

	if ( is_single() ) {
		$tags = get_the_tags($post->ID);
			if ($tags) {
			$tag_ids = array();
			foreach($tags as $individual_tag) $tag_ids[] = $individual_tag->term_id;
			$args=array(
			'tag__in' => $tag_ids,
			'post__not_in' => array($post->ID),
			'showposts'=>$instance[ 'post_count' ],  // Number of related posts that will be shown.
			'caller_get_posts'=>1
			);
	$my_query = new wp_query($args);
			if( $my_query->have_posts() ) {
	echo	'<div id="relatedposts">'.
				'<div class="single_title">'.
					'<h3>'. $related_title .'</h3>'.
				
				'</div>'.
			'<div class="related_section">';
		while ($my_query->have_posts()) {
			$my_query->the_post();
			$i++;
			$class = ( $i % 3) ? 'related_post_section' : 'related_post_section last';
	 ?>
			<div class="<?php echo $class; ?>">
							<div class="related_img">
								<?php
if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
 echo "<div class='featured_viedo_image featured_image'>";
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true); echo "</div>";	
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video
						  $f_img_width8 = $instance['width_size'];
							$f_img_height8 =$instance['height_size'];
							$default_img =  'Feature_image'; 
						// Auto feature image defaults
						$thumb = get_post_thumbnail_id(); 
						$img_url = wp_get_attachment_url( $thumb,'full' ); 
						$image = aq_resize( $img_url, $f_img_width8, $f_img_height8, true );
						// Catch the Image defaults
						$catch_img_url = catch_that_image( $thumb,'full' );
						$catch_image = aq_resize( $catch_img_url, $f_img_width8, $f_img_height8, true );
						if(has_post_thumbnail())
						echo
						"<div class=\"featured_image\">\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width8 . "\" height=\"" . $f_img_height8 . "\" alt=\"" . get_the_title() . "\"></a><div class='img_hover'><a class=\"link\" href=\"" . get_permalink() . "\"></a></div>\n".
						"</div>\n";
						elseif (catch_that_image()){ 
						echo
						"<div class=\"featured_image\">\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width8 . "\" height=\"" . $f_img_height8 . "\" alt=\"" . get_the_title() . "\"></a><div class='img_hover'><a class=\"link\" href=\"" . get_permalink() . "\"></a></div>\n".
						"</div>\n";  
						}
						}
						}						
					?>
							</div>

							<div class="related_post_cnt">
									<?php echo "<h3><a href='". get_permalink() ."'>".get_the_title()."";
									echo "</a></h3>";?>
									<span class='date'><?php the_time('M jS, Y') ?></span>
							
							</div>
					</div>
	<?php
			}
			echo '</div>';
			echo '</div>';
			}
		}
	$post = $backup;
			wp_reset_query();
			?>
			<div class="clear"></div>
			<?php
			 }
		
?>
</div>
<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {
if ( isset( $instance[ 'related_title' ] ) ) {
$related_title = $instance[ 'related_title' ];
}
else {
$related_title = __( 'Related Post', 'gl_related_post_widget_domain' );
}

 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '3', 'gl_related_post_widget_domain' );
}

if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '246', 'gl_related_post_widget_domain' );
}

 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '157', 'gl_related_post_widget_domain' );
}


?>
<p>
<label for="<?php echo $this->get_field_id( 'related_title' ); ?>"><?php _e( 'Post Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'related_title' ); ?>" name="<?php echo $this->get_field_name( 'related_title' ); ?>" type="text" value="<?php echo esc_attr( $related_title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Left Latest News Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Left Latest News  Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>
<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['related_title'] = ( ! empty( $new_instance['related_title'] ) ) ? strip_tags( $new_instance['related_title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';

return $instance;
}
}

//Single Page Related Post Widget Ends Here


//Top Welcome Box widget starts here;


class gl_top_welcome_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_top_welcome_widget', 

__('Front Top Welcome Box ', 'gl_top_welcome_widget_domain'), 

array( 'description' => __( 'Displays Front Top Welcome Box', 'gl_top_welcome_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$welcome_title = apply_filters( 'welcome_title', $instance['welcome_title'] );
$welcome_para = apply_filters( 'welcome_para', $instance['welcome_para'] );
$wel_read = apply_filters( 'wel_read', $instance['wel_read'] );
$wel_read_url = apply_filters( 'wel_read_url', $instance['wel_read_url'] );

echo $args['before_widget'];
if ( ! empty( $title ) )
//echo $args['before_title'] . $title . $args['after_title'];


?>
<div class="front_welcome_content front_cont">
<div class="inner_welcome_content wrap">
<div class="welcome_details">
<h3><?php echo $instance['welcome_title'];?></h3>
<p><?php echo $instance['welcome_para']; ?></p>

<div class="cl-effect-2 btn2">
<a class="welcome_read" href="<?php  echo $instance['wel_read_url'];?>"><span data-hover="Click here..."><?php  echo $instance['wel_read'];?></span></a>
</div>

</div>
</div>

</div>
<?php
echo $args['after_widget'];
}
		
public function form( $instance ) {

if ( isset( $instance[ 'welcome_title' ] ) ) {
$welcome_title = $instance[ 'welcome_title' ];
}
else {
$welcome_title = __( 'Header Text', 'gl_top_welcome_widget_domain' );
}


if ( isset( $instance[ 'welcome_para' ] ) ) {
$welcome_para = $instance[ 'welcome_para' ];
}
else {
$welcome_para = __( 'Header Para', 'gl_top_welcome_widget_domain' );
}

if ( isset( $instance[ 'wel_read' ] ) ) {
$wel_read = $instance[ 'wel_read' ];
}
else {
$wel_read = __( 'Read more', 'gl_top_welcome_widget_domain' );
}

if ( isset( $instance[ 'wel_read_url' ] ) ) {
$wel_read_url = $instance[ 'wel_read_url' ];
}
else {
$wel_read_url = __( '', 'gl_top_welcome_widget_domain' );
}
?>

<p>
<label for="<?php echo $this->get_field_id( 'welcome_title' ); ?>"><?php _e( 'Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'welcome_title' ); ?>" name="<?php echo $this->get_field_name( 'welcome_title' ); ?>" type="text" value="<?php echo esc_attr( $welcome_title ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'welcome_para' ); ?>"><?php _e( 'Welcome Box Para text:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'welcome_para' ); ?>" name="<?php echo $this->get_field_name( 'welcome_para' ); ?>" type="text" value="<?php echo esc_attr( $welcome_para ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'wel_read' ); ?>"><?php _e( 'Welcome Box Read more text:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'wel_read' ); ?>" name="<?php echo $this->get_field_name( 'wel_read' ); ?>" type="text" value="<?php echo esc_attr( $wel_read ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'wel_read_url' ); ?>"><?php _e( 'Read more URL Link:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'wel_read_url' ); ?>" name="<?php echo $this->get_field_name( 'wel_read_url' ); ?>" type="text" value="<?php echo esc_attr( $wel_read_url ); ?>" />
</p>

<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['welcome_title'] = ( ! empty( $new_instance['welcome_title'] ) ) ? strip_tags( $new_instance['welcome_title'] ) : '';
$instance['welcome_para'] = ( ! empty( $new_instance['welcome_para'] ) ) ? strip_tags( $new_instance['welcome_para'] ) : '';
$instance['wel_read'] = ( ! empty( $new_instance['wel_read'] ) ) ? strip_tags( $new_instance['wel_read'] ) : '';
$instance['wel_read_url'] = ( ! empty( $new_instance['wel_read_url'] ) ) ? strip_tags( $new_instance['wel_read_url'] ) : '';
return $instance;
}
}

//Top Welcome box Widget ends here


//Front Feature box  widget starts here;

class gl_feature_box_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_feature_box_widget', 

__('Front Top Feature Box ', 'gl_feature_box_widget_domain'), 

array( 'description' => __( 'Displays Front Top Feature Box', 'gl_feature_box_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$ftr_header_txt = apply_filters( 'ftr_header_txt', $instance['ftr_header_txt'] );

$fftr1_img = apply_filters( 'fftr1_img', $instance['fftr1_img'] );
$fftr1_title = apply_filters( 'fftr1_title', $instance['fftr1_title'] );
$fftr1_sub_title = apply_filters( 'fftr1_sub_title', $instance['fftr1_sub_title'] );
$fread_more_text1 = apply_filters( 'fread_more_text1', $instance['fread_more_text1'] );
$fread_more_url1 = apply_filters( 'fread_more_url1', $instance['fread_more_url1'] );

$fftr2_img = apply_filters( 'fftr2_img', $instance['fftr2_img'] );
$fftr2_title = apply_filters( 'fftr2_title', $instance['fftr2_title'] );
$fftr2_sub_title = apply_filters( 'fftr2_sub_title', $instance['fftr2_sub_title'] );
$fread_more_text2 = apply_filters( 'fread_more_text2', $instance['fread_more_text2'] );
$fread_more_url2 = apply_filters( 'fread_more_url2', $instance['fread_more_url2'] );

$fftr3_img = apply_filters( 'fftr3_img', $instance['fftr3_img'] );
$fftr3_title = apply_filters( 'fftr3_title', $instance['fftr3_title'] );
$fftr3_sub_title = apply_filters( 'fftr3_sub_title', $instance['fftr3_sub_title'] );
$fread_more_text3 = apply_filters( 'fread_more_text3', $instance['fread_more_text3'] );
$fread_more_url3 = apply_filters( 'fread_more_url3', $instance['fread_more_url3'] );

echo $args['before_widget'];
if ( ! empty( $title ) )
//echo $args['before_title'] . $title . $args['after_title'];


?>

<div class="front_feature_content front_cont">
 <div class='title'><h3 class='center_header'><?php echo $instance['ftr_header_txt']; ?></h3></div>
<div class="inner_feature_content wrap">

<div class='front_feature_section'>
<div class='front_feature_col'>
<div class='feature_img'>
<a href='<?php  echo $instance['fread_more_url1'];?>'><img alt='<?php echo $instance['fftr1_title']; ?>' src='<?php echo $instance['fftr1_img']; ?>'/></a>
</div>
<h3> <?php echo $instance['fftr1_title']; ?></h3>
<p><?php echo $instance['fftr1_sub_title']; ?></p>
<a class="ftr_read" href="<?php  echo $instance['fread_more_url1'];?>"><?php  echo $instance['fread_more_text1'];?></a>
</div>

<div class='front_feature_col'>
<div class='feature_img'>
<a href='<?php  echo $instance['fread_more_url2'];?>'><img alt='<?php echo $instance['fftr2_title']; ?>' src='<?php echo $instance['fftr2_img']; ?>'/></a>
</div>
<h3> <?php echo $instance['fftr2_title']; ?></h3>
<p><?php echo $instance['fftr2_sub_title']; ?></p>
<a class="ftr_read" href="<?php  echo $instance['fread_more_url2'];?>"><?php  echo $instance['fread_more_text2'];?></a>
</div>

<div class='front_feature_col last'>
<div class='feature_img'>
<a href='<?php  echo $instance['fread_more_url3'];?>'><img alt='<?php echo $instance['fftr3_title']; ?>' src='<?php echo $instance['fftr3_img']; ?>'/></a>
</div>
<h3> <?php echo $instance['fftr3_title']; ?></h3>
<p><?php echo $instance['fftr3_sub_title']; ?></p>
<a class="ftr_read" href="<?php  echo $instance['fread_more_url3'];?>"><?php  echo $instance['fread_more_text3'];?></a>
</div>

</div>
</div>
</div>
<?php
echo $args['after_widget'];
}
	
public function form( $instance ) {


if ( isset( $instance[ 'ftr_header_txt' ] ) ) {
$ftr_header_txt = $instance[ 'ftr_header_txt' ];
}
else {
$ftr_header_txt = __( '', 'gl_feature_box_widget_domain' );
}


if ( isset( $instance[ 'fftr1_img' ] ) ) {
$fftr1_img = $instance[ 'fftr1_img' ];
}
else {
$fftr1_img = __( '', 'gl_feature_box_widget_domain' );
}


if ( isset( $instance[ 'fftr1_title' ] ) ) {
$fftr1_title = $instance[ 'fftr1_title' ];
}
else {
$fftr1_title = __( '', 'gl_feature_box_widget_domain' );
}

if ( isset( $instance[ 'fftr1_sub_title' ] ) ) {
$fftr1_sub_title = $instance[ 'fftr1_sub_title' ];
}
else {
$fftr1_sub_title = __( '', 'gl_feature_box_widget_domain' );
}

if ( isset( $instance[ 'fread_more_text1' ] ) ) {
$fread_more_text1 = $instance[ 'fread_more_text1' ];
}
else {
$fread_more_text1 = __( '', 'gl_feature_box_widget_domain' );
}


if ( isset( $instance[ 'fread_more_url1' ] ) ) {
$fread_more_url1 = $instance[ 'fread_more_url1' ];
}
else {
$fread_more_url1 = __( '', 'gl_feature_box_widget_domain' );
}
//feature2

if ( isset( $instance[ 'fftr2_img' ] ) ) {
$fftr2_img = $instance[ 'fftr2_img' ];
}
else {
$fftr2_img = __( '', 'gl_feature_box_widget_domain' );
}


if ( isset( $instance[ 'fftr2_title' ] ) ) {
$fftr2_title = $instance[ 'fftr2_title' ];
}
else {
$fftr2_title = __( '', 'gl_feature_box_widget_domain' );
}

if ( isset( $instance[ 'fftr2_sub_title' ] ) ) {
$fftr2_sub_title = $instance[ 'fftr2_sub_title' ];
}
else {
$fftr2_sub_title = __( '', 'gl_feature_box_widget_domain' );
}

if ( isset( $instance[ 'fread_more_text2' ] ) ) {
$fread_more_text2 = $instance[ 'fread_more_text2' ];
}
else {
$fread_more_text2 = __( '', 'gl_feature_box_widget_domain' );
}


if ( isset( $instance[ 'fread_more_url2' ] ) ) {
$fread_more_url2 = $instance[ 'fread_more_url2' ];
}
else {
$fread_more_url2 = __( '', 'gl_feature_box_widget_domain' );
}
//feature3


if ( isset( $instance[ 'fftr3_img' ] ) ) {
$fftr3_img = $instance[ 'fftr3_img' ];
}
else {
$fftr3_img = __( '', 'gl_feature_box_widget_domain' );
}


if ( isset( $instance[ 'fftr3_title' ] ) ) {
$fftr3_title = $instance[ 'fftr3_title' ];
}
else {
$fftr3_title = __( '', 'gl_feature_box_widget_domain' );
}

if ( isset( $instance[ 'fftr3_sub_title' ] ) ) {
$fftr3_sub_title = $instance[ 'fftr3_sub_title' ];
}
else {
$fftr3_sub_title = __( '', 'gl_feature_box_widget_domain' );
}

if ( isset( $instance[ 'fread_more_text3' ] ) ) {
$fread_more_text3 = $instance[ 'fread_more_text3' ];
}
else {
$fread_more_text3 = __( '', 'gl_feature_box_widget_domain' );
}


if ( isset( $instance[ 'fread_more_url3' ] ) ) {
$fread_more_url3 = $instance[ 'fread_more_url3' ];
}
else {
$fread_more_url3 = __( '', 'gl_feature_box_widget_domain' );
}
?>

<p>
<label for="<?php echo $this->get_field_id( 'ftr_header_txt' ); ?>"><?php _e( 'Feature Header Text:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'ftr_header_txt' ); ?>" name="<?php echo $this->get_field_name( 'ftr_header_txt' ); ?>" type="text" value="<?php echo esc_attr( $ftr_header_txt ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'fftr1_img' ); ?>"><?php _e( 'Feature1 Image:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'fftr1_img' ); ?>" name="<?php echo $this->get_field_name( 'fftr1_img' ); ?>" type="text" value="<?php echo esc_attr( $fftr1_img ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'fftr1_title' ); ?>"><?php _e( 'Feature1 Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'fftr1_title' ); ?>" name="<?php echo $this->get_field_name( 'fftr1_title' ); ?>" type="text" value="<?php echo esc_attr( $fftr1_title ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'fftr1_sub_title' ); ?>"><?php _e( 'Feature1 Para Text:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'fftr1_sub_title' ); ?>" name="<?php echo $this->get_field_name( 'fftr1_sub_title' ); ?>" type="text" value="<?php echo esc_attr( $fftr1_sub_title ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'fread_more_text1' ); ?>"><?php _e( 'Feature1 Read more text:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'fread_more_text1' ); ?>" name="<?php echo $this->get_field_name( 'fread_more_text1' ); ?>" type="text" value="<?php echo esc_attr( $fread_more_text1 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'fread_more_url1' ); ?>"><?php _e( 'Feature1 Read more URL Link:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'fread_more_url1' ); ?>" name="<?php echo $this->get_field_name( 'fread_more_url1' ); ?>" type="text" value="<?php echo esc_attr( $fread_more_url1 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'fftr2_img' ); ?>"><?php _e( 'Feature2 Image:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'fftr2_img' ); ?>" name="<?php echo $this->get_field_name( 'fftr2_img' ); ?>" type="text" value="<?php echo esc_attr( $fftr2_img ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'fftr2_title' ); ?>"><?php _e( 'Feature2 Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'fftr2_title' ); ?>" name="<?php echo $this->get_field_name( 'fftr2_title' ); ?>" type="text" value="<?php echo esc_attr( $fftr2_title ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'fftr2_sub_title' ); ?>"><?php _e( 'Feature2 Para Text:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'fftr2_sub_title' ); ?>" name="<?php echo $this->get_field_name( 'fftr2_sub_title' ); ?>" type="text" value="<?php echo esc_attr( $fftr2_sub_title ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'fread_more_text2' ); ?>"><?php _e( 'Feature2 Read more text:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'fread_more_text2' ); ?>" name="<?php echo $this->get_field_name( 'fread_more_text2' ); ?>" type="text" value="<?php echo esc_attr( $fread_more_text2 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'fread_more_url2' ); ?>"><?php _e( 'Feature2 Read more URL Link:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'fread_more_url2' ); ?>" name="<?php echo $this->get_field_name( 'fread_more_url2' ); ?>" type="text" value="<?php echo esc_attr( $fread_more_url2 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'fftr3_img' ); ?>"><?php _e( 'Feature3 Image:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'fftr3_img' ); ?>" name="<?php echo $this->get_field_name( 'fftr3_img' ); ?>" type="text" value="<?php echo esc_attr( $fftr3_img ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'fftr3_title' ); ?>"><?php _e( 'Feature3 Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'fftr3_title' ); ?>" name="<?php echo $this->get_field_name( 'fftr3_title' ); ?>" type="text" value="<?php echo esc_attr( $fftr3_title ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'fftr3_sub_title' ); ?>"><?php _e( 'Feature3 Para Text:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'fftr3_sub_title' ); ?>" name="<?php echo $this->get_field_name( 'fftr3_sub_title' ); ?>" type="text" value="<?php echo esc_attr( $fftr3_sub_title ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'fread_more_text3' ); ?>"><?php _e( 'Feature3 Read more text:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'fread_more_text3' ); ?>" name="<?php echo $this->get_field_name( 'fread_more_text3' ); ?>" type="text" value="<?php echo esc_attr( $fread_more_text3 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'fread_more_url3' ); ?>"><?php _e( 'Feature3 Read more URL Link:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'fread_more_url3' ); ?>" name="<?php echo $this->get_field_name( 'fread_more_url3' ); ?>" type="text" value="<?php echo esc_attr( $fread_more_url3 ); ?>" />
</p>
<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['ftr_header_txt'] = ( ! empty( $new_instance['ftr_header_txt'] ) ) ? strip_tags( $new_instance['ftr_header_txt'] ) : '';

$instance['fftr1_img'] = ( ! empty( $new_instance['fftr1_img'] ) ) ? strip_tags( $new_instance['fftr1_img'] ) : '';
$instance['fftr1_title'] = ( ! empty( $new_instance['fftr1_title'] ) ) ? strip_tags( $new_instance['fftr1_title'] ) : '';
$instance['fftr1_sub_title'] = ( ! empty( $new_instance['fftr1_sub_title'] ) ) ? strip_tags( $new_instance['fftr1_sub_title'] ) : '';
$instance['fread_more_text1'] = ( ! empty( $new_instance['fread_more_text1'] ) ) ? strip_tags( $new_instance['fread_more_text1'] ) : '';
$instance['fread_more_url1'] = ( ! empty( $new_instance['fread_more_url1'] ) ) ? strip_tags( $new_instance['fread_more_url1'] ) : '';

$instance['fftr2_img'] = ( ! empty( $new_instance['fftr2_img'] ) ) ? strip_tags( $new_instance['fftr2_img'] ) : '';
$instance['fftr2_title'] = ( ! empty( $new_instance['fftr2_title'] ) ) ? strip_tags( $new_instance['fftr2_title'] ) : '';
$instance['fftr2_sub_title'] = ( ! empty( $new_instance['fftr2_sub_title'] ) ) ? strip_tags( $new_instance['fftr2_sub_title'] ) : '';
$instance['fread_more_text2'] = ( ! empty( $new_instance['fread_more_text2'] ) ) ? strip_tags( $new_instance['fread_more_text2'] ) : '';
$instance['fread_more_url2'] = ( ! empty( $new_instance['fread_more_url2'] ) ) ? strip_tags( $new_instance['fread_more_url2'] ) : '';

$instance['fftr3_img'] = ( ! empty( $new_instance['fftr3_img'] ) ) ? strip_tags( $new_instance['fftr3_img'] ) : '';
$instance['fftr3_title'] = ( ! empty( $new_instance['fftr3_title'] ) ) ? strip_tags( $new_instance['fftr3_title'] ) : '';
$instance['fftr3_sub_title'] = ( ! empty( $new_instance['fftr3_sub_title'] ) ) ? strip_tags( $new_instance['fftr3_sub_title'] ) : '';
$instance['fread_more_text3'] = ( ! empty( $new_instance['fread_more_text3'] ) ) ? strip_tags( $new_instance['fread_more_text3'] ) : '';
$instance['fread_more_url3'] = ( ! empty( $new_instance['fread_more_url3'] ) ) ? strip_tags( $new_instance['fread_more_url3'] ) : '';

return $instance;
}
}



//Front Feature box Widget ends here

//Front Portfolio box Widget starts here

class gl_portfolio_box_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_portfolio_box_widget', 

__('Premium - Portfolio Box ', 'gl_portfolio_box_widget_domain'), 

array( 'description' => __( 'Displays Portfolio Box Content', 'gl_portfolio_box_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$port_header_txt = apply_filters( 'port_header_txt', $instance['port_header_txt'] );
$port_para_txt = apply_filters( 'port_para_txt', $instance['port_para_txt'] );
$port_view = apply_filters( 'port_view', $instance['port_view'] );
$port_content_bg = apply_filters( 'port_content_bg', $instance['port_content_bg'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );

echo $args['before_widget'];
if ( ! empty( $title ) )
//echo $args['before_title'] . $title . $args['after_title'];


?>

<div class='port_container' style='background-image:url(<?php echo $instance['port_content_bg'];?> )'>
<div class='port_box_color'>
<div class='port_header'>
<div class='title'><h3 class='center_header'><?php echo $instance['port_header_txt']; ?></h3></div>
<p><?php echo $instance['port_para_txt']; ?></p></div>
<div class="portfolio">
				
<?php 
	global $post; 
	$portfolio_category = get_post_meta($post->ID, 'portfolio_category', true);
	$paged = get_query_var('paged') ? get_query_var('paged') : 1;
	$args = array('post_type' => 'portfolio', 'showposts' => $instance[ 'post_count' ], 'paged' => $paged, 'portfolio-category' => $portfolio_category);
	$query_args = wp_parse_args($cf, $args);
	$custom_query = new WP_Query($query_args);
	while($custom_query->have_posts()) : $custom_query->the_post(); 
	$terms = get_the_terms( $post->ID, 'portfolio_category' );
	if ( $terms && ! is_wp_error( $terms ) ) :
	$links = array();
	foreach ( $terms as $term ) {
	$links[] = $term->name;
	}
	$links = str_replace(' ', '-', $links);
	$tax = join( " ", $links );
	else :
	$tax = '';
	endif;
?>

<article class="entry <?php echo strtolower($tax); ?>">
							   <?php 
										// Defaults
										$f_img_width3 = $instance['width_size'];
										$f_img_height3 =$instance['height_size'];
										// Auto feature image defaults
										$thumb = get_post_thumbnail_id(); 
										$img_url = wp_get_attachment_url( $thumb,'full' ); 
										$image = aq_resize( $img_url, $f_img_width3, $f_img_height3, true );
										// Catch the Image defaults
										$catch_img_url = catch_that_image( $thumb,'full' );
										$catch_image = aq_resize( $catch_img_url, $f_img_width3, $f_img_height3, true );
										if(has_post_thumbnail())
										echo
										"<div class=\"featured_image\">\n".
										"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width3 . "\" height=\"" . $f_img_height3 . "\" alt=\"" . get_the_title() . "\"><div class='image_overlay'></div></a>\n".
										"</div>\n";
										elseif (catch_that_image()){ 
										echo
										"<div class=\"featured_image\">\n".
										"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width3 . "\" height=\"" . $f_img_height3 . "\" alt=\"" . get_the_title() . "\"><div class='image_overlay'></div></a>\n".
										"</div>\n"; 
										} 
									/*featured image ends here*/
									?>
<div class='portfolio_cnt_section'>
			 <?php
 echo "<h3><a href='".get_permalink()."'>";?><?php echo the_title(); ?></a></h3>
 <?php
echo "<p>";
$excerpt=get_the_excerpt();
echo limit_words($excerpt,8);
echo "</p>";
?>
<div class='port_permalink'><a href='<?php echo the_permalink(); ?>'><?php echo $instance['port_view']; ?></a></div> 
</div>
</article>
				
<?php			
endwhile;
wp_reset_query(); 
?>

</div>


</div>
</div>
<?php
echo $args['after_widget'];
}
	
public function form( $instance ) {

if ( isset( $instance[ 'port_header_txt' ] ) ) {
$port_header_txt = $instance[ 'port_header_txt' ];
}
else {
$port_header_txt = __( '', 'gl_portfolio_box_widget_domain' );
}

if ( isset( $instance[ 'port_para_txt' ] ) ) {
$port_para_txt = $instance[ 'port_para_txt' ];
}
else {
$port_para_txt = __( '', 'gl_portfolio_box_widget_domain' );
}

if ( isset( $instance[ 'port_view' ] ) ) {
$port_view = $instance[ 'port_view' ];
}
else {
$port_view = __( '', 'gl_portfolio_box_widget_domain' );
}

if ( isset( $instance[ 'port_content_bg' ] ) ) {
$port_content_bg = $instance[ 'port_content_bg' ];
}
else {
$port_content_bg = __( '', 'gl_portfolio_box_widget_domain' );
}

if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '', 'gl_portfolio_box_widget_domain' );
}

if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '', 'gl_portfolio_box_widget_domain' );
}

if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '', 'gl_portfolio_box_widget_domain' );
}

?>

<p>
<label for="<?php echo $this->get_field_id( 'port_header_txt' ); ?>"><?php _e( 'Header Text:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'port_header_txt' ); ?>" name="<?php echo $this->get_field_name( 'port_header_txt' ); ?>" type="text" value="<?php echo esc_attr( $port_header_txt ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'port_para_txt' ); ?>"><?php _e( 'Para text:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'port_para_txt' ); ?>" name="<?php echo $this->get_field_name( 'port_para_txt' ); ?>" type="text" value="<?php echo esc_attr( $port_para_txt ); ?>" />
</p>


<p>
<label for="<?php echo $this->get_field_id( 'port_view' ); ?>"><?php _e( 'View More Text:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'port_view' ); ?>" name="<?php echo $this->get_field_name( 'port_view' ); ?>" type="text" value="<?php echo esc_attr( $port_view ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'port_content_bg' ); ?>"><?php _e( 'Port Content BG:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'port_content_bg' ); ?>" name="<?php echo $this->get_field_name( 'port_content_bg' ); ?>" type="text" value="<?php echo esc_attr( $port_content_bg ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Feature image width:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Feature image height:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>

<?php 
}


public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['port_header_txt'] = ( ! empty( $new_instance['port_header_txt'] ) ) ? strip_tags( $new_instance['port_header_txt'] ) : '';
$instance['port_para_txt'] = ( ! empty( $new_instance['port_para_txt'] ) ) ? strip_tags( $new_instance['port_para_txt'] ) : '';
$instance['port_view'] = ( ! empty( $new_instance['port_view'] ) ) ? strip_tags( $new_instance['port_view'] ) : '';
$instance['port_content_bg'] = ( ! empty( $new_instance['port_content_bg'] ) ) ? strip_tags( $new_instance['port_content_bg'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';

return $instance;
}
}

//Front Portfolio box Widget Ends here

//Front Pricing Table Widget starts here

class gl_pricing_table_box_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_pricing_table_box_widget', 

__('Premium - Pricing Table Box ', 'gl_pricing_table_box_widget_domain'), 

array( 'description' => __( 'Displays Pricing Table Box Content', 'gl_pricing_table_box_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$price_header_txt = apply_filters( 'price_header_txt', $instance['price_header_txt'] );

$cell_one_title = apply_filters( 'cell_one_title', $instance['cell_one_title'] );
$cell_one_price = apply_filters( 'cell_one_price', $instance['cell_one_price'] );
$cell_one_duration = apply_filters( 'cell_one_duration', $instance['cell_one_duration'] );
$pricing_one_content1 = apply_filters( 'pricing_one_content1', $instance['pricing_one_content1'] );
$pricing_one_content2 = apply_filters( 'pricing_one_content2', $instance['pricing_one_content2'] );
$pricing_one_content3 = apply_filters( 'pricing_one_content3', $instance['pricing_one_content3'] );
$pricing_one_content4 = apply_filters( 'pricing_one_content4', $instance['pricing_one_content4'] );
$pricing_one_content5 = apply_filters( 'pricing_one_content5', $instance['pricing_one_content5'] );
$pricing1_read = apply_filters( 'pricing1_read', $instance['pricing1_read'] );
$pricing_one_url = apply_filters( 'pricing_one_url', $instance['pricing_one_url'] );

$cell_two_title = apply_filters( 'cell_two_title', $instance['cell_two_title'] );
$cell_two_price = apply_filters( 'cell_two_price', $instance['cell_two_price'] );
$cell_two_duration = apply_filters( 'cell_two_duration', $instance['cell_two_duration'] );
$pricing_two_content1 = apply_filters( 'pricing_two_content1', $instance['pricing_two_content1'] );
$pricing_two_content2 = apply_filters( 'pricing_two_content2', $instance['pricing_two_content2'] );
$pricing_two_content3 = apply_filters( 'pricing_two_content3', $instance['pricing_two_content3'] );
$pricing_two_content4 = apply_filters( 'pricing_two_content4', $instance['pricing_two_content4'] );
$pricing_two_content5 = apply_filters( 'pricing_two_content5', $instance['pricing_two_content5'] );
$pricing2_read = apply_filters( 'pricing2_read', $instance['pricing2_read'] );
$pricing_two_url = apply_filters( 'pricing_two_url', $instance['pricing_two_url'] );

$cell_three_title = apply_filters( 'cell_three_title', $instance['cell_three_title'] );
$cell_three_price = apply_filters( 'cell_three_price', $instance['cell_three_price'] );
$cell_three_duration = apply_filters( 'cell_three_duration', $instance['cell_three_duration'] );
$pricing_three_content1 = apply_filters( 'pricing_three_content1', $instance['pricing_three_content1'] );
$pricing_three_content2 = apply_filters( 'pricing_three_content2', $instance['pricing_three_content2'] );
$pricing_three_content3 = apply_filters( 'pricing_three_content3', $instance['pricing_three_content3'] );
$pricing_three_content4 = apply_filters( 'pricing_three_content4', $instance['pricing_three_content4'] );
$pricing_three_content5 = apply_filters( 'pricing_three_content5', $instance['pricing_three_content5'] );
$pricing3_read = apply_filters( 'pricing3_read', $instance['pricing3_read'] );
$pricing_three_url = apply_filters( 'pricing_three_url', $instance['pricing_three_url'] );

echo $args['before_widget'];
if ( ! empty( $title ) )
//echo $args['before_title'] . $title . $args['after_title'];


?>

<div class='pricingtable_contents'>
<div class='inner_pricing_table pricingtable_contents_inner wrap'>
<div class='title'><h3 class='center_header'>	<?php echo $instance['price_header_txt']; ?></h3></div>

<div class='pricingtable_cell_cont'>
<div class='pricingtable_cell'>
<div class='pricing_cell pricing_cell1'>		        	

<div class='price_hd'>
<div class='title'><h2><?php echo $instance['cell_one_title']; ?></h2></div>
<div class="divider"></div>
<div class="price"><h1><?php echo $instance['cell_one_price']; ?></h1></div>
<div class="duration"><?php echo $instance['cell_one_duration']; ?></div>
</div>
<ul>
<li><span ></span> <?php echo $instance['pricing_one_content1']; ?></li>
<li><span></span><?php echo $instance['pricing_one_content2']; ?></li>
<li><span></span><?php echo $instance['pricing_one_content3']; ?></li>
<li><span></span><?php echo $instance['pricing_one_content4']; ?></li>
<li><span></span><?php echo $instance['pricing_one_content5']; ?></li>
<li class='align-center'><a href='<?php echo $instance['pricing_one_url']; ?>'><?php echo $instance['pricing1_read']; ?></a></li>
</ul>								
</div>
</div>


<div class='pricingtable_cell'>
<div class='pricing_cell pricing_cell2 center_cell'>		        	

<div class='price_hd'>
<div class='title'><h2><?php echo $instance['cell_two_title']; ?></h2></div>
<div class="divider"></div>
<div class="price"><h1><?php echo $instance['cell_two_price']; ?></h1></div>
<div class="duration"><?php echo $instance['cell_two_duration']; ?></div>
</div>
<ul>
<li><span ></span> <?php echo $instance['pricing_two_content1']; ?></li>
<li><span></span><?php echo $instance['pricing_two_content2']; ?></li>
<li><span></span><?php echo $instance['pricing_two_content3']; ?></li>
<li><span></span> <?php echo $instance['pricing_two_content4']; ?></li>
<li><span></span><?php echo $instance['pricing_two_content5']; ?></li>
<li class='align-center'><a href='<?php echo $instance['pricing_two_url'];?>'><?php echo $instance['pricing2_read']; ?></a></li>
</ul>								
</div>
</div>

<div class='pricingtable_cell last'>
<div class='pricing_cell pricing_cell3'>		        	

<div class='price_hd'>
<div class='title'><h2><?php echo $instance['cell_three_title']; ?></h2></div>
<div class="divider"></div>
<div class="price"><h1><?php echo $instance['cell_three_price']; ?></h1></div>
<div class="duration"><?php echo $instance['cell_three_duration']; ?></div>
</div>
<ul>
<li><span></span> <?php echo $instance['pricing_three_content1']; ?></li>
<li><span></span><?php echo $instance['pricing_three_content2']; ?></li>
<li><span></span><?php echo $instance['pricing_three_content3']; ?></li>
<li><span></span><?php echo $instance['pricing_three_content4']; ?></li>
<li><span></span><?php echo $instance['pricing_three_content5']; ?></li>
<li class='align-center'><a href='<?php echo $instance['pricing_three_url']; ?>'><?php echo $instance['pricing3_read']; ?></a></li>
</ul>								
</div>
</div>

</div>

</div>

</div>

<?php
echo $args['after_widget'];
}
	

	
public function form( $instance ) {

if ( isset( $instance[ 'price_header_txt' ] ) ) {
$price_header_txt = $instance[ 'price_header_txt' ];
}
else {
$price_header_txt = __( '', 'gl_pricing_table_box_widget_domain' );
}

if ( isset( $instance[ 'cell_one_title' ] ) ) {
$cell_one_title = $instance[ 'cell_one_title' ];
}
else {
$cell_one_title = __( '', 'gl_pricing_table_box_widget_domain' );
}

if ( isset( $instance[ 'cell_one_price' ] ) ) {
$cell_one_price = $instance[ 'cell_one_price' ];
}
else {
$cell_one_price = __( '', 'gl_pricing_table_box_widget_domain' );
}

if ( isset( $instance[ 'cell_one_duration' ] ) ) {
$cell_one_duration = $instance[ 'cell_one_duration' ];
}
else {
$cell_one_duration = __( '', 'gl_pricing_table_box_widget_domain' );
}

if ( isset( $instance[ 'pricing_one_content1' ] ) ) {
$pricing_one_content1 = $instance[ 'pricing_one_content1' ];
}
else {
$pricing_one_content1 = __( '', 'gl_pricing_table_box_widget_domain' );
}

if ( isset( $instance[ 'pricing_one_content2' ] ) ) {
$pricing_one_content2 = $instance[ 'pricing_one_content2' ];
}
else {
$pricing_one_content2 = __( '', 'gl_pricing_table_box_widget_domain' );
}

if ( isset( $instance[ 'pricing_one_content3' ] ) ) {
$pricing_one_content3 = $instance[ 'pricing_one_content3' ];
}
else {
$pricing_one_content3 = __( '', 'gl_pricing_table_box_widget_domain' );
}
if ( isset( $instance[ 'pricing_one_content4' ] ) ) {
$pricing_one_content4 = $instance[ 'pricing_one_content4' ];
}
else {
$pricing_one_content4 = __( '', 'gl_pricing_table_box_widget_domain' );
}

if ( isset( $instance[ 'pricing_one_content5' ] ) ) {
$pricing_one_content5 = $instance[ 'pricing_one_content5' ];
}
else {
$pricing_one_content5 = __( '', 'gl_pricing_table_box_widget_domain' );
}


if ( isset( $instance[ 'pricing1_read' ] ) ) {
$pricing1_read = $instance[ 'pricing1_read' ];
}
else {
$pricing1_read = __( '', 'gl_pricing_table_box_widget_domain' );
}

if ( isset( $instance[ 'pricing_one_url' ] ) ) {
$pricing_one_url = $instance[ 'pricing_one_url' ];
}
else {
$pricing_one_url = __( '', 'gl_pricing_table_box_widget_domain' );
}

//pricing two cell

if ( isset( $instance[ 'cell_two_title' ] ) ) {
$cell_two_title = $instance[ 'cell_two_title' ];
}
else {
$cell_two_title = __( '', 'gl_pricing_table_box_widget_domain' );
}

if ( isset( $instance[ 'cell_two_price' ] ) ) {
$cell_two_price = $instance[ 'cell_two_price' ];
}
else {
$cell_two_price = __( '', 'gl_pricing_table_box_widget_domain' );
}

if ( isset( $instance[ 'cell_two_duration' ] ) ) {
$cell_two_duration = $instance[ 'cell_two_duration' ];
}
else {
$cell_two_duration = __( '', 'gl_pricing_table_box_widget_domain' );
}

if ( isset( $instance[ 'pricing_two_content1' ] ) ) {
$pricing_two_content1 = $instance[ 'pricing_two_content1' ];
}
else {
$pricing_two_content1 = __( '', 'gl_pricing_table_box_widget_domain' );
}

if ( isset( $instance[ 'pricing_two_content2' ] ) ) {
$pricing_two_content2 = $instance[ 'pricing_two_content2' ];
}
else {
$pricing_two_content2 = __( '', 'gl_pricing_table_box_widget_domain' );
}

if ( isset( $instance[ 'pricing_two_content3' ] ) ) {
$pricing_two_content3 = $instance[ 'pricing_two_content3' ];
}
else {
$pricing_two_content3 = __( '', 'gl_pricing_table_box_widget_domain' );
}
if ( isset( $instance[ 'pricing_two_content4' ] ) ) {
$pricing_two_content4 = $instance[ 'pricing_two_content4' ];
}
else {
$pricing_two_content4 = __( '', 'gl_pricing_table_box_widget_domain' );
}

if ( isset( $instance[ 'pricing_two_content5' ] ) ) {
$pricing_two_content5 = $instance[ 'pricing_two_content5' ];
}
else {
$pricing_two_content5 = __( '', 'gl_pricing_table_box_widget_domain' );
}


if ( isset( $instance[ 'pricing2_read' ] ) ) {
$pricing2_read = $instance[ 'pricing2_read' ];
}
else {
$pricing2_read = __( '', 'gl_pricing_table_box_widget_domain' );
}

if ( isset( $instance[ 'pricing_two_url' ] ) ) {
$pricing_two_url = $instance[ 'pricing_two_url' ];
}
else {
$pricing_two_url = __( '', 'gl_pricing_table_box_widget_domain' );
}


//pricing three cell

if ( isset( $instance[ 'cell_three_title' ] ) ) {
$cell_three_title = $instance[ 'cell_three_title' ];
}
else {
$cell_three_title = __( '', 'gl_pricing_table_box_widget_domain' );
}

if ( isset( $instance[ 'cell_three_price' ] ) ) {
$cell_three_price = $instance[ 'cell_three_price' ];
}
else {
$cell_three_price = __( '', 'gl_pricing_table_box_widget_domain' );
}

if ( isset( $instance[ 'cell_three_duration' ] ) ) {
$cell_three_duration = $instance[ 'cell_three_duration' ];
}
else {
$cell_three_duration = __( '', 'gl_pricing_table_box_widget_domain' );
}

if ( isset( $instance[ 'pricing_three_content1' ] ) ) {
$pricing_three_content1 = $instance[ 'pricing_three_content1' ];
}
else {
$pricing_three_content1 = __( '', 'gl_pricing_table_box_widget_domain' );
}

if ( isset( $instance[ 'pricing_three_content2' ] ) ) {
$pricing_three_content2 = $instance[ 'pricing_three_content2' ];
}
else {
$pricing_three_content2 = __( '', 'gl_pricing_table_box_widget_domain' );
}

if ( isset( $instance[ 'pricing_three_content3' ] ) ) {
$pricing_three_content3 = $instance[ 'pricing_three_content3' ];
}
else {
$pricing_three_content3 = __( '', 'gl_pricing_table_box_widget_domain' );
}
if ( isset( $instance[ 'pricing_three_content4' ] ) ) {
$pricing_three_content4 = $instance[ 'pricing_three_content4' ];
}
else {
$pricing_three_content4 = __( '', 'gl_pricing_table_box_widget_domain' );
}

if ( isset( $instance[ 'pricing_three_content5' ] ) ) {
$pricing_three_content5 = $instance[ 'pricing_three_content5' ];
}
else {
$pricing_three_content5 = __( '', 'gl_pricing_table_box_widget_domain' );
}


if ( isset( $instance[ 'pricing3_read' ] ) ) {
$pricing3_read = $instance[ 'pricing3_read' ];
}
else {
$pricing3_read = __( '', 'gl_pricing_table_box_widget_domain' );
}

if ( isset( $instance[ 'pricing_three_url' ] ) ) {
$pricing_three_url = $instance[ 'pricing_three_url' ];
}
else {
$pricing_three_url = __( '', 'gl_pricing_table_box_widget_domain' );
}
?>

<p>
<label for="<?php echo $this->get_field_id( 'price_header_txt' ); ?>"><?php _e( 'Header Text:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'price_header_txt' ); ?>" name="<?php echo $this->get_field_name( 'price_header_txt' ); ?>" type="text" value="<?php echo esc_attr( $price_header_txt ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'cell_one_title' ); ?>"><?php _e( 'Column1 Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'cell_one_title' ); ?>" name="<?php echo $this->get_field_name( 'cell_one_title' ); ?>" type="text" value="<?php echo esc_attr( $cell_one_title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'cell_one_price' ); ?>"><?php _e( 'Column1 Price:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'cell_one_price' ); ?>" name="<?php echo $this->get_field_name( 'cell_one_price' ); ?>" type="text" value="<?php echo esc_attr( $cell_one_price ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'cell_one_duration' ); ?>"><?php _e( 'Column1 Duration:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'cell_one_duration' ); ?>" name="<?php echo $this->get_field_name( 'cell_one_duration' ); ?>" type="text" value="<?php echo esc_attr( $cell_one_duration ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'pricing_one_content1' ); ?>"><?php _e( 'Column1 List1 :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'pricing_one_content1' ); ?>" name="<?php echo $this->get_field_name( 'pricing_one_content1' ); ?>" type="text" value="<?php echo esc_attr( $pricing_one_content1 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'pricing_one_content2' ); ?>"><?php _e( 'Column1 List2 :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'pricing_one_content2' ); ?>" name="<?php echo $this->get_field_name( 'pricing_one_content2' ); ?>" type="text" value="<?php echo esc_attr( $pricing_one_content2 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'pricing_one_content3' ); ?>"><?php _e( 'Column1 List3 :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'pricing_one_content3' ); ?>" name="<?php echo $this->get_field_name( 'pricing_one_content3' ); ?>" type="text" value="<?php echo esc_attr( $pricing_one_content3 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'pricing_one_content4' ); ?>"><?php _e( 'Column1 List4 :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'pricing_one_content4' ); ?>" name="<?php echo $this->get_field_name( 'pricing_one_content4' ); ?>" type="text" value="<?php echo esc_attr( $pricing_one_content4 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'pricing_one_content5' ); ?>"><?php _e( 'Column1 List5 :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'pricing_one_content5' ); ?>" name="<?php echo $this->get_field_name( 'pricing_one_content5' ); ?>" type="text" value="<?php echo esc_attr( $pricing_one_content5 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'pricing1_read' ); ?>"><?php _e( 'Column1 Readmore Text :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'pricing1_read' ); ?>" name="<?php echo $this->get_field_name( 'pricing1_read' ); ?>" type="text" value="<?php echo esc_attr( $pricing1_read ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'pricing_one_url' ); ?>"><?php _e( 'Column1 Readmore URL Link :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'pricing_one_url' ); ?>" name="<?php echo $this->get_field_name( 'pricing_one_url' ); ?>" type="text" value="<?php echo esc_attr( $pricing_one_url ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'cell_two_title' ); ?>"><?php _e( 'Column2 Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'cell_two_title' ); ?>" name="<?php echo $this->get_field_name( 'cell_two_title' ); ?>" type="text" value="<?php echo esc_attr( $cell_two_title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'cell_two_price' ); ?>"><?php _e( 'Column2 Price:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'cell_two_price' ); ?>" name="<?php echo $this->get_field_name( 'cell_two_price' ); ?>" type="text" value="<?php echo esc_attr( $cell_two_price ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'cell_two_duration' ); ?>"><?php _e( 'Column2 Duration:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'cell_two_duration' ); ?>" name="<?php echo $this->get_field_name( 'cell_two_duration' ); ?>" type="text" value="<?php echo esc_attr( $cell_two_duration ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'pricing_two_content1' ); ?>"><?php _e( 'Column2 List1 :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'pricing_two_content1' ); ?>" name="<?php echo $this->get_field_name( 'pricing_two_content1' ); ?>" type="text" value="<?php echo esc_attr( $pricing_two_content1 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'pricing_two_content2' ); ?>"><?php _e( 'Column2 List2 :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'pricing_two_content2' ); ?>" name="<?php echo $this->get_field_name( 'pricing_two_content2' ); ?>" type="text" value="<?php echo esc_attr( $pricing_two_content2 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'pricing_two_content3' ); ?>"><?php _e( 'Column2 List3 :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'pricing_two_content3' ); ?>" name="<?php echo $this->get_field_name( 'pricing_two_content3' ); ?>" type="text" value="<?php echo esc_attr( $pricing_two_content3 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'pricing_two_content4' ); ?>"><?php _e( 'Column2 List4 :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'pricing_two_content4' ); ?>" name="<?php echo $this->get_field_name( 'pricing_two_content4' ); ?>" type="text" value="<?php echo esc_attr( $pricing_two_content4 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'pricing_two_content5' ); ?>"><?php _e( 'Column2 List5 :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'pricing_two_content5' ); ?>" name="<?php echo $this->get_field_name( 'pricing_two_content5' ); ?>" type="text" value="<?php echo esc_attr( $pricing_two_content5 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'pricing2_read' ); ?>"><?php _e( 'Column2 Readmore Text :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'pricing2_read' ); ?>" name="<?php echo $this->get_field_name( 'pricing2_read' ); ?>" type="text" value="<?php echo esc_attr( $pricing2_read ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'pricing_two_url' ); ?>"><?php _e( 'Column2 Readmore URL Link :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'pricing_two_url' ); ?>" name="<?php echo $this->get_field_name( 'pricing_two_url' ); ?>" type="text" value="<?php echo esc_attr( $pricing_two_url ); ?>" />
</p>


<p>
<label for="<?php echo $this->get_field_id( 'cell_three_title' ); ?>"><?php _e( 'Column3 Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'cell_three_title' ); ?>" name="<?php echo $this->get_field_name( 'cell_three_title' ); ?>" type="text" value="<?php echo esc_attr( $cell_three_title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'cell_three_price' ); ?>"><?php _e( 'Column3 Price:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'cell_three_price' ); ?>" name="<?php echo $this->get_field_name( 'cell_three_price' ); ?>" type="text" value="<?php echo esc_attr( $cell_three_price ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'cell_three_duration' ); ?>"><?php _e( 'Column3 Duration:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'cell_three_duration' ); ?>" name="<?php echo $this->get_field_name( 'cell_three_duration' ); ?>" type="text" value="<?php echo esc_attr( $cell_three_duration ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'pricing_three_content1' ); ?>"><?php _e( 'Column3 List1 :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'pricing_three_content1' ); ?>" name="<?php echo $this->get_field_name( 'pricing_three_content1' ); ?>" type="text" value="<?php echo esc_attr( $pricing_three_content1 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'pricing_three_content2' ); ?>"><?php _e( 'Column3 List2 :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'pricing_three_content2' ); ?>" name="<?php echo $this->get_field_name( 'pricing_three_content2' ); ?>" type="text" value="<?php echo esc_attr( $pricing_three_content2 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'pricing_three_content3' ); ?>"><?php _e( 'Column3 List3 :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'pricing_three_content3' ); ?>" name="<?php echo $this->get_field_name( 'pricing_three_content3' ); ?>" type="text" value="<?php echo esc_attr( $pricing_three_content3 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'pricing_three_content4' ); ?>"><?php _e( 'Column3 List4 :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'pricing_three_content4' ); ?>" name="<?php echo $this->get_field_name( 'pricing_three_content4' ); ?>" type="text" value="<?php echo esc_attr( $pricing_three_content4 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'pricing_three_content5' ); ?>"><?php _e( 'Column3 List5 :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'pricing_three_content5' ); ?>" name="<?php echo $this->get_field_name( 'pricing_three_content5' ); ?>" type="text" value="<?php echo esc_attr( $pricing_three_content5 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'pricing3_read' ); ?>"><?php _e( 'Column3 Readmore Text :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'pricing3_read' ); ?>" name="<?php echo $this->get_field_name( 'pricing3_read' ); ?>" type="text" value="<?php echo esc_attr( $pricing3_read ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'pricing_three_url' ); ?>"><?php _e( 'Column3 Readmore URL Link :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'pricing_three_url' ); ?>" name="<?php echo $this->get_field_name( 'pricing_three_url' ); ?>" type="text" value="<?php echo esc_attr( $pricing_three_url ); ?>" />
</p>

<?php 
}


public function update( $new_instance, $old_instance ) {
$instance = array();

$instance['price_header_txt'] = ( ! empty( $new_instance['price_header_txt'] ) ) ? strip_tags( $new_instance['price_header_txt'] ) : '';

$instance['cell_one_title'] = ( ! empty( $new_instance['cell_one_title'] ) ) ? strip_tags( $new_instance['cell_one_title'] ) : '';
$instance['cell_one_price'] = ( ! empty( $new_instance['cell_one_price'] ) ) ? strip_tags( $new_instance['cell_one_price'] ) : '';
$instance['cell_one_duration'] = ( ! empty( $new_instance['cell_one_duration'] ) ) ? strip_tags( $new_instance['cell_one_duration'] ) : '';
$instance['pricing_one_content1'] = ( ! empty( $new_instance['pricing_one_content1'] ) ) ? strip_tags( $new_instance['pricing_one_content1'] ) : '';
$instance['pricing_one_content2'] = ( ! empty( $new_instance['pricing_one_content2'] ) ) ? strip_tags( $new_instance['pricing_one_content2'] ) : '';
$instance['pricing_one_content3'] = ( ! empty( $new_instance['pricing_one_content3'] ) ) ? strip_tags( $new_instance['pricing_one_content3'] ) : '';
$instance['pricing_one_content4'] = ( ! empty( $new_instance['pricing_one_content4'] ) ) ? strip_tags( $new_instance['pricing_one_content4'] ) : '';
$instance['pricing_one_content5'] = ( ! empty( $new_instance['pricing_one_content5'] ) ) ? strip_tags( $new_instance['pricing_one_content5'] ) : '';
$instance['pricing1_read'] = ( ! empty( $new_instance['pricing1_read'] ) ) ? strip_tags( $new_instance['pricing1_read'] ) : '';
$instance['pricing_one_url'] = ( ! empty( $new_instance['pricing_one_url'] ) ) ? strip_tags( $new_instance['pricing_one_url'] ) : '';


$instance['cell_two_title'] = ( ! empty( $new_instance['cell_two_title'] ) ) ? strip_tags( $new_instance['cell_two_title'] ) : '';
$instance['cell_two_price'] = ( ! empty( $new_instance['cell_two_price'] ) ) ? strip_tags( $new_instance['cell_two_price'] ) : '';
$instance['cell_two_duration'] = ( ! empty( $new_instance['cell_two_duration'] ) ) ? strip_tags( $new_instance['cell_two_duration'] ) : '';
$instance['pricing_two_content1'] = ( ! empty( $new_instance['pricing_two_content1'] ) ) ? strip_tags( $new_instance['pricing_two_content1'] ) : '';
$instance['pricing_two_content2'] = ( ! empty( $new_instance['pricing_two_content2'] ) ) ? strip_tags( $new_instance['pricing_two_content2'] ) : '';
$instance['pricing_two_content3'] = ( ! empty( $new_instance['pricing_two_content3'] ) ) ? strip_tags( $new_instance['pricing_two_content3'] ) : '';
$instance['pricing_two_content4'] = ( ! empty( $new_instance['pricing_two_content4'] ) ) ? strip_tags( $new_instance['pricing_two_content4'] ) : '';
$instance['pricing_two_content5'] = ( ! empty( $new_instance['pricing_two_content5'] ) ) ? strip_tags( $new_instance['pricing_two_content5'] ) : '';
$instance['pricing2_read'] = ( ! empty( $new_instance['pricing2_read'] ) ) ? strip_tags( $new_instance['pricing2_read'] ) : '';
$instance['pricing_two_url'] = ( ! empty( $new_instance['pricing_two_url'] ) ) ? strip_tags( $new_instance['pricing_two_url'] ) : '';



$instance['cell_three_title'] = ( ! empty( $new_instance['cell_three_title'] ) ) ? strip_tags( $new_instance['cell_three_title'] ) : '';
$instance['cell_three_price'] = ( ! empty( $new_instance['cell_three_price'] ) ) ? strip_tags( $new_instance['cell_three_price'] ) : '';
$instance['cell_three_duration'] = ( ! empty( $new_instance['cell_three_duration'] ) ) ? strip_tags( $new_instance['cell_three_duration'] ) : '';
$instance['pricing_three_content1'] = ( ! empty( $new_instance['pricing_three_content1'] ) ) ? strip_tags( $new_instance['pricing_three_content1'] ) : '';
$instance['pricing_three_content2'] = ( ! empty( $new_instance['pricing_three_content2'] ) ) ? strip_tags( $new_instance['pricing_three_content2'] ) : '';
$instance['pricing_three_content3'] = ( ! empty( $new_instance['pricing_three_content3'] ) ) ? strip_tags( $new_instance['pricing_three_content3'] ) : '';
$instance['pricing_three_content4'] = ( ! empty( $new_instance['pricing_three_content4'] ) ) ? strip_tags( $new_instance['pricing_three_content4'] ) : '';
$instance['pricing_three_content5'] = ( ! empty( $new_instance['pricing_three_content5'] ) ) ? strip_tags( $new_instance['pricing_three_content5'] ) : '';
$instance['pricing3_read'] = ( ! empty( $new_instance['pricing3_read'] ) ) ? strip_tags( $new_instance['pricing3_read'] ) : '';
$instance['pricing_three_url'] = ( ! empty( $new_instance['pricing_three_url'] ) ) ? strip_tags( $new_instance['pricing_three_url'] ) : '';

 
return $instance;
}
}

//Front Pricing Table Widget Ends here


//Front Call to action box Widget starts here

class gl_call_to_action_box_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_call_to_action_box_widget', 

__('Premium - Call To Action Box ', 'gl_call_to_action_box_widget_domain'), 

array( 'description' => __( 'Displays Call To Action Box Content', 'gl_call_to_action_box_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$call_header_txt = apply_filters( 'call_header_txt', $instance['call_header_txt'] );
$call_header_para = apply_filters( 'call_header_para', $instance['call_header_para'] );
$call_view_more = apply_filters( 'call_view_more', $instance['call_view_more'] );
$call_action_url = apply_filters( 'call_action_url', $instance['call_action_url'] );


echo $args['before_widget'];
if ( ! empty( $title ) )
//echo $args['before_title'] . $title . $args['after_title'];


?>

<div class='call_to_action_content'>
<div class='inner_call_to_action wrap'>
<div class='callto_section'>
<div class='callto_section_title_para'>
<h3><?php echo $instance['call_header_txt']; ?></h3>
<p><?php echo $instance['call_header_para']; ?></p>
</div>
<a class ='call_read' href='<?php echo $instance['call_action_url']; ?>'><?php echo $instance['call_view_more']; ?></a>

</div>


</div>
</div>

<?php
echo $args['after_widget'];
}


	
public function form( $instance ) {

if ( isset( $instance[ 'call_header_txt' ] ) ) {
$call_header_txt = $instance[ 'call_header_txt' ];
}
else {
$call_header_txt = __( '', 'gl_call_to_action_box_widget_domain' );
}

if ( isset( $instance[ 'call_header_para' ] ) ) {
$call_header_para = $instance[ 'call_header_para' ];
}
else {
$call_header_para = __( '', 'gl_call_to_action_box_widget_domain' );
}

if ( isset( $instance[ 'call_view_more' ] ) ) {
$call_view_more = $instance[ 'call_view_more' ];
}
else {
$call_view_more = __( '', 'gl_call_to_action_box_widget_domain' );
}

if ( isset( $instance[ 'call_action_url' ] ) ) {
$call_action_url = $instance[ 'call_action_url' ];
}
else {
$call_action_url = __( '', 'gl_call_to_action_box_widget_domain' );
}

?>


<p>
<label for="<?php echo $this->get_field_id( 'call_header_txt' ); ?>"><?php _e( 'Header Text:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'call_header_txt' ); ?>" name="<?php echo $this->get_field_name( 'call_header_txt' ); ?>" type="text" value="<?php echo esc_attr( $call_header_txt ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'call_header_para' ); ?>"><?php _e( 'Para text:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'call_header_para' ); ?>" name="<?php echo $this->get_field_name( 'call_header_para' ); ?>" type="text" value="<?php echo esc_attr( $call_header_para ); ?>" />
</p>


<p>
<label for="<?php echo $this->get_field_id( 'call_view_more' ); ?>"><?php _e( 'View More Text:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'call_view_more' ); ?>" name="<?php echo $this->get_field_name( 'call_view_more' ); ?>" type="text" value="<?php echo esc_attr( $call_view_more ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'call_action_url' ); ?>"><?php _e( 'View More URL Link:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'call_action_url' ); ?>" name="<?php echo $this->get_field_name( 'call_action_url' ); ?>" type="text" value="<?php echo esc_attr( $call_action_url ); ?>" />
</p>


<?php 
}


public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['call_header_txt'] = ( ! empty( $new_instance['call_header_txt'] ) ) ? strip_tags( $new_instance['call_header_txt'] ) : '';
$instance['call_header_para'] = ( ! empty( $new_instance['call_header_para'] ) ) ? strip_tags( $new_instance['call_header_para'] ) : '';
$instance['call_view_more'] = ( ! empty( $new_instance['call_view_more'] ) ) ? strip_tags( $new_instance['call_view_more'] ) : '';
$instance['call_action_url'] = ( ! empty( $new_instance['call_action_url'] ) ) ? strip_tags( $new_instance['call_action_url'] ) : '';

return $instance;
}
}

//Front Call to action box Widget Ends here

//Front Testimonial box Widget starts here

class gl_testimonial_box_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_testimonial_box_widget', 

__('Premium - Testimonial Box ', 'gl_testimonial_box_widget_domain'), 

array( 'description' => __( 'Displays Testimonial Box Content', 'gl_testimonial_box_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$testimonial_title = apply_filters( 'testimonial_title', $instance['testimonial_title'] );
$test_content_bg = apply_filters( 'test_content_bg', $instance['test_content_bg'] );


echo $args['before_widget'];
if ( ! empty( $title ) )
//echo $args['before_title'] . $title . $args['after_title'];


?>
<div class='testimonial_box' style='background-image:url(<?php echo $instance['test_content_bg'];?> )'>
<div class='testimonial_box_color'>
<div class='inner_testimonial_box wrap'>
<div class='title'><h3 class='center_header'><?php echo $instance['testimonial_title']; ?></h3></div>
<div class="b_testimonial">
<div class="studies">
<div class="wmuSlider example1 section" id="section-1">
<?php
global $post;
$portfolio_category = get_post_meta($post->ID, 'testimonial_category', true);
$paged = get_query_var('paged') ? get_query_var('paged') : 1;
$args = array('post_type' => 'testimonial', 'showposts' => 3, 'paged' => $paged, 'testimonial-category' => $portfolio_category);
$query_args = wp_parse_args($cf, $args);
$wp_query = new WP_Query($query_args);
$loop_counter = 0;
if ( $wp_query->have_posts() ) : while ( $wp_query->have_posts() ) : $wp_query->the_post(); /* Start Posts */
?>
<article style="position: absolute; width: 100%; opacity: 0;"> 
<div class="man">
<?php the_post_thumbnail('Testimonial [small]'); ?>
<h4><a href=" <?php echo the_permalink(); ?>"><?php echo the_title(); ?></a></h4>
</div>
<div class="data">
<p>
<?php $excerpt=get_the_excerpt();
echo string_limit_words($excerpt,45); 
?>
</p>
</div>
<div class="clearfix"></div>
</article>
<?php
$loop_counter++;
endwhile; /** end of one post **/ else : /** if no posts exist **/ endif; /** end loop **/
wp_reset_query();
?>
<ul class="wmuSliderPagination">
<li><a href="#" class="">0</a></li>
<li><a href="#" class="">1</a></li>
<li><a href="#" class="">2</a></li>
</ul>
</div>
</div>
</div>
</div>
</div>
</div>

<?php
echo $args['after_widget'];
}


	
public function form( $instance ) {

if ( isset( $instance[ 'testimonial_title' ] ) ) {
$testimonial_title = $instance[ 'testimonial_title' ];
}
else {
$testimonial_title = __( '', 'gl_testimonial_box_widget_domain' );
}

if ( isset( $instance[ 'test_content_bg' ] ) ) {
$test_content_bg = $instance[ 'test_content_bg' ];
}
else {
$test_content_bg = __( '', 'gl_testimonial_box_widget_domain' );
}

?>


<p>
<label for="<?php echo $this->get_field_id( 'testimonial_title' ); ?>"><?php _e( 'Header Text:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'testimonial_title' ); ?>" name="<?php echo $this->get_field_name( 'testimonial_title' ); ?>" type="text" value="<?php echo esc_attr( $testimonial_title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'test_content_bg' ); ?>"><?php _e( 'Background Image url:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'test_content_bg' ); ?>" name="<?php echo $this->get_field_name( 'test_content_bg' ); ?>" type="text" value="<?php echo esc_attr( $test_content_bg ); ?>" />
</p>



<?php 
}


public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['testimonial_title'] = ( ! empty( $new_instance['testimonial_title'] ) ) ? strip_tags( $new_instance['testimonial_title'] ) : '';
$instance['test_content_bg'] = ( ! empty( $new_instance['test_content_bg'] ) ) ? strip_tags( $new_instance['test_content_bg'] ) : '';

return $instance;
}
}

//Front Testimonial box Widget Ends here



//Front clients box Widget starts here

class gl_clients_box_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_clients_box_widget', 

__('Premium - Our Clients Box ', 'gl_clients_box_widget_domain'), 

array( 'description' => __( 'Displays Our Clients Box Content', 'gl_clients_box_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$client_header_txt = apply_filters( 'client_header_txt', $instance['client_header_txt'] );

$client1_img = apply_filters( 'client1_img', $instance['client1_img'] );
$client1_title = apply_filters( 'client1_title', $instance['client1_title'] );
$client1_url_link = apply_filters( 'client1_url_link', $instance['client1_url_link'] );

$client2_img = apply_filters( 'client2_img', $instance['client2_img'] );
$client2_title = apply_filters( 'client2_title', $instance['client2_title'] );
$client2_url_link = apply_filters( 'client2_url_link', $instance['client2_url_link'] );

$client3_img = apply_filters( 'client3_img', $instance['client3_img'] );
$client3_title = apply_filters( 'client3_title', $instance['client3_title'] );
$client3_url_link = apply_filters( 'client3_url_link', $instance['client3_url_link'] );

$client4_img = apply_filters( 'client4_img', $instance['client4_img'] );
$client4_title = apply_filters( 'client4_title', $instance['client4_title'] );
$client4_url_link = apply_filters( 'client4_url_link', $instance['client4_url_link'] );

$client5_img = apply_filters( 'client5_img', $instance['client5_img'] );
$client5_title = apply_filters( 'client5_title', $instance['client5_title'] );
$client5_url_link = apply_filters( 'client5_url_link', $instance['client5_url_link'] );

$client6_img = apply_filters( 'client6_img', $instance['client6_img'] );
$client6_title = apply_filters( 'client6_title', $instance['client6_title'] );
$client6_url_link = apply_filters( 'client6_url_link', $instance['client6_url_link'] );

$client7_img = apply_filters( 'client7_img', $instance['client7_img'] );
$client7_title = apply_filters( 'client7_title', $instance['client7_title'] );
$client7_url_link = apply_filters( 'client7_url_link', $instance['client7_url_link'] );

$client8_img = apply_filters( 'client8_img', $instance['client8_img'] );
$client8_title = apply_filters( 'client8_title', $instance['client8_title'] );
$client8_url_link = apply_filters( 'client8_url_link', $instance['client8_url_link'] );

$client9_img = apply_filters( 'client9_img', $instance['client9_img'] );
$client9_title = apply_filters( 'client9_title', $instance['client9_title'] );
$client9_url_link = apply_filters( 'client9_url_link', $instance['client9_url_link'] );

$client10_img = apply_filters( 'client10_img', $instance['client10_img'] );
$client10_title = apply_filters( 'client10_title', $instance['client10_title'] );
$client10_url_link = apply_filters( 'client10_url_link', $instance['client10_url_link'] );


echo $args['before_widget'];
if ( ! empty( $title ) )
//echo $args['before_title'] . $title . $args['after_title'];


?>
<div class='clients_box'>
<div class='inner_clients_box wrap'>
<div class='title'><h3 class='center_header'><?php echo $instance['client_header_txt']; ?></h3></div>


<div class='clients'>
<a href='<?php echo $instance['client1_url_link']; ?>'><img alt='<?php echo $instance['client1_title']; ?>' src='	<?php echo $instance['client1_img']; ?>'/></a>
</div>
<div class='clients'>
<a href='<?php echo $instance['client2_url_link']; ?>'><img alt='<?php echo $instance['client2_title']; ?>' src='<?php echo $instance['client2_img']; ?>'/></a>
</div>
<div class='clients'>
<a href='<?php echo $instance['client3_url_link']; ?>'><img alt='<?php echo $instance['client3_title']; ?>' src='<?php echo $instance['client3_img']; ?>'/></a>
</div>
<div class='clients'>
<a href='<?php echo $instance['client4_url_link']; ?>'><img alt='<?php echo $instance['client4_title']; ?>' src='<?php echo $instance['client4_img']; ?>'/></a>
</div>
<div class='clients last'>
<a href='<?php echo $instance['client5_url_link']; ?>'><img alt='<?php echo $instance['client5_title']; ?>' src='<?php echo $instance['client5_img']; ?>'/></a>
</div>
<div class='clients'>
<a href='<?php echo $instance['client6_url_link']; ?>'><img alt='<?php echo $instance['client6_title']; ?>' src='<?php echo $instance['client6_img']; ?>'/></a>
</div>
<div class='clients'>
<a href='<?php echo $instance['client7_url_link']; ?>'><img alt='<?php echo $instance['client7_title']; ?>' src='<?php echo $instance['client7_img']; ?>'/></a>
</div>
<div class='clients'>
<a href='<?php echo $instance['client8_url_link']; ?>'><img alt='<?php echo $instance['client8_title']; ?>' src='<?php echo $instance['client8_img']; ?>'/></a>
</div>
<div class='clients'>
<a href='<?php echo $instance['client9_url_link']; ?>'><img alt='<?php echo $instance['client9_title']; ?>' src='<?php echo $instance['client9_img']; ?>'/></a>
</div>
<div class='clients last'>
<a href='<?php echo $instance['client10_url_link'];?>'><img alt='<?php echo $instance['client10_title'];?>' src='<?php echo $instance['client10_img']; ?>'/></a>
</div>

</div>
</div>

<?php
echo $args['after_widget'];
}

	
public function form( $instance ) {

if ( isset( $instance[ 'client_header_txt' ] ) ) {
$client_header_txt = $instance[ 'client_header_txt' ];
}
else {
$client_header_txt = __( '', 'gl_clients_box_widget_domain' );
}


if ( isset( $instance[ 'client1_img' ] ) ) {
$client1_img = $instance[ 'client1_img' ];
}
else {
$client1_img = __( '', 'gl_clients_box_widget_domain' );
}

if ( isset( $instance[ 'client1_title' ] ) ) {
$client1_title = $instance[ 'client1_title' ];
}
else {
$client1_title = __( '', 'gl_clients_box_widget_domain' );
}


if ( isset( $instance[ 'client1_url_link' ] ) ) {
$client1_url_link = $instance[ 'client1_url_link' ];
}
else {
$client1_url_link = __( '', 'gl_clients_box_widget_domain' );
}


if ( isset( $instance[ 'client2_img' ] ) ) {
$client2_img = $instance[ 'client2_img' ];
}
else {
$client2_img = __( '', 'gl_clients_box_widget_domain' );
}

if ( isset( $instance[ 'client2_title' ] ) ) {
$client2_title = $instance[ 'client2_title' ];
}
else {
$client2_title = __( '', 'gl_clients_box_widget_domain' );
}


if ( isset( $instance[ 'client2_url_link' ] ) ) {
$client2_url_link = $instance[ 'client2_url_link' ];
}
else {
$client2_url_link = __( '', 'gl_clients_box_widget_domain' );
}


if ( isset( $instance[ 'client3_img' ] ) ) {
$client3_img = $instance[ 'client3_img' ];
}
else {
$client3_img = __( '', 'gl_clients_box_widget_domain' );
}

if ( isset( $instance[ 'client3_title' ] ) ) {
$client3_title = $instance[ 'client3_title' ];
}
else {
$client3_title = __( '', 'gl_clients_box_widget_domain' );
}


if ( isset( $instance[ 'client3_url_link' ] ) ) {
$client3_url_link = $instance[ 'client3_url_link' ];
}
else {
$client3_url_link = __( '', 'gl_clients_box_widget_domain' );
}


if ( isset( $instance[ 'client4_img' ] ) ) {
$client4_img = $instance[ 'client4_img' ];
}
else {
$client4_img = __( '', 'gl_clients_box_widget_domain' );
}

if ( isset( $instance[ 'client4_title' ] ) ) {
$client4_title = $instance[ 'client4_title' ];
}
else {
$client4_title = __( '', 'gl_clients_box_widget_domain' );
}


if ( isset( $instance[ 'client4_url_link' ] ) ) {
$client4_url_link = $instance[ 'client4_url_link' ];
}
else {
$client4_url_link = __( '', 'gl_clients_box_widget_domain' );
}


if ( isset( $instance[ 'client5_img' ] ) ) {
$client5_img = $instance[ 'client5_img' ];
}
else {
$client5_img = __( '', 'gl_clients_box_widget_domain' );
}

if ( isset( $instance[ 'client5_title' ] ) ) {
$client5_title = $instance[ 'client5_title' ];
}
else {
$client5_title = __( '', 'gl_clients_box_widget_domain' );
}


if ( isset( $instance[ 'client5_url_link' ] ) ) {
$client5_url_link = $instance[ 'client5_url_link' ];
}
else {
$client5_url_link = __( '', 'gl_clients_box_widget_domain' );
}


if ( isset( $instance[ 'client6_img' ] ) ) {
$client6_img = $instance[ 'client6_img' ];
}
else {
$client6_img = __( '', 'gl_clients_box_widget_domain' );
}

if ( isset( $instance[ 'client6_title' ] ) ) {
$client6_title = $instance[ 'client6_title' ];
}
else {
$client6_title = __( '', 'gl_clients_box_widget_domain' );
}


if ( isset( $instance[ 'client6_url_link' ] ) ) {
$client6_url_link = $instance[ 'client6_url_link' ];
}
else {
$client6_url_link = __( '', 'gl_clients_box_widget_domain' );
}


if ( isset( $instance[ 'client7_img' ] ) ) {
$client7_img = $instance[ 'client7_img' ];
}
else {
$client7_img = __( '', 'gl_clients_box_widget_domain' );
}

if ( isset( $instance[ 'client7_title' ] ) ) {
$client7_title = $instance[ 'client7_title' ];
}
else {
$client7_title = __( '', 'gl_clients_box_widget_domain' );
}


if ( isset( $instance[ 'client7_url_link' ] ) ) {
$client7_url_link = $instance[ 'client7_url_link' ];
}
else {
$client7_url_link = __( '', 'gl_clients_box_widget_domain' );
}



if ( isset( $instance[ 'client8_img' ] ) ) {
$client8_img = $instance[ 'client8_img' ];
}
else {
$client8_img = __( '', 'gl_clients_box_widget_domain' );
}

if ( isset( $instance[ 'client8_title' ] ) ) {
$client8_title = $instance[ 'client8_title' ];
}
else {
$client8_title = __( '', 'gl_clients_box_widget_domain' );
}


if ( isset( $instance[ 'client8_url_link' ] ) ) {
$client8_url_link = $instance[ 'client8_url_link' ];
}
else {
$client8_url_link = __( '', 'gl_clients_box_widget_domain' );
}


if ( isset( $instance[ 'client9_img' ] ) ) {
$client9_img = $instance[ 'client9_img' ];
}
else {
$client9_img = __( '', 'gl_clients_box_widget_domain' );
}

if ( isset( $instance[ 'client9_title' ] ) ) {
$client9_title = $instance[ 'client9_title' ];
}
else {
$client9_title = __( '', 'gl_clients_box_widget_domain' );
}


if ( isset( $instance[ 'client9_url_link' ] ) ) {
$client9_url_link = $instance[ 'client9_url_link' ];
}
else {
$client9_url_link = __( '', 'gl_clients_box_widget_domain' );
}



if ( isset( $instance[ 'client10_img' ] ) ) {
$client10_img = $instance[ 'client10_img' ];
}
else {
$client10_img = __( '', 'gl_clients_box_widget_domain' );
}

if ( isset( $instance[ 'client10_title' ] ) ) {
$client10_title = $instance[ 'client10_title' ];
}
else {
$client10_title = __( '', 'gl_clients_box_widget_domain' );
}


if ( isset( $instance[ 'client10_url_link' ] ) ) {
$client10_url_link = $instance[ 'client10_url_link' ];
}
else {
$client10_url_link = __( '', 'gl_clients_box_widget_domain' );
}
?>

<p>
<label for="<?php echo $this->get_field_id( 'client_header_txt' ); ?>"><?php _e( 'Header Text:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'client_header_txt' ); ?>" name="<?php echo $this->get_field_name( 'client_header_txt' ); ?>" type="text" value="<?php echo esc_attr( $client_header_txt ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'client1_img' ); ?>"><?php _e( 'Client1 Image url:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'client1_img' ); ?>" name="<?php echo $this->get_field_name( 'client1_img' ); ?>" type="text" value="<?php echo esc_attr( $client1_img ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'client1_title' ); ?>"><?php _e( 'Client1 Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'client1_title' ); ?>" name="<?php echo $this->get_field_name( 'client1_title' ); ?>" type="text" value="<?php echo esc_attr( $client1_title ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'client1_url_link' ); ?>"><?php _e( 'Client1 Read more URL :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'client1_url_link' ); ?>" name="<?php echo $this->get_field_name( 'client1_url_link' ); ?>" type="text" value="<?php echo esc_attr( $client1_url_link ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'client2_img' ); ?>"><?php _e( 'Client2 Image url:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'client2_img' ); ?>" name="<?php echo $this->get_field_name( 'client2_img' ); ?>" type="text" value="<?php echo esc_attr( $client2_img ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'client2_title' ); ?>"><?php _e( 'Client2 Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'client2_title' ); ?>" name="<?php echo $this->get_field_name( 'client2_title' ); ?>" type="text" value="<?php echo esc_attr( $client2_title ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'client2_url_link' ); ?>"><?php _e( 'Client2 Read more URL :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'client2_url_link' ); ?>" name="<?php echo $this->get_field_name( 'client2_url_link' ); ?>" type="text" value="<?php echo esc_attr( $client2_url_link ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'client3_img' ); ?>"><?php _e( 'Client3 Image url:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'client3_img' ); ?>" name="<?php echo $this->get_field_name( 'client3_img' ); ?>" type="text" value="<?php echo esc_attr( $client3_img ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'client3_title' ); ?>"><?php _e( 'Client3 Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'client3_title' ); ?>" name="<?php echo $this->get_field_name( 'client3_title' ); ?>" type="text" value="<?php echo esc_attr( $client3_title ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'client3_url_link' ); ?>"><?php _e( 'Client3 Read more URL :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'client3_url_link' ); ?>" name="<?php echo $this->get_field_name( 'client3_url_link' ); ?>" type="text" value="<?php echo esc_attr( $client3_url_link ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'client4_img' ); ?>"><?php _e( 'Client4 Image url:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'client4_img' ); ?>" name="<?php echo $this->get_field_name( 'client4_img' ); ?>" type="text" value="<?php echo esc_attr( $client4_img ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'client4_title' ); ?>"><?php _e( 'Client4 Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'client4_title' ); ?>" name="<?php echo $this->get_field_name( 'client4_title' ); ?>" type="text" value="<?php echo esc_attr( $client4_title ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'client5_url_link' ); ?>"><?php _e( 'Client4 Read More URL :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'client5_url_link' ); ?>" name="<?php echo $this->get_field_name( 'client5_url_link' ); ?>" type="text" value="<?php echo esc_attr( $client5_url_link ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'client5_img' ); ?>"><?php _e( 'Client5 Image url:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'client5_img' ); ?>" name="<?php echo $this->get_field_name( 'client5_img' ); ?>" type="text" value="<?php echo esc_attr( $client5_img ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'client5_title' ); ?>"><?php _e( 'Client5 Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'client5_title' ); ?>" name="<?php echo $this->get_field_name( 'client5_title' ); ?>" type="text" value="<?php echo esc_attr( $client5_title ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'client5_url_link' ); ?>"><?php _e( 'Client5 Read more URL :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'client5_url_link' ); ?>" name="<?php echo $this->get_field_name( 'client5_url_link' ); ?>" type="text" value="<?php echo esc_attr( $client5_url_link ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'client6_img' ); ?>"><?php _e( 'Client6 Image url:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'client6_img' ); ?>" name="<?php echo $this->get_field_name( 'client6_img' ); ?>" type="text" value="<?php echo esc_attr( $client6_img ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'client6_title' ); ?>"><?php _e( 'Client6 Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'client6_title' ); ?>" name="<?php echo $this->get_field_name( 'client6_title' ); ?>" type="text" value="<?php echo esc_attr( $client6_title ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'client6_url_link' ); ?>"><?php _e( 'Client6 Read more URL :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'client6_url_link' ); ?>" name="<?php echo $this->get_field_name( 'client6_url_link' ); ?>" type="text" value="<?php echo esc_attr( $client6_url_link ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'client7_img' ); ?>"><?php _e( 'Client7 Image url:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'client7_img' ); ?>" name="<?php echo $this->get_field_name( 'client7_img' ); ?>" type="text" value="<?php echo esc_attr( $client7_img ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'client7_title' ); ?>"><?php _e( 'Client7 Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'client7_title' ); ?>" name="<?php echo $this->get_field_name( 'client7_title' ); ?>" type="text" value="<?php echo esc_attr( $client7_title ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'client7_url_link' ); ?>"><?php _e( 'Client7 Read more URL :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'client7_url_link' ); ?>" name="<?php echo $this->get_field_name( 'client7_url_link' ); ?>" type="text" value="<?php echo esc_attr( $client7_url_link ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'client8_img' ); ?>"><?php _e( 'Client8 Image url:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'client8_img' ); ?>" name="<?php echo $this->get_field_name( 'client8_img' ); ?>" type="text" value="<?php echo esc_attr( $client8_img ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'client8_title' ); ?>"><?php _e( 'Client8 Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'client8_title' ); ?>" name="<?php echo $this->get_field_name( 'client8_title' ); ?>" type="text" value="<?php echo esc_attr( $client8_title ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'client8_url_link' ); ?>"><?php _e( 'Client8 Read more URL :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'client8_url_link' ); ?>" name="<?php echo $this->get_field_name( 'client8_url_link' ); ?>" type="text" value="<?php echo esc_attr( $client8_url_link ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'client9_img' ); ?>"><?php _e( 'Client9 Image url:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'client9_img' ); ?>" name="<?php echo $this->get_field_name( 'client9_img' ); ?>" type="text" value="<?php echo esc_attr( $client9_img ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'client9_title' ); ?>"><?php _e( 'Client9 Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'client9_title' ); ?>" name="<?php echo $this->get_field_name( 'client9_title' ); ?>" type="text" value="<?php echo esc_attr( $client9_title ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'client9_url_link' ); ?>"><?php _e( 'Client9 Read more URL :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'client9_url_link' ); ?>" name="<?php echo $this->get_field_name( 'client9_url_link' ); ?>" type="text" value="<?php echo esc_attr( $client9_url_link ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'client10_img' ); ?>"><?php _e( 'Client10 Image url:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'client10_img' ); ?>" name="<?php echo $this->get_field_name( 'client10_img' ); ?>" type="text" value="<?php echo esc_attr( $client10_img ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'client10_title' ); ?>"><?php _e( 'Client10 Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'client10_title' ); ?>" name="<?php echo $this->get_field_name( 'client10_title' ); ?>" type="text" value="<?php echo esc_attr( $client10_title ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'client10_url_link' ); ?>"><?php _e( 'Client10 Read more URL :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'client10_url_link' ); ?>" name="<?php echo $this->get_field_name( 'client10_url_link' ); ?>" type="text" value="<?php echo esc_attr( $client10_url_link ); ?>" />
</p>

<?php 
}


public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['client_header_txt'] = ( ! empty( $new_instance['client_header_txt'] ) ) ? strip_tags( $new_instance['client_header_txt'] ) : '';
$instance['client1_img'] = ( ! empty( $new_instance['client1_img'] ) ) ? strip_tags( $new_instance['client1_img'] ) : '';
$instance['client1_title'] = ( ! empty( $new_instance['client1_title'] ) ) ? strip_tags( $new_instance['client1_title'] ) : '';
$instance['client1_url_link'] = ( ! empty( $new_instance['client1_url_link'] ) ) ? strip_tags( $new_instance['client1_url_link'] ) : '';

$instance['client2_img'] = ( ! empty( $new_instance['client2_img'] ) ) ? strip_tags( $new_instance['client2_img'] ) : '';
$instance['client2_title'] = ( ! empty( $new_instance['client2_title'] ) ) ? strip_tags( $new_instance['client2_title'] ) : '';
$instance['client2_url_link'] = ( ! empty( $new_instance['client2_url_link'] ) ) ? strip_tags( $new_instance['client2_url_link'] ) : '';

$instance['client3_img'] = ( ! empty( $new_instance['client3_img'] ) ) ? strip_tags( $new_instance['client3_img'] ) : '';
$instance['client3_title'] = ( ! empty( $new_instance['client3_title'] ) ) ? strip_tags( $new_instance['client3_title'] ) : '';
$instance['client3_url_link'] = ( ! empty( $new_instance['client3_url_link'] ) ) ? strip_tags( $new_instance['client3_url_link'] ) : '';

$instance['client4_img'] = ( ! empty( $new_instance['client4_img'] ) ) ? strip_tags( $new_instance['client4_img'] ) : '';
$instance['client4_title'] = ( ! empty( $new_instance['client4_title'] ) ) ? strip_tags( $new_instance['client4_title'] ) : '';
$instance['client4_url_link'] = ( ! empty( $new_instance['client4_url_link'] ) ) ? strip_tags( $new_instance['client4_url_link'] ) : '';

$instance['client5_img'] = ( ! empty( $new_instance['client5_img'] ) ) ? strip_tags( $new_instance['client5_img'] ) : '';
$instance['client5_title'] = ( ! empty( $new_instance['client5_title'] ) ) ? strip_tags( $new_instance['client5_title'] ) : '';
$instance['client5_url_link'] = ( ! empty( $new_instance['client5_url_link'] ) ) ? strip_tags( $new_instance['client5_url_link'] ) : '';

$instance['client6_img'] = ( ! empty( $new_instance['client6_img'] ) ) ? strip_tags( $new_instance['client6_img'] ) : '';
$instance['client6_title'] = ( ! empty( $new_instance['client6_title'] ) ) ? strip_tags( $new_instance['client6_title'] ) : '';
$instance['client6_url_link'] = ( ! empty( $new_instance['client6_url_link'] ) ) ? strip_tags( $new_instance['client6_url_link'] ) : '';

$instance['client7_img'] = ( ! empty( $new_instance['client7_img'] ) ) ? strip_tags( $new_instance['client7_img'] ) : '';
$instance['client7_title'] = ( ! empty( $new_instance['client7_title'] ) ) ? strip_tags( $new_instance['client7_title'] ) : '';
$instance['client7_url_link'] = ( ! empty( $new_instance['client7_url_link'] ) ) ? strip_tags( $new_instance['client7_url_link'] ) : '';

$instance['client8_img'] = ( ! empty( $new_instance['client8_img'] ) ) ? strip_tags( $new_instance['client8_img'] ) : '';
$instance['client8_title'] = ( ! empty( $new_instance['client8_title'] ) ) ? strip_tags( $new_instance['client8_title'] ) : '';
$instance['client8_url_link'] = ( ! empty( $new_instance['client8_url_link'] ) ) ? strip_tags( $new_instance['client8_url_link'] ) : '';

$instance['client9_img'] = ( ! empty( $new_instance['client9_img'] ) ) ? strip_tags( $new_instance['client9_img'] ) : '';
$instance['client9_title'] = ( ! empty( $new_instance['client9_title'] ) ) ? strip_tags( $new_instance['client9_title'] ) : '';
$instance['client9_url_link'] = ( ! empty( $new_instance['client9_url_link'] ) ) ? strip_tags( $new_instance['client9_url_link'] ) : '';

$instance['client10_img'] = ( ! empty( $new_instance['client10_img'] ) ) ? strip_tags( $new_instance['client10_img'] ) : '';
$instance['client10_title'] = ( ! empty( $new_instance['client10_title'] ) ) ? strip_tags( $new_instance['client10_title'] ) : '';
$instance['client10_url_link'] = ( ! empty( $new_instance['client10_url_link'] ) ) ? strip_tags( $new_instance['client10_url_link'] ) : '';
return $instance;
}
}

//Front Clients  box Widget Ends here


// Team Section Widget Starts Here

class gl_team_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_team_widget', 

__('Premium - Team Section', 'gl_team_widget_domain'), 

array( 'description' => __( 'Displays Team Section', 'gl_team_widget_domain' ), $widget_ops, $control_ops ) 
);
}

public function widget( $args, $instance ) {
$team_hdr = apply_filters( 'team_hdr', $instance['team_hdr'] );

$team_img1 = apply_filters( 'team_img1', $instance['team_img1'] );
$team_name1 = apply_filters( 'team_name1', $instance['team_name1'] );
$team_profession1 = apply_filters( 'team_profession1', $instance['team_profession1'] );
$team1_para = apply_filters( 'team1_para', $instance['team1_para'] );
$f1check1 = $instance[ 'f1check1' ] ? 'true' : 'false';
$t1check1 = $instance[ 't1check1' ] ? 'true' : 'false';
$l1check1 = $instance[ 'l1check1' ] ? 'true' : 'false';
$g1check1 = $instance[ 'g1check1' ] ? 'true' : 'false';
$fb1 = apply_filters( 'fb1', $instance['fb1'] );
$twitter1 = apply_filters( 'twitter1', $instance['twitter1'] );
$linkedin1 = apply_filters( 'linkedin1', $instance['linkedin1'] );
$google1 = apply_filters( 'google1', $instance['google1'] );

$team_img2 = apply_filters( 'team_img2', $instance['team_img2'] );
$team_name2 = apply_filters( 'team_name2', $instance['team_name2'] );
$team_profession2 = apply_filters( 'team_profession2', $instance['team_profession2'] );
$team2_para = apply_filters( 'team2_para', $instance['team2_para'] );
$f2check2 = $instance[ 'f2check2' ] ? 'true' : 'false';
$t2check2 = $instance[ 't2check2' ] ? 'true' : 'false';
$l2check2 = $instance[ 'l2check2' ] ? 'true' : 'false';
$g2check2 = $instance[ 'g2check2' ] ? 'true' : 'false';
$fb2 = apply_filters( 'fb2', $instance['fb2'] );
$twitter2 = apply_filters( 'twitter2', $instance['twitter2'] );
$linkedin2 = apply_filters( 'linkedin2', $instance['linkedin2'] );
$google2 = apply_filters( 'google2', $instance['google2'] );

$team_img3 = apply_filters( 'team_img3', $instance['team_img3'] );
$team_name3 = apply_filters( 'team_name3', $instance['team_name3'] );
$team_profession3 = apply_filters( 'team_profession3', $instance['team_profession3'] );
$team3_para = apply_filters( 'team3_para', $instance['team3_para'] );
$f3check3 = $instance[ 'f3check3' ] ? 'true' : 'false';
$t3check3 = $instance[ 't3check3' ] ? 'true' : 'false';
$l3check3 = $instance[ 'l3check3' ] ? 'true' : 'false';
$g3check3 = $instance[ 'g3check3' ] ? 'true' : 'false';
$fb3 = apply_filters( 'fb3', $instance['fb3'] );
$twitter3 = apply_filters( 'twitter3', $instance['twitter3'] );
$linkedin3 = apply_filters( 'linkedin3', $instance['linkedin3'] );
$google3 = apply_filters( 'google3', $instance['google3'] );



echo $args['before_widget'];
if ( ! empty( $title ) )
/*echo $args['before_title'] . $title . $args['after_title'];*/

?>

<div class='our_team_box'>
<div class='inner_team_box wrap'>
<div class='title'><h3 class='center_header'><?php echo $instance['team_hdr']; ?></h3></div>
<div class='our_team_content'>

<div class='team_column'>
<div class='team_img'>
<a href="<?php echo $instance['team1_url_link']; ?>">
<img alt="<?php echo $instance['team_name1']; ?>" src='<?php echo $instance['team_img1']; ?>'/></a> 
<div class='image_hover'></div>
 
</div>

<div class='team_content'>
<h4><?php echo "<a href='". $instance['team1_url_link'] ."'> ". $instance['team_name1'] ."</a>";?><span><?php echo $instance['team_profession1']; ?></span></h4>
<p><?php echo $instance['team1_para']; ?></p>




<?php

echo "<div class='social_media'>";
if( 'on' == $instance[ 'f1check1' ] ) : 
echo "<div class='social_follow fbk'>
<a title='Facebook' href='". $instance['fb1'] ."' target='_blank'>
<i class='fa icon-facebook'></i>
</a>
</div>";
endif; 

if( 'on' == $instance[ 't1check1' ] ) : 
echo "<div class='social_follow twt'>
<a title='Twitter' href='". $instance['twitter1'] ."' target='_blank'>
<i class='fa icon-twitter'></i>
</a>
</div>";
endif; 

if( 'on' == $instance[ 'l1check1' ] ) : 
echo "<div class='social_follow linkdn'>
<a title='linkedin' href='". $instance['linkedin1'] ."' target='_blank'>
<i class='fa icon-linkedin'></i>
</a>
</div>";
endif; 

if( 'on' == $instance[ 'g1check1' ] ) : 
echo "<div class='social_follow google'>
<a title='Google Plus' href='". $google1 ."' target='_blank'>
<i class='fa icon-google-plus'></i>
</a>
</div>";
endif; 
echo "</div>";

?>
</div>
</div>


<div class='team_column'>


<div class='team_img'>
<a href="<?php echo $instance['team2_url_link']; ?>">
<img alt="<?php echo $instance['team_name2']; ?>" src='<?php echo $instance['team_img2']; ?>'/></a> 
<div class='image_hover'></div>
 
</div>

<div class='team_content'>
<h4><?php echo "<a href='". $instance['team2_url_link'] ."'> ". $instance['team_name2'] ."</a>";?><span><?php echo $instance['team_profession2']; ?></span></h4>
<p><?php echo $instance['team2_para']; ?></p>


<?php

echo "<div class='social_media'>";
if( 'on' == $instance[ 'f2check2' ] ) : 
echo "<div class='social_follow fbk'>
<a title='Facebook' href='". $instance['fb2'] ."' target='_blank'>
<i class='fa icon-facebook'></i>
</a>
</div>";
endif; 

if( 'on' == $instance[ 't2check2' ] ) : 
echo "<div class='social_follow twt'>
<a title='Twitter' href='". $instance['twitter2'] ."' target='_blank'>
<i class='fa icon-twitter'></i>
</a>
</div>";
endif; 

if( 'on' == $instance[ 'l2check2' ] ) : 
echo "<div class='social_follow linkdn'>
<a title='linkedin' href='". $instance['linkedin2'] ."' target='_blank'>
<i class='fa icon-linkedin'></i>
</a>
</div>";
endif; 

if( 'on' == $instance[ 'g2check2' ] ) : 
echo "<div class='social_follow google'>
<a title='Google Plus' href='". $google2 ."' target='_blank'>
<i class='fa icon-google-plus'></i>
</a>
</div>";
endif; 
echo "</div>";

?>
</div>
</div>


<div class='team_column last'>
<div class='team_img'>
<a href="<?php echo $instance['team3_url_link']; ?>">
<img alt="<?php echo $instance['team_name3']; ?>" src='<?php echo $instance['team_img3']; ?>'/></a> 
<div class='image_hover'></div>
 
</div>

<div class='team_content'>
<h4><?php echo "<a href='". $instance['team3_url_link'] ."'> ". $instance['team_name3'] ."</a>";?><span><?php echo $instance['team_profession3']; ?></span></h4>
<p><?php echo $instance['team3_para']; ?></p>

<?php

echo "<div class='social_media'>";
if( 'on' == $instance[ 'f3check3' ] ) : 
echo "<div class='social_follow fbk'>
<a title='Facebook' href='". $instance['fb3'] ."' target='_blank'>
<i class='fa icon-facebook'></i>
</a>
</div>";
endif; 

if( 'on' == $instance[ 't3check3' ] ) : 
echo "<div class='social_follow twt'>
<a title='Twitter' href='". $instance['twitter3'] ."' target='_blank'>
<i class='fa icon-twitter'></i>
</a>
</div>";
endif; 

if( 'on' == $instance[ 'l3check3' ] ) : 
echo "<div class='social_follow linkdn'>
<a title='linkedin' href='". $instance['linkedin3'] ."' target='_blank'>
<i class='fa icon-linkedin'></i>
</a>
</div>";
endif; 

if( 'on' == $instance[ 'g3check3' ] ) : 
echo "<div class='social_follow google'>
<a title='Google Plus' href='". $google3 ."' target='_blank'>
<i class='fa icon-google-plus'></i>
</a>
</div>";
endif; 
echo "</div>";

?>
</div>
</div>

</div>
</div>
</div>

<?php


echo $args['after_widget'];
}
	
public function form( $instance ) {

$defaults = array( 'f1check1' => 'off', 't1check1' => 'off', 'l1check1' => 'off', 'g1check1' => 'off', 'f2check2' => 'off', 't2check2' => 'off', 'l2check2' => 'off', 'g2check2' => 'off', 'f3check3' => 'off', 't3check3' => 'off', 'l3check3' => 'off', 'g3check3' => 'off', 'fbcheck4' => 'off', 'gpcheck4' => 'off', 'twcheck4' => 'off', 'lincheck4' => 'off' );
    $instance = wp_parse_args( ( array ) $instance, $defaults );
	
	
	
 if ( isset( $instance[ 'team_hdr' ] ) ) {
$team_hdr = $instance[ 'team_hdr' ];
}
else {
$team_hdr = __( 'Our Team', 'gl_team_widget_domain' );
}

//team1

 if ( isset( $instance[ 'team_img1' ] ) ) {
$team_img1 = $instance[ 'team_img1' ];
}
else {
$team_img1 = __( '', 'gl_team_widget_domain' );
}


if ( isset( $instance[ 'team_name1' ] ) ) {
$team_name1 = $instance[ 'team_name1' ];
}
else {
$team_name1 = __( '', 'gl_team_widget_domain' );
}


 if ( isset( $instance[ 'team_profession1' ] ) ) {
$team_profession1 = $instance[ 'team_profession1' ];
}
else {
$team_profession1 = __( '', 'gl_team_widget_domain' );
}

 
if ( isset( $instance[ 'team1_para' ] ) ) {
$team1_para = $instance[ 'team1_para' ];
}
else {
$team1_para = __( '', 'gl_team_widget_domain' );
}

if ( isset( $instance[ 'fb1' ] ) ) {
$fb1 = $instance[ 'fb1' ];
}
else {
$fb1 = __( '', 'gl_team_widget_domain' );
}

if ( isset( $instance[ 'twitter1' ] ) ) {
$twitter1 = $instance[ 'twitter1' ];
}
else {
$twitter1 = __( '', 'gl_team_widget_domain' );
}

if ( isset( $instance[ 'linkedin1' ] ) ) {
$linkedin1 = $instance[ 'linkedin1' ];
}
else {
$linkedin1 = __( '', 'gl_team_widget_domain' );
}

if ( isset( $instance[ 'google1' ] ) ) {
$google1 = $instance[ 'google1' ];
}
else {
$google1 = __( '', 'gl_team_widget_domain' );
}


//team2

 if ( isset( $instance[ 'team_img2' ] ) ) {
$team_img2 = $instance[ 'team_img2' ];
}
else {
$team_img2 = __( '', 'gl_team_widget_domain' );
}


if ( isset( $instance[ 'team_name2' ] ) ) {
$team_name2 = $instance[ 'team_name2' ];
}
else {
$team_name2 = __( '', 'gl_team_widget_domain' );
}


 if ( isset( $instance[ 'team_profession2' ] ) ) {
$team_profession2 = $instance[ 'team_profession2' ];
}
else {
$team_profession2 = __( '', 'gl_team_widget_domain' );
}

 
if ( isset( $instance[ 'team2_para' ] ) ) {
$team2_para = $instance[ 'team2_para' ];
}
else {
$team2_para = __( '', 'gl_team_widget_domain' );
}

if ( isset( $instance[ 'fb2' ] ) ) {
$fb2 = $instance[ 'fb2' ];
}
else {
$fb2 = __( '', 'gl_team_widget_domain' );
}

if ( isset( $instance[ 'twitter2' ] ) ) {
$twitter2 = $instance[ 'twitter2' ];
}
else {
$twitter2 = __( '', 'gl_team_widget_domain' );
}

if ( isset( $instance[ 'linkedin2' ] ) ) {
$linkedin2 = $instance[ 'linkedin2' ];
}
else {
$linkedin2 = __( '', 'gl_team_widget_domain' );
}

if ( isset( $instance[ 'google2' ] ) ) {
$google2 = $instance[ 'google2' ];
}
else {
$google2 = __( '', 'gl_team_widget_domain' );
}


//team3

 if ( isset( $instance[ 'team_img3' ] ) ) {
$team_img3 = $instance[ 'team_img3' ];
}
else {
$team_img3 = __( '', 'gl_team_widget_domain' );
}


if ( isset( $instance[ 'team_name3' ] ) ) {
$team_name3 = $instance[ 'team_name3' ];
}
else {
$team_name3 = __( '', 'gl_team_widget_domain' );
}


 if ( isset( $instance[ 'team_profession3' ] ) ) {
$team_profession3 = $instance[ 'team_profession3' ];
}
else {
$team_profession3 = __( '', 'gl_team_widget_domain' );
}

 
if ( isset( $instance[ 'team3_para' ] ) ) {
$team3_para = $instance[ 'team3_para' ];
}
else {
$team3_para = __( '', 'gl_team_widget_domain' );
}

if ( isset( $instance[ 'fb3' ] ) ) {
$fb3 = $instance[ 'fb3' ];
}
else {
$fb3 = __( '', 'gl_team_widget_domain' );
}

if ( isset( $instance[ 'twitter3' ] ) ) {
$twitter3 = $instance[ 'twitter3' ];
}
else {
$twitter3 = __( '', 'gl_team_widget_domain' );
}

if ( isset( $instance[ 'linkedin3' ] ) ) {
$linkedin3 = $instance[ 'linkedin3' ];
}
else {
$linkedin3 = __( '', 'gl_team_widget_domain' );
}

if ( isset( $instance[ 'google3' ] ) ) {
$google3 = $instance[ 'google3' ];
}
else {
$google3 = __( '', 'gl_team_widget_domain' );
}
?>

<p>
<label for="<?php echo $this->get_field_id( 'team_hdr' ); ?>"><?php _e( 'Team Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'team_hdr' ); ?>" name="<?php echo $this->get_field_name( 'team_hdr' ); ?>" type="text" value="<?php echo esc_attr( $team_hdr ); ?>" />
</p>


<p>
<label for="<?php echo $this->get_field_id( 'team_img1' ); ?>"><?php _e( 'Team Image1 URL Link:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'team_img1' ); ?>" name="<?php echo $this->get_field_name( 'team_img1' ); ?>" type="text" value="<?php echo esc_attr( $team_img1 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'team_name1' ); ?>"><?php _e( 'Team Name1:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'team_name1' ); ?>" name="<?php echo $this->get_field_name( 'team_name1' ); ?>" type="text" value="<?php echo esc_attr( $team_name1 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'team_profession1' ); ?>"><?php _e( 'Team Name1 Profession:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'team_profession1' ); ?>" name="<?php echo $this->get_field_name( 'team_profession1' ); ?>" type="text" value="<?php echo esc_attr( $team_profession1 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'team1_para' ); ?>"><?php _e( 'Team Name1 Content :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'team1_para' ); ?>" name="<?php echo $this->get_field_name( 'team1_para' ); ?>" type="text" value="<?php echo esc_attr( $team1_para ); ?>" />
</p>

<p>
<input class="checkbox" type="checkbox" <?php checked( $instance[ 'f1check1' ], 'on' ); ?> id="<?php echo $this->get_field_id( 'f1check1' ); ?>" name="<?php echo $this->get_field_name( 'f1check1' ); ?>" /> 
<label for="<?php echo $this->get_field_id( 'f1check1' ); ?>">Show Facebook Icon</label>
</p>
<p>
<input class="checkbox" type="checkbox" <?php checked( $instance[ 't1check1' ], 'on' ); ?> id="<?php echo $this->get_field_id( 't1check1' ); ?>" name="<?php echo $this->get_field_name( 't1check1' ); ?>" /> 
<label for="<?php echo $this->get_field_id( 't1check1' ); ?>">Show Twitter Icon</label>
</p>
<p>
<input class="checkbox" type="checkbox" <?php checked( $instance[ 'l1check1' ], 'on' ); ?> id="<?php echo $this->get_field_id( 'l1check1' ); ?>" name="<?php echo $this->get_field_name( 'l1check1' ); ?>" /> 
<label for="<?php echo $this->get_field_id( 'l1check1' ); ?>">Show Linkedin Icon</label>
</p>
<p>
<input class="checkbox" type="checkbox" <?php checked( $instance[ 'g1check1' ], 'on' ); ?> id="<?php echo $this->get_field_id( 'g1check1' ); ?>" name="<?php echo $this->get_field_name( 'g1check1' ); ?>" /> 
<label for="<?php echo $this->get_field_id( 'g1check1' ); ?>">Show Googleplus Icon</label>
</p>
	
<p>
<label for="<?php echo $this->get_field_id( 'fb1' ); ?>"><?php _e( 'Team Name1 Facebook Page URL Link :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'fb1' ); ?>" name="<?php echo $this->get_field_name( 'fb1' ); ?>" type="text" value="<?php echo esc_attr( $fb1 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'twitter1' ); ?>"><?php _e( 'Team Name1 Twitter Page URL Link :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'twitter1' ); ?>" name="<?php echo $this->get_field_name( 'twitter1' ); ?>" type="text" value="<?php echo esc_attr( $twitter1 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'linkedin1' ); ?>"><?php _e( 'Team Name1 Linkedin Page URL Link :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'linkedin1' ); ?>" name="<?php echo $this->get_field_name( 'linkedin1' ); ?>" type="text" value="<?php echo esc_attr( $linkedin1 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'google1' ); ?>"><?php _e( 'Team Name1 Googleplus  Page URL Link :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'google1' ); ?>" name="<?php echo $this->get_field_name( 'google1' ); ?>" type="text" value="<?php echo esc_attr( $google1 ); ?>" />
</p>


<p>
<label for="<?php echo $this->get_field_id( 'team_img2' ); ?>"><?php _e( 'Team Image2 URL Link:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'team_img2' ); ?>" name="<?php echo $this->get_field_name( 'team_img2' ); ?>" type="text" value="<?php echo esc_attr( $team_img2 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'team_name2' ); ?>"><?php _e( 'Team Name2:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'team_name2' ); ?>" name="<?php echo $this->get_field_name( 'team_name2' ); ?>" type="text" value="<?php echo esc_attr( $team_name2 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'team_profession2' ); ?>"><?php _e( 'Team Name2 Profession:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'team_profession2' ); ?>" name="<?php echo $this->get_field_name( 'team_profession2' ); ?>" type="text" value="<?php echo esc_attr( $team_profession2 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'team2_para' ); ?>"><?php _e( 'Team Name2 Content :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'team2_para' ); ?>" name="<?php echo $this->get_field_name( 'team2_para' ); ?>" type="text" value="<?php echo esc_attr( $team2_para ); ?>" />
</p>

<p>
<input class="checkbox" type="checkbox" <?php checked( $instance[ 'f2check2' ], 'on' ); ?> id="<?php echo $this->get_field_id( 'f2check2' ); ?>" name="<?php echo $this->get_field_name( 'f2check2' ); ?>" /> 
<label for="<?php echo $this->get_field_id( 'f2check2' ); ?>">Show Facebook Icon</label>
</p>
<p>
<input class="checkbox" type="checkbox" <?php checked( $instance[ 't2check2' ], 'on' ); ?> id="<?php echo $this->get_field_id( 't2check2' ); ?>" name="<?php echo $this->get_field_name( 't2check2' ); ?>" /> 
<label for="<?php echo $this->get_field_id( 't2check2' ); ?>">Show Twitter Icon</label>
</p>
<p>
<input class="checkbox" type="checkbox" <?php checked( $instance[ 'l2check2' ], 'on' ); ?> id="<?php echo $this->get_field_id( 'l2check2' ); ?>" name="<?php echo $this->get_field_name( 'l2check2' ); ?>" /> 
<label for="<?php echo $this->get_field_id( 'l2check2' ); ?>">Show Linkedin Icon</label>
</p>
<p>
<input class="checkbox" type="checkbox" <?php checked( $instance[ 'g2check2' ], 'on' ); ?> id="<?php echo $this->get_field_id( 'g2check2' ); ?>" name="<?php echo $this->get_field_name( 'g2check2' ); ?>" /> 
<label for="<?php echo $this->get_field_id( 'g2check2' ); ?>">Show google2 Icon</label>
</p>

<p>
<label for="<?php echo $this->get_field_id( 'fb2' ); ?>"><?php _e( 'Team Name2 Facebook Page URL Link :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'fb2' ); ?>" name="<?php echo $this->get_field_name( 'fb2' ); ?>" type="text" value="<?php echo esc_attr( $fb2 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'twitter2' ); ?>"><?php _e( 'Team Name2 Twitter Page URL Link :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'twitter2' ); ?>" name="<?php echo $this->get_field_name( 'twitter2' ); ?>" type="text" value="<?php echo esc_attr( $twitter2 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'linkedin2' ); ?>"><?php _e( 'Team Name2 Linkedin Page URL Link :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'linkedin2' ); ?>" name="<?php echo $this->get_field_name( 'linkedin2' ); ?>" type="text" value="<?php echo esc_attr( $linkedin2 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'google2' ); ?>"><?php _e( 'Team Name2 Googleplus Page URL Link :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'google2' ); ?>" name="<?php echo $this->get_field_name( 'google2' ); ?>" type="text" value="<?php echo esc_attr( $google2 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'team_img3' ); ?>"><?php _e( 'Team Image3 URL Link:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'team_img3' ); ?>" name="<?php echo $this->get_field_name( 'team_img3' ); ?>" type="text" value="<?php echo esc_attr( $team_img3 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'team_name3' ); ?>"><?php _e( 'Team Name3:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'team_name3' ); ?>" name="<?php echo $this->get_field_name( 'team_name3' ); ?>" type="text" value="<?php echo esc_attr( $team_name3 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'team_profession3' ); ?>"><?php _e( 'Team Name3 Profession:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'team_profession3' ); ?>" name="<?php echo $this->get_field_name( 'team_profession3' ); ?>" type="text" value="<?php echo esc_attr( $team_profession3 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'team3_para' ); ?>"><?php _e( 'Team Name3 Content :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'team3_para' ); ?>" name="<?php echo $this->get_field_name( 'team3_para' ); ?>" type="text" value="<?php echo esc_attr( $team3_para ); ?>" />
</p>

<p>
<input class="checkbox" type="checkbox" <?php checked( $instance[ 'f3check3' ], 'on' ); ?> id="<?php echo $this->get_field_id( 'f3check3' ); ?>" name="<?php echo $this->get_field_name( 'f3check3' ); ?>" /> 
<label for="<?php echo $this->get_field_id( 'f3check3' ); ?>">Show Facebook Icon</label>
</p>
<p>
<input class="checkbox" type="checkbox" <?php checked( $instance[ 't3check3' ], 'on' ); ?> id="<?php echo $this->get_field_id( 't3check3' ); ?>" name="<?php echo $this->get_field_name( 't3check3' ); ?>" /> 
<label for="<?php echo $this->get_field_id( 't3check3' ); ?>">Show Twitter Icon</label>
</p>
<p>
<input class="checkbox" type="checkbox" <?php checked( $instance[ 'l3check3' ], 'on' ); ?> id="<?php echo $this->get_field_id( 'l3check3' ); ?>" name="<?php echo $this->get_field_name( 'l3check3' ); ?>" /> 
<label for="<?php echo $this->get_field_id( 'l3check3' ); ?>">Show Linkedin Icon</label>
</p>
<p>
<input class="checkbox" type="checkbox" <?php checked( $instance[ 'g3check3' ], 'on' ); ?> id="<?php echo $this->get_field_id( 'g3check3' ); ?>" name="<?php echo $this->get_field_name( 'g3check3' ); ?>" /> 
<label for="<?php echo $this->get_field_id( 'g3check3' ); ?>">Show Googleplus Icon</label>
</p>

<p>
<label for="<?php echo $this->get_field_id( 'fb3' ); ?>"><?php _e( 'Team Name3 Facebook Page URL Link :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'fb3' ); ?>" name="<?php echo $this->get_field_name( 'fb3' ); ?>" type="text" value="<?php echo esc_attr( $fb3 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'twitter3' ); ?>"><?php _e( 'Team Name3 Twitter Page URL Link :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'twitter3' ); ?>" name="<?php echo $this->get_field_name( 'twitter3' ); ?>" type="text" value="<?php echo esc_attr( $twitter3 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'linkedin3' ); ?>"><?php _e( 'Team Name3 Linkedin Page URL Link :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'linkedin3' ); ?>" name="<?php echo $this->get_field_name( 'linkedin3' ); ?>" type="text" value="<?php echo esc_attr( $linkedin3 ); ?>" />
</p>
<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['team_hdr'] = ( ! empty( $new_instance['team_hdr'] ) ) ? strip_tags( $new_instance['team_hdr'] ) : '';
$instance['team_img1'] = ( ! empty( $new_instance['team_img1'] ) ) ? strip_tags( $new_instance['team_img1'] ) : '';
$instance['team_name1'] = ( ! empty( $new_instance['team_name1'] ) ) ? strip_tags( $new_instance['team_name1'] ) : '';
$instance['team_profession1'] = ( ! empty( $new_instance['team_profession1'] ) ) ? strip_tags( $new_instance['team_profession1'] ) : '';
$instance['team1_para'] = ( ! empty( $new_instance['team1_para'] ) ) ? strip_tags( $new_instance['team1_para'] ) : '';
$instance[ 'f1check1' ] = $new_instance[ 'f1check1' ];
$instance[ 't1check1' ] = $new_instance[ 't1check1' ];
$instance[ 'l1check1' ] = $new_instance[ 'l1check1' ];
$instance[ 'g1check1' ] = $new_instance[ 'g1check1' ]; 
$instance['fb1'] = ( ! empty( $new_instance['fb1'] ) ) ? strip_tags( $new_instance['fb1'] ) : '';
$instance['twitter1'] = ( ! empty( $new_instance['twitter1'] ) ) ? strip_tags( $new_instance['twitter1'] ) : '';
$instance['linkedin1'] = ( ! empty( $new_instance['linkedin1'] ) ) ? strip_tags( $new_instance['linkedin1'] ) : '';
$instance['google1'] = ( ! empty( $new_instance['google1'] ) ) ? strip_tags( $new_instance['google1'] ) : '';

$instance['team_img2'] = ( ! empty( $new_instance['team_img2'] ) ) ? strip_tags( $new_instance['team_img2'] ) : '';
$instance['team_name2'] = ( ! empty( $new_instance['team_name2'] ) ) ? strip_tags( $new_instance['team_name2'] ) : '';
$instance['team_profession2'] = ( ! empty( $new_instance['team_profession2'] ) ) ? strip_tags( $new_instance['team_profession2'] ) : '';
$instance['team2_para'] = ( ! empty( $new_instance['team2_para'] ) ) ? strip_tags( $new_instance['team2_para'] ) : '';
$instance[ 'f2check2' ] = $new_instance[ 'f2check2' ];
$instance[ 't2check2' ] = $new_instance[ 't2check2' ];
$instance[ 'l2check2' ] = $new_instance[ 'l2check2' ];
$instance[ 'g2check2' ] = $new_instance[ 'g2check2' ]; 
$instance['fb2'] = ( ! empty( $new_instance['fb2'] ) ) ? strip_tags( $new_instance['fb2'] ) : '';
$instance['twitter2'] = ( ! empty( $new_instance['twitter2'] ) ) ? strip_tags( $new_instance['twitter2'] ) : '';
$instance['linkedin2'] = ( ! empty( $new_instance['linkedin2'] ) ) ? strip_tags( $new_instance['linkedin2'] ) : '';
$instance['google2'] = ( ! empty( $new_instance['google2'] ) ) ? strip_tags( $new_instance['google2'] ) : '';

$instance['team_img3'] = ( ! empty( $new_instance['team_img3'] ) ) ? strip_tags( $new_instance['team_img3'] ) : '';
$instance['team_name3'] = ( ! empty( $new_instance['team_name3'] ) ) ? strip_tags( $new_instance['team_name3'] ) : '';
$instance['team_profession3'] = ( ! empty( $new_instance['team_profession3'] ) ) ? strip_tags( $new_instance['team_profession3'] ) : '';
$instance['team3_para'] = ( ! empty( $new_instance['team3_para'] ) ) ? strip_tags( $new_instance['team3_para'] ) : '';
$instance[ 'f3check3' ] = $new_instance[ 'f3check3' ];
$instance[ 't3check3' ] = $new_instance[ 't3check3' ];
$instance[ 'l3check3' ] = $new_instance[ 'l3check3' ];
$instance[ 'g3check3' ] = $new_instance[ 'g3check3' ]; 
$instance['fb3'] = ( ! empty( $new_instance['fb3'] ) ) ? strip_tags( $new_instance['fb3'] ) : '';
$instance['twitter3'] = ( ! empty( $new_instance['twitter3'] ) ) ? strip_tags( $new_instance['twitter3'] ) : '';
$instance['linkedin3'] = ( ! empty( $new_instance['linkedin3'] ) ) ? strip_tags( $new_instance['linkedin3'] ) : '';
$instance['google3'] = ( ! empty( $new_instance['google3'] ) ) ? strip_tags( $new_instance['google3'] ) : '';

return $instance;
}
}

// Team Section Widget ends here

// Register and load the widget
function gl_load_widget() {

register_widget( 'gl_search_widget' );
register_widget( 'gl_aboutus_widget' );

	register_widget( 'gl_popular_widget' );
	register_widget( 'gl_random_widget' );
	register_widget( 'gl_last_update_widget' );
	
	register_widget( 'gl_related_post_widget' );
	
	register_widget( 'gl_top_welcome_widget' );
	register_widget( 'gl_feature_box_widget' );
	register_widget( 'gl_portfolio_box_widget' );
	register_widget( 'gl_pricing_table_box_widget' );
	register_widget( 'gl_call_to_action_box_widget' );
	register_widget( 'gl_testimonial_box_widget' );
	register_widget( 'gl_clients_box_widget' );
	register_widget( 'gl_team_widget' );
}
add_action( 'widgets_init', 'gl_load_widget' );