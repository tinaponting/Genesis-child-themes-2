<?php
/*
Template Name: Landing Page With Feature
*/


// Add custom body class to the head
add_filter( 'body_class', 'metro_add_body_class' );
function metro_add_body_class( $classes ) {
   $classes[] = 'landingpage';
   return $classes;
}

// set full width layout
add_filter ( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );
remove_action( 'genesis_sidebar', 'genesis_do_sidebar' ); 
add_action('genesis_before_content','before_content');
function before_content(){
?>
<div class="landing_page_container wrap">
<?php
}

add_action('genesis_after_content','after_content');
function after_content(){
?>
</div>
<?php
}


add_action('genesis_before_content_sidebar_wrap','landingpage_optin',1);
function landingpage_optin(){
if (genesism_get_option('landing_img_optin')){	
?>

<div class="optin_img_box wrap" style='background-image:url(<?php echo genesism_option('land_optin_bg');?> )'>
<div class='optin_img_box_color'>
<div class="optin_img_box_inner ">
<div class="lob_left">
		<div class='squeeze_video'><?php echo genesism_option('land_optin_img'); ?>
		</div>
	</div>
	
	<div class="lob_right">
		<div class="right_side_optin">
			<div class="landing_optin_title">
				<h3><?php echo genesism_option('opt_title'); ?></h3>
				<p><?php echo genesism_option('opt_content'); ?></p>	
			</div>	
			<form method="post" class="form" action="<?php echo stripslashes(genesism_option('optin_url1')); ?>" target="_blank">
			<div class="names"><input class="name" type="text" name="<?php echo stripslashes(genesism_option('optin_name1')); ?>" placeholder="<?php echo stripslashes(genesism_option('name_text1')); ?>"><div class='admins'></div></div>					
			<div class="names"><input class="email" type="text" name="<?php echo stripslashes(genesism_option('optin_email1')); ?>" placeholder="  <?php echo stripslashes(genesism_option('email_text1')); ?>"><div class='mails'></div></div>
			<?php echo stripslashes(genesism_option('optin_hidden1')); ?>
			<input name="submit" class="submit" type="submit" value="<?php echo stripslashes(genesism_option('submit_text1')); ?>"/>
			</form>
		</div>
	</div>
	
	
		
</div>
</div>
</div>

<?php 
}
}

add_action('genesis_before_content_sidebar_wrap','landingpage_feature',2);
function landingpage_feature(){
if (genesism_get_option('landing_feature')){	
?>

<div class='landing_feature_box'>
<div class='inner_landing wrap'>
<div class='landing_header'>
<h2><?php echo genesism_option('landing_feature_title'); ?></h2>
<p><?php echo genesism_option('landing_feature_para'); ?></p>
</div>

<div class='landing_feature_content'>

<div class='ftr_col'>
<div class='land_feature_img'>
<img alt='<?php echo genesism_option('ftr1_title'); ?>' src='<?php echo genesism_option('land_ftr1_img'); ?>'/>
</div>
<div class='feature_cont'>
<h2> <a href="<?php echo genesism_option('ftr1_link'); ?>" > <?php echo genesism_option('ftr1_title'); ?></a></h2>
<p><?php echo genesism_option('feature1_para'); ?></p>
</div>
</div>


<div class='ftr_col'>
<div class='land_feature_img'>
<img alt='<?php echo genesism_option('ftr2_title'); ?>' src='<?php echo genesism_option('land_ftr2_img'); ?>'/>
</div>
<div class='feature_cont'>
<h2> <a href="<?php echo genesism_option('ftr2_link'); ?>" ><?php echo genesism_option('ftr2_title'); ?></a></h2>
<p><?php echo genesism_option('feature2_para'); ?></p>
</div>
</div>

<div class='ftr_col last'>
<div class='land_feature_img'>
<img alt='<?php echo genesism_option('ftr3_title'); ?>' src='<?php echo genesism_option('land_ftr3_img'); ?>'/>
</div>
<div class='feature_cont'>
<h2> <a href="<?php echo genesism_option('ftr3_link'); ?>" >
<?php echo genesism_option('ftr3_title'); ?></a></h2>
<p><?php echo genesism_option('feature3_para'); ?></p>
</div>
</div>


<div class='ftr_col'>
<div class='land_feature_img'>
<img alt='<?php echo genesism_option('ftr4_title'); ?>' src='<?php echo genesism_option('land_ftr4_img'); ?>'/>
</div>
<div class='feature_cont'>
<h2> <a href="<?php echo genesism_option('ftr4_link'); ?>" ><?php echo genesism_option('ftr4_title'); ?></a></h2>
<p><?php echo genesism_option('feature4_para'); ?></p>
</div>
</div>


<div class='ftr_col'>
<div class='land_feature_img'>
<img alt='<?php echo genesism_option('ftr5_title'); ?>' src='<?php echo genesism_option('land_ftr5_img'); ?>'/>
</div>
<div class='feature_cont'>
<h2> <a href="<?php echo genesism_option('ftr5_link'); ?>" >
<?php echo genesism_option('ftr5_title'); ?></a></h2>
<p><?php echo genesism_option('feature5_para'); ?></p>
</div>
</div>


<div class='ftr_col last'>
<div class='land_feature_img'>
<img alt='<?php echo genesism_option('ftr6_title'); ?>' src='<?php echo genesism_option('land_ftr6_img'); ?>'/>
</div>
<div class='feature_cont'>
<h2> <a href="<?php echo genesism_option('ftr6_link'); ?>" ><?php echo genesism_option('ftr6_title'); ?></a></h2>
<p><?php echo genesism_option('feature6_para'); ?></p>
</div>
</div>

</div>
</div>
</div>

<?php 
}
}

genesis();