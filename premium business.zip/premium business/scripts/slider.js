
var j=jQuery.noConflict();
j('.example1').wmuSlider()
