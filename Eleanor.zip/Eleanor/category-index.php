<?php
/**
* Template Name: Category Index Page Template
* Description: Template used for the category index page
*/

//* Add Custom Body Class
add_filter( 'body_class', 'ollieandkay_categoryindex_body_class' );
function ollieandkay_categoryindex_body_class( $classes ) {
	$classes[] = 'category-index';
	return $classes;
}

// Force full width page layout
add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );

// Remove Loop
remove_action( 'genesis_loop', 'genesis_do_loop' );

// Add widget area markup
add_action( 'genesis_after_content', 'ollieandkay_categoryindex_widget_area' );
function ollieandkay_categoryindex_widget_area() {
 
genesis_widget_area( 'category-index-1', array(
		'before' => '<div class="category-index-1 widget-area animated fadeInUp duration2"><div class="wrap">',
		'after'  => '</div></div>', 
	) );

genesis_widget_area( 'category-index-2', array(
		'before' => '<div class="category-index-2 widget-area animated fadeInUp duration2 eds-on-scroll"><div class="wrap">',
		'after'  => '</div></div>', 
	) );

genesis_widget_area( 'category-index-3', array(
		'before' => '<div class="category-index-3 widget-area animated fadeInUp duration2 eds-on-scroll"><div class="wrap">',
		'after'  => '</div></div>', 
	) );

genesis_widget_area( 'category-index-4', array(
		'before' => '<div class="category-index-4 widget-area animated fadeInUp duration2 eds-on-scroll"><div class="wrap">',
		'after'  => '</div></div>', 
	) );

genesis_widget_area( 'category-index-5', array(
		'before' => '<div class="category-index-5 widget-area animated fadeInUp duration2 eds-on-scroll"><div class="wrap">',
		'after'  => '</div></div>', 
	) );

genesis_widget_area( 'category-index-6', array(
		'before' => '<div class="category-index-6 widget-area animated fadeInUp duration2 eds-on-scroll"><div class="wrap">',
		'after'  => '</div></div>', 
	) );
    
}

genesis();