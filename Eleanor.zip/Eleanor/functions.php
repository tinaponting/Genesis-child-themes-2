<?php
// Start the engine.
include_once( get_template_directory() . '/lib/init.php' );

// Setup Theme.
include_once( get_stylesheet_directory() . '/lib/theme-defaults.php' );

// Set Localization.
add_action( 'after_setup_theme', 'eleanor_theme_localization_setup' );
function eleanor_theme_localization_setup(){
	load_child_theme_textdomain( 'eleanor-theme', get_stylesheet_directory() . '/languages' );
}

// Add the helper functions.
include_once( get_stylesheet_directory() . '/lib/helper-functions.php' );

// Add Image upload and Color select to WordPress Theme Customizer.
require_once( get_stylesheet_directory() . '/lib/customize.php' );

// Include Customizer CSS.
include_once( get_stylesheet_directory() . '/lib/output.php' );

// Child theme (do not remove).
define( 'CHILD_THEME_NAME', 'Eleanor' );
define( 'CHILD_THEME_VERSION', '1.0.0' );

// Remove the header right widget area.
unregister_sidebar( 'header-right' );

// Remove secondary navigation menu.
add_theme_support( 'genesis-menus', array( 'primary' => __( 'Primary Navigation Menu', 'genesis' ) ) );

// Remove categories and tags
remove_action( 'genesis_entry_footer', 'genesis_entry_footer_markup_open', 5 );
remove_action( 'genesis_entry_footer', 'genesis_entry_footer_markup_close', 15 );
remove_action( 'genesis_entry_footer', 'genesis_post_meta' );

// Remove the author box on single posts HTML5 Themes.
remove_action( 'genesis_after_entry', 'genesis_do_author_box_single', 8 );

// Remove footer.
remove_action( 'genesis_before_footer', 'genesis_footer_widget_areas' );

// Adding custom Favicon.
add_filter( 'genesis_pre_load_favicon', 'custom_favicon' );
function custom_favicon( $favicon_url ) {
	return ''. trailingslashit( get_bloginfo('url') ) .'/wp-content/themes/eleanor/images/favicon.png';
}

// Add Image Sizes.
add_image_size( 'featured-image', 850, 1000, TRUE );
add_image_size( 'featured-image-2', 850, 1200, TRUE );
add_image_size( 'featured-image-3', 850, 500, TRUE );
add_image_size( 'featured-image-square', 850, 850, TRUE );
add_image_size( 'featured-image-small', 100, 100, TRUE );
add_image_size( 'featured-image-medium', 300, 200, TRUE );
add_image_size( 'singular-featured-thumb', 1000, 600, TRUE );
add_image_size( 'related', 350, 350, true );
add_image_size( 'portfolio-image', 330, 230, true );

// Portfolio
add_post_type_support( 'portfolio', 'genesis-cpt-archives-settings' );

// Enqueue Scripts and Styles.
add_action( 'wp_enqueue_scripts', 'eleanor_theme_enqueue_scripts_styles' );
function eleanor_theme_enqueue_scripts_styles() {

	wp_enqueue_style( 'eleanor-theme-fonts', '//fonts.googleapis.com/css?family=Lato:400,700|Poppins:400,500,600|Playfair+Display:400,400i', array(), eleanor-theme );
	wp_enqueue_style( 'dashicons' );

	$suffix = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';
	wp_enqueue_script( 'eleanor-theme-responsive-menu', get_stylesheet_directory_uri() . "/js/responsive-menus{$suffix}.js", array( 'jquery' ), eleanor-theme, true );
	wp_localize_script(
		'eleanor-theme-responsive-menu',
		'genesis_responsive_menu',
		eleanor_theme_responsive_menu_settings()
	);

}

// Define our responsive menu settings.
function eleanor_theme_responsive_menu_settings() {

	$settings = array(
		'mainMenu'          => __( 'Menu', 'eleanor-theme' ),
		'menuIconClass'     => 'dashicons-before dashicons-menu',
		'subMenu'           => __( 'Submenu', 'eleanor-theme' ),
		'subMenuIconsClass' => 'dashicons-before dashicons-arrow-down-alt2',
		'menuClasses'       => array(
			'combine' => array(
				'.nav-primary',
				'.nav-header',
			),
			'others'  => array(),
		),
	);

	return $settings;

}

// Add HTML5 markup structure.
add_theme_support( 'html5', array( 'caption', 'comment-form', 'comment-list', 'gallery', 'search-form' ) );

// Add Accessibility support.
add_theme_support( 'genesis-accessibility', array( '404-page', 'drop-down-menu', 'headings', 'rems', 'search-form', 'skip-links' ) );

// Add viewport meta tag for mobile browsers.
add_theme_support( 'genesis-responsive-viewport' );

// Add support for custom header.
add_theme_support( 'custom-header', array(
	'width'           => 800,
	'height'          => 400,
	'header-selector' => '.site-title a',
	'header-text'     => false,
	'flex-height'     => true,
) );

// Move Primary Nav Menu Above Header.
remove_action( 'genesis_after_header', 'genesis_do_nav' );
add_action( 'genesis_before_header', 'genesis_do_nav' );

// Unregister secondary sidebar.
unregister_sidebar( 'sidebar-alt' );

// Unregister other site layouts.
genesis_unregister_layout( 'content-sidebar-sidebar' );
genesis_unregister_layout( 'sidebar-sidebar-content' );
genesis_unregister_layout( 'sidebar-content-sidebar' );

// Customize Read More Text.
add_filter( 'excerpt_more', 'child_read_more_link' );
add_filter( 'get_the_content_more_link', 'child_read_more_link' );
add_filter( 'the_content_more_link', 'child_read_more_link' );
function child_read_more_link() {
 
return '<a href="' . get_permalink() . '" class="more-link" rel="nofollow">Read More</a>';
}

// Force full width layout on all archive pages.
add_filter( 'genesis_pre_get_option_site_layout', 'full_width_layout_archives' );
function full_width_layout_archives( $opt ) {
if ( is_home() ) {
    $opt = 'full-width-content'; 
    return $opt;

    } 

if ( is_archive() ) {
    $opt = 'full-width-content'; 
    return $opt;

    } 


}

// Force a layout
function themeprefix_cpt_layout() {
    if ( is_singular( array( 'portfolio', 'treatment' ) ) ) {
        return 'full-width-content';
    }
}

// Add support for after entry widget.
add_theme_support( 'genesis-after-entry-widget-area' );

// Modify the speak your mind title in comments
add_filter( 'comment_form_defaults', 'sp_comment_form_defaults' );
function sp_comment_form_defaults( $defaults ) {
 
	$defaults['title_reply'] = __( '<span>Leave a Comment</span>' );
	return $defaults;
 
}

add_filter('genesis_title_comments', 'custom_comment_text');
function custom_comment_text() {
return (' ');
}

// Modify the author says text in comments
add_filter( 'comment_author_says_text', 'sp_comment_author_says_text' );
function sp_comment_author_says_text() {
	return ' ';
}

add_action( 'genesis_before_comments' , 'wps_post_type_check' );
function wps_post_type_check () {
	if ( is_single() ) {
		if ( have_comments() ) {
			remove_action( 'genesis_comment_form', 'genesis_do_comment_form' );
			add_action( 'genesis_list_comments', 'genesis_do_comment_form' , 5 );
		}
	}
}

// Insert span tag into widget title
add_filter( 'dynamic_sidebar_params', 'b3m_wrap_widget_titles', 20 );
function b3m_wrap_widget_titles( array $params ) {
        
        // $params will ordinarily be an array of 2 elements, we're only interested in the first element
        $widget =& $params[0];
        $widget['before_title'] = '<h4 class="widget-title"><span>';
        $widget['after_title'] = '</span></h4>';
        
        return $params;
        
}

// Modify size of the Gravatar in the author box.
add_filter( 'genesis_author_box_gravatar_size', 'eleanor_theme_author_box_gravatar' );
function eleanor_theme_author_box_gravatar( $size ) {
	return 120;
}

// Modify size of the Gravatar in the entry comments.
add_filter( 'genesis_comment_list_args', 'eleanor_theme_comments_gravatar' );
function eleanor_theme_comments_gravatar( $args ) {

	$args['avatar_size'] = 60;

	return $args;

}

// Change search form text.
function themeprefix_search_button_text( $text ) {
return ( 'search + enter');
}
add_filter( 'genesis_search_text', 'themeprefix_search_button_text' );

// Animated search in the menu.
add_action( 'wp_enqueue_scripts', 'custom_enqueue_scripts_styles' );
function custom_enqueue_scripts_styles() {

	wp_enqueue_style( 'font-awesome', '//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css' );
	
	wp_enqueue_script( 'global', get_bloginfo( 'stylesheet_directory' ) . '/js/global.js', array( 'jquery' ), '1.0.0', true );

}

add_filter( 'wp_nav_menu_items', 'theme_menu_extras', 10, 2 );

function theme_menu_extras( $menu, $args ) {

	if ( 'primary' !== $args->theme_location )
		return $menu;

	$menu .= '<li class="search"><a id="main-nav-search-link" class="icon-search"></a><div class="search-div">' . get_search_form( false ) . '</div></li>';
	
	return $menu;

}

// Customize search form input button text.
add_filter( 'genesis_search_button_text', 'sp_search_button_text' );
function sp_search_button_text( $text ) {
	return esc_attr( 'Go' );
}

// Social Icons - Menu.
genesis_register_sidebar( array(
	'id'          => 'nav-social-menu',
	'name'        => __( 'Navigation - Social Icons', 'ollieandkay' ),
	'description' => __( 'This is the nav social menu section.', 'ollieandkay' ),
) );

add_filter( 'genesis_nav_items', 'sws_social_icons', 10, 2 );
add_filter( 'wp_nav_menu_items', 'sws_social_icons', 10, 2 );

function sws_social_icons($menu, $args) {
	$args = (array)$args;
	if ( 'primary' !== $args['theme_location'] )
		return $menu;
	ob_start();
	genesis_widget_area('nav-social-menu');
	$social = ob_get_clean();
	return $menu . $social;
}

// Social sharing icons under each post.
function crunchify_social_sharing_buttons($content) {
    if(is_singular() ){
    
        // Get current page URL 
        $crunchifyURL = get_permalink();
 
        // Get current page title
        $crunchifyTitle = str_replace( ' ', '%20', get_the_title());
        
        // Get Post Thumbnail for pinterest
        $crunchifyThumbnail = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full' );
 
        // Construct sharing URL without using any script
        $twitterURL = 'https://twitter.com/intent/tweet?text='.$crunchifyTitle.'&amp;url='.$crunchifyURL.'&amp;via=Crunchify';
        $facebookURL = 'https://www.facebook.com/sharer/sharer.php?u='.$crunchifyURL;
        $googleURL = 'https://plus.google.com/share?url='.$crunchifyURL;
        $bufferURL = 'https://bufferapp.com/add?url='.$crunchifyURL.'&amp;text='.$crunchifyTitle;
$stumbleURL = 'http://www.stumbleupon.com/submit?url='.$crunchifyURL.'&title='.$crunchifyTitle;
        
        // Based on popular demand added Pinterest too
        $pinterestURL = 'https://pinterest.com/pin/create/button/?url='.$crunchifyURL.'&amp;media='.$crunchifyThumbnail[0].'&amp;description='.$crunchifyTitle;
 
        // Add sharing button at the end of page/page content
        $content .= '<!-- Crunchify.com social sharing. Get your copy here: http://crunfy.me/1EFBLtA -->';
        $content .= '<div class="crunchify-social">';
        $content .= '<h5>SHARE:</h5> <a class="crunchify-link crunchify-twitter" href="'. $twitterURL .'" target="_blank"><i class="fa fa-twitter"></i></a>';
$content .= '<a class="crunchify-link crunchify-pinterest" href="'.$pinterestURL.'" target="_blank"><i class="fa fa-pinterest"></i></a>';
        $content .= '<a class="crunchify-link crunchify-facebook" href="'.$facebookURL.'" target="_blank"><i class="fa fa-facebook"></i></a>';
        $content .= '<a class="crunchify-link crunchify-googleplus" href="'.$googleURL.'" target="_blank"><i class="fa fa-google-plus"></i></a>';
      $content .= '<a class="crunchify-link crunchify-stumble" href="'.$stumbleURL.'" target="_blank"><i class="fa fa-stumbleupon" aria-hidden="true"></i></i></a>';
        $content .= '</div>';
        
        return $content;
    }else{
        // if not a post/page then don't include sharing button
        return $content;
    }
};
add_filter( 'the_content', 'crunchify_social_sharing_buttons');

// Position post info above post title.
remove_action( 'genesis_entry_header', 'genesis_post_info', 12);
add_action( 'genesis_entry_header', 'genesis_post_info', 9 );

// Featured image.
function ollieandkay_featured_img() {
	if ( is_singular('post') ) { 
	
	$background = wp_get_attachment_image_src( get_post_thumbnail_id( $page->ID ), 'featuredimg' ); 
	if (is_array($background)) {  
	echo '<div class="features" style="background: url(' ;
	echo $background[0];
	echo ') no-repeat scroll center center #FFFFFF; background-attachment: fixed; background-size: 100%; background-position: top;
    "><div class="wrap">';
echo '<div class="featuredpostinformation">';
	echo '<div class="featuredpostinformationdate">';
echo get_the_date();
	echo '</div>';
	echo '<div class="featuredpostinformationtitle">';
echo get_the_title(); 
	echo '</div>';
echo '</div>';
		genesis_widget_area( 'featuredimg', array(
		'before' => '<div class="features-widgetarea"><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a>',
		'after' => '</div>',

	) );
		echo '</div></div>'; 
	}



}

if ( is_singular('portfolio') ) { 
	remove_action( 'genesis_after_entry_content', 'child_related_posts' );
	$background = wp_get_attachment_image_src( get_post_thumbnail_id( $page->ID ), 'featuredimg' ); 
	if (is_array($background)) {  
	echo '<div class="features" style="background: url(' ;
	echo $background[0];
	echo ') no-repeat scroll center center #FFFFFF; background-attachment: fixed; background-size: 100%; background-position: top;
    "><div class="wrap">';
echo '<div class="featuredpostinformation">';
	echo '<div class="featuredpostinformationtitle">';
echo get_the_title(); 
	echo '</div>';
echo '</div>';
		genesis_widget_area( 'featuredimg', array(
		'before' => '<div class="features-widgetarea"><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a>',
		'after' => '</div>',

	) );
		echo '</div></div>'; 
	}


}

}
 
add_action( 'genesis_after_header', 'ollieandkay_featured_img' );

add_filter( 'genesis_site_layout', 'themeprefix_cpt_layout' );

// Move image above post title in Genesis Framework 2.0.
remove_action( 'genesis_entry_content', 'genesis_do_post_image', 8 );
add_action( 'genesis_entry_header', 'genesis_do_post_image', 8 );

// Code to Display Featured Image on top of the post.
add_action( 'genesis_before_entry', 'featured_post_image', 8 );
function featured_post_image() {
  if ( ! is_singular( 'post' ) ) return;
echo '<div class="featuredimage">';
	the_post_thumbnail('post-image');
echo '</div>';
}

add_action( 'loop_start', 'remove_titles_all_single_posts' );
function remove_titles_all_single_posts() {
    if ( is_singular('post') ) {
        remove_action( 'genesis_entry_header', 'genesis_do_post_title' );
    }
if ( is_singular('portfolio') ) {
        remove_action( 'genesis_entry_header', 'genesis_do_post_title' );
    }
}

// Customize the post info function
add_filter( 'genesis_post_info', 'sp_post_info_filter' );
function sp_post_info_filter($post_info) {
if(is_archive() )
{
	$post_info = '[post_date] [post_comments]';
	return $post_info;
}
if ( is_singular() ) {
	$post_info = ' ';
	return $post_info;
}
if ( is_home() ) {
	$post_info = '[post_date] [post_comments]';
	return $post_info;
}
if ( is_search() ) {
	$post_info = '[post_date] [post_comments]';
	return $post_info;
}
}

// Related Posts
//for XHTML themes
add_action( 'genesis_after_post_content', 'child_related_posts' );
//for HTML5 themes
add_action( 'genesis_after_entry_content', 'child_related_posts' );
/**
 * Outputs related posts with thumbnail
 * @global object $post 
 */
function child_related_posts() {
     
    if ( is_single ( ) ) {
         
        global $post;
 
        $count = 0;
        $postIDs = array( $post->ID );
        $related = '';
        $tags = wp_get_post_tags( $post->ID );
        $cats = wp_get_post_categories( $post->ID );
         
        if ( $tags ) {
             
            foreach ( $tags as $tag ) {
                 
                $tagID[] = $tag->term_id;
                 
            }
             
            $args = array(
                'tag__in'               => $tagID,
                'post__not_in'          => $postIDs,
                'showposts'             => 4,
                'ignore_sticky_posts'   => 1,
                'tax_query'             => array(
                    array(
                                        'taxonomy'  => 'post_format',
                                        'field'     => 'slug',
                                        'terms'     => array( 
                                            'post-format-link', 
                                            'post-format-status', 
                                            'post-format-aside', 
                                            'post-format-quote'
                                            ),
                                        'operator'  => 'NOT IN'
                    )
                )
            );
 
            $tag_query = new WP_Query( $args );
             
            if ( $tag_query->have_posts() ) {
                 
                while ( $tag_query->have_posts() ) {
                     
                    $tag_query->the_post();
 
                    $img = genesis_get_image() ? genesis_get_image( array( 'size' => 'related' ) ) : '<img src="' . get_bloginfo( 'stylesheet_directory' ) . '/images/related.png" alt="' . get_the_title() . '" />';
 
                    $related .= '<li><a href="' . get_permalink() . '" rel="bookmark" title="Permanent Link to' . get_the_title() . '">' . $img . get_the_title() . '</a></li>';
                     
                    $postIDs[] = $post->ID;
 
                    $count++;
                }
            }
        }
 
        if ( $count <= 5 ) {
             
            $catIDs = array( );
 
            foreach ( $cats as $cat ) {
                 
                if ( 4 == $cat )
                    continue;
                $catIDs[] = $cat;
                 
            }
             
            $showposts = 4 - $count;
 
            $args = array(
                'category__in'          => $catIDs,
                'post__not_in'          => $postIDs,
                'showposts'             => $showposts,
                'ignore_sticky_posts'   => 1,
                'orderby'               => 'rand',
                'tax_query'             => array(
                                    array(
                                        'taxonomy'  => 'post_format',
                                        'field'     => 'slug',
                                        'terms'     => array( 
                                            'post-format-link', 
                                            'post-format-status', 
                                            'post-format-aside', 
                                            'post-format-quote' ),
                                        'operator' => 'NOT IN'
                                    )
                )
            );
 
            $cat_query = new WP_Query( $args );
             
            if ( $cat_query->have_posts() ) {
                 
                while ( $cat_query->have_posts() ) {
                     
                    $cat_query->the_post();
 
                    $img = genesis_get_image() ? genesis_get_image( array( 'size' => 'related' ) ) : '<img src="' . get_bloginfo( 'stylesheet_directory' ) . '/images/related.png" alt="' . get_the_title() . '" />';
 
                    $related .= '<li><a href="' . get_permalink() . '" rel="bookmark" title="Permanent Link to' . get_the_title() . '">' . $img . get_the_title() . '</a></li>';
                }
            }
        }
 
        if ( $related ) {
             
            printf( '<div class="related-posts"><h3 class="related-title">Related Posts</h3><ul class="related-list">%s</ul></div>', $related );
         
        }
         
        wp_reset_query();
         
    }
}


// Change the footer text
add_filter('genesis_footer_creds_text', 'sp_footer_creds_filter');
function sp_footer_creds_filter( $creds ) {
	$creds = 'Web Design by <a href="http://exempel.se">MY OWN SITE!</a>';
	return $creds;
}

// Tagcloud, change the font size.
function custom_tag_cloud_widget($args) {
    $args['largest'] = 9; //largest tag
    $args['smallest'] = 9; //smallest tag
    $args['unit'] = 'px'; //tag font unit
    return $args;
}
add_filter( 'widget_tag_cloud_args', 'custom_tag_cloud_widget' );

// Extra Widget Area
function genesischild_footerwidgetheader() {
	genesis_register_sidebar( array(
	'id' => 'footerwidgetheader',
	'name' => __( 'Footer - Instagram and Subscribe', 'ollieandkay' ),
	'description' => __( 'This is footer Instagram widget area.', 'ollieandkay' ),
	) );

}

add_action ('widgets_init','genesischild_footerwidgetheader');

// Position Widget Header.
function genesischild_footerwidgetheader_position ()  {
	echo '<div class="footerwidgetheader-container"><div class="wrap">';
	genesis_widget_area ('footerwidgetheader');
	echo '</div></div>';

}


add_action ('genesis_before_footer','genesischild_footerwidgetheader_position', 5 );

//*** WooCommerce Plugin.
// Add WooCommerce support.
include_once( get_stylesheet_directory() . '/lib/woocommerce/woocommerce-setup.php' );

// Add the required WooCommerce styles and Customizer CSS.
include_once( get_stylesheet_directory() . '/lib/woocommerce/woocommerce-output.php' );

// Add the Genesis Connect WooCommerce notice.
include_once( get_stylesheet_directory() . '/lib/woocommerce/woocommerce-notice.php' );

// WooCommerce Images.
add_theme_support( 'wc-product-gallery-lightbox' );
add_theme_support( 'wc-product-gallery-slider' );

// Tabs.
add_filter( 'woocommerce_product_tabs', 'woo_rename_tabs', 98 );
function woo_rename_tabs( $tabs ) {

	$tabs['description']['title'] = __( 'Description' );		// Rename the description tab
	$tabs['reviews']['title'] = __( 'Ratings' );				// Rename the reviews tab
	$tabs['additional_information']['title'] = __( 'Information' );	// Rename the additional information tab

	return $tabs;

}

add_filter( 'woocommerce_product_tabs', 'woo_reorder_tabs', 98 );
function woo_reorder_tabs( $tabs ) {

	$tabs['reviews']['priority'] = 15;			// Reviews first
	$tabs['description']['priority'] = 5;			// Description second
	$tabs['additional_information']['priority'] = 10;	// Additional information third

	return $tabs;
}

//* Front Page Widgets
// Register widget areas 
genesis_register_sidebar( array(
	'id'			=> 'front-page-1',
	'name'			=> __( 'Front Page - Widget 1', 'ollieandkay-theme' ),
	'description'	=> __( 'This is a widget area appearing on Front Page.', 'ollieandkay-theme' ),
) );

genesis_register_sidebar( array(
	'id'			=> 'front-page-2',
	'name'			=> __( 'Front Page - Widget 2', 'ollieandkay-theme' ),
	'description'	=> __( 'This is a widget area appearing on Front Page.', 'ollieandkay-theme' ),
) );

genesis_register_sidebar( array(
	'id'			=> 'front-page-3',
	'name'			=> __( 'Front Page - Widget 3', 'ollieandkay-theme' ),
	'description'	=> __( 'This is a widget area appearing on Front Page.', 'ollieandkay-theme' ),
) );

genesis_register_sidebar( array(
	'id'			=> 'front-page-4',
	'name'			=> __( 'Front Page - Widget 4', 'ollieandkay-theme' ),
	'description'	=> __( 'This is a widget area appearing on Front Page.', 'ollieandkay-theme' ),
) );

genesis_register_sidebar( array(
	'id'			=> 'front-page-5',
	'name'			=> __( 'Front Page - Widget 5', 'ollieandkay-theme' ),
	'description'	=> __( 'This is a widget area appearing on Front Page.', 'ollieandkay-theme' ),
) );

genesis_register_sidebar( array(
	'id'			=> 'front-page-6',
	'name'			=> __( 'Front Page - Widget 6', 'ollieandkay-theme' ),
	'description'	=> __( 'This is a widget area appearing on Front Page.', 'ollieandkay-theme' ),
) );

genesis_register_sidebar( array(
	'id'			=> 'front-page-7',
	'name'			=> __( 'Front Page - Widget 7', 'ollieandkay-theme' ),
	'description'	=> __( 'This is a widget area appearing on Front Page.', 'ollieandkay-theme' ),
) );

genesis_register_sidebar( array(
	'id'			=> 'front-page-8',
	'name'			=> __( 'Front Page - Widget 8', 'ollieandkay-theme' ),
	'description'	=> __( 'This is a widget area appearing on Front Page.', 'ollieandkay-theme' ),
) );

genesis_register_widget_area( array(
	'id'          => 'category-index-1',
	'name'        => __( 'Category Index - Widget 1', 'eleanor-theme' ),
	'description' => __( 'This is a widget area appearing on Category Index page.', 'eleanor-theme' ),
) );

genesis_register_widget_area( array(
	'id'          => 'category-index-2',
	'name'        => __( 'Category Index - Widget 2', 'eleanor-theme' ),
	'description' => __( 'This is a widget area appearing on Category Index page.', 'eleanor-theme' ),
) );

genesis_register_widget_area( array(
	'id'          => 'category-index-3',
	'name'        => __( 'Category Index - Widget 3', 'eleanor-theme' ),
	'description' => __( 'This is a widget area appearing on Category Index page.', 'eleanor-theme' ),
) );

genesis_register_widget_area( array(
	'id'          => 'category-index-4',
	'name'        => __( 'Category Index - Widget 4', 'eleanor-theme' ),
	'description' => __( 'This is a widget area appearing on Category Index page.', 'eleanor-theme' ),
) );

genesis_register_widget_area( array(
	'id'          => 'category-index-5',
	'name'        => __( 'Category Index - Widget 5', 'eleanor-theme' ),
	'description' => __( 'This is a widget area appearing on Category Index page.', 'eleanor-theme' ),
) );

//* Blog Widgets
function ng_home_page_widgets() {
 		if( is_home() && !is_paged() ) {
	genesis_widget_area ('blog-page-1', array(
		'before' => '<div class="blog-page-1 widget-area animated fadeInUp duration2">',
		'after' => '</div>',));
}
	if( is_home() && !is_paged() ) {
	genesis_widget_area ('blog-page-2', array(
		'before' => '<div class="blog-page-2 widget-area animated fadeInUp duration2 eds-on-scroll">',
		'after' => '</div>',));
}
		if( is_home() && !is_paged() ) {
	genesis_widget_area ('blog-page-3', array(
		'before' => '<div class="blog-page-3 widget-area animated fadeInUp duration2 eds-on-scroll">',
		'after' => '</div>',));
}
		if( is_home() && !is_paged() ) {
	genesis_widget_area ('blog-page-4', array(
		'before' => '<div class="blog-page-4 widget-area animated fadeInUp duration2 eds-on-scroll">',
		'after' => '</div>',));
}
		
	}

add_action( 'genesis_before_content', 'ng_home_page_widgets' );

add_action( 'widgets_init', 'ollieandkay_home_widgets' );

 function ollieandkay_home_widgets() {
 genesis_register_sidebar( array(
 'name' => __( 'Blog Page - Widget 1', 'genesis' ),
 'id' => 'blog-page-1',
 'description' => __( 'This is a widget area appearing on blog page.', 'genesis' ),
 ) );
 genesis_register_sidebar( array(
 'name' => __( 'Blog Page - Widget 2', 'genesis' ),
 'id' => 'blog-page-2',
 'description' => __( 'This is a widget area appearing on blog page.', 'genesis' ),
 ) );
 genesis_register_sidebar( array(
 'name' => __( 'Blog Page - Widget 3', 'genesis' ),
 'id' => 'blog-page-3',
 'description' => __( 'This is a widget area appearing on blog page.', 'genesis' ),
 ) );
 genesis_register_sidebar( array(
 'name' => __( 'Blog Page - Widget 4', 'genesis' ),
 'id' => 'blog-page-4',
 'description' => __( 'This is a widget area appearing on blog page.', 'genesis' ),
 ) );
 genesis_register_sidebar( array(
 'name' => __( 'Blog Page - Widget 5', 'genesis' ),
 'id' => 'blog-page-5',
 'description' => __( 'This is a widget area appearing on blog page.', 'genesis' ),
 ) );
 }
