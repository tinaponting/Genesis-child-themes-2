<?php
/**
 * Genesis Sample.
 *
 * This file adds the required CSS to the front end to the Genesis Sample Theme.
 *
 * @package Genesis Sample
 * @author  StudioPress
 * @license GPL-2.0+
 * @link    http://www.studiopress.com/
 */

add_action( 'wp_enqueue_scripts', 'genesis_sample_css' );
/**
* Checks the settings for the link color, and accent color.
* If any of these value are set the appropriate CSS is output.
*
* @since 2.2.3
*/
function genesis_sample_css() {

	$handle  = defined( 'CHILD_THEME_NAME' ) && CHILD_THEME_NAME ? sanitize_title_with_dashes( CHILD_THEME_NAME ) : 'child-theme';
$color_link = get_theme_mod( 'genesis_sample_link_color', genesis_sample_customizer_get_default_link_color() );
$color_accent = get_theme_mod( 'genesis_sample_accent_color', genesis_sample_customizer_get_default_accent_color() );
$color_navbcg = get_theme_mod( 'genesis_sample_navbcg_color', genesis_sample_customizer_get_default_navbcg_color() );
$color_nav = get_theme_mod( 'genesis_sample_nav_color', genesis_sample_customizer_get_default_nav_color() );
$color_navsocial = get_theme_mod( 'genesis_sample_navsocial_color', genesis_sample_customizer_get_default_navsocial_color() );
$color_title = get_theme_mod( 'genesis_sample_title_color', genesis_sample_customizer_get_default_title_color() );
$color_button1 = get_theme_mod( 'genesis_sample_button1_color', genesis_sample_customizer_get_default_button1_color() );
$color_button1h = get_theme_mod( 'genesis_sample_button1h_color', genesis_sample_customizer_get_default_button1h_color() );
$color_button1text = get_theme_mod( 'genesis_sample_button1text_color', genesis_sample_customizer_get_default_button1text_color() );
$color_button1texth = get_theme_mod( 'genesis_sample_button1texth_color', genesis_sample_customizer_get_default_button1texth_color() );
$color_fpabouttitle = get_theme_mod( 'genesis_sample_fpabouttitle_color', genesis_sample_customizer_get_default_fpabouttitle_color() );
$color_subsfooter = get_theme_mod( 'genesis_sample_subsfooter_color', genesis_sample_customizer_get_default_subsfooter_color() );
$color_mainacc = get_theme_mod( 'genesis_sample_mainacc_color', genesis_sample_customizer_get_default_mainacc_color() );
$color_mainl = get_theme_mod( 'genesis_sample_mainl_color', genesis_sample_customizer_get_default_mainl_color() );
$color_sidebarw = get_theme_mod( 'genesis_sample_sidebarw_color', genesis_sample_customizer_get_default_sidebarw_color() );
$color_sidebarssi = get_theme_mod( 'genesis_sample_sidebarssi_color', genesis_sample_customizer_get_default_sidebarssi_color() );
$color_sidebarssih = get_theme_mod( 'genesis_sample_sidebarssih_color', genesis_sample_customizer_get_default_sidebarssih_color() );
$color_mbcta = get_theme_mod( 'genesis_sample_mbcta_color', genesis_sample_customizer_get_default_mbcta_color() );
$color_pagemain = get_theme_mod( 'genesis_sample_pagemain_color', genesis_sample_customizer_get_default_pagemain_color() );
$color_pagemaintext = get_theme_mod( 'genesis_sample_pagemaintext_color', genesis_sample_customizer_get_default_pagemaintext_color() );
$color_pagemainhover = get_theme_mod( 'genesis_sample_pagemainhover_color', genesis_sample_customizer_get_default_pagemainhover_color() );


	$css = '';

$css .= ( genesis_sample_customizer_get_default_navbcg_color() !== $color_navbcg ) ? sprintf( '

		.nav-primary, .menu-toggle, .menu-toggle:hover, .menu-toggle, .menu-toggle:focus, .menu-toggle:hover, .search-div, .footerwidgetheader-container .widget-title, .site-footer
 {
			background: %s;
		}

		', $color_navbcg ) : '';


$css .= ( genesis_sample_customizer_get_default_nav_color() !== $color_nav ) ? sprintf( '

		.genesis-nav-menu a, .menu-toggle:hover, .menu-toggle:focus, .menu-toggle::before, .menu-toggle {
			color: %s;
		}

		', $color_nav ) : '';

$css .= ( genesis_sample_customizer_get_default_navsocial_color() !== $color_navsocial ) ? sprintf( '

		.nav-primary .widget_wpcom_social_media_icons_widget .genericon {
			color: %s;
		}

		', $color_navsocial ) : '';

$css .= ( genesis_sample_customizer_get_default_title_color() !== $color_title ) ? sprintf( '

		.site-title a, .site-title a:focus, .site-title a:hover {
			color: %s;
		}

		', $color_title ) : '';

$css .= ( genesis_sample_customizer_get_default_button1_color() !== $color_button1 ) ? sprintf( '

		.top-info .button {
			background: %s; 
		}


		', $color_button1 ) : '';

$css .= ( genesis_sample_customizer_get_default_button1h_color() !== $color_button1h ) ? sprintf( '

		.top-info .button:hover {
			background: %s;
		}



		', $color_button1h ) : '';

$css .= ( genesis_sample_customizer_get_default_button1text_color() !== $color_button1text ) ? sprintf( '

		.top-info .button {
			color: %s; 
		}


		', $color_button1text ) : '';

$css .= ( genesis_sample_customizer_get_default_button1texth_color() !== $color_button1texth ) ? sprintf( '

		.top-info .button:hover {
			color: %s; 
		}


		', $color_button1texth ) : '';

$css .= ( genesis_sample_customizer_get_default_fpabouttitle_color() !== $color_fpabouttitle ) ? sprintf( '

		.about-subtitle {
			color: %s;
		}

		', $color_fpabouttitle ) : '';

$css .= ( genesis_sample_customizer_get_default_subsfooter_color() !== $color_subsfooter ) ? sprintf( '

		.jetpack_subscription_widget, .enews-widget {
			background: %s;
		}

		', $color_subsfooter ) : '';

$css .= ( genesis_sample_customizer_get_default_mainacc_color() !== $color_mainacc ) ? sprintf( '

		.testimonial_rotator_star, .archive a.more-link, .blog a.more-link, .woocommerce ul.products li.product h3:hover, .woocommerce ul.products li.product .price, .woocommerce div.product p.price, .woocommerce div.product span.price {
			color: %s !important;
		}

		', $color_mainacc ) : '';

$css .= ( genesis_sample_customizer_get_default_mainl_color() !== $color_mainl ) ? sprintf( '

		a, .sidebar .widget.user-profile p a {
			color: %s;
		}

		', $color_mainl ) : '';

$css .= ( genesis_sample_customizer_get_default_sidebarw_color() !== $color_sidebarw ) ? sprintf( '

		.sidebar .widget_search, .sidebar .jetpack_subscription_widget, .sidebar .enews-widget {
			background: %s !important;
		}

		', $color_sidebarw ) : '';

$css .= ( genesis_sample_customizer_get_default_sidebarssi_color() !== $color_sidebarssi ) ? sprintf( '

		.sidebar .simple-social-icons ul li a {
			color: %s !important;
		}

		', $color_sidebarssi ) : '';

$css .= ( genesis_sample_customizer_get_default_sidebarssih_color() !== $color_sidebarssih ) ? sprintf( '

		.sidebar .simple-social-icons ul li a:hover, .simple-social-icons ul li a:focus {
			color: %s !important;
		}

		', $color_sidebarssih ) : '';

$css .= ( genesis_sample_customizer_get_default_mbcta_color() !== $color_mbcta ) ? sprintf( '

		.call-to-action {
			background: %s;
		}

		', $color_mbcta ) : '';

$css .= ( genesis_sample_customizer_get_default_pagemain_color() !== $color_pagemain ) ? sprintf( '

		.page-main {
			border-color: %s;
		}

		', $color_pagemain ) : '';

$css .= ( genesis_sample_customizer_get_default_pagemaintext_color() !== $color_pagemaintext ) ? sprintf( '

		.page-title-2 {
			color: %s;
		}

		', $color_pagemaintext ) : '';

$css .= ( genesis_sample_customizer_get_default_pagemainhover_color() !== $color_pagemainhover ) ? sprintf( '

		.page-main:hover {
			background-color: %s;
		}

		', $color_pagemainhover ) : '';

	$css .= ( genesis_sample_customizer_get_default_link_color() !== $color_link ) ? sprintf( '

		a,
		.entry-title a:focus,
		.entry-title a:hover,
		.genesis-nav-menu a:focus,
		.genesis-nav-menu a:hover,
		.genesis-nav-menu .current-menu-item > a,
		.genesis-nav-menu .sub-menu .current-menu-item > a:focus,
		.genesis-nav-menu .sub-menu .current-menu-item > a:hover,
		.menu-toggle:focus,
		.menu-toggle:hover,
		.sub-menu-toggle:focus,
		.sub-menu-toggle:hover {
			color: %s;
		}

		', $color_link ) : '';

	$css .= ( genesis_sample_customizer_get_default_accent_color() !== $color_accent ) ? sprintf( '

		button:focus,
		button:hover,
		input[type="button"]:focus,
		input[type="button"]:hover,
		input[type="reset"]:focus,
		input[type="reset"]:hover,
		input[type="submit"]:focus,
		input[type="submit"]:hover,
		input[type="reset"]:focus,
		input[type="reset"]:hover,
		input[type="submit"]:focus,
		input[type="submit"]:hover,
		.archive-pagination li a:focus,
		.archive-pagination li a:hover,
		.archive-pagination .active a,
		.button:focus,
		.button:hover,
		.sidebar .enews-widget input[type="submit"] {
			background-color: %s;
			color: %s;
		}
		', $color_accent, genesis_sample_color_contrast( $color_accent ) ) : '';

	if ( $css ) {
		wp_add_inline_style( $handle, $css );
	}

}
