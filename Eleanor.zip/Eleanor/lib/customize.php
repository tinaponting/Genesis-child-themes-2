<?php
/**
 * Genesis Sample.
 *
 * This file adds the Customizer additions to the Genesis Sample Theme.
 *
 * @package Genesis Sample
 * @author  StudioPress
 * @license GPL-2.0+
 * @link    http://www.studiopress.com/
 */

add_action( 'customize_register', 'genesis_sample_customizer_register' );
/**
 * Register settings and controls with the Customizer.
 *
 * @since 2.2.3
 *
 * @param WP_Customize_Manager $wp_customize Customizer object.
 */
function genesis_sample_customizer_register( $wp_customize ) {

$wp_customize->add_setting(
		'genesis_sample_mainacc_color',
		array(
			'default'           => genesis_sample_customizer_get_default_mainacc_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'genesis_sample_mainacc_color',
			array(
				'description' => __( 'Accent color will be applied to Read More links on archive pages, prices on shop page and testimonial stars.', 'genesis-sample' ),
			    'label'       => __( 'Accent color', 'genesis-sample' ),
			    'section'     => 'colors',
			    'settings'    => 'genesis_sample_mainacc_color',
			)
		)
	);

$wp_customize->add_setting(
		'genesis_sample_mainl_color',
		array(
			'default'           => genesis_sample_customizer_get_default_mainl_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'genesis_sample_mainl_color',
			array(
				'description' => __( 'Change the color of the links appearing in post or page content as well as Read More link in Profile widget.', 'genesis-sample' ),
			    'label'       => __( 'Link Color', 'genesis-sample' ),
			    'section'     => 'colors',
			    'settings'    => 'genesis_sample_mainl_color',
			)
		)
	);

$wp_customize->add_setting(
		'genesis_sample_navbcg_color',
		array(
			'default'           => genesis_sample_customizer_get_default_navbcg_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'genesis_sample_navbcg_color',
			array(
				'description' => __( 'Change the menu background color.', 'genesis-sample' ),
			    'label'       => __( 'Navigation Background Color', 'genesis-sample' ),
			    'section'     => 'colors',
			    'settings'    => 'genesis_sample_navbcg_color',
			)
		)
	);

$wp_customize->add_setting(
		'genesis_sample_nav_color',
		array(
			'default'           => genesis_sample_customizer_get_default_nav_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'genesis_sample_nav_color',
			array(
				'description' => __( 'Change the menu text color.', 'genesis-sample' ),
			    'label'       => __( 'Navigation Text Color', 'genesis-sample' ),
			    'section'     => 'colors',
			    'settings'    => 'genesis_sample_nav_color',
			)
		)
	);

$wp_customize->add_setting(
		'genesis_sample_navsocial_color',
		array(
			'default'           => genesis_sample_customizer_get_default_navsocial_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'genesis_sample_navsocial_color',
			array(
				'description' => __( 'Change the social icons color.', 'genesis-sample' ),
			    'label'       => __( 'Social Icons Color - Menu', 'genesis-sample' ),
			    'section'     => 'colors',
			    'settings'    => 'genesis_sample_navsocial_color',
			)
		)
	);

$wp_customize->add_setting(
		'genesis_sample_title_color',
		array(
			'default'           => genesis_sample_customizer_get_default_title_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'genesis_sample_title_color',
			array(
				'description' => __( 'Change the site title text color.', 'genesis-sample' ),
			    'label'       => __( 'Site title color', 'genesis-sample' ),
			    'section'     => 'colors',
			    'settings'    => 'genesis_sample_title_color',
			)
		)
	);

$wp_customize->add_setting(
		'genesis_sample_button1_color',
		array(
			'default'           => genesis_sample_customizer_get_default_button1_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'genesis_sample_button1_color',
			array(
				'description' => __( 'Change the button color.', 'genesis-sample' ),
			    'label'       => __( 'Front Page - Top Image Widget - Button Background Color', 'genesis-sample' ),
			    'section'     => 'colors',
			    'settings'    => 'genesis_sample_button1_color',
			)
		)
	);


$wp_customize->add_setting(
		'genesis_sample_button1h_color',
		array(
			'default'           => genesis_sample_customizer_get_default_button1h_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'genesis_sample_button1h_color',
			array(
				'description' => __( 'Change the button color on hover.', 'genesis-sample' ),
			    'label'       => __( 'Front Page - Top Image Widget - Button Background on Hover', 'genesis-sample' ),
			    'section'     => 'colors',
			    'settings'    => 'genesis_sample_button1h_color',
			)
		)
	);

$wp_customize->add_setting(
		'genesis_sample_button1text_color',
		array(
			'default'           => genesis_sample_customizer_get_default_button1text_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'genesis_sample_button1text_color',
			array(
				'description' => __( 'Change the button color.', 'genesis-sample' ),
			    'label'       => __( 'Front Page - Top Image Widget - Button Text Color', 'genesis-sample' ),
			    'section'     => 'colors',
			    'settings'    => 'genesis_sample_button1text_color',
			)
		)
	);


$wp_customize->add_setting(
		'genesis_sample_button1texth_color',
		array(
			'default'           => genesis_sample_customizer_get_default_button1texth_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'genesis_sample_button1texth_color',
			array(
				'description' => __( 'Change the button color.', 'genesis-sample' ),
			    'label'       => __( 'Front Page - Top Image Widget - Button Text Color on Hover', 'genesis-sample' ),
			    'section'     => 'colors',
			    'settings'    => 'genesis_sample_button1texth_color',
			)
		)
	);

$wp_customize->add_setting(
		'genesis_sample_fpabouttitle_color',
		array(
			'default'           => genesis_sample_customizer_get_default_fpabouttitle_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'genesis_sample_fpabouttitle_color',
			array(
				'description' => __( 'Change the title color.', 'genesis-sample' ),
			    'label'       => __( 'Front Page - About You Widget - Title', 'genesis-sample' ),
			    'section'     => 'colors',
			    'settings'    => 'genesis_sample_fpabouttitle_color',
			)
		)
	);

$wp_customize->add_setting(
		'genesis_sample_subsfooter_color',
		array(
			'default'           => genesis_sample_customizer_get_default_subsfooter_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'genesis_sample_subsfooter_color',
			array(
				'description' => __( 'Change the background of subscription widget in footer.', 'genesis-sample' ),
			    'label'       => __( 'Front Page - Subscription Widget', 'genesis-sample' ),
			    'section'     => 'colors',
			    'settings'    => 'genesis_sample_subsfooter_color',
			)
		)
	);

$wp_customize->add_setting(
		'genesis_sample_sidebarw_color',
		array(
			'default'           => genesis_sample_customizer_get_default_sidebarw_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'genesis_sample_sidebarw_color',
			array(
				'description' => __( 'Change the background of widgets in the sidebar.', 'genesis-sample' ),
			    'label'       => __( 'Sidebar Widgets Background', 'genesis-sample' ),
			    'section'     => 'colors',
			    'settings'    => 'genesis_sample_sidebarw_color',
			)
		)
	);


$wp_customize->add_setting(
		'genesis_sample_sidebarssi_color',
		array(
			'default'           => genesis_sample_customizer_get_default_sidebarssi_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'genesis_sample_sidebarssi_color',
			array(
				'description' => __( 'Change the color of social icons in the sidebar.', 'genesis-sample' ),
			    'label'       => __( 'Social Icons Color - Sidebar', 'genesis-sample' ),
			    'section'     => 'colors',
			    'settings'    => 'genesis_sample_sidebarssi_color',
			)
		)
	);

$wp_customize->add_setting(
		'genesis_sample_sidebarssih_color',
		array(
			'default'           => genesis_sample_customizer_get_default_sidebarssih_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'genesis_sample_sidebarssih_color',
			array(
				'description' => __( 'Change the color of social icons (on hover) in the sidebar.', 'genesis-sample' ),
			    'label'       => __( 'Social Icons Color on Hover - Sidebar', 'genesis-sample' ),
			    'section'     => 'colors',
			    'settings'    => 'genesis_sample_sidebarssih_color',
			)
		)
	);

$wp_customize->add_setting(
		'genesis_sample_mbcta_color',
		array(
			'default'           => genesis_sample_customizer_get_default_mbcta_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'genesis_sample_mbcta_color',
			array(
				'description' => __( 'Change the background color of call to action box.', 'genesis-sample' ),
			    'label'       => __( 'Call to Action Box - Background Color', 'genesis-sample' ),
			    'section'     => 'colors',
			    'settings'    => 'genesis_sample_mbcta_color',
			)
		)
	);

$wp_customize->add_setting(
		'genesis_sample_pagemain_color',
		array(
			'default'           => genesis_sample_customizer_get_default_pagemain_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'genesis_sample_pagemain_color',
			array(
				'description' => __( 'Change the border color of the box linking to a page.', 'genesis-sample' ),
			    'label'       => __( 'Box Linking to a Page - Border Color', 'genesis-sample' ),
			    'section'     => 'colors',
			    'settings'    => 'genesis_sample_pagemain_color',
			)
		)
	);

$wp_customize->add_setting(
		'genesis_sample_pagemaintext_color',
		array(
			'default'           => genesis_sample_customizer_get_default_pagemaintext_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'genesis_sample_pagemaintext_color',
			array(
				'description' => __( 'Change the color of the text appearing in the box linking to a page.', 'genesis-sample' ),
			    'label'       => __( 'Box Linking to a Page - Text Color', 'genesis-sample' ),
			    'section'     => 'colors',
			    'settings'    => 'genesis_sample_pagemaintext_color',
			)
		)
	);

$wp_customize->add_setting(
		'genesis_sample_pagemainhover_color',
		array(
			'default'           => genesis_sample_customizer_get_default_pagemainhover_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'genesis_sample_pagemainhover_color',
			array(
				'description' => __( 'Change the background color on hover of the box linking to a page.', 'genesis-sample' ),
			    'label'       => __( 'Box Linking to a Page - Background Color on Hover', 'genesis-sample' ),
			    'section'     => 'colors',
			    'settings'    => 'genesis_sample_pagemainhover_color',
			)
		)
	);

}
