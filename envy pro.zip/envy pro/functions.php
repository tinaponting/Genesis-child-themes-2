<?php
//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );

//* Child theme (do not remove)
define( 'CHILD_THEME_NAME', 'Envy Pro' );
define( 'CHILD_THEME_URL', 'http://envy.krolyn.com' );
define( 'CHILD_THEME_VERSION', '1.0.2' );

//* Set localization (do not remove)
load_child_theme_textdomain( 'envy-pro', apply_filters( 'child_theme_textdomain', get_stylesheet_directory() . '/lib/languages', 'envy-pro' ) );

//* Enqueue scripts
add_action( 'wp_enqueue_scripts', 'envy_scripts' );
function envy_scripts() {
	wp_enqueue_script( 'main-js', get_stylesheet_directory_uri() . '/lib/js/main.js', array( 'jquery' ), '1.0.2' );
	wp_enqueue_style( 'google-fonts', '//fonts.googleapis.com/css?family=Lato:300,400,700', array(), CHILD_THEME_VERSION );
	wp_enqueue_style( 'font-awesome', '//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css' );
}

//* Add html5 markup structure
add_theme_support( 'html5' );

//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Add theme support for 4-column footer widgets
add_theme_support( 'genesis-footer-widgets', 4 );

//* Add support for custom header
add_theme_support( 'custom-header', array( 'width' => 250, 'height' => 70, 'header-selector' => '.site-title a', 'header-text' => false ) );

//* Add theme support for custom background
add_theme_support( 'custom-background' );

//* Add theme support for additional color style options
add_theme_support( 'genesis-style-selector', array(
	'envy-pro-green'  => __( 'Green With Envy Pro', 'envy-pro' ),
	'envy-pro-orange'  => __( 'Orange With Envy Pro', 'envy-pro' ),
	'envy-pro-purple'  => __( 'Purple With Envy Pro', 'envy-pro' ),
	'envy-pro-pink'  => __( 'Pink With Envy Pro', 'envy-pro' ),
	'envy-pro-blue'  =>  __( 'Blue With Envy Pro', 'envy-pro' ),
) );

//* Enable shortcodes in widgets
add_filter('widget_text', 'do_shortcode');

//* Remove the site description
remove_action( 'genesis_site_description', 'genesis_seo_site_description' );

//* Unregister site layouts
genesis_unregister_layout( 'content-sidebar-sidebar' );
genesis_unregister_layout( 'sidebar-sidebar-content' );
genesis_unregister_layout( 'sidebar-content-sidebar' );

//* Relocate secondary sidebar to before loop and append (top)
unregister_sidebar( 'sidebar-alt' );
genesis_register_sidebar( array(
	'id' 			=> 'sidebar-alt',
	'name' 			=> __( 'Secondary Sidebar (Topbar)', 'envy-pro' ),
	'description'	=> __( 'This is the secondary sidebar (topbar). This widget area appears above the content and is useful for displaying priority data on smaller screens.', 'envy-pro' ),
) );
remove_action( 'genesis_after_content', 'genesis_get_sidebar_alt' );
add_action( 'genesis_before_loop', 'genesis_get_sidebar_alt' );

//* Register new layouts with secondary sidebar (topbar)
genesis_register_layout( 'topbar-content-sidebar', array(
	'label' => __('Topbar/Content/Sidebar', 'envy-pro'),
	'img' => get_stylesheet_directory_uri() . '/lib/icons/tcs.gif'
) );
genesis_register_layout( 'sidebar-topbar-content', array(
	'label' => __('Sidebar/Topbar/Content', 'envy-pro'),
	'img' => get_stylesheet_directory_uri() . '/lib/icons/stc.gif'
) );

//* Register widget areas
genesis_register_sidebar( array(
	'id'			=> 'home-slider',
	'name'			=> __( 'Home Slider', 'envy-pro' ),
	'description'	=> __( 'This is the Slider (full-width) section of the homepage.', 'envy-pro' ),
) );
genesis_register_sidebar( array(
	'id'			=> 'home-featured-products',
	'name'			=> __( 'Home Featured Products', 'envy-pro' ),
	'description'	=> __( 'This is the Featured Products (full-width) section of the homepage.', 'envy-pro' ),
) );
genesis_register_sidebar( array(
	'id'			=> 'home-featured-boxes',
	'name'			=> __( 'Home Featured Boxes', 'envy-pro' ),
	'description'	=> __( 'This is the Featured Boxes (full-width) section of the homepage.', 'envy-pro' ),
) );
genesis_register_sidebar( array(
	'id'			=> 'call-to-action',
	'name'			=> __( 'Home Call-to-Action', 'envy-pro' ),
	'description'	=> __( 'This is Call-to-Action (full-width) section of the homepage.', 'envy-pro' ),
) );
genesis_register_sidebar( array(
	'id'			=> 'home-featured-content',
	'name'			=> __( 'Home Featured Content', 'envy-pro' ),
	'description'	=> __( 'This is the Featured Content section of the homepage.', 'envy-pro' ),
) );
genesis_register_sidebar( array(
	'id'			=> 'logos-categories',
	'name'			=> __( 'Logos / Categories', 'envy-pro' ),
	'description'	=> __( 'This is the Logos or Categories (full-width) section.', 'envy-pro' ),
) );

//* Add logos-categories widget area above footer
add_action( 'genesis_before_footer', 'categories_widget' );
function categories_widget() {
	genesis_widget_area( 'logos-categories', array(
		'before' => '<div class="logos-categories widget-area"><div class="wrap">',
		'after'  => '</div></div>',
	) );
}
remove_action( 'genesis_before_footer', 'genesis_footer_widget_areas' );
add_action( 'genesis_before_footer', 'genesis_footer_widget_areas' );

//* Add new image sizes
add_image_size( 'featured', 850, 420, TRUE );
add_image_size( 'icon', 45, 45, TRUE );

//* Relocate featured image above titles
remove_action( 'genesis_entry_content', 'genesis_do_post_image', 8 );
add_action( 'genesis_entry_header', 'genesis_do_post_image', 1 );

//* Position secondary menu before header
remove_action( 'genesis_after_header', 'genesis_do_subnav' );
add_action( 'genesis_before_header', 'genesis_do_subnav' );

//* Set Genesis Responsive Slider defaults
add_filter( 'genesis_responsive_slider_settings_defaults', 'envy_pro_responsive_slider_defaults' );
function envy_pro_responsive_slider_defaults( $defaults ) { 
	$args = array( 
		'posts_term'                      => 'category_name,slider',
		'posts_num'                       => 3,
		'slideshow_pager'		  	      => 0,
		'slideshow_height'                => 800,
		'slideshow_width'                 => 1200,
		'slideshow_excerpt_content'       => 'full',
		'slideshow_excerpt_content_limit' => '',
		'slideshow_more_text'             => __( 'More Details', 'envy-pro' ),
		'slideshow_excerpt_width'         => 100,
		'slideshow_title_show'            => 1,
		'location_horizontal'             => 'right',
		'location_vertical'               => 'bottom'
	);
	$args = wp_parse_args( $args, $defaults );
	return $args;
}
 
//* Customize search form placeholder and button text
add_filter( 'genesis_search_text', 'envy_pro_search_text' );
function envy_pro_search_text( $text ) {
	return esc_attr( __('Website search', 'envy-pro') );
}
add_filter( 'genesis_search_button_text', 'envy_pro_search_button' );
function envy_pro_search_button( $text ) {
	return esc_attr( '&#xf002;', 'envy-pro' );
}

//* Modify more links
add_filter( 'excerpt_more', 'envy_pro_more_link' );
function envy_pro_more_link() {
	return ' &hellip;<a class="more-link" href="' . get_permalink() . '">' . __('Read More', 'envy-pro') . '</a>';
}
add_filter( 'the_content_more_link', 'envy_pro_read_more_link' );
function envy_pro_read_more_link() {
	return ' <a class="more-link" href="' . get_permalink() . '">' . __('Read More', 'envy-pro') . '</a>';
}

//* Change archive pagination previous and next texts
add_filter( 'genesis_prev_link_text', 'envy_pro_prev_link_text' );
function envy_pro_prev_link_text() {
	$prevlink = '';
	return $prevlink;
}
add_filter( 'genesis_next_link_text', 'envy_pro_next_link_text' );
function envy_pro_next_link_text() {
	$nextlink = '';
	return $nextlink;
}


/**
 * WooCommerce functions
 */
 
//* Add theme support for WooCommerce
add_theme_support( 'genesis-connect-woocommerce' );
 
//* Add custom stylesheet for WooCommerce
add_action('wp_enqueue_scripts', 'envy_pro_woocommerce_styles');
function envy_pro_woocommerce_styles() {
wp_enqueue_style( 'woocommerce-styling', get_stylesheet_directory_uri() . '/woocommerce/woocommerce.css' );
}

//* Redefine WooCommerce default image sizes
global $pagenow;
if ( is_admin() && isset( $_GET['activated'] ) && $pagenow == 'themes.php' ) add_action( 'init', 'envy_pro_woocommerce_image_dimensions', 1 );
 function envy_pro_woocommerce_image_dimensions() {
  	$catalog = array(
		'width' 	=> '320',
		'height'	=> '320',
		'crop'		=> 1
	); 
	$single = array(
		'width' 	=> '440',
		'height'	=> '440',
		'crop'		=> 1
	);
	$thumbnail = array(
		'width' 	=> '90',
		'height'	=> '90',
		'crop'		=> 0
	);
	update_option( 'shop_catalog_image_size', $catalog );
	update_option( 'shop_single_image_size', $single );
	update_option( 'shop_thumbnail_image_size', $thumbnail );
}

//* Customize WooCommerce product search form
add_filter( 'get_product_search_form' , 'envy_pro_product_searchform' );
function envy_pro_product_searchform( $form ) {
	$form = '<form role="search" method="get" id="searchform" action="' . esc_url( home_url( '/'  ) ) . '">
		<div>
			<input type="text" value="' . get_search_query() . '" name="s" id="s" placeholder="' . __( 'Product search', 'envy-pro' ) . '" />
			<input type="submit" id="searchsubmit" value="'. esc_attr__( '&#xf002;', 'envy-pro' ) .'" />
			<input type="hidden" name="post_type" value="product" />
		</div>
	</form>';
	return $form;	
}

//* Set number of products per row
add_filter('loop_shop_columns', 'loop_columns');
if (!function_exists('loop_columns')) {
	$cols = 3;
	function loop_columns() {
		global $cols;
		return $cols;
	}
	//* Add 'columns-' body class to assign widths
	add_filter( 'body_class', 'loop_columns_body_class' );
	function loop_columns_body_class( $classes ) {
		global $cols;
		$classes[] = 'columns-' . $cols;
		return $classes;
	}
}

//* Display 12 products per page maximum
add_filter( 'loop_shop_per_page', create_function( '$cols', 'return 12;' ), 20 );

//* Replace default placeholder image with custom image
add_action( 'init', 'envy_pro_custom_thumbnail' );
function envy_pro_custom_thumbnail() {
	add_filter('woocommerce_placeholder_img_src', 'envy_pro_custom_placeholder_img_src');   
	function envy_pro_custom_placeholder_img_src( $src ) {
		$src = get_stylesheet_directory_uri() . '/images/placeholder.gif';	 
		return $src;
	}
}

//* Replace WooCommerce pagination with Genesis pagination
remove_action( 'woocommerce_after_shop_loop', 'woocommerce_pagination', 10 );
add_action( 'woocommerce_after_shop_loop', 'genesis_posts_nav', 10 );