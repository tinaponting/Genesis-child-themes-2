<?php
/**
 * This file adds the Home Page to the Envy Pro theme.
 *
 */
 
add_action( 'genesis_meta', 'envy_pro_home_genesis_meta' );
/**
 * Add widget support for homepage. If no widgets active, display the default home page and loop.
 *
 */
function envy_pro_home_genesis_meta() {

	if ( is_active_sidebar( 'home-slider' ) || is_active_sidebar( 'home-featured-products' ) || is_active_sidebar( 'home-featured-boxes' ) || is_active_sidebar( 'call-to-action' ) || is_active_sidebar( 'home-featured-content' ) ) {

		remove_action( 'genesis_loop', 'genesis_do_loop' );
		add_action( 'genesis_after_header', 'envy_pro_after_header_sections' );
		add_action( 'genesis_loop', 'envy_pro_loop_sections' );
		add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_content_sidebar' );
		add_filter( 'body_class', 'envy_pro_add_home_body_class' );

	}
	
}

//* Add slider, featured products, featured boxes and call-to-action widgets below header
function envy_pro_after_header_sections () {
	
	genesis_widget_area( 'home-slider', array(
		'before' => '<div class="home-slider widget-area full"><div class="wrap">',
		'after'  => '</div></div>',
	) );
	
	genesis_widget_area( 'home-featured-products', array(
		'before' => '<div class="home-featured-products widget-area"><div class="wrap">',
		'after'  => '</div></div>',
	) );
	
	genesis_widget_area( 'home-featured-boxes', array(
		'before' => '<div class="home-featured-boxes widget-area"><div class="wrap">',
		'after'  => '</div></div>',
	) );
	
	genesis_widget_area( 'call-to-action', array(
		'before' => '<div class="call-to-action widget-area"><div class="wrap">',
		'after'  => '</div></div>',
	) );

}

//* Add featured content to loop
function envy_pro_loop_sections() {

	genesis_widget_area( 'home-featured-content', array(
		'before' => '<div class="home-featured-content widget-area">',
		'after'  => '</div>',
	) );
	
}

//* Add body class to home page		
function envy_pro_add_home_body_class( $classes ) {

	$classes[] = 'envy-pro-home';
	return $classes;
	
}

genesis();
