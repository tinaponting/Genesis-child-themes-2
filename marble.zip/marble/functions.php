<?php
/**
 * BloomBlogShop
 * @package      BloomBlogShop
 */
/**
 * Set up the content width value based on the theme's design.
 */
if ( ! isset( $content_width ) )
    $content_width = 740;

/**
 * Theme setup.
 *
 * Attach all of the site-wide functions to the correct hooks and filters. All
 * the functions themselves are defined below this setup function.
 */

function jt_child_theme_setup() {

    // Genesis & Sensei Specific Changes
    include_once( get_stylesheet_directory() . '/inc/genesis-changes.php' );

    // Adds customizer support
    include_once( get_stylesheet_directory() . '/inc/customizer.php' );

    // Editor Styles
    add_editor_style( 'css/editor-style.css' );

    // Global enqueues
    add_action( 'wp_enqueue_scripts', 'jt_global_enqueues' );

    // Header
    add_theme_support( 'custom-header', array(
        'header-selector' => '.site-title',
        'height'          => 120,
        'width'           => 320,
        'header-text'     => false
    ) );

    // Register Widgets
    add_action( 'widgets_init', 'jt_register_widget_areas' );

    // Add Home Widgets
    add_action( 'genesis_before_content', 'jt_home_widgets', 5 );

    // Footer
    remove_action( 'genesis_footer', 'genesis_do_footer' );
    add_action( 'genesis_footer', 'jt_footer' );

}
add_action( 'genesis_setup', 'jt_child_theme_setup', 15 );

/**
 * Global enqueues
 *
 * @since  1.0.0
 * @global array $wp_styles
 */
function jt_global_enqueues() {

    // javascript
    wp_enqueue_script( 'fitvids', get_stylesheet_directory_uri() . '/js/jquery.fitvids.js', array( 'jquery' ), '1.1', true );
    wp_enqueue_script( 'jt-global', get_stylesheet_directory_uri() . '/js/global.js', array( 'jquery', 'fitvids' ), '1.0', true );
    wp_enqueue_script( 'headhesive', get_stylesheet_directory_uri() . '/js/headhesive.min.js', array( 'jquery' ), null, true );
    wp_enqueue_script( 'jt-responsive-menu', get_stylesheet_directory_uri() . '/js/responsive-menu.js', array( 'jquery' ), '1.0', true );

    // css
    wp_enqueue_style( 'dashicons' );
    wp_enqueue_style( 'fonts', 'http://fonts.googleapis.com/css?family=Karla:400,400italic,700,700italic' );
}

/**
 * Register Widget Areas
 *
 */

function jt_register_widget_areas() {

    genesis_register_sidebar( array(
        'id'            => 'featured',
        'name'          => 'Featured',
        'description'   => 'This is the featured section on the home page.'
    ));
    genesis_register_sidebar( array(
        'id'            => 'home-middle-1',
        'name'          => 'Home Middle 1',
        'description'   => 'This is the first third of the home middle section.'
    ));
    genesis_register_sidebar( array(
        'id'            => 'home-middle-2',
        'name'          => 'Home Middle 2',
        'description'   => 'This is the second third of the home middle section.'
    ));
    genesis_register_sidebar( array(
        'id'            => 'home-middle-3',
        'name'          => 'Home Middle 3',
        'description'   => 'This is the last third of the home middle section.'
    ));
}

// Home Page Widget

function jt_home_widgets() {
    if ( is_home() && is_front_page() ) {
        if ( is_active_sidebar( 'featured' ) ) {
            genesis_widget_area ( 'featured', array(
                'before' => '<div class="featured-widget">',
                'after'  => '</div>',
            ));
        }

        if ( is_active_sidebar( 'home-middle-1' ) ) {
            genesis_widget_area ( 'home-middle-1', array(
                'before' => '<div class="home-middle-1 one-third first">',
                'after'  => '</div>',
            ));
        }

        if ( is_active_sidebar( 'home-middle-2' ) ) {
            genesis_widget_area ( 'home-middle-2', array(
                'before' => '<div class="home-middle-2 one-third">',
                'after'  => '</div>',
            ));
        }

        if ( is_active_sidebar( 'home-middle-3' ) ) {
            genesis_widget_area ( 'home-middle-3', array(
                'before' => '<div class="home-middle-3 one-third">',
                'after'  => '</div>',
            ));
        }
    }
}



/**
 * Footer
 *
 */

// Copyright
function jt_footer() {
    echo '<p class="site-creds">&copy; Copyright ' . date("Y") . '. ' . get_bloginfo( 'name' ) . '. All Rights Reserved. Madly made by <a href="http://exempel.se/">MY OWN DESIGN!/a>.</p>';
}