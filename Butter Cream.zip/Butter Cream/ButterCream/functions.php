<?php
//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );

//* Set Localization (do not remove)
load_child_theme_textdomain( 'butter', apply_filters( 'child_theme_textdomain', get_stylesheet_directory() . '/languages', 'butter' ) );

//* Child theme (do not remove)
define( 'CHILD_THEME_NAME', __( 'Butter Cream Theme', 'butter' ) );
define( 'CHILD_THEME_VERSION', '2.0.0' );

//* Add HTML5 markup structure
add_theme_support( 'html5' );

//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Enqueue Google fonts
add_action( 'wp_enqueue_scripts', 'butter_google_fonts' );
function butter_google_fonts() {wp_enqueue_style( 'google-font', '//fonts.googleapis.com/css?family=Oswald:400', array(), CHILD_THEME_VERSION );
}
//* Enqueue Backstretch script and prepare images for loading
add_action( 'wp_enqueue_scripts', 'butter_enqueue_scripts' );
function butter_enqueue_scripts() {
	if ( ! get_background_image() )return;
	wp_enqueue_script( 'butter-cream-backstretch', get_bloginfo( 'stylesheet_directory' ) . '/js/backstretch.js', array( 'jquery' ), '1.0.0' );
	wp_enqueue_script( 'butter-cream-backstretch-set', get_bloginfo('stylesheet_directory').'/js/backstretch-set.js' , array( 'jquery', 'butter-cream-backstretch' ), '1.0.0' );
	wp_localize_script( 'butter-cream-backstretch-set', 'BackStretchImg', array( 'src' => get_background_image() ) );
}
//* Add custom background callback for background color
function butter_background_callback() {
	if ( ! get_background_color() )return;printf( '<style>body { background-color: #%s; }</style>' . "\n", get_background_color() );
}
//* Add new image sizes
add_image_size( 'home-bottom', 150, 150, TRUE );
add_image_size( 'home-middle', 332, 190, TRUE );
add_image_size( 'home-top', 700, 400, TRUE );

//* Add support for custom background
add_theme_support( 'custom-background', array( 'wp-head-callback' => 'butter_background_callback' ) );

/** Add support for custom header */
/* add_theme_support( 'custom-header', array(
	'width'=> 270,
	'height'=> 80,
	'header-selector'=> '.site-title a',
	'header-text'=> false
)); */
//* Add support for additional color style options
add_theme_support( 'genesis-style-selector', array(
	'butter-cream-purple'=> __( 'Purple', 'butter' ),
	'butter-cream-green'=> __( 'Green', 'butter' ),
	'butter-cream-gray'=> __( 'Gray', 'butter' ),
	'butter-cream-Gold'=> __( 'Gold', 'butter' ),
));
//* Add support for 3-column footer widgets
add_theme_support( 'genesis-footer-widgets', 3 );

//* Remove the site description
remove_action( 'genesis_site_description', 'genesis_seo_site_description' );

//* Reposition the secondary navigation
remove_action( 'genesis_after_header', 'genesis_do_subnav' );
add_action( 'genesis_before', 'genesis_do_subnav' );

//* Hooks after-entry widget area to single posts
add_action( 'genesis_entry_footer', 'butter_after_post'  ); 
function butter_after_post() {
    if ( ! is_singular( 'post' ) )return;
    genesis_widget_area( 'after-entry', array(
		'before'=> '<div class="after-entry widget-area"><div class="wrap">',
		'after'=> '</div></div>',
    ));}
//* Reposition the footer widgets
remove_action( 'genesis_before_footer', 'genesis_footer_widget_areas' );
add_action( 'genesis_after', 'genesis_footer_widget_areas' );

//* Reposition the footer
remove_action( 'genesis_footer', 'genesis_footer_markup_open', 5 );
remove_action( 'genesis_footer', 'genesis_do_footer' );
remove_action( 'genesis_footer', 'genesis_footer_markup_close', 15 );
add_action( 'genesis_after', 'genesis_footer_markup_open', 11 );
add_action( 'genesis_after', 'genesis_do_footer', 12 );
add_action( 'genesis_after', 'genesis_footer_markup_close', 13 );
genesis_register_sidebar( array(
	'id'=> 'home-top',
	'name'=> __( 'Home - Top', 'butter' ),
	'description'=> __( 'This is the top section of the homepage.', 'butter' ),
));
genesis_register_sidebar( array(
	'id'=> 'home-middle-left',
	'name'=> __( 'Home - Middle Left', 'butter' ),
	'description'=> __( 'This is the middle left section of the homepage.', 'butter' ),
));
genesis_register_sidebar( array(
	'id'=> 'home-middle-right',
	'name'=> __( 'Home - Middle Right', 'butter' ),
	'description'=> __( 'This is the middle right section of the homepage.', 'butter' ),
));
genesis_register_sidebar( array(
	'id'=> 'home-bottom',
	'name'=> __( 'Home - Bottom', 'butter' ),
	'description'=> __( 'This is the bottom section of the homepage.', 'butter' ),
));
genesis_register_sidebar( array(
	'id'=> 'after-entry',
	'name'=> __( 'After Entry', 'butter' ),
	'description'=> __( 'This is the after entry section.', 'butter' ),
));
/**
 * Filter the genesis_seo_site_title function to use an image for the logo instead of a background image
 */
	add_filter( 'genesis_seo_title', 'bhww_filter_genesis_seo_site_title', 10, 2 );
	function bhww_filter_genesis_seo_site_title( $title, $inside ){	 
		$child_inside = sprintf( '<a href="%s" title="%s"><img src="'. get_stylesheet_directory_uri() .'/images/logo.png" title="%s" alt="%s"/></a>', trailingslashit( home_url() ), esc_attr( get_bloginfo( 'name' ) ), esc_attr( get_bloginfo( 'name' ) ), esc_attr( get_bloginfo( 'name' ) ) );
		$title = str_replace( $inside, $child_inside, $title );	 return $title;		
	} 	
//* Change the footer text
add_filter('genesis_footer_creds_text', 'sp_footer_creds_filter');
function sp_footer_creds_filter( $creds ) {$creds = '[footer_copyright] &middot; <a href="https://exempel.se">MY OWN DESIGN</a>';	return $creds;
}