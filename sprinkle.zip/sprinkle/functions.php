<?php
//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );

//* Enqueue Lato Google font
add_action( 'wp_enqueue_scripts', 'genesis_sample_google_fonts' );
function genesis_sample_google_fonts() {
	wp_enqueue_script( 'sprinkle-responsive-menu', get_bloginfo( 'stylesheet_directory' ) . '/js/responsive-menu.js', array( 'jquery' ), '1.0.0' );
	wp_enqueue_style( 'google-font', '//fonts.googleapis.com/css?family=Lato:300,700|Playfair+Display', array() );
}

//* Enqueue Dashicons
add_action( 'wp_enqueue_scripts', 'enqueue_dashicons' );
function enqueue_dashicons() {

	wp_enqueue_style( 'dashicons' );

}

//* Reposition enqueue of css file
remove_action( 'genesis_meta', 'genesis_load_stylesheet' );
add_action( 'wp_enqueue_scripts', 'genesis_enqueue_main_stylesheet', 15 );

//* Add HTML5 markup structure
add_theme_support( 'html5' );

//* Add new image sizes
add_image_size( 'featured', 460, 300, TRUE );
add_image_size( 'home-middle', 365, 150, TRUE );
add_image_size( 'sidebar', 280, 150, TRUE );


//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Add support for custom background
add_theme_support( 'custom-background' );

//* Add support for custom header
add_theme_support( 'custom-header', array(
	'width'           => 500,
	'height'          => 150,
	'header-selector' => '.site-title a',
	'header-text'     => false
) );

//* Add support for 3-column footer widgets
add_theme_support( 'genesis-footer-widgets', 3 );

//* Remove the header right widget area
unregister_sidebar( 'header-right' );

//* Add support for additional color style options
add_theme_support( 'genesis-style-selector', array(
	'sprinkle-gold'         => __( 'Gold', 'sprinkle' ),
	'sprinkle-fashionista'  => __( 'Fashionista', 'sprinkle' ),
	'sprinkle-navy'         => __( 'Navy', 'sprinkle' ),
	'sprinkle-joyful'       => __( 'Joyful', 'sprinkle' ),
	'sprinkle-fucshia '     => __( 'Fucshia', 'sprinkle' ),
	'sprinkle-natural'      => __( 'Natural', 'sprinkle' ),
) );

//* Reposition the secondary navigation
remove_action( 'genesis_after_header', 'genesis_do_subnav' );
add_action( 'genesis_before', 'genesis_do_subnav' );

//* Hooks home top section widget area to home page
add_action( 'genesis_meta', 'sprinkle_home_featured' );
/**
 * Add widget support for homepage. If no widgets active, display the default loop.
 *
 */
function sprinkle_home_featured() {

	if ( is_front_page() & is_active_sidebar( 'home-slider' ) ) {

		add_action( 'genesis_after_header', 'sprinkle_home_top' );

	}
	
}

function sprinkle_home_top() {

	echo '<div class="home-top-feature"><div class="wrap">';
    	
    echo '<div class="home-top"><div class="wrap">';

    genesis_widget_area( 'home-slider', array(
		'before' => '<div class="home-slider widget-area"><div class="wrap">',
		'after'  => '</div></div>',
    ) );
    
    genesis_widget_area( 'home-cta', array(
		'before' => '<div class="home-cta widget-area"><div class="wrap">',
		'after'  => '</div></div>',
    ) );
    
    echo '</div></div>';
    
    echo '<div class="home-middle"><div class="wrap">';

    genesis_widget_area( 'home-middle-left', array(
		'before' => '<div class="home-middle-left widget-area"><div class="wrap">',
		'after'  => '</div></div>',
    ) );
    
    genesis_widget_area( 'home-middle-middle', array(
		'before' => '<div class="home-middle-middle widget-area"><div class="wrap">',
		'after'  => '</div></div>',
    ) );
    
     genesis_widget_area( 'home-middle-right', array(
		'before' => '<div class="home-middle-right widget-area"><div class="wrap">',
		'after'  => '</div></div>',
    ) );
    
    echo '</div></div>';
    
    echo '</div></div>';

	
}

//* Set Genesis Responsive Slider defaults
add_filter( 'genesis_responsive_slider_settings_defaults', 'sprinkle_responsive_slider_defaults' );
function sprinkle_responsive_slider_defaults( $defaults ) {

	$args = array(
		'posts_num'                       => '5',
		'slideshow_height'                => '500',
		'slideshow_title_show'            => 1,
		'slideshow_width'                 => '739',
	);

	$args = wp_parse_args( $args, $defaults );
	
	return $args;
}

//* Position post info above post title
remove_action( 'genesis_entry_header', 'genesis_post_info', 12);
add_action( 'genesis_entry_header', 'genesis_post_info', 9 );

//* Hooks previous and next post
add_action( 'genesis_entry_footer', 'single_post_nav', 9 );
function single_post_nav() {

	if ( is_singular('post' ) ) {

		$prev_post = get_adjacent_post(false, '', true);
		$next_post = get_adjacent_post(false, '', false);
		echo '<div class="prev-next-post-links">';
			previous_post_link( '<div class="previous-post-link" title="Previous Post: ' . $prev_post->post_title . '">%link</div>', '&laquo;' );
			next_post_link( '<div class="next-post-link" title="Next Post: ' . $next_post->post_title . '">%link</div>', '&raquo;' );
		echo '</div>';

	}

}

//* Add Theme Support for WooCommerce
add_theme_support( 'genesis-connect-woocommerce' );

//* Customize the credits 
add_filter('genesis_footer_creds_text', 'custom_footer_creds_text');
function custom_footer_creds_text() {
    echo '<div class="creds"><p>';
    echo 'Copyright &copy; ';
    echo date('Y');
    echo ' &middot;  <a target="_blank" href="http://exempel.se">Made by design!</a>';
    echo '</p></div>';

}

//* Register widget areas
genesis_register_sidebar( array(
	'id'			=> 'home-slider',
	'name'			=> __( 'Home Slider', 'sprinkle' ),
	'description'	=> __( 'This is the slider on the home page', 'sprinkle' ),
) );
genesis_register_sidebar( array(
	'id'			=> 'home-cta',
	'name'			=> __( 'Home CTA', 'sprinkle' ),
	'description'	=> __( 'This is the call to action on the home page', 'sprinkle' ),
) );
genesis_register_sidebar( array(
	'id'			=> 'home-middle-left',
	'name'			=> __( 'Home Middle Left', 'sprinkle' ),
	'description'	=> __( 'This is the call to action on the home page', 'sprinkle' ),
) );
genesis_register_sidebar( array(
	'id'			=> 'home-middle-middle',
	'name'			=> __( 'Home Middle Middle', 'sprinkle' ),
	'description'	=> __( 'This is the call to action on the home page', 'sprinkle' ),
) );
genesis_register_sidebar( array(
	'id'			=> 'home-middle-right',
	'name'			=> __( 'Home Middle Right', 'sprinkle' ),
	'description'	=> __( 'This is the call to action on the home page', 'sprinkle' ),
) );
genesis_register_sidebar( array(
	'id'			=> 'home-featured',
	'name'			=> __( 'Home Featured', 'sprinkle' ),
	'description'	=> __( 'This is the home featured section of the home page', 'sprinkle' ),
) );