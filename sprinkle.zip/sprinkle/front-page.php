<?php
/**
 * This file adds the Home Page to the Sprinkle Theme.
 *
 * @author Restored316
 * @package Generate
 * @subpackage Customizations
 */
 
add_action( 'genesis_meta', 'sprinkle_home_genesis_meta' );
/**
 * Add widget support for homepage. If no widgets active, display the default loop.
 *
 */
function sprinkle_home_genesis_meta() {

	if ( is_active_sidebar( 'home-featured' ) ) {

		remove_action( 'genesis_loop', 'genesis_do_loop' );
		add_action( 'genesis_loop', 'sprinkle_home_sections' );
		add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );
		add_filter( 'body_class', 'sprinkle_add_home_body_class' );

	}
	
}

function sprinkle_home_sections() {

	genesis_widget_area( 'home-featured', array(
		'before' => '<div class="home-featured widget-area">',
		'after'  => '</div>',
	) );
	
}

//* Add body class to home page		
function sprinkle_add_home_body_class( $classes ) {

	$classes[] = 'sprinkle-home';
	return $classes;
	
}

genesis();
