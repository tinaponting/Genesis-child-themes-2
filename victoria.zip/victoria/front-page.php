<?php
/**
* Front page template
* @package		Victoria
*/
//* Add widget support for homepage. If no widgets active, display the default loop.
add_action( 'genesis_meta', 'victoria_home_genesis_meta' );
function victoria_home_genesis_meta() {

	if ( is_active_sidebar( 'home-featured' ) ) {

		add_action( 'genesis_before_content_sidebar_wrap', 'victoria_home_sections', 1 );

	}
}

function victoria_home_sections() {
if( !is_paged()) {
		genesis_widget_area( 'home-featured', array(
		'before' => '<div class="home-featured widget-area"><div class="wrap">',
		'after'  => '</div></div>',
	) );
		
}}

//* Remove Featured image (if set in Theme Settings)
add_filter( 'genesis_pre_get_option_content_archive_thumbnail', 'victoria_no_post_image' );
function victoria_no_post_image() {
	return '0';
}

//* Show Excerpts regardless of Theme Settings
add_filter( 'genesis_pre_get_option_content_archive', 'victoria_show_excerpts' );
function victoria_show_excerpts() {
	return 'excerpts';
}

//* Modify the length of post excerpts
add_filter( 'excerpt_length', 'victoria_excerpt_length' );
function victoria_excerpt_length( $length ) {
	return 100; //* pull first 100 words
}

//* Modify the Excerpt read more link
add_filter('excerpt_more', 'victoria_new_excerpt_more');
function victoria_new_excerpt_more($more) {
	return '... <a class="more-link" href="' . get_permalink() . '">Read On »</a>';
}

//* Make sure content limit (if set in Theme Settings) doesn't apply
add_filter( 'genesis_pre_get_option_content_archive_limit', 'victoria_no_content_limit' );
function victoria_no_content_limit() {
	return '0';
}

//* Display centered wide featured image for First Post and left aligned thumbnail for the next five
add_action( 'genesis_entry_header', 'victoria_show_featured_image', 8 );
function victoria_show_featured_image() {

	if ( !has_post_thumbnail() )
		return;

	echo '<div class="entry-thumbnail">';
	genesis_image( array( 'size' => 'blog-featured' ) );
	echo '</div>';

}

//* Remove entry meta
remove_action( 'genesis_entry_footer', 'genesis_entry_footer_markup_open', 5 );
remove_action( 'genesis_entry_footer', 'genesis_entry_footer_markup_close', 15 );
remove_action( 'genesis_entry_footer', 'genesis_post_meta' );
genesis();