<?php
/**
* This file adds the Customizer settings to the Victoria Theme. 
* @package		Victoria
*/

/**
 * Get default primary color for Customizer.
 *
 * Abstracted here since at least two functions use it.
 * @return string Hex color code for primary color.
 */
function victoria_customizer_get_default_primary_color() {
	return '#333';
}

/**
 * Get default accent color for Customizer.
 *
 * Abstracted here since at least two functions use it.
 * @return string Hex color code for accent color.
 */
function victoria_customizer_get_default_accent_color() {
	return '#fbc3c8';
}

/**
 * Get default site title color for Customizer.
 *
 * Abstracted here since at least two functions use it.
 * @return string Hex color code for primary color.
 */
function victoria_customizer_get_default_title_color() {
	return '#333';
}

/**
 * Get default site tagline / description color for Customizer.
 *
 * Abstracted here since at least two functions use it.
 * @return string Hex color code for primary color.
 */
function victoria_customizer_get_default_tagline_color() {
	return '#333';
}

add_action( 'customize_register', 'victoria_customizer_register' );
/**
 * Register settings and controls with the Customizer.
 * @param WP_Customize_Manager $wp_customize Customizer object.
 */
function victoria_customizer_register() {

	global $wp_customize;
	
	$wp_customize->add_setting(
		'victoria_primary_color',
		array(
			'default' 			=> victoria_customizer_get_default_primary_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'victoria_primary_color',
			array(
				'description' => __( 'Change the default color for your top navigation, footer, and a few other elements.', 'victoria' ),
			    'label'    => __( 'Primary Color', 'victoria' ),
			    'section'  => 'colors',
			    'settings' => 'victoria_primary_color',
			)
		)
	);
	
	$wp_customize->add_setting(
		'victoria_accent_color',
		array(
			'default' 			=> victoria_customizer_get_default_accent_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'victoria_accent_color',
			array(
				'description' => __( 'Change the default navigation links, buttons, and text on top of your Primary Color chosen above.', 'victoria' ),
			    'label'    => __( 'Accent Color', 'victoria' ),
			    'section'  => 'colors',
			    'settings' => 'victoria_accent_color',
			)
		)
	);

	$wp_customize->add_setting(
		'victoria_title_color',
		array(
			'default' 			=> victoria_customizer_get_default_title_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'victoria_title_color',
			array(
				'description' => __( 'Change the color of the site title.', 'victoria' ),
			    'label'    => __( 'Site Title Color', 'victoria' ),
			    'section'  => 'colors',
			    'settings' => 'victoria_title_color',
			)
		)
	);

	$wp_customize->add_setting(
		'victoria_tagline_color',
		array(
			'default' 			=> victoria_customizer_get_default_tagline_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'victoria_tagline_color',
			array(
				'description' => __( 'Change the color of the site description / tagline.', 'victoria' ),
			    'label'    => __( 'Site Description Color', 'victoria' ),
			    'section'  => 'colors',
			    'settings' => 'victoria_tagline_color',
			)
		)
	);
}