<?php
/**
* This file adds the required CSS to the front end of the Victoria Theme when using the Customizer.
* @package		Victoria
*/
add_action( 'wp_enqueue_scripts', 'victoria_css' );
/**
* Checks the settings for the accent color, highlight color, and header
* If any of these value are set the appropriate CSS is output
*/
function victoria_css() {

	$handle  = defined( 'CHILD_THEME_NAME' ) && CHILD_THEME_NAME ? sanitize_title_with_dashes( CHILD_THEME_NAME ) : 'child-theme';

	$color_primary = get_theme_mod( 'victoria_primary_color', victoria_customizer_get_default_primary_color() );
	$color_accent = get_theme_mod( 'victoria_accent_color', victoria_customizer_get_default_accent_color() );
	$color_title = get_theme_mod( 'victoria_title_color', victoria_customizer_get_default_title_color() );
	$color_tagline = get_theme_mod( 'victoria_tagline_color', victoria_customizer_get_default_tagline_color() );

	$css = '';
		
	$css .= ( victoria_customizer_get_default_primary_color() !== $color_primary ) ? sprintf( '
		
		button:hover,
		input:hover[type="button"],
		input:hover[type="reset"],
		input:hover[type="submit"],
		.button:hover,
		button:focus,
		input:focus[type="button"],
		input:focus[type="reset"],
		input:focus[type="submit"],
		.button:focus,
		.nav-primary,
		.home-featured .featured-content .entry-title a:hover,
		.home-featured .featured-content .entry-title a:focus,
		a.more-link,
		.archive-pagination a:hover,
		.archive-pagination a:focus,
		.enews-widget input:hover[type="submit"],
		.enews-widget input:focus[type="submit"],
		.sidebar .menu a:hover,
		.sidebar .menu a:focus,
		.home-featured #genesis-responsive-slider h2 a,
		.site-footer,
		.menu-toggle,
		.sub-menu-toggle,
		.js nav button:hover,
		.js .menu-toggle:hover,
		.js .nav-primary,
		.js nav button:focus,
		.js .menu-toggle:focus,
		.footer-widgets-1 .null-instagram-feed p a {
			background-color: %1$s;
		}
		
		.genesis-nav-menu .sub-menu a {
			color: %1$s;
		}

		.enews-widget input:hover[type="submit"],
		.enews-widget input:focus[type="submit"] {
			border-color: %1$s;
		}
		
		', $color_primary ) : '';

	$css .= ( victoria_customizer_get_default_accent_color() !== $color_accent ) ? sprintf( '
		
		button,
		input[type="button"],
		input[type="reset"],
		input[type="submit"],
		.button,
		a.more-link:hover,
		a.more-link:focus,
		.archive-pagination .active a,
		.enews-widget input[type="submit"],
		.sidebar .menu a,
		.footer-widgets-1 .null-instagram-feed p a:hover,
		.footer-widgets-1 .null-instagram-feed p a:focus {
			background-color: %1$s;
		}

		a:hover,
		a:focus,
		.genesis-nav-menu a:hover,
		.genesis-nav-menu a:focus,
		.site-footer a:hover,
		.site-footer a:focus,
		.footer-widgets-1 .menu-item a:hover,
		.footer-widgets-1 .menu-item a:focus {
			color: %1$s;
		}

		.enews-widget input[type="submit"] {
			border-color: %1$s;
		}
		', $color_accent ) : '';

	$css .= ( victoria_customizer_get_default_title_color() !== $color_title ) ? sprintf( '

		.site-title a,
		.site-title a:hover,
		.site-title a:focus {
			color: %1$s;
		}
		', $color_title ) : '';

	$css .= ( victoria_customizer_get_default_tagline_color() !== $color_tagline ) ? sprintf( '

		.site-description {
			color: %1$s;
		}
		', $color_tagline ) : '';

	if ( $css ) {
		wp_add_inline_style( $handle, $css );
	}
}