( function( $ ) {
//Update Secondary Background Colorwp.customize( 'secondary_bg_color', function( value ) {	value.bind( function( newval ) {		$('.home-middle .widget .entry-title, .woocommerce .woocommerce-ordering, .woocommerce .woocommerce-result-count, ul.filter, .prev-next-post-links, .woocommerce-breadcrumb, .woocommerce div.product .woocommerce-tabs ul.tabs, .pagination ul, .home-featured .woocommerce ul.product_list_widget li').css('backgroundColor', newval );	} );} );
//Update Body Background Color
wp.customize( 'body_background_color', function( value ) {
	value.bind( function( newval ) {
		$('body').css('backgroundColor', newval );
	} );
} );

//Update Site Title Color
wp.customize( 'site_title_color', function( value ) {
	value.bind( function( newval ) {
		$('.site-title, .site-title a, .site-title a:hover, .site-title a:focus').css('color', newval );
	} );
} );

//Update Body Text Color
wp.customize( 'body_text_color', function( value ) {
	value.bind( function( newval ) {
		$('body').css('color', newval );
	} );
} );

//Update Link Color
wp.customize( 'body_link_color', function( value ) {
	value.bind( function( newval ) {
		$('a, a:active').css('color', newval );
	} );
} );

//Update Menu Link Color
wp.customize( 'menu_link_color', function( value ) {
	value.bind( function( newval ) {
		$('.genesis-nav-menu a, .genesis-nav-menu a:active, .genesis-nav-menu .current-menu-item > a, li a.icon-search:hover').css('color', newval );
	} );
} );

//Update Page Title Color
wp.customize( 'page_title_color', function( value ) {
	value.bind( function( newval ) {
		$('h1, h2, h3, h4, h5, h6, .entry-title, .page-title, .sidebar .widget .widgettitle').css('color', newval );
	} );
} );//Update Input Background Colorwp.customize( 'input_color', function( value ) {	value.bind( function( newval ) {		$('.footer-widgets-1 .enews-widget input[type="text"], .footer-widgets-1 .enews-widget input[type="email"] , .woocommerce .woocommerce-ordering select').css('backgroundColor', newval );	} );} );

//Update Button Color
wp.customize( 'button_color', function( value ) {
	value.bind( function( newval ) {
		$('.button, .woocommerce input#submit, .woocommerce a.button, .woocommerce button.button, .woocommerce input.button, .woocommerce button.button.alt, .enews-widget input[type="submit"], top-left .enews-widget .enews input[type="submit"], .woocommerce #respond input#submit.alt, .woocommerce a.button.alt, .woocommerce button.button.alt, .woocommerce input.button.alt', 'background-color'').css('backgroundColor', newval );
	} );
} );

//Update Footer Primary Background Color
wp.customize( 'footer_primary_bg_color', function( value ) {
	value.bind( function( newval ) {
		$('.footer-widgets-1, .footer-widgets-2').css('backgroundColor', newval );
	} );
} );//Update Footer Secondary Background Colorwp.customize( 'footer_secondary_bg_color', function( value ) {	value.bind( function( newval ) {		$('.footer-widgets').css('backgroundColor', newval );	} );} );

	
} )( jQuery );