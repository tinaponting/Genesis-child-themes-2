jQuery(function( $ ){
		$('.thumblight').featherlightGallery();
});