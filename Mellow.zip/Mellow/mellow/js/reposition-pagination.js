jQuery(function( $ ){
 
	var $element_to_be_moved = $('.archive-pagination');
	$element_to_be_moved.insertAfter($element_to_be_moved.parent());
 
});