<?php

/**
 * Custom Front Page Template // Widgetized Home Page Template
 * ------------------------------------------------------------------------------------------------
 * ------------------------------------------------------------------------------------------------
 *
 * Add widget support for homepage. If no widgets active, display the default loop.
 *
 * @author Meadow Creative
 * @since 1.0
 *
 */


add_action( 'genesis_meta', 'custom_home_genesis_meta' );

function custom_home_genesis_meta() {

if ( is_active_sidebar( 'home-slider-bottom' ) || is_active_sidebar( 'home-slider' )  || is_active_sidebar( 'home-middle-left' ) || is_active_sidebar( 'home-middle-center' ) || is_active_sidebar( 'home-middle-right' ) || is_active_sidebar( 'home-featured' ) || is_active_sidebar( 'home-bottom-left' ) || is_active_sidebar( 'home-bottom-right' ) ) {

		remove_action( 'genesis_loop', 'genesis_do_loop' );
		add_action( 'genesis_loop', 'custom_home_loop_helper' );
		add_action( 'genesis_after_content', 'mc_home_featured' );
		add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );
	}
}

function mc_home_featured() {

	// WP_Query arguments
	$args = array (
		'category_name' => 'featured', // enter the slug of category from which posts should be pulled
		'posts_per_page' => '7',
		'meta_query' => array(
			array( 'key' => '_thumbnail_id' ) // pulls only posts with featured images
		),
	);

	// The Query
	$query = new WP_Query( $args );

	// The Loop
	if ( $query->have_posts() ) {
		echo '<div class="home-featured-grid"><div class="wrap">';

			while ( $query->have_posts() ) {
				$query->the_post(); ?>

					<?php if ( 0 == $query->current_post || 2 == $query->current_post || 5 == $query->current_post ) { // add opening div before 1st, 3rd and 6th posts ?>
					<div class="col">
					<?php } ?>
						<div class="<?php echo ( 0 == $query->current_post || 6 == $query->current_post ) ? 'large' : 'small'; // if 1st or 7th post, 'large' otherwise 'small' ?> item">

							<a href="<?php the_permalink(); ?>">
								<div class="post-img" style="background-image:url(<?php echo genesis_get_image( array( 'format' => 'url', 'size' => 'home-featured' ) ); ?>)"></div>
								<div class="feat-inside">
									<h2><?php the_title(); ?></h2>
								</div>
							</a>
					</div>

					<?php if ( 1 == $query->current_post || 4 == $query->current_post || 6 == $query->current_post ) { // add closing div after 2nd, 5th and 7th posts ?>
					</div>
					<?php } ?>

			<?php }
		echo '</div></div>';
	} else {
		// no posts found
	}
	// Restore original Post Data
	wp_reset_postdata();
}

function custom_home_loop_helper() {

	echo '<!-- Start Home Slider -->';

	echo '<div class="home-top widget-area">';

	if ( is_active_sidebar( 'home-slider' ) ) {

		echo '<!-- Start Home Slider --><div class="home-top">';
		dynamic_sidebar( 'home-slider' );
		echo '</div><!-- End Home Slider -->';
	}

	echo '</div><!-- End Home Slider Section -->';

	
	echo '<!-- Start Home Slider Bottom -->';

	echo '<div class="home-slider-bottom widget-area">';

	if ( is_active_sidebar( 'home-slider-bottom' ) ) {

		echo '<div class="home-below-slider">';
		dynamic_sidebar( 'home-slider-bottom' );
		echo '</div>';
	}

	echo '</div><!-- End Home Slider Bottom Section -->';

	

	echo '<!-- Start Home Middle Section -->';

	echo '<div class="home-middle widget-area">';

	if ( is_active_sidebar( 'home-middle-left' ) ) {

		echo '<!-- Start Home Middle Left --><div class="home-middle-left"><div class="hm-content">';
		dynamic_sidebar( 'home-middle-left' );
		echo '</div></div><!-- End Home Middle Left -->';
	}

	if ( is_active_sidebar( 'home-middle-center' ) ) {

		echo '<!-- Start Home Middle Center --><div class="home-middle-center"><div class="hm-content">';
		dynamic_sidebar( 'home-middle-center' );
		echo '</div></div><!-- End Home Middle Center -->';
	}

	if ( is_active_sidebar( 'home-middle-right' ) ) {

		echo '<!-- Start Home Middle Right --><div class="home-middle-right"><div class="hm-content">';
		dynamic_sidebar( 'home-middle-right' );
		echo '</div></div><!-- End Home Middle Right -->';
	}

	echo '</div><!-- End Home Middle Section -->';

	echo '<!-- Start Home Featured Section -->';

	if ( is_active_sidebar( 'home-featured' ) ) {

		echo '<div class="home-featured widget-area">';
		dynamic_sidebar( 'home-featured' );
		echo '</div><!-- End Home Featured Section -->';
	}

	echo '<!-- Start Home Bottom Section -->';

	echo '<div class="home-bottom widget-area">';

	if ( is_active_sidebar( 'home-bottom-left' ) ) {

		echo '<!-- Start Home Bottom Left --><div class="home-bottom-left">';
		dynamic_sidebar( 'home-bottom-left' );
		echo '</div><!-- End Home Bottom Left -->';
	}

	if ( is_active_sidebar( 'home-bottom-right' ) ) {

		echo '<!-- Start Home Bottom Right --><div class="home-bottom-right">';
		dynamic_sidebar( 'home-bottom-right' );
		echo '</div><!-- End Home Bottom Right -->';
	}

	echo '</div><!-- End Home Bottom Section -->';

}

genesis();