<?php

/*
	Template Name: Grid Layout
*/


/**
 * Grid Layout // Custom Blog Template Page
 * ------------------------------------------------------------------------------------------------
 * ------------------------------------------------------------------------------------------------
 *
 * Displays all blog posts in a grid Layout via custom template
 *
 * @author Meadow Creative
 * @since 1.0
 *
 */


//* Grab the Posts and Run Loop
//* -----------------------------------------------------------------------------------
remove_action( 'genesis_loop', 'genesis_do_loop' );
add_action( 'genesis_loop', 'mc_grid_loop' );

function mc_grid_loop() {

	$include = genesis_get_option( 'blog_cat' );
	$exclude = genesis_get_option( 'blog_cat_exclude' ) ? explode( ',', str_replace( ' ', '', genesis_get_option( 'blog_cat_exclude' ) ) ) : '';
	$paged   = get_query_var( 'paged' ) ? get_query_var( 'paged' ) : 1;

	$query_args = wp_parse_args(

		genesis_get_custom_field( 'query_args' ),
		array(
			'cat'              => $include,
			'category__not_in' => $exclude,
			'showposts'        => genesis_get_option( 'blog_cat_num' ),
			'paged'            => $paged,
		)
	);

	genesis_custom_loop( $query_args );
	wp_reset_postdata();

}


//* Arrange Posts into Grid Layout
//* -----------------------------------------------------------------------------------
add_action( 'get_header', 'mc_posts_in_columns' );

function mc_posts_in_columns() {

	add_filter( 'post_class', 'be_archive_post_class' );	
	remove_action( 'genesis_entry_content', 'genesis_do_post_image', 8 );
	remove_action( 'genesis_entry_footer', 'genesis_post_meta' );
	remove_action( 'genesis_entry_footer', 'genesis_entry_footer_markup_open', 5 );
	remove_action( 'genesis_entry_footer', 'genesis_entry_footer_markup_close', 15 );
	remove_action( 'genesis_entry_footer', 'genesis_post_meta' );

	add_action( 'genesis_entry_header', 'mc_do__grid_image', 9 );
	add_action( 'genesis_entry_header', 'genesis_post_meta', 13 );

}


//* Column Class
//* -----------------------------------------------------------------------------------
function be_archive_post_class( $classes ) {

	// Don't run on single posts or pages
	if( is_singular() )

		return $classes;

	$classes[] = 'one-half';
	global $wp_query;

	if( 0 == $wp_query->current_post || 0 == $wp_query->current_post % 2 )

		$classes[] = 'first';

	return $classes;

}


//* Grab Post Image Thumb
//* -----------------------------------------------------------------------------------
function mc_do__grid_image() {

	echo '<a href="' . get_permalink() . '"><div class="grid-image" style="background-image:url(' . genesis_get_image( array( 'format' => 'url', 'size' => 'grid-image' ) ) . ')"></div></a>';

}


//* Force Content Limit regardless of Content Archive theme settings
//* -----------------------------------------------------------------------------------
add_filter( 'genesis_pre_get_option_content_archive', 'mc_grid_full_content' );
add_filter( 'genesis_pre_get_option_content_archive_limit', 'mc_grid_content_limit' );

function mc_grid_full_content() {

	return 'full';

}

function mc_grid_content_limit() {

	return '200'; // Limit content to 100 characters

}


//* Add custom body class to the head
//* -----------------------------------------------------------------------------------
add_filter( 'body_class', 'mc_grid_body_class' );

function mc_grid_body_class( $classes ) {

	$classes[] = 'grid-page';

	return $classes;

}


//* Customize Entry Meta in Post Header
//* -----------------------------------------------------------------------------------
add_filter( 'genesis_post_info', 'mc_grid_info_filter' );

function mc_grid_info_filter($post_info) {

	$post_info = '[post_date]';

	return $post_info;

}


//* Customize Entry Meta in Post Footer
//* -----------------------------------------------------------------------------------
add_filter( 'genesis_post_meta', 'mc_grid_meta_filter' );

function mc_grid_meta_filter($post_meta) {

	$post_meta = '[post_categories before=""]';

	return $post_meta;

}


genesis();