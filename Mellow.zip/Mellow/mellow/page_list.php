<?php

/*
	Template Name: List Layout
*/


/**
 * List Layout // Custom Blog Template Page
 * ------------------------------------------------------------------------------------------------
 * ------------------------------------------------------------------------------------------------
 *
 * Displays all blog posts in a List Layout via custom page template
 *
 * @author Meadow Creative
 * @since 1.0
 *
 */


//* Grab the Posts and run loop
//* -----------------------------------------------------------------------------------
remove_action( 'genesis_loop', 'genesis_do_loop' );
add_action( 'genesis_loop', 'pl_grid_loop' );

function pl_grid_loop() {

	$include = genesis_get_option( 'blog_cat' );

	$exclude = genesis_get_option( 'blog_cat_exclude' ) ? explode( ',', str_replace( ' ', '', genesis_get_option( 'blog_cat_exclude' ) ) ) : '';

	$paged   = get_query_var( 'paged' ) ? get_query_var( 'paged' ) : 1;

	//* Easter Egg
	$query_args = wp_parse_args(

		genesis_get_custom_field( 'query_args' ),

		array(

			'cat'              => $include,
			'category__not_in' => $exclude,
			'showposts'        => genesis_get_option( 'blog_cat_num' ),
			'paged'            => $paged,

		)

	);

	genesis_custom_loop( $query_args );
	wp_reset_postdata();

}


//* Add custom body class to the head
//* -----------------------------------------------------------------------------------
add_filter( 'body_class', 'mc_body_class' );

function mc_body_class( $classes ) {

	$classes[] = 'list-page';

	return $classes;

}


// Remove post info, post title, content and post meta and add post title and content for entries
//* -----------------------------------------------------------------------------------
add_action ('genesis_meta','mc_remove_post_stuff_list');

function mc_remove_post_stuff_list() {

	remove_action( 'genesis_entry_header', 'genesis_do_post_title' );
	remove_action( 'genesis_entry_content', 'genesis_do_post_content' );
	remove_action( 'genesis_entry_content', 'genesis_do_post_image' );
	remove_action( 'genesis_entry_header', 'genesis_post_info', 12 );

	add_action( 'genesis_entry_content', 'genesis_do_post_title' );
	add_action( 'genesis_entry_content', 'genesis_do_post_content' );
	add_action( 'genesis_entry_content', 'genesis_post_info', 5);

}


//* Customize the entry meta in the entry header
//* -----------------------------------------------------------------------------------
add_filter( 'genesis_post_info', 'mc_list_post_info_filter' );
function mc_list_post_info_filter($post_info) {
	
	$post_info = '[post_categories before="in " after=" on "][post_date format="d/m/y"]';
	
	return $post_info;
}


//* Force Content Limit regardless of Content Archive theme settings
//* -----------------------------------------------------------------------------------
add_filter( 'genesis_pre_get_option_content_archive', 'mc_show_full_content' );
add_filter( 'genesis_pre_get_option_content_archive_limit', 'mc_content_limit' );

function mc_show_full_content() {

	return 'full';

}

function mc_content_limit() {

	return '250'; // Limit content

}


//* Add List Layout Featured Image
//* -----------------------------------------------------------------------------------
add_action ( 'genesis_entry_header', 'mc_featured_image_title' );
function mc_featured_image_title() {

	if ( !has_post_thumbnail() )
		
		return;

	echo '<div class="list-thumb">';

	genesis_image( array( 'size' => 'list-image' ) );

	echo '</div>';

}


//* Now Remove the post image
//* -----------------------------------------------------------------------------------
remove_action( 'genesis_entry_content', 'genesis_do_post_image', 8 );


genesis();