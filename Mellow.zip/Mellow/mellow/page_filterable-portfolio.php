<?php

/*
	Template Name: Filterable Portfolio
*/

/**
 * Filterable Portfolio // Custom Portfolio Template Page
 * ------------------------------------------------------------------------------------------------
 * ------------------------------------------------------------------------------------------------
 *
 * Displays a portfolio which is filterable by category
 *
 * @author Meadow Creative
 * @since 1.0
 *
 */


//* Force full width content
//* -----------------------------------------------------------------------------------
add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );


//* Enqueue Featherlight
//* -----------------------------------------------------------------------------------
add_action( 'wp_enqueue_scripts', 'pl_enqueue_port_scripts' );
function pl_enqueue_port_scripts() {

	wp_enqueue_style( 'featherlight-css', get_stylesheet_directory_uri() . '/css/featherlight.min.css' );
	wp_enqueue_script( 'featherlight', get_stylesheet_directory_uri() . '/js/featherlight.min.js', array( 'jquery' ), '1.2.3', true );
	wp_enqueue_script( 'featherlight-init', get_stylesheet_directory_uri() . '/js/featherlight-init.js', array( 'jquery' ), '1.0.0', true );

}

wp_enqueue_script('isotope', get_stylesheet_directory_uri() . '/js/jquery.isotope.min.js', array('jquery'), '1.5.25', true);
wp_enqueue_script('isotope_init', get_stylesheet_directory_uri() . '/js/isotope_init.js', array('isotope'), '', true);


//* Add custom body class
//* -----------------------------------------------------------------------------------
add_filter( 'body_class', 'filerable_portfolio_add_body_class' );


//* Filterable Portfolio custom body class
//* -----------------------------------------------------------------------------------
function filerable_portfolio_add_body_class( $classes ) {

	$classes[] = 'filterable-portfolio-page';
	return $classes;
}

remove_action( 'genesis_loop', 'genesis_do_loop' );
add_action( 'genesis_loop', 'filterable_portfolio_do_loop' );


/**
 * Outputs a custom loop
 *
 * @global mixed $paged current page number if paginated
 * @return void
 */
function filterable_portfolio_do_loop() { ?>

    <header id="page-heading" class="entry-header">

        <?php genesis_do_post_title(); ?>

        <?php $terms = get_terms( 'portfolio_category' ); ?>

        <?php if ($terms !== 0 && $terms !== null) { ?>

            <ul id="portfolio-cats" class="filter clearfix">

                <li><a href="#" class="active" data-filter="*"><span><?php _e('All', 'genesis'); ?></span></a></li>

                <?php foreach ($terms as $term ) : ?>

                    <li><a href="#" data-filter=".<?php echo $term->slug; ?>"><span><?php echo $term->name; ?></span></a></li>

                <?php endforeach; ?>

            </ul><!-- /portfolio-cats -->

        <?php } ?>

    </header><!-- /page-heading -->

    <div class="entry-content" itemprop="text">

         <?php $wpex_port_query = new WP_Query(

            array(

                'post_type' => 'portfolio',
                'showposts' => '-1',
                'no_found_rows' => true,

            )
        );

        if( $wpex_port_query->posts ) { ?>

            <div id="portfolio-wrap" class="clearfix filterable-portfolio">

                <div class="portfolio-content">

                    <?php $wpex_count=0; ?>

                    <?php while ( $wpex_port_query->have_posts() ) : $wpex_port_query->the_post(); ?>

                        <?php $wpex_count++; ?>

                        <?php $terms = get_the_terms( get_the_ID(), 'portfolio_category' ); ?>

                        <?php if ( has_post_thumbnail($post->ID) ) { ?>

                            <article class="portfolio-item col-<?php echo $wpex_count; ?> <?php if( $terms ) foreach ( $terms as $term ) { echo $term->slug .' '; }; ?>">

                               <a href="<?php echo genesis_get_image( array( 'format' => 'url', 'size' => 'large') ); ?>" data-featherlight="image" rel="bookmark" title="<?php the_title_attribute(); ?>">

					<?php echo genesis_get_image( array( size => 'portfolio' ) ); ?>

                                <div class="portfolio-overlay"><h3><?php the_title(); ?></h3></div><!-- portfolio-overlay --></a>

                            </article>

                        <?php } ?>

                    <?php endwhile; ?>

                </div><!-- /portfolio-content -->

            </div><!-- /portfolio-wrap -->

        <?php } ?>

        <?php wp_reset_postdata(); ?>

    </div><!-- /entry-content -->

<?php }


genesis();