<?php
//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );


//* Child theme (do not remove)
//* --------------------------------------------------------
define( 'CHILD_THEME_NAME', 'Mellow Theme' );
define( 'CHILD_THEME_URL', 'http://www.meadowcreative.co.uk/' );
define( 'CHILD_THEME_VERSION', '1.0' );



//* --------------------------------------------------------------------------------------------------------------------------
//* ACCESSIBILITY & SUPPORT >>
//* --------------------------------------------------------------------------------------------------------------------------


//* Reposition enqueue of css file
//* --------------------------------------------------------
remove_action( 'genesis_meta', 'genesis_load_stylesheet' );
add_action( 'wp_enqueue_scripts', 'genesis_enqueue_main_stylesheet', 15 );


//* Enqueue Google Fonts
//* --------------------------------------------------------
add_action( 'wp_enqueue_scripts', 'meadow_base_google_fonts' );
function meadow_base_google_fonts() {

	wp_enqueue_style( 'google-fonts', '//fonts.googleapis.com/css?family=Raleway|Montserrat|Open+Sans|Roboto', array(), CHILD_THEME_VERSION );
	wp_enqueue_style( 'font-awesome', '//maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css' );

}


//* Add HTML5 markup structure
//* --------------------------------------------------------
add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption' ) );


//* Add Accessibility support
//* --------------------------------------------------------
add_theme_support( 'genesis-accessibility', array( 'headings', 'drop-down-menu',  'search-form', 'skip-links', 'rems' ) );


//* Add viewport meta tag for mobile browsers
//* --------------------------------------------------------
add_theme_support( 'genesis-responsive-viewport' );


//* Customizer
//* --------------------------------------------------------

//* Meadow Customize Class
class meadow_Customize {
	
	public static function register ( $wp_customize ) {
      

      $wp_customize->add_section('mc_section_home',
         array(
            'title'		=> __( 'Home Page Options', 'mellow-theme' ),
            'priority'		=> 8
         )
      );

      $wp_customize->add_section( 'meadow_options', 
         array(
            'title' 		=> __( 'Theme Colours', 'mellow-theme' ),
            'priority' 		=> 9,
            'capability' 	=> 'edit_theme_options',
         ) 
      );

      $wp_customize->add_setting( 'home_featured_display',
         array(
            'default'		=> false,
            'type' 		=> 'theme_mod',
            'capability' 	=> 'edit_theme_options',
            'transport' 	=> 'refresh',
         ) 
      );

      $wp_customize->add_setting( 'primary_bg_color',
         array(
            'default' 		=> '#ede2e0',
            'type' 		=> 'theme_mod',
            'capability' 	=> 'edit_theme_options',
            'transport' 	=> 'refresh',
         ) 
      );

      $wp_customize->add_setting( 'secondary_bg_color',
         array(
            'default' 		=> '#f4ecea',
            'type' 		=> 'theme_mod',
            'capability' 	=> 'edit_theme_options',
            'transport' 	=> 'postMessage',
         ) 
      );

      $wp_customize->add_setting( 'body_background_color',
         array(
            'default' 		=> '#f1f1f1',
            'type' 		=> 'theme_mod',
            'capability' 	=> 'edit_theme_options',
            'transport' 	=> 'postMessage',
         ) 
      );
      
      $wp_customize->add_setting( 'site_title_color',
         array(
            'default' 		=> '#000000',
            'type' 		=> 'theme_mod',
            'capability' 	=> 'edit_theme_options',
            'transport' 	=> 'postMessage',
         ) 
      );

      $wp_customize->add_setting( 'body_text_color',
         array(
            'default' 		=> '#000000',
            'type' 		=> 'theme_mod',
            'capability' 	=> 'edit_theme_options',
            'transport' 	=> 'postMessage',
         ) 
      );

      $wp_customize->add_setting( 'body_link_color',
         array(
            'default' 		=> '#666666',
            'type' 		=> 'theme_mod',
            'capability' 	=> 'edit_theme_options',
            'transport' 	=> 'postMessage',
         ) 
      );

      $wp_customize->add_setting( 'link_hover_color',
         array(
            'default' 		=> '#dcb5ba',
            'type' 		=> 'theme_mod',
            'capability' 	=> 'edit_theme_options',
            'transport' 	=> 'refresh',
         ) 
      );

      $wp_customize->add_setting( 'menu_bar_color',
         array(
            'default' 		=> '#ffffff',
            'type' 		=> 'theme_mod',
            'capability' 	=> 'edit_theme_options',
            'transport' 	=> 'refresh',
         ) 
      ); 

      $wp_customize->add_setting( 'menu_link_color',
         array(
            'default' 		=> '#000000',
            'type' 		=> 'theme_mod',
            'capability' 	=> 'edit_theme_options',
            'transport' 	=> 'refresh',
         ) 
      );   

      $wp_customize->add_setting( 'menu_hover_color',
         array(
            'default' 		=> '#dcb5ba',
            'type' 		=> 'theme_mod',
            'capability' 	=> 'edit_theme_options',
            'transport' 	=> 'refresh',
         ) 
      );   

      $wp_customize->add_setting( 'page_title_color',
         array(
            'default' 		=> '#000000',
            'type' 		=> 'theme_mod',
            'capability' 	=> 'edit_theme_options',
            'transport' 	=> 'postMessage',
         ) 
      );

      $wp_customize->add_setting( 'input_color',
         array(
            'default' 		=> '#f8f2f0',
            'type' 		=> 'theme_mod',
            'capability' 	=> 'edit_theme_options',
            'transport' 	=> 'postMessage',
         ) 
      );

      $wp_customize->add_setting( 'button_color',
         array(
            'default' 		=> '#ede2e0',
            'type' 		=> 'theme_mod',
            'capability' 	=> 'edit_theme_options',
            'transport' 	=> 'postMessage',
         ) 
      );

      $wp_customize->add_setting( 'button_hover_color',
         array(
            'default' 		=> '#dcb5ba',
            'type' 		=> 'theme_mod',
            'capability' 	=> 'edit_theme_options',
            'transport' 	=> 'refresh',
         ) 
      );

      $wp_customize->add_setting( 'footer_primary_bg_color',
         array(
            'default' 		=> '#ede2e0',
            'type' 		=> 'theme_mod',
            'capability' 	=> 'edit_theme_options',
            'transport' 	=> 'postMessage',
         ) 
      );

      $wp_customize->add_setting( 'footer_secondary_bg_color',
         array(
            'default' 		=> '#f4ecea',
            'type' 		=> 'theme_mod',
            'capability' 	=> 'edit_theme_options',
            'transport' 	=> 'postMessage',
         ) 
      );

      $wp_customize->add_control(
         'mc_home_featured_display',
         array(
            'label' 		=> __( 'Homepage Featured Grid', 'mellow-theme' ),
            'description'	=> __( 'Hide the Featured Posts Grid on the Home Page?', 'mellow-theme' ),
            'type'		=> 'checkbox',
            'section' 		=> 'mc_section_home',
            'settings' 		=> 'home_featured_display',
         ) 
      );

      $wp_customize->add_control( new WP_Customize_Color_Control( 
         $wp_customize, 
         'mc_primary_bg_color',
         array(
            'label' 		=> __( 'Primary Color', 'mellow-theme' ),
            'section' 		=> 'meadow_options',
            'settings' 		=> 'primary_bg_color',
         ) 
      ) );

      $wp_customize->add_control( new WP_Customize_Color_Control( 
         $wp_customize, 
         'mc_secondary_bg_color',
         array(
            'label' 		=> __( 'Secondary Color', 'mellow-theme' ),
            'section' 		=> 'meadow_options',
            'settings' 		=> 'secondary_bg_color',
         ) 
      ) );

      $wp_customize->add_control( new WP_Customize_Color_Control( 
         $wp_customize, 
         'mc_body_background_color',
         array(
            'label' 		=> __( 'Body Background Color', 'mellow-theme' ),
            'section' 		=> 'meadow_options',
            'settings' 		=> 'body_background_color',
         ) 
      ) );

      $wp_customize->add_control( new WP_Customize_Color_Control( 
         $wp_customize, 
         'mc_site_title_color',
         array(
            'label' 		=> __( 'Site Title Color', 'mellow-theme' ),
            'section' 		=> 'meadow_options',
            'settings' 		=> 'site_title_color',
         ) 
      ) );

      $wp_customize->add_control( new WP_Customize_Color_Control( 
         $wp_customize, 
         'mc_body_text_color',
         array(
            'label' 		=> __( 'Text Color', 'mellow-theme' ),
            'section' 		=> 'meadow_options',
            'settings' 		=> 'body_text_color',
         ) 
      ) );

      $wp_customize->add_control( new WP_Customize_Color_Control( 
         $wp_customize, 
         'mc_body_link_color',
         array(
            'label' 		=> __( 'Link Color', 'mellow-theme' ),
            'section' 		=> 'meadow_options',
            'settings' 		=> 'body_link_color',
         ) 
      ) );

      $wp_customize->add_control( new WP_Customize_Color_Control( 
         $wp_customize, 
         'mc_link_hover_color',
         array(
            'label' 		=> __( 'Link Hover Color', 'mellow-theme' ),
            'section' 		=> 'meadow_options',
            'settings' 		=> 'link_hover_color',
         ) 
      ) );

      $wp_customize->add_control( new WP_Customize_Color_Control( 
         $wp_customize, 
         'mc_menu_bar_color',
         array(
            'label' 		=> __( 'Menu Background Color', 'mellow-theme' ),
            'section' 		=> 'meadow_options',
            'settings' 		=> 'menu_bar_color',
         ) 
      ) );

      $wp_customize->add_control( new WP_Customize_Color_Control( 
         $wp_customize, 
         'mc_menu_link_color',
         array(
            'label' 		=> __( 'Menu Link Color', 'mellow-theme' ),
            'section' 		=> 'meadow_options',
            'settings' 		=> 'menu_link_color',
         ) 
      ) );

      $wp_customize->add_control( new WP_Customize_Color_Control( 
         $wp_customize, 
         'mc_menu_hover_color',
         array(
            'label' 		=> __( 'Menu Link Hover Color', 'mellow-theme' ),
            'section' 		=> 'meadow_options',
            'settings' 		=> 'menu_hover_color',
         ) 
      ) );

      $wp_customize->add_control( new WP_Customize_Color_Control( 
         $wp_customize, 
         'mc_page_title_color',
         array(
            'label' 		=> __( 'Page Title Color', 'mellow-theme' ),
            'section' 		=> 'meadow_options',
            'settings' 		=> 'page_title_color',
         ) 
      ) );

      $wp_customize->add_control( new WP_Customize_Color_Control( 
         $wp_customize, 
         'mc_input_color',
         array(
            'label' 		=> __( 'Input Background Color', 'mellow-theme' ),
            'section' 		=> 'meadow_options',
            'settings' 		=> 'input_color',
         ) 
      ) );

      $wp_customize->add_control( new WP_Customize_Color_Control( 
         $wp_customize, 
         'mc_button_color',
         array(
            'label' 		=> __( 'Button Color', 'mellow-theme' ),
            'section' 		=> 'meadow_options',
            'settings' 		=> 'button_color',
         ) 
      ) );

      $wp_customize->add_control( new WP_Customize_Color_Control( 
         $wp_customize, 
         'mc_button_hover_color',
         array(
            'label' 		=> __( 'Button Hover Color', 'mellow-theme' ),
            'section' 		=> 'meadow_options',
            'settings' 		=> 'button_hover_color',
         ) 
      ) );

      $wp_customize->add_control( new WP_Customize_Color_Control( 
         $wp_customize, 
         'mc_footer_primary_bg_color',
         array(
            'label' 		=> __( 'Footer Primary Background Color', 'mellow-theme' ),
            'section' 		=> 'meadow_options',
            'settings' 		=> 'footer_primary_bg_color',
         ) 
      ) );

      $wp_customize->add_control( new WP_Customize_Color_Control( 
         $wp_customize, 
         'mc_footer_secondary_bg_color',
         array(
            'label' 		=> __( 'Footer Secondary Background Color', 'mellow-theme' ),
            'section' 		=> 'meadow_options',
            'settings' 		=> 'footer_secondary_bg_color',
         ) 
      ) );

   }

   public static function header_output() {
      ?>
      <style type="text/css">
	
	.home-featured-grid {
	<?php if ( true === get_theme_mod( 'home_featured_display' ) ) { ?>
		display: none !important;
	<?php } ?>
	}

	<?php self::generate_css('.home-below-slider, .content .entry-header, .page-title, .sidebar .widget .widgettitle, .entry-comments-link, .entry-comments h3, .entry-pings h3, .comment-respond h3, .sidebar .featured-content .entry-title a, .portfolio-overlay h3, .woocommerce h2, .home-featured-grid .item .post-img:after, .home-featured .widget_products .widget-title, .search-div .search-form input[type="search"], .woocommerce ul.products li.product, .woocommerce div.product .product_title, .woocommerce div.product .woocommerce-tabs ul.tabs li.active', 'background-color', 'primary_bg_color'); ?>

	<?php self::generate_css('.page-title::after, .content .entry-header::after, .sidebar .widget .widgettitle::after, .entry-comments-link::before, .entry-comments-link::after, .list-page .content article, .woocommerce div.product .product_title::after', 'border-top-color', 'primary_bg_color'); ?>

	<?php self::generate_css('.home-middle .widget .entry-title, .woocommerce .woocommerce-ordering, .woocommerce .woocommerce-result-count, ul.filter, .prev-next-post-links, .woocommerce-breadcrumb, .woocommerce div.product .woocommerce-tabs ul.tabs, .pagination ul, .home-featured .woocommerce ul.product_list_widget li', 'background-color', 'secondary_bg_color'); ?>

	<?php self::generate_css('body', 'background-color', 'body_background_color'); ?>

	<?php self::generate_css('.site-title, .site-title a, .site-title a:hover, .site-title a:focus', 'color', 'site_title_color'); ?>

	<?php self::generate_css('body', 'color', 'body_text_color'); ?>

	<?php self::generate_css('a, a:active', 'color', 'body_link_color'); ?>

	a:hover, a:focus { color:<?php echo get_theme_mod('link_hover_color', '#dcb5ba'); ?>; }

	.nav-secondary, .genesis-nav-menu .sub-menu { background-color:<?php echo get_theme_mod('menu_bar_color', '#ffffff'); ?>; }

	<?php self::generate_css('.genesis-nav-menu a, .genesis-nav-menu a:active, .genesis-nav-menu .current-menu-item > a, li a.icon-search:hover', 'color', 'menu_link_color'); ?>

	.genesis-nav-menu a:hover, .genesis-nav-menu a:focus, .genesis-nav-menu .sub-menu .current-menu-item > a:hover, .genesis-nav-menu .sub-menu .current-menu-item > a:focus, li a.icon-search { color:<?php echo get_theme_mod('menu_hover_color', '#dcb5ba'); ?>; }

	<?php self::generate_css('h1, h2, h3, h4, h5, h6, .entry-title, .entry-title a, .page-title, .sidebar .widget .widgettitle', 'color', 'page_title_color'); ?>
	
	<?php self::generate_css('.footer-widgets-1 .enews-widget input[type="text"], .footer-widgets-1 .enews-widget input[type="email"] , .woocommerce .woocommerce-ordering select', 'background-color', 'input_color'); ?>

	<?php self::generate_css('.button, .woocommerce input#submit, .woocommerce a.button, .woocommerce button.button, .woocommerce input.button, .woocommerce button.button.alt, .enews-widget input[type="submit"], top-left .enews-widget .enews input[type="submit"], .woocommerce #respond input#submit.alt, .woocommerce a.button.alt, .woocommerce button.button.alt, .woocommerce input.button.alt', 'background-color', 'button_color'); ?>

	.button:hover, .woocommerce input#submit:hover, .woocommerce a.button:hover, .woocommerce button.button:hover, .woocommerce input.button:hover, .woocommerce button.button.alt:hover, .enews-widget input[type="submit"]:hover, .home-top-left .enews-widget .enews input[type="submit"]:hover, .woocommerce #respond input#submit.alt:hover, .woocommerce a.button.alt:hover, .woocommerce button.button.alt:hover, .woocommerce input.button.alt:hover, .footer-widgets-1 .enews-widget input[type="submit"], ul.filter a:hover { background-color:<?php echo get_theme_mod('button_hover_color', '#dcb5ba'); ?>; }

	<?php self::generate_css('.footer-widgets-1, .footer-widgets-2', 'background-color', 'footer_primary_bg_color'); ?>

	<?php self::generate_css('.footer-widgets', 'background-color', 'footer_secondary_bg_color'); ?>
      
      </style>
      <?php
   }

function mc_customizer_live_preview() {
	wp_enqueue_script(
		'mc-theme-customizer',
		get_stylesheet_directory_uri() . '/js/theme-customizer.js',
		array( 'customize-preview' ),
		'0.1.0',
		true
	);
} // end mc_customizer_live_preview

    public static function generate_css( $selector, $style, $mod_name, $prefix='', $postfix='', $echo=true ) {
      $return = '';
      $mod = get_theme_mod($mod_name);
      if ( ! empty( $mod ) ) {
         $return = sprintf('%s { %s:%s; }',
            $selector,
            $style,
            $prefix.$mod.$postfix
         );
         if ( $echo ) {
            echo $return;
         }
      }
      return $return;
    }
}

add_action( 'customize_register' , array( 'meadow_Customize' , 'register' ) );
add_action( 'wp_head' , array( 'meadow_Customize' , 'header_output' ) );
add_action( 'customize_preview_init' , array( 'meadow_Customize' , 'mc_customizer_live_preview' ) );


//* --------------------------------------------------------------------------------------------------------------------------
//* IMAGES & PORTFOLIO >>
//* --------------------------------------------------------------------------------------------------------------------------



//* Define New Image Sizes
//* --------------------------------------------------------

add_image_size( 'list-image', 500, 500, true );
add_image_size( 'grid-image', 420, 220, true );
add_image_size( 'home-featured', 800, 0, true );
add_image_size( 'portfolio', 300, 200, true );
add_image_size( 'side-post', 100, 100, true );


//* Modify the size of the Gravatar in comments
//* --------------------------------------------------------
add_filter( 'genesis_comment_list_args', 'mc_comments_gravatar' );
function mc_comments_gravatar( $args ) {
	$args['avatar_size'] = 96;
	return $args;
}


/* Modify Gravatar Size in Sidebar */
//* --------------------------------------------------------
add_filter( 'genesis_gravatar_sizes', 'mc_user_profile' );
function mc_user_profile( $sizes ) {
	$sizes['Full Size'] = 300;
	return $sizes;
}



//* --------------------------------------------------------------------------------------------------------------------------
//* HEADER & NAVIGATION >>
//* --------------------------------------------------------------------------------------------------------------------------



//* Remove the header right widget area
//* --------------------------------------------------------
unregister_sidebar( 'header-right' );


//* Custom Header Support
//* --------------------------------------------------------
add_theme_support( 'custom-header', array(
	'flex-height'     => true,
	'width'           => 1200,
	'height'          => 300,
	'header-selector' => '.site-title a',
	'header-text'     => false,
) );


//* Move Secondary Navigation to Page Top
//* --------------------------------------------------------
remove_action( 'genesis_after_header', 'genesis_do_subnav' );
add_action( 'genesis_before_header', 'genesis_do_subnav' );


//* Dropdown Search in Secondary Nav Bar
//* --------------------------------------------------------
add_action( 'wp_enqueue_scripts', 'custom_enqueue_scripts_styles' );
function custom_enqueue_scripts_styles() {
	wp_enqueue_script( 'global', get_bloginfo( 'stylesheet_directory' ) . '/js/global.js', array( 'jquery' ), '1.0.0', true );
}

add_filter( 'wp_nav_menu_items', 'theme_menu_extras', 10, 2 );
function theme_menu_extras( $menu, $args ) {

	if ( 'secondary' !== $args->theme_location )
		return $menu;

	$menu .= '<li class="search right"><a id="main-nav-search-link" class="icon-search"></a><div class="search-div">' . get_search_form( false ) . '</div></li>';
	
	return $menu;
}


//* Add Social Icons to Menu
//* --------------------------------------------------------
add_filter( 'wp_nav_menu_items', 'genesis_secondary_nav_menu', 10, 2 );
function genesis_secondary_nav_menu( $menu, stdClass $args ){
  if ( 'secondary' != $args->theme_location )
    return $menu;
        if( genesis_get_option( 'nav_extras' ) )
          return $menu;
	ob_start();
	echo '<li id="menu-item-4439203" class="custom-social menu-item right">';
	genesis_widget_area('menu-widget-right');
	$social = ob_get_clean();
    return $menu . $social;
}


//* Customize search form input button text
//* --------------------------------------------------------
add_filter( 'genesis_search_button_text', 'sp_search_button_text' );
function sp_search_button_text( $text ) {
	return esc_attr( 'Go' );
}


//* Add Skip Links
//* --------------------------------------------------------
add_filter( 'genesis_attr_nav-secondary', 'mc_add_nav_secondary_id' );
function mc_add_nav_secondary_id( $attributes ) {
	$attributes['id'] = 'genesis-nav-secondary';
	return $attributes;
}

add_filter( 'genesis_skip_links_output', 'mc_add_nav_secondary_skip_link' );
function mc_add_nav_secondary_skip_link( $links ) {
	$new_links = $links;
	array_splice( $new_links, 1 );

	if ( has_nav_menu( 'secondary' ) ) {
		$new_links['genesis-nav-secondary'] = __( 'Skip to secondary navigation', 'mellow' );
	}

	return array_merge( $new_links, $links );
}


//* Responsive Navigation
//* --------------------------------------------------------
add_action( 'wp_enqueue_scripts', 'mc_load_scripts', 15 );
function mc_load_scripts() {
	// Responsive Navigation
	wp_enqueue_script( 'mc-responsive-menu', get_stylesheet_directory_uri() . '/js/responsive-menu.js', array( 'jquery' ), '1.0.0', true );
	$output = array(
		'mainMenu' => __( 'Menu', 'mellow-theme' ),
		'subMenu'  => __( 'Menu', 'mellow-theme' ),
	);
	wp_localize_script( 'mc-responsive-menu', 'MellowL10n', $output );
}



//* --------------------------------------------------------------------------------------------------------------------------
//* HOMEPAGE >>
//* --------------------------------------------------------------------------------------------------------------------------


//* Set Genesis Responsive Slider defaults
//* --------------------------------------------------------
add_filter( 'genesis_responsive_slider_settings_defaults', 'mc_responsive_slider_defaults' );
function mc_responsive_slider_defaults( $defaults ) {
	$args = array( 
		'slideshow_timer' => 14000,
        	'slideshow_delay' => 1000,
        	'slideshow_arrows' => 1,
        	'slideshow_pager' => 0,
        	'slideshow_height' => 500,
        	'slideshow_width' => 1200,
        	'slideshow_effect' => 'fade',
        	'slideshow_title_show' => 0,
        	'slideshow_excerpt_show' => 0,
        	'slideshow_excerpt_width' => 45,
        	'location_vertical' => 'bottom',
        	'location_horizontal' => 'right',
        	'slideshow_hide_mobile' => 0
	);
	$args = wp_parse_args( $args, $defaults );
	
	return $args;
}



//* Register Home Widget Areas
//* --------------------------------------------------------

genesis_register_sidebar( array(
	'id'          => 'menu-widget-right',
	'name'        => __( 'Menu Widget Right', 'mellow-theme' ),
	'description' => __( 'This is the widget area at the right of the top menu.', 'mellow-theme' ),
) );

genesis_register_sidebar( array(
	'id'            => 'home-slider',
	'name'          => __( 'Home Page Slider', 'mellow-theme' ),
	'description'   => __( 'This is the slider section at the top of the home page.', 'mellow-theme' ),
) );

genesis_register_sidebar( array(
	'id'            => 'home-slider-bottom',
	'name'          => __( 'Slider Bottom', 'mellow-theme' ),
	'description'   => __( 'This is the section below the slider on the homepage.', 'mellow-theme' ),
) );

genesis_register_sidebar( array(
	'id'            => 'home-middle-left',
	'name'          => __( 'Home Middle Left', 'mellow-theme' ),
	'description'   => __( 'The middle widget section, on the left', 'mellow-theme' ),
) );

genesis_register_sidebar( array(
	'id'            => 'home-middle-center',
	'name'          => __( 'Home Middle Center', 'mellow-theme' ),
	'description'   => __( 'The middle widget section, in the center', 'mellow-theme' ),
) );

genesis_register_sidebar( array(
	'id'            => 'home-middle-right',
	'name'          => __( 'Home Middle Right', 'mellow-theme' ),
	'description'   => __( 'The middle widget section, on the right', 'mellow-theme' ),
) );

genesis_register_sidebar( array(
	'id'            => 'home-featured',
	'name'          => __( 'Home Featured', 'mellow-theme' ),
	'description'   => __( 'The featured widget area, below Home Middle and above Home Bottom', 'mellow-theme' ),
) );

genesis_register_sidebar( array(
	'id'            => 'home-bottom-left',
	'name'          => __( 'Home Bottom Left', 'mellow-theme' ),
	'description'   => __( 'The bottom widget section, on the left', 'mellow-theme' ),
) );

genesis_register_sidebar( array(
	'id'            => 'home-bottom-right',
	'name'          => __( 'Home Bottom Right', 'mellow-theme' ),
	'description'   => __( 'The bottom widget section, on the right', 'mellow-theme' ),
) );




//* --------------------------------------------------------------------------------------------------------------------------
//* POSTS >>
//* --------------------------------------------------------------------------------------------------------------------------

//* Pre-Load Simple Social Icons Defaults
//* --------------------------------------------------------
add_filter( 'simple_social_default_styles', 'mc_ss_default_style' );
function mc_ss_default_style( $defaults ) {

	$defaults['size']                      = '38';
	$defaults['border_radius']             = '0';
	$defaults['icon_color']	               = '#000';
	$defaults['icon_color_hover']          = '#fff';
	$defaults['background_color']          = 'transparent';
	$defaults['background_color_hover']    = 'transparent';
	$defaults['alignment']                 = 'aligncenter';

	return $defaults;
}


//* Move Author to Bottom
//* --------------------------------------------------------
add_action( 'genesis_entry_footer', 'mc_move_byline', 6);
function mc_move_byline() {
	if ( !is_page() ) {
		echo do_shortcode('[post_author before="by " after=""]');
	}
}


//* Display only first category level in Entry Meta
//* --------------------------------------------------------
add_shortcode( 'post_category', 'mc_show_the_first_category_name_only' );

function mc_show_the_first_category_name_only( $atts ) {
	$categories = get_the_category( $post->ID );

	if( $categories[0] ) {
		return 'in <a href="' . get_category_link( $categories[0]->term_id ) . '">' . $categories[0]->cat_name . '</a>';
	}

}


//* Move Comments to Bottom
//* --------------------------------------------------------
add_action( 'genesis_entry_footer', 'mc_move_comments', 7);
function mc_move_comments() {
	if ( !is_page() ) {
		echo do_shortcode('[post_comments zero="0" one="1" more="%" hide_if_off="disabled"]');
	}
}


//* Customize the entry meta in the entry header (requires HTML5 theme support)
add_filter( 'genesis_post_info', 'mc_post_info_filter' );
function mc_post_info_filter($post_info) {
	
	$post_info = '[post_categories before="in " after=" on "][post_date format="d/m/y"]';
	
	return $post_info;
}


//* Show Featured Image in Single Posts
//* --------------------------------------------------------
remove_action( 'genesis_entry_content', 'genesis_do_post_image', 8 );
add_action( 'genesis_before_entry_content', 'mc_show_featured_image_single_posts', 5 );
function mc_show_featured_image_single_posts() {
	// if ( !is_singular( array( 'post', 'page' ) )) {
		// return;
	// }

	$image_args = array(
		'size' => 'full',
	);

	genesis_image( $image_args );
}


//* Modify the Genesis content limit read more link
//* --------------------------------------------------------
add_filter( 'get_the_content_more_link', 'mc_read_more_link' );
function mc_read_more_link() {
	return '<p><a class="cont-link" href="' . get_permalink() . '">Continue Reading <span class="cont-line"></span></a></p>';
}


//* Add Social Share to Entry Footer
//* --------------------------------------------------------
add_action( 'genesis_entry_footer', 'mc_simple_share');
function mc_simple_share() {
	if ( ! function_exists('genesis_share_icon_output') ) {
		return;
	}
	
	wp_enqueue_style( 'sharrre-css', get_bloginfo( 'stylesheet_directory' ) . '/css/sharrre.css' );
	genesis_share_icon_output( 'buttons', array(  'googlePlus', 'facebook', 'twitter', 'pinterest', 'linkedin', 'stumbleupon' ) );
}

//* Add Custom Gravatar
//* --------------------------------------------------------
add_filter( 'avatar_defaults', 'mc_custom_gravatar' );
function mc_custom_gravatar ($avatar) {
	$custom_avatar = get_stylesheet_directory_uri() . '/images/gravatar.png';
	$avatar[$custom_avatar] = "Meadow Gravatar";
	return $avatar;
}


// Previous and Next Post navigation in the same category in single Posts only
add_action('genesis_before_entry', 'mc_custom_post_nav');
function mc_custom_post_nav() {

	if ( !is_singular('post') )
		return;
	echo '<div class="prev-next-post-links">';
		previous_post_link('<div class="previous-post-link alignleft"><i class="fa fa-caret-left" aria-hidden="true"></i> %link</div>', 'Previous Post');
		next_post_link('<div class="next-post-link alignright">%link <i class="fa fa-caret-right" aria-hidden="true"></i></div>', 'Next Post');
	echo '</div>';

}




//* --------------------------------------------------------------------------------------------------------------------------
//* WOOCOMMERCE >>
//* --------------------------------------------------------------------------------------------------------------------------



//* Load Custom Woocommerce Stylesheet
//* --------------------------------------------------------
add_action( 'wp_enqueue_scripts', 'mc_custom_woo_css' );
function mc_custom_woo_css() {
	wp_enqueue_style( 'custom-stylesheet', CHILD_URL . '/custom-woo.css', array(), PARENT_THEME_VERSION );
}


//* Add Woocommerce Support
//* --------------------------------------------------------
add_theme_support( 'genesis-connect-woocommerce' );


//* Woocommerce - Remove Sidebar
//* --------------------------------------------------------
remove_action('woocommerce_sidebar', 'woocommerce_get_sidebar',10);


//* Woocommerce - Move Product Description
//* --------------------------------------------------------
/** Display product description the_content */
function dot_do_product_desc() {

    global $woocommerce, $post;

    if ( $post->post_content ) : ?>
        <div itemprop="description" class="item-description">
            <?php $heading = apply_filters('woocommerce_product_description_heading', __('Product Description', 'woocommerce')); ?>

            <!-- <h2><?php echo $heading; ?></h2> -->
            <?php the_content(); ?>

        </div>
    <?php endif;
}
add_action( 'woocommerce_single_product_summary', 'dot_do_product_desc', 20 );

remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_excerpt', 20);



//* Woocommerce - Add Cart to Menu
//* --------------------------------------------------------
add_filter('wp_nav_menu_items','mc_wcmenucart', 10, 2);
function mc_wcmenucart($menu, $args) {

	// Check if WooCommerce is active and add a new item to a menu assigned to Secondary Navigation Menu location
	if ( !in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) || 'secondary' !== $args->theme_location )
		return $menu;

	ob_start();
		global $woocommerce;
		$viewing_cart = __('View your shopping cart', 'mellow-theme');
		$start_shopping = __('Start shopping', 'mellow-theme');
		$cart_url = $woocommerce->cart->get_cart_url();
		$shop_page_url = get_permalink( woocommerce_get_page_id( 'shop' ) );
		$cart_contents_count = $woocommerce->cart->cart_contents_count;
		$cart_contents = sprintf(_n('%d item', '%d items', $cart_contents_count, 'mellow-theme'), $cart_contents_count);
		$cart_total = $woocommerce->cart->get_cart_total();
		// Uncomment the line below to hide nav menu cart item when there are no items in the cart
		if ( $cart_contents_count > 0 ) {
			if ($cart_contents_count == 0) {
				$menu_item = '<li class="right"><a class="wcmenucart-contents" href="'. $shop_page_url .'" title="'. $start_shopping .'">';
			} else {
				$menu_item = '<li class="right"><a class="wcmenucart-contents" href="'. $cart_url .'" title="'. $viewing_cart .'">';
			}

			$menu_item .= '<i class="fa fa-shopping-cart"></i> ';

			$menu_item .= $cart_contents.' - '. $cart_total;
			$menu_item .= '</a></li>';
		// Uncomment the line below to hide nav menu cart item when there are no items in the cart
		}
		echo $menu_item;
	$social = ob_get_clean();
	return $menu . $social;

}



//* --------------------------------------------------------------------------------------------------------------------------
//* FOOTER >>
//* --------------------------------------------------------------------------------------------------------------------------



//* --------------------------------------------------------
remove_action( 'genesis_footer', 'genesis_do_footer' );
add_action( 'genesis_footer', 'mc_custom_footer' );
function mc_custom_footer() {
	?>
	Copyright &copy; 2016 &middot; Design by <a href="http://www.meadowprintables.com">Meadow</a>
	<?php
}

//* Add support for 3-column footer widgets
//* --------------------------------------------------------
add_theme_support( 'genesis-footer-widgets', 2 );