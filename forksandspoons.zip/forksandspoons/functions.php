<?php
//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );

//* Child theme (do not remove)
define( 'CHILD_THEME_NAME', 'Forks & Spoons' );
define( 'CHILD_THEME_VERSION', '1.0' );

//* Enqueue Google Fonts
add_action( 'wp_enqueue_scripts', 'genesis_sample_google_fonts' );
function genesis_sample_google_fonts() {
	wp_enqueue_style( 'google-fonts', '//fonts.googleapis.com/css?family=Averia+Sans+Libre|Inconsolata:400,700)', array(), CHILD_THEME_VERSION );
}

//* Add HTML5 markup structure
add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list' ) );

//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Add support for custom background
add_theme_support( 'custom-background' );

//* Add support for 3-column footer widgets
add_theme_support( 'genesis-footer-widgets', 3 );

//* Customize the entry meta in the entry header (requires HTML5 theme support)
add_filter( 'genesis_post_info', 'tbs_post_info_filter' );
function tbs_post_info_filter($post_info) {
	$post_info = '[post_date] [post_comments] [post_edit]';
	return $post_info;
}

//* Customize the credits
add_filter( 'genesis_footer_creds_text', 'tbs_footer_creds_text' );
function tbs_footer_creds_text() {
	echo '<div class="creds"><p>';
	echo 'Copyright &copy; ';
	echo date('Y');
	echo ' &middot; Designed & Developed by <a href="http://exempel.se" target="_blank">Ooch! It is my blog!</a> ';
	echo '</p></div>';
}

//* Customize the post meta function
add_filter( 'genesis_post_meta', 'tbs_post_meta_filter' );
function tbs_post_meta_filter($post_meta) {
if ( !is_page() ) {
	$post_meta = '[post_categories before="Categories: "] [post_tags before="Tagged: "]';
	return $post_meta;
}}

//* Modify the WordPress read more link
add_filter( 'the_content_more_link', 'tbs_read_more_link' );
function tbs_read_more_link() {
	return '<a class="more-link" href="' . get_permalink() . '">Keep Reading</a>';
}

//* Customize search form input box text
add_filter( 'genesis_search_text', 'tbs_search_text' );
function tbs_search_text( $text ) {
	return esc_attr( 'Search My Blog' );
}

//* Customize the previous page link
add_filter ( 'genesis_prev_link_text' , 'tbs_previous_page_link' );
function tbs_previous_page_link ( $text ) {
    return '&#x000AB; Previous';
}

//* Customize the next page link
add_filter ( 'genesis_next_link_text' , 'tbs_next_page_link' );
function tbs_next_page_link ( $text ) {
    return 'Next &#x000BB;';
}
