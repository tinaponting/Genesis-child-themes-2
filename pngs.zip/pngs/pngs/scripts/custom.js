/* Search */
	
	jQuery(".header-search-a").click(function (){
		var header_search = jQuery(this).parent();
		if (header_search.hasClass("header-search-active")) {
			header_search.removeClass("header-search-active");
			header_search.find("i").addClass("icon-search").removeClass("icon-close");
			jQuery(".wrap-search").slideUp(300);
		}else {
			var header = jQuery("#header").height();
			header_search.addClass("header-search-active");
			header_search.find("i").addClass("icon-close").removeClass("icon-search");
			jQuery(".wrap-search").css({"padding-top":header+50});
			jQuery(".wrap-search").slideDown(300);
		}
	});
	
	
//Sticky

var j=jQuery.noConflict();	
j(window).scroll(function(){
  var sticky = j('.sticky'),
      scroll = j(window).scrollTop();

  if (scroll >= 240) sticky.addClass('fixeds');
  else sticky.removeClass('fixeds');
});	

//Menu

var j=jQuery.noConflict();
(function(){
var classes = document.getElementsByClassName('menu_control');
for (i = 0; i < classes.length; i++) {
classes[i].onclick = function() {
var menu = this.nextElementSibling;
if (/show_menu/.test(menu.className))
menu.className = menu.className.replace('show_menu', '').trim();
else
menu.className += ' show_menu';
};
}
})();