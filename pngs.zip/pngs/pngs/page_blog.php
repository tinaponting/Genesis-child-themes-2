<?php
/*
Template Name: Blog
*/


// Add custom body class to the head
add_filter( 'body_class', 'metro_add_body_class' );
function metro_add_body_class( $classes ) {
   $classes[] = 'blog blog2';
   return $classes;
}

genesis();