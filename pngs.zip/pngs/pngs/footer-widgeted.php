<div class="footer-widgets" id="footer">
	<div class="wrap">
    	<div class="footer-widgets-1">
		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer Left') ) : ?>
    			<div class="widget">
            		<h4 itemprop="headline"><?php _e("Footer #Left", 'genesis'); ?></h4>
            		<p><?php _e("This is an example of a widget area that you can place text to describe a product or service. You can also use other WordPress widgets such as recent posts, recent comments, a tag cloud or more.", 'genesis'); ?></p>
	    		</div><!-- end .widget -->
	    	<?php endif; ?> 
		 </div>

   		<!-- end .footer-left -->
		
<div class="footer-widgets-2">
<?php
if (genesism_get_option('news_in_picture')){
?>		   	
<div class="footer-widgets2 widget footer_widget news_picture">

<div class="line_title">
<h4 class="widget-title"><?php echo genesism_option('news_pic_title'); ?></h4>
</div>
			<div class='news_flickr_cnt'>
				<?php
					query_posts('post_type=post&posts_per_page=9&orderby=comment_count&order=DESC');
					while (have_posts()): the_post(); 
					$i++;
					$class = ( $i % 3 ) ? 'news_flickr entry_cnt' : 'news_flickr entry_cnt last';
				?>
					<div class='<?php echo $class; ?>'>
						<div class='news_img'>
							<?php
							
							if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true);
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video
							 $f_img_width23 = 106;
							$f_img_height23 = 80;
								// Auto feature image defaults
							$thumb = get_post_thumbnail_id(); 
							$img_url = wp_get_attachment_url( $thumb,'full' ); 
							$image = aq_resize( $img_url, $f_img_width23, $f_img_height23, true );
							// Catch the Image defaults
							$catch_img_url = catch_that_image( $thumb,'full' );
							$catch_image = aq_resize( $catch_img_url, $f_img_width23, $f_img_height23, true );
							if(has_post_thumbnail())
							echo
							"<div class=\"featured_image\">\n".
							"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width23 . "\" height=\"" . $f_img_height23 . "\" alt=\"" . get_the_title() . "\"><div class='thumb_hover'></div></a>\n".
							"</div>\n";
							elseif (catch_that_image()){ 
							echo
							"<div class=\"featured_image\">\n".
							"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width23 . "\" height=\"" . $f_img_height23 . "\" alt=\"" . get_the_title() . "\"></a>\n".
							"</div>\n"; 
							}
}
}							
							/*featured image ends here*/
							?>
						</div>
					</div>
				<?php
					endwhile;
				?>
			</div>
			
</div>
<?php
}
?>	
</div>
    
 
    	</div><!-- end .wrap -->
</div><!-- end #footer-widgets -->