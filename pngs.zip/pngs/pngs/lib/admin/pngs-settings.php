<?php

/**
 * This function registers the default values for genesis theme settings
 */
 
function genesism_theme_settings_defaults() {
$defaults = array( // define our defaults
'style' => 'default',
'custom' => 0,
'shortcodes-css' => 1,

'top_header' => 1,
'btm_header' => 1,
'btm_menu' => 1,
'header_social' => 1,
'search_section' => 1,
'read_more' => 1,
'sidebar_optin_section' => 1,
'news_in_picture' => 1,
'single_social_share' => 1,
'single_ad_box' => 1,
'landing_video_optin' => 1,
'landing_feature' => 1,
'footer1' => 1,

'top_header_logo_img' => 'http://pngs.genesislovers.com/wp-content/uploads/2016/03/tlogo.png',
'top_header_bg_img' => 'http://pngs.genesislovers.com/wp-content/uploads/2016/03/imag2.jpg',
'btm_header_logo_img' => 'http://pngs.genesislovers.com/wp-content/uploads/2016/03/logo1.png',
'search_text' => 'Search here',
'read_text' => 'View More',
'email_text' => 'Enter Your email',
'submit_text' => 'submit',
'optin_header_one' => 'PNGS FREE NEWSLETTER',
'optin_header_fs' => 'THE',
'optin_header_cs' => 'DAILY',
'optin_header_ls' => 'NEWS',
'news_pic_title' => 'News in Pictures',
'share_title' => 'Social Share',
'float' => 'right',
'single_ad_img' => '<img alt="Single Page Ad" src="http://pngs.genesislovers.com/wp-content/uploads/2016/03/postad.png"/>',
'name_text1' => 'Enter your name',
'email_text1' => 'Enter your email',
'submit_text1' => 'Submit',
'ovb_title' => 'Lorem epsum dollar eveniet',
'ovb_content' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy. There are many variations of.',
'land_optin_video' => '<iframe width="420" height="315" src="https://www.youtube.com/embed/k7wAIqlK-Pc"  allowfullscreen></iframe>',
'land_optin_bg' => 'http://pngs.genesislovers.com/wp-content/uploads/2016/03/g4.jpg',
'landing_feature_title' => 'Explore awesomeness',
'landing_feature_para' => 'Lorem ipsum dolor sit amet consectetur adipisicing elit sed',
'land_ftr1_img' => 'http://pngs.genesislovers.com/wp-content/uploads/2016/03/ico1.png',
'ftr1_title' => 'Easy to Customize ',
'feature1_para' => 'Lorem lean startup ipsum product market fit customer development acquihire technical cofounder fit customer development acquihire.',
'land_ftr2_img' => 'http://pngs.genesislovers.com/wp-content/uploads/2016/03/ico2.png',
'ftr2_title' => 'Responsive Design',
'feature2_para' => 'Lorem lean startup ipsum product market fit customer development acquihire technical cofounder fit customer development acquihire.',
'land_ftr3_img' => 'http://pngs.genesislovers.com/wp-content/uploads/2016/03/ico3.png',
'ftr3_title' => 'User Engagement',
'feature3_para' => 'Lorem lean startup ipsum product market fit customer development acquihire technical cofounder fit customer development acquihire.',
'land_ftr4_img' => 'http://pngs.genesislovers.com/wp-content/uploads/2016/03/ico4.png',
'ftr4_title' => 'Responsive Design',
'feature4_para' => 'Lorem lean startup ipsum product market fit customer development acquihire technical cofounder fit customer development acquihire.',
'land_ftr5_img' => 'http://pngs.genesislovers.com/wp-content/uploads/2016/03/ico5.png',
'ftr5_title' => 'Lots of Variations',
'feature5_para' => 'Lorem lean startup ipsum product market fit customer development acquihire technical cofounder fit customer development acquihire.',
'land_ftr6_img' => 'http://pngs.genesislovers.com/wp-content/uploads/2016/03/ico6.png',
'ftr6_title' => 'Customer Development',
'feature6_para' => 'Lorem lean startup ipsum product market fit customer development acquihire technical cofounder fit customer development acquihire.',



'f_img_width'=>'304',
'f_img_height'=>'202',



'footer_text' => 'Copyright &copy;'.date('Y') .  ' <a href="'. get_bloginfo('url') .'">' . get_bloginfo('name') . '</a>'
	
	);
	
	return apply_filters('genesism_theme_settings_defaults', $defaults);

}



function genesism_theme_settings_boxes() {
	global $_genesism_theme_settings_pagehook;
	
	if (function_exists('add_screen_option')) { add_screen_option('layout_columns', array('max' => 2, 'default' => 2) ); }

add_meta_box('genesism-theme-settings-version', __('Theme Information', 'genesism'), 'genesism_theme_settings_info_box', $_genesism_theme_settings_pagehook, 'normal');	
 }
  
 function genesism_theme_settings_info_box() { 
?>

<p class="bolder"><strong><?php echo CHILD_THEME_NAME; ?></strong> by <a href="http://genesislovers.com">genesislovers.com</a></p>
<p><strong>
  <?php _e('Version:', 'genesism'); ?>
  </strong> <?php echo CHILD_THEME_VERSION; ?> <strong>
   </p>
<p><span class="description">
  <?php _e('For support, please visit <a href="http://genesislovers.com/contactus/">http://genesislovers.com/contactus/</a>', 'genesism'); ?>
  </span></p>

<div id="tabs">

	<ul>
		<li><a href="#tabs-1"><?php _e("Top Header Section", 'genesism'); ?></a></li>
		<li><a href="#tabs-2"><?php _e("Bottom Header Logo", 'genesism'); ?></a></li>	
		<li><a href="#tabs-3"><?php _e("Bottom Menu", 'genesism'); ?></a></li>	
		<li><a href="#tabs-4"><?php _e("Header Social", 'genesism'); ?></a></li>
		<li><a href="#tabs-5"><?php _e("Header Search", 'genesism'); ?></a></li>
		<li><a href="#tabs-6"><?php _e("Feature Image", 'genesism'); ?></a></li>		
		<li><a href="#tabs-7"><?php _e("Read More Section", 'genesism'); ?></a></li>		
		<li><a href="#tabs-8"><?php _e("Sidebar Optin Section", 'genesism'); ?></a></li>		
		<li><a href="#tabs-9"><?php _e("Footer News in Pictures Section", 'genesism'); ?></a></li>
		<li><a href="#tabs-10"><?php _e("Single Page Social Share", 'genesism'); ?></a></li>		
		<li><a href="#tabs-11"><?php _e("Single Page Advertisement", 'genesism'); ?></a></li>
		<li><a href="#tabs-12"><?php _e("Landing Video Optin Box", 'genesism'); ?></a></li>
		<li><a href="#tabs-13"><?php _e("Landing Feature Box", 'genesism'); ?></a></li>
		<li><a href="#tabs-14"><?php _e("Footer Text section", 'genesism'); ?></a></li>		
		<li><a href="#tabs-15"><?php _e("Custom CSS", 'genesism'); ?></a></li>
	</ul>
	
	<div id="tabs-1">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo PNGS_SETTINGS_FIELD; ?>[top_header]" id="<?php echo PNGS_SETTINGS_FIELD; ?>[top_header]" value="1" <?php checked(1, genesism_get_option('top_header')); ?> />
				<label for="<?php echo PNGS_SETTINGS_FIELD; ?>[top_header]">
				<?php _e("Enable Top Header Logo Section", 'genesism'); ?>
				</label>
			</li>
			<li class="second_list">
				<label>Enter the Top Header Logo Url Link here</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[top_header_logo_img]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('top_header_logo_img') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Paste your Top Header Background img Url Link here</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[top_header_bg_img]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('top_header_bg_img') ); ?></textarea>
			</li>
			
		</ul>
	</div>
	
	<div id="tabs-2">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo PNGS_SETTINGS_FIELD; ?>[btm_header]" id="<?php echo PNGS_SETTINGS_FIELD; ?>[btm_header]" value="1" <?php checked(1, genesism_get_option('btm_header')); ?> />
				<label for="<?php echo PNGS_SETTINGS_FIELD; ?>[btm_header]">
				<?php _e("Enable Bottom Header Logo Section", 'genesism'); ?>
				</label>
			</li>
			<li class="second_list">
				<label>Enter the Bottom Header Logo Url Link here</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[btm_header_logo_img]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('btm_header_logo_img') ); ?></textarea>
			</li>	
		</ul>
	</div>
	
	<div id="tabs-3">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo PNGS_SETTINGS_FIELD; ?>[btm_menu]" id="<?php echo PNGS_SETTINGS_FIELD; ?>[btm_menu]" value="1" <?php checked(1, genesism_get_option('btm_menu')); ?> />
				<label for="<?php echo PNGS_SETTINGS_FIELD; ?>[btm_menu]">
				<?php _e("Enable Bottom Header Menu Section", 'genesism'); ?>
				</label>
			</li>
		</ul>
	</div>
	
	<div id="tabs-4">
		<ul>
						
			<li class="second_list">
				<label>Paste your Facebook URL Link</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[facebook_text1]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('facebook_text1') ); ?></textarea> 
			</li>
			
			<li class="second_list"><label>Paste your Twitter URL Link</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[twitter_text1]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('twitter_text1') ); ?></textarea> 
			</li>
			<li class="second_list"><label>Paste your Googleplus URL Link</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[googleplus_text1]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('googleplus_text1') ); ?></textarea> 
			</li>
			
			<li class="second_list"><label>Paste your Pinterest URL Link</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[pinterest_text1]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('pinterest_text1') ); ?></textarea>
			</li>
			
			<li class="second_list"><label>Paste your Instagram URL Link</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[instagram_text1]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('instagram_text1') ); ?></textarea>
			</li>
			
			<li class="second_list"><label>Paste your Youtube URL Link</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[youtube_text1]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('youtube_text1') ); ?></textarea>
			</li>
			
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo PNGS_SETTINGS_FIELD; ?>[header_social]" id="<?php echo PNGS_SETTINGS_FIELD; ?>[header_social]" value="1" <?php checked(1, genesism_get_option(header_social)); ?> />
				<label for="<?php echo PNGS_SETTINGS_FIELD; ?>[header_social]">
				<?php _e("Disable Header Social follow Icons", 'genesism'); ?>
				</label>
			</li>
			
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo PNGS_SETTINGS_FIELD; ?>[fb_check]" id="<?php echo PNGS_SETTINGS_FIELD; ?>[fb_check]" value="1" <?php checked(1, genesism_get_option(fb_check)); ?> />
				<label for="<?php echo PNGS_SETTINGS_FIELD; ?>[fb_check]">
				<?php _e("Disable Facebook Icon", 'genesism'); ?>
				</label>
			</li>
			
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo PNGS_SETTINGS_FIELD; ?>[tw_check]" id="<?php echo PNGS_SETTINGS_FIELD; ?>[tw_check]" value="1" <?php checked(1, genesism_get_option(tw_check)); ?> />
				<label for="<?php echo PNGS_SETTINGS_FIELD; ?>[tw_check]">
				<?php _e("Disable Twitter Icon", 'genesism'); ?>
				</label>
			</li>
			
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo PNGS_SETTINGS_FIELD; ?>[gp_check]" id="<?php echo PNGS_SETTINGS_FIELD; ?>[gp_check]" value="1" <?php checked(1, genesism_get_option(gp_check)); ?> />
				<label for="<?php echo PNGS_SETTINGS_FIELD; ?>[gp_check]">
				<?php _e("Disable Googleplus Icon", 'genesism'); ?>
				</label>
			</li>
			
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo PNGS_SETTINGS_FIELD; ?>[pin_check]" id="<?php echo PNGS_SETTINGS_FIELD; ?>[pin_check]" value="1" <?php checked(1, genesism_get_option(pin_check)); ?> />
				<label for="<?php echo PNGS_SETTINGS_FIELD; ?>[pin_check]">
				<?php _e("Disable Pinterest Icon", 'genesism'); ?>
				</label>
			</li>
			
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo PNGS_SETTINGS_FIELD; ?>[ins_check]" id="<?php echo PNGS_SETTINGS_FIELD; ?>[ins_check]" value="1" <?php checked(1, genesism_get_option(ins_check)); ?> />
				<label for="<?php echo PNGS_SETTINGS_FIELD; ?>[ins_check]">
				<?php _e("Disable Instagram Icon", 'genesism'); ?>
				</label>
			</li>
			
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo PNGS_SETTINGS_FIELD; ?>[yt_check]" id="<?php echo PNGS_SETTINGS_FIELD; ?>[yt_check]" value="1" <?php checked(1, genesism_get_option(yt_check)); ?> />
				<label for="<?php echo PNGS_SETTINGS_FIELD; ?>[yt_check]">
				<?php _e("Disable Youtube Icon", 'genesism'); ?>
				</label>
			</li>
			
		</ul>	
	</div>
	
	<div id="tabs-5">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo PNGS_SETTINGS_FIELD; ?>[search_section]" id="<?php echo PNGS_SETTINGS_FIELD; ?>[search_section]" value="1" <?php checked(1, genesism_get_option('search_section')); ?> />
				<label for="<?php echo PNGS_SETTINGS_FIELD; ?>[search_section]">
				<?php _e("Enable Header Search", 'genesism'); ?>
				</label>
			</li>
			<li class="second_list">
				<label>Enter the Search Placeholder text here</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[search_text]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('search_text') ); ?></textarea>
			</li>
		</ul>
	</div>
	
	<div id="tabs-6">
		<ul>
			<li class="second_list"><label>Width of the Featured Image</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[f_img_width]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('f_img_width') ); ?></textarea> 
			</li>
			<li class="second_list"><label>Height of the Featured Image</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[f_img_height]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('f_img_height') ); ?></textarea> 
			</li>
		</ul>
	</div>
	

		
	<div id="tabs-7">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo PNGS_SETTINGS_FIELD; ?>[read_more]" id="<?php echo PNGS_SETTINGS_FIELD; ?>[read_more]" value="1" <?php checked(1, genesism_get_option('read_more')); ?> />
				<label for="<?php echo PNGS_SETTINGS_FIELD; ?>[read_more]">
				<?php _e("Enable Read More Section", 'genesism'); ?>
				</label>
			</li>
			<li class="second_list">
				<label>Enter the Read More Text here</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[read_text]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('read_text') ); ?></textarea>
			</li>
		</ul>
	</div>
	
		
	<div id="tabs-8">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo PNGS_SETTINGS_FIELD; ?>[sidebar_optin_section]" id="<?php echo PNGS_SETTINGS_FIELD; ?>[sidebar_optin_section]" value="1" <?php checked(1, genesism_get_option('sidebar_optin_section')); ?> />
				<label for="<?php echo PNGS_SETTINGS_FIELD; ?>[sidebar_optin_section]">
				<?php _e("Enable Sidebar Optin Section", 'genesism'); ?>
				</label>
			</li>
			<li class="second_list">
				<label>Paste your Optin Code and Press Tab Button</label>
				<textarea id="optin_code" name="<?php echo PNGS_SETTINGS_FIELD; ?>[optin_code]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_code') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form name</label>
				<textarea id="optin_name" name="<?php echo PNGS_SETTINGS_FIELD; ?>[optin_name]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('optin_name') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form Email</label>
				<textarea id="optin_email" name="<?php echo PNGS_SETTINGS_FIELD; ?>[optin_email]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('optin_email') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form action url</label>
				<textarea id="optin_url" name="<?php echo PNGS_SETTINGS_FIELD; ?>[optin_url]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_url') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Hidden fields</label>
				<textarea id="optin_hidden" name="<?php echo PNGS_SETTINGS_FIELD; ?>[optin_hidden]" rows="10" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_hidden') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Change your Enter your Email Place holder text here</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[email_text]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('email_text') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change your Subscribe me button text</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[submit_text]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('submit_text') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Enter the Optin Header Text here</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[optin_header_one]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('optin_header_one') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Enter the Optin Sub header First Section Text here</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[optin_header_fs]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('optin_header_fs') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Enter the Optin Sub header Center Section Text here</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[optin_header_cs]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('optin_header_cs') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Enter the Optin Sub header Last Section Text here</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[optin_header_ls]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('optin_header_ls') ); ?></textarea>
			</li>
	</ul>
<script type="text/javascript">

	var $j = jQuery.noConflict();

	$j(document).ready(function(){

	$j("#optin_code").blur(function(){

	var txt=$j(this).val();

	

	if(txt=="")

	{

	$j("#optin_url").val("");

	$j("#optin_hidden").val("");

	$j("#optin_name").val("");

	$j("#optin_email").val("");

	return false;

	}

	

	var pos1=0;

	var pos2=0;

	var i=1;

	var hidden="";

	while(1)

	{

	pos1=txt.indexOf("<input",pos1);

	if(pos1<0) break;

	pos2=txt.indexOf(">",pos1+1);

	var text=txt.substr(pos1,pos2-pos1);

	

	pp=text.indexOf('type="hidden"');

	pp1=text.indexOf('type="submit"');

	

	if(pp>0)

	{

	hidden+=text+">";

	}

	if(pp<0 && pp1<0){

	pp=text.indexOf('name="');

	pp=pp+6;

	pp1=text.indexOf('"',pp+1);

	var tt=text.substr(pp,pp1-pp);

	if(i==1) $j("#optin_name").val(tt);

	else $j("#optin_email").val(tt);

	i++;

	}

	

	pos1=pos2+1;

	}

	

	pos1=txt.indexOf("<form",0);

	pos2=txt.indexOf(">",pos1+1);

	text=txt.substr(pos1,pos2-pos1);

	pp=text.indexOf('action="');

	pp=pp+8;

	pp1=text.indexOf('"',pp+1);

	var tt=text.substr(pp,pp1-pp);

	$j("#optin_url").val(tt);

	$j("#optin_hidden").val(hidden);

	});

	});



</script> 				
	
</div>
	
	
	
	<div id="tabs-9">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo PNGS_SETTINGS_FIELD; ?>[news_in_picture]" id="<?php echo PNGS_SETTINGS_FIELD; ?>[news_in_picture]" value="1" <?php checked(1, genesism_get_option('news_in_picture')); ?> />
				<label for="<?php echo PNGS_SETTINGS_FIELD; ?>[news_in_picture]">
				<?php _e("Enable Footer News in Pictures Section", 'genesism'); ?>
				</label>
			</li>
			
			<li class="second_list">
				<label>Change the News in Picture Header Text here</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[news_pic_title]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('news_pic_title') ); ?></textarea>
			</li>
			
		</ul>
	</div>
	
	<div id="tabs-10">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo PNGS_SETTINGS_FIELD; ?>[single_social_share]" id="<?php echo PNGS_SETTINGS_FIELD; ?>[single_social_share]" value="1" <?php checked(1, genesism_get_option('single_social_share')); ?> />
				<label for="<?php echo PNGS_SETTINGS_FIELD; ?>[single_social_share]">
				<?php _e("Enable Single Page Social Share Section", 'genesism'); ?>
				</label>
			</li>
			
			<li class="second_list">
				<label>Change the Single Page Social Share Header Text here</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[share_title]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('share_title') ); ?></textarea>
			</li>
			
		</ul>
	</div>
	
		
	<div id="tabs-11">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo PNGS_SETTINGS_FIELD; ?>[single_ad_box]" id="<?php echo PNGS_SETTINGS_FIELD; ?>[single_ad_box]" value="1" <?php checked(1, genesism_get_option('single_ad_box')); ?> />
				<label for="<?php echo PNGS_SETTINGS_FIELD; ?>[single_ad_box]">
				<?php _e("Enable Single Page Advertisement", 'genesism'); ?>
				</label>
			</li>
			<li class="second_list">
				<label>Enter the ad position ... left or right...</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[float]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('float') ); ?></textarea> 
			</li>
			<li class="second_list">
				<label>Enter the Single Page Advertisement Image url Link here</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[single_ad_img]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('single_ad_img') ); ?></textarea>
			</li>
			
		</ul>
	</div>
	
	<div id="tabs-12">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo PNGS_SETTINGS_FIELD; ?>[landing_video_optin]" id="<?php echo PNGS_SETTINGS_FIELD; ?>[landing_video_optin]" value="1" <?php checked(1, genesism_get_option('landing_video_optin')); ?> />
				<label for="<?php echo PNGS_SETTINGS_FIELD; ?>[landing_video_optin]">
				<?php _e("Enable Landing Page Video & Optin Section", 'genesism'); ?>
				</label>
			</li>
			
			<li class="second_list">
				<label>Paste your Optin Code and Press Tab Button</label>
				<textarea id="optin_code1" name="<?php echo PNGS_SETTINGS_FIELD; ?>[optin_code1]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_code1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form name</label>
				<textarea id="optin_name1" name="<?php echo PNGS_SETTINGS_FIELD; ?>[optin_name1]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('optin_name1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form Email</label>
				<textarea id="optin_email1" name="<?php echo PNGS_SETTINGS_FIELD; ?>[optin_email1]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('optin_email1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form action url</label>
				<textarea id="optin_url1" name="<?php echo PNGS_SETTINGS_FIELD; ?>[optin_url1]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_url1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Hidden fields</label>
				<textarea id="optin_hidden1" name="<?php echo PNGS_SETTINGS_FIELD; ?>[optin_hidden1]" rows="10" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_hidden1') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Change your Optin Name Place holder text here</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[name_text1]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('name_text1') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Enter your Email Place holder text here</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[email_text1]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('email_text1') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Change your Subscribe me button text</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[submit_text1]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('submit_text1') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Enter the Optin Header Text here</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[ovb_title]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('ovb_title') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Enter the Optin Content Text here</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[ovb_content]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('ovb_content') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Page video URL link here</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[land_optin_video]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('land_optin_video') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Change the Landing Page Background Image URL link here</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[land_optin_bg]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('land_optin_bg') ); ?></textarea>
			</li>
			
			
			
		<script type="text/javascript">

	var $j = jQuery.noConflict();

	$j(document).ready(function(){

	$j("#optin_code1").blur(function(){

	var txt=$j(this).val();

	

	if(txt=="")

	{

	$j("#optin_url1").val("");

	$j("#optin_hidden1").val("");

	$j("#optin_name1").val("");

	$j("#optin_email1").val("");

	return false;

	}

	

	var pos1=0;

	var pos2=0;

	var i=1;

	var hidden="";

	while(1)

	{

	pos1=txt.indexOf("<input",pos1);

	if(pos1<0) break;

	pos2=txt.indexOf(">",pos1+1);

	var text=txt.substr(pos1,pos2-pos1);

	

	pp=text.indexOf('type="hidden"');

	pp1=text.indexOf('type="submit"');

	

	if(pp>0)

	{

	hidden+=text+">";

	}

	if(pp<0 && pp1<0){

	pp=text.indexOf('name="');

	pp=pp+6;

	pp1=text.indexOf('"',pp+1);

	var tt=text.substr(pp,pp1-pp);

	if(i==1) $j("#optin_name1").val(tt);

	else $j("#optin_email1").val(tt);

	i++;

	}

	

	pos1=pos2+1;

	}

	

	pos1=txt.indexOf("<form",0);

	pos2=txt.indexOf(">",pos1+1);

	text=txt.substr(pos1,pos2-pos1);

	pp=text.indexOf('action="');

	pp=pp+8;

	pp1=text.indexOf('"',pp+1);

	var tt=text.substr(pp,pp1-pp);

	$j("#optin_url1").val(tt);

	$j("#optin_hidden1").val(hidden);

	});

	});



</script> 
			
			
		</ul>
	</div>
	
	
	<div id="tabs-13">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo PNGS_SETTINGS_FIELD; ?>[landing_feature]" id="<?php echo PNGS_SETTINGS_FIELD; ?>[landing_feature]" value="1" <?php checked(1, genesism_get_option('landing_feature')); ?> />
				<label for="<?php echo PNGS_SETTINGS_FIELD; ?>[landing_feature]">
				<?php _e("Enable Landing Feature Section", 'genesism'); ?>
				</label>
			</li>
			
			<li class="second_list">
				<label>Change the Landing Feature Header Text here</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[landing_feature_title]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('landing_feature_title') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Feature Content Text here</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[landing_feature_para]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_para') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Change the Landing Feature One Image URL Link here</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[land_ftr1_img]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('land_ftr1_img') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Change the Landing Feature One Title Text here</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[ftr1_title]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('ftr1_title') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Feature One Title Link here</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[ftr1_link]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('ftr1_link') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Feature One Para Text here</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[feature1_para]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('feature1_para') ); ?></textarea>
			</li>
			
			
			<li class="second_list">
				<label>Change the Landing Feature Two Image URL Link here</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[land_ftr2_img]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('land_ftr2_img') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Change the Landing Feature Two Title Text here</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[ftr2_title]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('ftr2_title') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Feature Two Title Link here</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[ftr2_link]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('ftr2_link') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Feature Two Para Text here</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[feature2_para]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('feature2_para') ); ?></textarea>
			</li>
			
			
			<li class="second_list">
				<label>Change the Landing Feature Three Image URL Link here</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[land_ftr3_img]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('land_ftr3_img') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Change the Landing Feature Three Title Text here</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[ftr3_title]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('ftr3_title') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Feature Three Title Link here</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[ftr3_link]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('ftr3_link') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Feature Three Para Text here</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[feature3_para]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('feature3_para') ); ?></textarea>
			</li>
			
			
			<li class="second_list">
				<label>Change the Landing Feature Four Image URL Link here</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[land_ftr4_img]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('land_ftr4_img') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Change the Landing Feature Four Title Text here</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[ftr4_title]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('ftr4_title') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Feature Four Title Link here</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[ftr4_link]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('ftr4_link') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Feature Four Para Text here</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[feature4_para]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('feature4_para') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Change the Landing Feature Five Image URL Link here</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[land_ftr5_img]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('land_ftr5_img') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Change the Landing Feature Five Title Text here</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[ftr5_title]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('ftr5_title') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Feature Five Title Link here</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[ftr5_link]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('ftr5_link') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Feature Five Para Text here</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[feature5_para]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('feature5_para') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Change the Landing Feature Six Image URL Link here</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[land_ftr6_img]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('land_ftr6_img') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Change the Landing Feature Six Title Text here</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[ftr6_title]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('ftr6_title') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Feature Six Title Link here</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[ftr6_link]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('ftr6_link') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Feature Six Para Text here</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[feature6_para]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('feature6_para') ); ?></textarea>
			</li>
			
			
			
		</ul>
	</div>
	
	<div id="tabs-14">	   
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo PNGS_SETTINGS_FIELD; ?>[footer1]" id="<?php echo PNGS_SETTINGS_FIELD; ?>[footer1]" value="1" <?php checked(1, genesism_get_option('footer1')); ?> />
				<label for="<?php echo PNGS_SETTINGS_FIELD; ?>[footer1]">
				<?php _e("Enable Footer text", 'genesism'); ?>
				</label>
			</li>
			<li class="second_list"><label>Use custom footer text?</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[footer_text]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('footer_text') ); ?></textarea> 
			</li>
		</ul>
	</div>	
	
	
	
	 <div id="tabs-15">
		<ul>
		<li class="second_list">
				<label>Enter the Custom CSS here</label>
				<textarea name="<?php echo PNGS_SETTINGS_FIELD; ?>[custom_css]" rows="30" cols="70"><?php echo htmlspecialchars( genesism_get_option('custom_css') ); ?></textarea>
		</li>			
		</ul>
	</div>
	
	
	
	
</div>  
  
<?php
}
 
 

	