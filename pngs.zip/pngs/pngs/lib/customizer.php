<?php

function pngs_customize_register( $wp_customize ) {
 /*******************************************
Color scheme
********************************************/
 
// add the section to contain the settings
$wp_customize->add_section( 'textcolors' , array(
    'title' =>  'Color Scheme',
) );

// 1.Background Color
$txtcolors[] = array(
    'slug'=>'body_bg_color', 
    'default' => '#FFFFFF',
    'label' => 'Background Color'
);

 
// 2.Body Text Color
$txtcolors[] = array(
    'slug'=>'body_txt_color', 
    'default' => '#888888',
    'label' => 'Body Text Color'
);


// 3.Header Text Color
$txtcolors[] = array(
    'slug'=>'header_txt_color', 
    'default' => '#212121',
    'label' => 'Header Text Color'
);

// 4.Bottom Header Background

$txtcolors[] = array(
    'slug'=>'btm_header_bg', 
    'default' => '#232323',
    'label' => 'Bottom Header BG Color'
);



// 5.link color
$txtcolors[] = array(
    'slug'=>'link_color', 
    'default' => '#FF006D',
    'label' => 'Link Color'
);


//6.Menu Text
$txtcolors[] = array(
    'slug'=>'menu_text', 
    'default' => '#fafafa',
    'label' => 'Menu Text Color '
);

// 7.Border color 
$txtcolors[] = array(
    'slug'=>'border_color', 
    'default' => '#EEEEEE',
    'label' => 'Border Color '
);
 
// 8.Editor Left BG color 
$txtcolors[] = array(
    'slug'=>'editor_left_bg', 
    'default' => '#222222',
    'label' => 'Editor Left BG Color '
);

// 9.Border One color 
$txtcolors[] = array(
    'slug'=>'border_one', 
    'default' => '#E3E3E3',
    'label' => 'Border One Color '
);


//10.Footer Text
$txtcolors[] = array(
    'slug'=>'footer_text_clr', 
    'default' => '#cccccc',
    'label' => 'Footer Text Color '
);

//11.Hover BG
$txtcolors[] = array(
    'slug'=>'hover_bg', 
    'default' => '#333333',
    'label' => 'Hover BG Color '
);

//12.Top Footer BG
$txtcolors[] = array(
    'slug'=>'top_footer_bg', 
    'default' => '#171717',
    'label' => 'Top Footer BG Color '
);



// add the settings and controls for each color
foreach( $txtcolors as $txtcolor ) {
 
    // SETTINGS
    $wp_customize->add_setting(
        $txtcolor['slug'], array(
            'default' => $txtcolor['default'],
            'type' => 'option', 
            'capability' => 
            'edit_theme_options'
        )
    );
    // CONTROLS
    $wp_customize->add_control(
        new WP_Customize_Color_Control(
            $wp_customize,
            $txtcolor['slug'], 
            array('label' => $txtcolor['label'], 
            'section' => 'textcolors',
            'settings' => $txtcolor['slug'])
        )
    );
}
}
add_action( 'customize_register', 'pngs_customize_register' );