<?php
/*
Template Name: Landing Page Without Feature
*/


// Add custom body class to the head
add_filter( 'body_class', 'metro_add_body_class' );
function metro_add_body_class( $classes ) {
   $classes[] = 'landingpage';
   return $classes;
}

// set full width layout
add_filter ( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );
remove_action( 'genesis_sidebar', 'genesis_do_sidebar' ); 
add_action('genesis_before_content','before_content');
function before_content(){
?>
<div class="landing_page_container wrap">
<?php
}

add_action('genesis_after_content','after_content');
function after_content(){
?>
</div>
<?php
}


add_action('genesis_before_content_sidebar_wrap','landingpage_optin',1);
function landingpage_optin(){
if (genesism_get_option('landing_video_optin')){	
?>

<div class="optin_video_box" style='background-image:url(<?php echo genesism_option('land_optin_bg');?> )'>
<div class='optin_video_box_color'>
<div class="optin_video_box_inner wrap">

	<div class="ovb_left">
		<div class="left_side_optin">
			<div class="landing_optin_title">
				<h3><?php echo genesism_option('ovb_title'); ?></h3>
				<p><?php echo genesism_option('ovb_content'); ?></p>	
			</div>	
			<form method="post" class="form" action="<?php echo stripslashes(genesism_option('optin_url1')); ?>" target="_blank">
			<div class="names"><input class="name" type="text" name="<?php echo stripslashes(genesism_option('optin_name1')); ?>" placeholder="<?php echo stripslashes(genesism_option('name_text1')); ?>"><div class='admins'></div></div>					
			<div class="names"><input class="email" type="text" name="<?php echo stripslashes(genesism_option('optin_email1')); ?>" placeholder="  <?php echo stripslashes(genesism_option('email_text1')); ?>"><div class='mails'></div></div>
			<?php echo stripslashes(genesism_option('optin_hidden1')); ?>
			<input name="submit" class="submit" type="submit" value="<?php echo stripslashes(genesism_option('submit_text1')); ?>"/>
			</form>
		</div>
	</div>
	<div class="ovb_right">
		<div class='squeeze_video'><?php echo genesism_option('land_optin_video'); ?>
		</div>
	</div>
	
		
</div>
</div>
</div>
<?php 
}
}


genesis();