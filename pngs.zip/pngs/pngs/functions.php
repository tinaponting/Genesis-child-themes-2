<?php
require_once(TEMPLATEPATH.'/lib/init.php'); // Start Genesis Engine
require_once(STYLESHEETPATH.'/lib/init.php'); // Start blog Options
require_once(STYLESHEETPATH.'/lib/updates.php'); // updates

include_once( 'lib/customizer.php' );
//* Add HTML5 markup structure
add_theme_support( 'html5' );


/** Support for various Image sizes */
add_theme_support('post-thumbnails');
//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Add support for custom background
add_theme_support( 'custom-background' );

//* Remove for custom background
 remove_custom_background();
 
 
 //* Display author box on archive pages
add_filter( 'get_the_author_genesis_author_box_archive', '__return_true' );

//* Customize the author box title
add_filter( 'genesis_author_box_title', 'custom_author_box_title' );
function custom_author_box_title() {
	return "<h3 itemscope=\"Name\"> " . get_the_author() . "</h3>";
}

function ea_default_term_title( $value, $term_id, $meta_key, $single ) {
	if( ( is_category() || is_tag() || is_tax() ) && 'headline' == $meta_key && ! is_admin() ) {
	
		// Grab the current value, be sure to remove and re-add the hook to avoid infinite loops
		remove_action( 'get_term_metadata', 'ea_default_term_title', 10 );
		$value = get_term_meta( $term_id, 'headline', true );
		add_action( 'get_term_metadata', 'ea_default_term_title', 10, 4 );
		// Use term name if empty
		if( empty( $value ) ) {
			$term = get_term_by( 'term_taxonomy_id', $term_id );
			$value = $term->name;
		}
	
	}
	return $value;		
}
add_filter( 'get_term_metadata', 'ea_default_term_title', 10, 4 );

// Add widgeted footer section
add_action('genesis_before_footer', 'footer_bottom_widgets'); 
function footer_bottom_widgets() {
    require(CHILD_DIR.'/footer-widgeted.php');
}

/** Register widget areas */



genesis_register_sidebar( array(
	'id'			=> 'front_page_top_widget',
	'name'			=> __( 'Front Page Top Widget', 'Resoluty Genesis Theme' ),
	'description'	=> __( 'This is the front page top widget if you are using a two or three column site layout option.', 'PNGS Genesis Child Theme' ),
	
) );

genesis_register_sidebar( array(
	'id'			=> 'front_page_content_widget',
	'name'			=> __( 'Front Page Content Widget', 'Resoluty Genesis Theme' ),
	'description'	=> __( 'This is the front page Content widget if you are using a two or three column site layout option.', 'PNGS Genesis Child Theme' ),
	
) );

genesis_register_sidebar( array(
	'id'			=> 'single_post_related',
	'name'			=> __( 'Single Page Related Post Widget', 'SEOGEN Genesis Theme' ),
	'description'	=> __( 'This is the Single Page Related Post widget if you are using a two or three column site layout option.', 'PNGS Genesis Child Theme' ),
	
) );


genesis_register_sidebar( array(
	'id'			=> 'footer-left',
	'name'			=> __( 'Footer Left', 'PNGS Genesis Child Theme ' ),
	'description'	=> __( 'This is the footer left section.', 'PPNGS Genesis Child Theme' ),
) );

genesis_register_sidebar( array(
	'id'			=> 'footer-right',
	'name'			=> __( 'Footer Right', 'PNGS Genesis Child Theme' ),
	'description'	=> __( 'This is the footer right section.', 'PNGS Genesis Child Theme' ),
) );

//Remove Post  entry footer  Meta data 
remove_action( 'genesis_entry_footer', 'genesis_post_meta' );
//remove archive description
remove_action( 'genesis_before_content', 'genesis_do_taxonomy_title_description', 15 );

//placeholder for comment box in single page
add_filter('comment_form_default_fields','comment_form_placeholder');
function comment_form_placeholder($fields){ 
	$fields['author'] = '<p class="comment-form-author">' . '<label for="author">' . __( '', 'genesis' ) . '</label> ' . 	
	( $req ? '<span class="required">*</span>' : '' ) .                   
	'<input id="author" name="author" type="text" placeholder="Name *" value="' . 				
	esc_attr( $commenter['comment_author'] ) . '" size="30"' . $aria_req . ' /></p>';				
    $fields['email'] = '<p class="comment-form-email"><label for="email">' . __( '', 'genesis' ) . '</label> ' .
	( $req ? '<span class="required">*</span>' : '' ) .
	'<input id="email" name="email" type="text" placeholder="Email *" value="' . 	
	esc_attr(  $commenter['comment_author_email'] ) . '" size="30"' . $aria_req . ' /></p>';	
	$fields['url'] = '<p class="comment-form-url"><label for="url">' . __( '', 'genesis' ) . '</label>' .    
	'<input id="url" name="url" type="text" placeholder="URL *" value="' . 	
	esc_attr( $commenter['comment_author_url'] ) . '" size="30" /></p>';	
    return $fields;
}

 
// Customizes Footer Text (set in options) 
if (genesism_get_option('footer1')) { 
	add_filter('genesis_footer_creds_text', 'custom_footer_creds_text');
	function custom_footer_creds_text($creds) {
    	$creds = genesism_get_option('footer_text');
    return $creds;
	}
}

remove_action( 'genesis_site_title', 'genesis_seo_site_title' );
remove_action( 'genesis_site_description', 'genesis_seo_site_description' );
/* BEGIN Custom User Contact Info */
function extra_contact_info($contactmethods) {

$contactmethods['facebook'] = 'Facebook';
$contactmethods['twitter'] = 'Twitter';

return $contactmethods;
}
add_filter('user_contactmethods', 'extra_contact_info');
/* END Custom User Contact Info */


add_action( 'genesis_before_comments', 'pngs_author_box',2 );
function pngs_author_box() {
if( is_single() ) {
 echo"<div class='single_title'><h3>THIS ARTICLE WAS WRITTEN BY</h3></div>";
echo "<div class=\"about-author\"><div class=\"author-info\" itemscope=\"itemscope\" itemtype=\"http://schema.org/person\" itemprop=\"Authorpost\" >" . get_avatar( get_the_author_meta( 'ID' ), '100' ) . "</div>
<div class='author_right_cnt'>";?>
<h3 class="author_name"><?php the_author_posts_link(); ?></h3> 
  <?php echo "<p itemprop=\"description\">" . get_the_author_meta( 'description' ) . 
 "</p>
 <div class=\"author_social\">"; 

 if ( get_the_author_meta( 'facebook' ) != '' ) {
 echo "<a class=\"afb  fa\" href=\"https://www.facebook.com/". get_the_author_meta( 'facebook' ) . "\"></a>";
 }
 if ( get_the_author_meta( 'googleplus' ) != '' ) {
 echo "<a class=\"agp fa\" href=\"https://plus.google.com/". get_the_author_meta( 'googleplus' ) . "\"></a>";
 }
 if ( get_the_author_meta( 'twitter' ) != '' ) {
 echo "<a class=\"atw fa\" href=\"https://twitter.com/". get_the_author_meta( 'twitter' ) . "\"></a>";
 }
 
echo "</div></div></div>";
 }
} 
//* Remove the entry meta in the entry header 
 

 add_filter( 'genesis_post_info', 'sp_post_info_filter' );
function sp_post_info_filter($post_info) {
if ( is_single() ) {
	$post_info = '[post_date] by [post_author_posts_link] [post_comments]';
	return $post_info;
}}
 

// Register Genesis Menus
add_action( 'init', 'register_additional_menu' );
function register_additional_menu() {
  
register_nav_menu( 'FirstMenu' ,__( 'Bottom Menu' ));
     
}

/** Remove Header */
remove_action( 'genesis_header', 'genesis_header_markup_open', 5 );
remove_action( 'genesis_header', 'genesis_do_header' );
remove_action( 'genesis_header', 'genesis_header_markup_close', 15 );

/** Add custom header support */
		  
add_action('genesis_header','injectHeader');	  
function injectHeader(){ 

?>

<div class="top_header_cont">
<div class="top_header_cont_bg" style='background-image:url(<?php echo genesism_option('top_header_bg_img');?> )'>
<div class="logo_section">
				<?php
				if (genesism_get_option('top_header')){?>
					<a title="<?php bloginfo('name'); ?>" href="<?php bloginfo('wpurl'); ?>"><img src="<?php echo genesism_get_option('top_header_logo_img'); ?>" alt="<?php bloginfo('name'); ?>"/></a>
				<?php
				}
				else { ?>
					<h1 itemprop="headline"><a title="<?php bloginfo('name'); ?>" href="<?php bloginfo('wpurl'); ?>"><?php bloginfo('name');?> </a></h1>
					
				<?php } ?>
</div>
</div>
</div>

<div class="btm_header_cont example sticky">
 <div class="btm_inner_header wrap ">
	<div class="btm_left_header">
			
		<div class="bottom_menu_sec">
	
			<?php 
			if (genesism_get_option('btm_menu')){
			?>
			<div class="btm_menu">
				<span class="menu_control">≡ Menu</span>
				<?php wp_nav_menu( array( 'theme_location' => 'FirstMenu','container' => false,'menu_id' => 'menu_btm_menu' ) );?>
			</div>
			
			<?php 
			}
			?>
			
			</div>
		
		
	</div> 
	
	<div class="btm_right_header">
	
		<div class="btm_right_header_left">
			<div class="header_social">
				<?php
				if (!genesism_get_option('header_social')){?>
				<?php
				if (!genesism_get_option('fb_check')){
				?>
				<div class="social_icons">
					<a class="facebook" title="Facebook" href="<?php echo genesism_get_option('facebook_text1'); ?>" target="_blank">
						<i class="fa icon-facebook"></i>
					</a>
				</div>
				<?php
				}
				if (!genesism_get_option('tw_check')){
				?>
				<div class="social_icons">
					<a class="twitter" title="Twitter" href="<?php echo genesism_get_option('twitter_text1'); ?>" target="_blank">
						<i class="fa icon-twitter"></i>
					</a>
				</div>
				<?php
				}
				if (!genesism_get_option('gp_check')){
				?>
				<div class="social_icons">
					<a class="googleplus" title="google plus" href="<?php echo genesism_get_option('googleplus_text1'); ?>" target="_blank">
						<i class="fa icon-google-plus"></i>
					</a>
				</div>
				<?php
				}
				if (!genesism_get_option('pin_check')){
				?>
				<div class="social_icons">
					<a class="pinterest" title="pinterest" href="<?php echo genesism_get_option('pinterest_text1'); ?>" target="_blank">
						<i class="fa icon-pinterest"></i>
					</a>
				</div>
				<?php
				}
				if (!genesism_get_option('ins_check')){
				?>
				<div class="social_icons">
					<a class="instagram" title="instagram" href="<?php echo genesism_get_option('instagram_text1'); ?>" target="_blank">
						<i class="fa icon-instagram"></i>
					</a>
				</div>
				<?php
				}
				if (!genesism_get_option('yt_check')){
				?>
				<div class="social_icons">
					<a class="youtube" title="youtube" href="<?php echo genesism_get_option('youtube_text1'); ?>" target="_blank">
						<i class="fa icon-youtube"></i>
					</a>
				</div>
				<?php
				}
				?>
			<?php 
		}
		?>
			</div>		
		</div>
	
		<div class="btm_right_header_rgt">
			<div class="widget_search_box">
			<?php
			if (genesism_get_option('search_section')){
			?>
				
				
				<div class="search_box_section">
				<div class='search-container widget_search'>
				<div class="header-search">
				<div class="header-search-a"><button id="trigger-overlay" type="button"><i class='fa icon-search'></i></button></div>
				</div>
				</div>
				
				</div>
				
				
			<?php 
			}
			?>
			</div>	
		</div>
	</div>
		
 </div>
</div>


<?php 
}
 
add_action('genesis_before_header','before_header');	
function before_header() { ?>
<div class="wrap-search">
<div class="wrap">

	<form action='<?php echo get_bloginfo('home'); ?>' method="post" id="search-block-form--2"><div><div class="container-inline">
      
   <div class="search_form"> <div class="form-item form-type-textfield form-item-search-block-form ">
   <input class='search_text' type='text' placeholder='<?php echo genesism_get_option('search_text'); ?>' name='s' id='s' />		

</div>
<div class="form-actions form-wrapper" id="edit-actions--3">
<button type='submit' class='button btn-success'>
				<i class='fa icon-search'></i>
				</button></div>
</div>

</div>
</div></form>
</div>
</div>
<div class="header" id="header" itemscope="itemscope" itemtype="http://schema.org/WPHeader">
<?php
}
 
add_action('genesis_after_header','after_header');			
function after_header() { ?>

 </div>	

<?php
} 
 

// Add Post Feature image

add_action( 'genesis_entry_header', 'custom_post_featureimage');
function custom_post_featureimage() {
if(!is_page()&&!is_single()){  
?>
<div class="post_featured_img">
<?php

if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true);
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video

 // Defaults
         $f_img_width = genesism_get_option('f_img_width');
        $f_img_height = genesism_get_option('f_img_height');
        $default_img =  'Feature_image'; 

		// Auto feature image defaults
		$thumb = get_post_thumbnail_id(); 
		$img_url = wp_get_attachment_url( $thumb,'full' ); 
		$image = aq_resize( $img_url,$f_img_width,$f_img_height, true );
		// Catch the Image defaults
        $catch_img_url = catch_that_image( $thumb,'full' );
        $catch_image = aq_resize( $catch_img_url, $f_img_width, $f_img_height, true );
        // Default Image
        $default_image = aq_resize( $default_img, $f_img_width, $f_img_height, true );
		if(has_post_thumbnail())
		echo
		"<div class=\"featured_image\">\n".
		"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width . "\" height=\"" . $f_img_height . "\" alt=\"" . get_the_title() . "\"><div class='thumb_hover'></div></a>\n".
		"</div>\n";
		elseif (catch_that_image()){ 
		echo
		"<div class=\"featured_image\">\n".
		"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width . "\" height=\"" . $f_img_height . "\" alt=\"" . get_the_title() . "\"></a>\n".
		
		"</div>\n"; 
		} 
		}
		}

		/*featured image ends here*/
?>

</div>
<?php	
}      
}
 
 
 
add_action( 'genesis_post_info', 'post_info_filter');
function post_info_filter() {
if(!is_page()){ 
?>
<div class="byline">
<?php
		$category = get_the_category(); 
	?>
	<span class="cat"><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></span>
	<span class='author'><?php the_author() ?></span>
	<span class='date'><?php the_time('j M , Y') ?></span>
	<span class='info_comments'><a  href="<?php the_permalink(); ?>#comments" title="<?php comments_number(__('0 Comment','fb'),__('1 Comment','periodic'),__('% Comments','fb')); ?>"><?php comments_number(__('0 Comment','periodic'),__('1 Comment','periodic'),__('% Comments','fb')); ?> </a></span>
</div>								
<?php
}
}


	
add_action ('genesis_entry_content','post_read_more');
function post_read_more(){
if (genesism_get_option('read_more')){
if(!is_page()&&!is_single()){
?>
<div class="read_more">
	<a class="read_more_btn" href="<?php echo the_permalink(); ?>"><?php  echo (genesism_get_option('read_text'));?></a>
</div>
<?php 
}
}	
}	


add_action ('genesis_before_sidebar_widget_area','before_sidebar_widget_area');
function before_sidebar_widget_area(){

?>
<div class="sidebar_section">
<?php 
}



add_action ('genesis_before_sidebar_widget_area','sidebar_adv_optin',5);
function sidebar_adv_optin(){	

?>

<div class='adv_optin_section sidebar_widget '>

<?php
if (genesism_get_option('sidebar_optin_section')){
?>
<div class="sidebar_optin_cnt">

<div class='sb_optin_bg'>
<h2><?php echo genesism_get_option('optin_header_one'); ?></h2>
<h3><?php echo genesism_get_option('optin_header_fs'); ?><span><?php echo genesism_get_option('optin_header_cs'); ?></span><?php echo genesism_get_option('optin_header_ls'); ?></h3>
<form method="post" class="form" action="<?php echo stripslashes(genesism_get_option('optin_url')); ?>" target="_blank">	
<div class="names">
<label><?php echo genesism_get_option('email'); ?></label>
<div class="sb_input">
<input class="email" type="text" name="<?php echo stripslashes(genesism_get_option('optin_email')); ?>" placeholder="<?php echo stripslashes(genesism_get_option('email_text')); ?>"><div class='mails'></div>
<?php echo stripslashes(genesism_get_option('optin_hidden')); ?>
<input name="submit" class="submit" type="submit" value="<?php echo stripslashes(genesism_get_option('submit_text')); ?>"/>
</div>
</div>
</form>
</div>

</div>

</div>

<?php 
}
}



add_action ('genesis_after_sidebar_widget_area','after_sidebar_widget_area');
function after_sidebar_widget_area(){
?>
</div>
<?php 
}

// Customize the post meta function
add_filter('genesis_entry_footer', 'post_meta_filter',1);
function post_meta_filter() {
if ( is_single() ) {?>
<p class='post_tags'> 
	<?php // Tag
		$posttags = get_the_tags();
		if ($posttags) {
		foreach($posttags as $tag) {
		
		echo $tag->name .'  '; 
		}
		}
	?>
</p>
<?php
}
}


/** Genesis Previous/Next Post Post Navigation */
add_action ('genesis_entry_footer','prev_next_post_nav',3);
function prev_next_post_nav(){
if ( is_single() ) {
echo '<div class="prev-next-navigation">';
previous_post_link( '<div class="previous"><span>Previous article:</span> %link</div>', '%title' );
next_post_link( '<div class="next"><span>Next article:</span> %link</div>', '%title' );
echo '</div><!-- .prev-next-navigation -->';
}
}	


add_action( 'genesis_entry_header', 'single_page_category',2);
function single_page_category(){
if ( is_single() ) {?>

<?php
		$category = get_the_category(); 
	?>
	<span class="single_category"><h4><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></h4></span>

<?php
}
}

add_action('genesis_entry_content','post_ad',2);
function post_ad(){
if(genesism_get_option('single_ad_box')){
if ( is_single() ) {?>
		<div class="post-ad" style="float:<?php echo genesism_option('float');?>; padding-right:0px; padding-left:21px; padding-top: 11px;">
		<?php  echo stripslashes((genesism_get_option('single_ad_img')));?>
		</div>
        <?php
}
}
}

add_action( 'genesis_before_comments', 'single_page_socialshare',2);
function single_page_socialshare(){
if (genesism_get_option('single_social_share')){
if ( is_single() ) {?>
<div class="sharing group sharing_social_count">
<div class="single_title">
	<h3><?php  echo (genesism_get_option('share_title'));?></h3>
	<span class="sep"></span>
</div>
<ul class="social_share_count">

	
		<li class="share_tweet">
		<a href="http://twitter.com/share?text=<?php echo htmlspecialchars(urlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8')), ENT_COMPAT, 'UTF-8'); ?>&amp;url=<?php the_permalink(); ?>" target="_blank">
		<i class="icon-twitter icon"></i>
		<span>
		 Twitter
		</span>
		</a>
		</li>
		<li class="share_fb">
		<a href="http://www.facebook.com/sharer.php?u=<?php the_permalink(); ?>&amp;t=<?php echo htmlspecialchars(urlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8')), ENT_COMPAT, 'UTF-8'); ?>" target="_blank">
		<i class="icon-facebook icon"></i>
		<span>
		 Facebook
		</span>
		</a>
		</li>
		<li class="share_plus">
		<a href="https://plus.google.com/share?url=<?php the_permalink(); ?>" target="_blank" title="Click to share">
		<i class="icon-google-plus icon"></i>
		<span>
		 G-plus
		</span>
		</a>
		</li>
		<li class="share_linkedin">
		<a target="_blank" href="http://www.linkedin.com/shareArticle?mini=true&amp;url=<?php the_permalink(); ?>">
		<i class="icon-linkedin icon"></i>
		<span>
		 Linkedin
		</span>
		</a> 
		</li>
		<li class="share_reddit">
		<a target="_blank" href="http://www.reddit.com/submit?url=<?php the_permalink(); ?>&amp;title=<?php echo htmlspecialchars(urlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8')), ENT_COMPAT, 'UTF-8'); ?>">
		<i class="icon-reddit icon"></i>
		<span>
		 Reddit
		</span>
		</a>
		</li>
		<li class="share_pintrest">
		<a target="_blank" href="http://pinterest.com/pinthis?url=<?php the_permalink(); ?>&amp;title=<?php echo htmlspecialchars(urlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8')), ENT_COMPAT, 'UTF-8'); ?>">
		<i class="icon-pinterest icon"></i>
		<span>
		 Pintrest
		</span>
		</a>
		</li>		
	</ul>

</div>
<?php
}
}
}


	//Related Post Box

add_action( 'genesis_before_comments', 'related_posts',3);
function related_posts(){
?>
<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Single Page Related Post Widget') ) : ?>
<div class="widget">
<h4 itemprop="headline"><?php _e("Single Page Related Post #Widget", 'genesis'); ?></h4>
<p><?php _e("Displays Single Page Realated Post with thumbnails.", 'genesis'); ?></p>
</div><!-- end .widget -->
<?php endif; ?> 


<?php
}


add_action('wp_head','color_box');
function color_box(){

$body_bg_color = get_option('body_bg_color');
$body_txt_color = get_option('body_txt_color');
$header_txt_color = get_option('header_txt_color');
$btm_header_bg =get_option('btm_header_bg');
$link_color =get_option('link_color');
$menu_text =get_option('menu_text');
$border_color =get_option('border_color');
$editor_left_bg =get_option('editor_left_bg');
$border_one =get_option('border_one');
$footer_text_clr =get_option('footer_text_clr');
$hover_bg =get_option('hover_bg');
$top_footer_bg =get_option('top_footer_bg');


?>
<style type="text/css">

body {
background:<?php echo $body_bg_color; ?>;
}


body, .fourth_cat_left_section .sec_cat_left_btm p, .fourth_cat_left_section .second_cat_byline span, .info_comments a, .cat_head_para p {
color:<?php echo $body_txt_color; ?>;
}


a, .entry-comments h3, .landing_header h2, .single .entry-header h1, .cat_head_para  h3 a, .first_cat_btm h3 a, .widget-wrap h4.widgettitle, .sidebar_optin_cnt  input[type="text"], .sidebar_optin_cnt h3, .sidebar_widget .sidebar_heading h3, .lat_news_cont_right h3 a, .content .single_title h3, #reply-title, .author_right_cnt h3{
color:<?php echo $header_txt_color; ?>;
}

.btm_header_cont, .widget_search button{
background-color:<?php echo $btm_header_bg; ?>;
}


a:hover, .single .post .byline span, .single .post .byline span a, .single_category a, .blog .byline .cat a, .archive .byline .cat a, .search .byline .cat a, .permalink a:after, .permalink a, .popular_cnt .pop_byline span, .aboutus_cnt_title_para a:hover, .block_title, .lat_news_cont_right .permalink  a:after, .lat_news_cont_right .permalink  a, .lat_news_cont_right h3 a:hover, .lat_news_cont_right h4 a, .fourth_cat_title h4 a, .sec_category_content .entry_cat_title  h3 a:hover, .img_content_area .entry_cat_title h3 a:hover, .first_cat_btm h3 :after, .cat_head_para  h3 a:hover, .first_cat_btm h3 a:hover, .cat_head_para .entry_cat_title h4 a, .edit_news_cont_left .permalink  a:hover, .edit_news_cont_left .blog_title h4 a:hover, .social_icons a:hover, .menu .sub-menu li:hover a, .menu li a:hover, .archive-description .archive-title, .entry-title a:hover  {
color: <?php echo $link_color; ?> ;
}
 .menu .current-menu-item > a{
 color:  <?php echo $link_color; ?> !important;
 }
.menu .sub-menu .sub-menu li:hover a,.widget .aboutus_cnt_title_para h4:hover,.author-box h3{
color:  <?php echo $link_color; ?>;
}

.footer-widgets-1 .tagcloud a, .left_side_optin .form  input[type="submit"], .comment-reply a, .single .post_tags, .read_more a, .sidebar .tagcloud a, .sec_cat_left_btm, .sec_category_content .entry_cat_title  h4 a, .img_content_area .entry_cat_title h4 a, .edit_news_cont_left .permalink  a, .archive-pagination li a:hover, .archive-pagination .active a, .archive-pagination li a, .form-submit input[type="submit"]:hover, .author_social a:hover{
background-color:  <?php echo $link_color; ?>;
}

.footer-widgets-1 .tagcloud a:hover, .footer-widgets-1 .tagcloud a, .left_side_optin .form  input[type="submit"], .comment-reply a, .edit_news_cont_left .permalink a{
border-color:  <?php echo $link_color; ?>;
}

.sb_optin_bg, .sidebar_optin_cnt input[type="submit"]{
background-color: <?php echo $link_color; ?>;
}

.menu a,.menu .sub-menu .sub-menu li a{
color: <?php echo $menu_text; ?>;
}

.related_post_section, .social_share_count li a, li.comment, .prev-next-navigation, .single .post .byline, .blog .content .post, .archive .content .post, .search .content .post, .border_line, .lat_news_sec, .fourth_cat_right, .fourth_cat_left_section .sec_cat_left_btm, .third_full_width, .first_cat_btm, .first_cat_top_section, .site-header .sub-menu, .site-footer {
border-color:  <?php echo $border_color; ?>;
}

.comment-header .avatar{
background-color:<?php echo $border_color; ?>;
}
.byline{
    border-bottom-color:<?php echo $border_color; ?>;
}

.edit_news_cont_left{
background-color: <?php echo $editor_left_bg; ?>;

}

.content .single_title h3, #reply-title, .entry blockquote{
border-color: <?php echo $border_one; ?>;
}

.widget_search .search_text{
color: <?php echo $border_one; ?>;
}

.landing_optin_title p, .edit_news_cont_left p, .widget_search button, .widget_recent_entries ul li a, .textwidget, .social_icons a {
color:  <?php echo $footer_text_clr; ?> ;
}

.widget_recent_entries ul li a, .textwidget{
color: <?php echo $footer_text_clr; ?> ;
}

.footer-widgets-1 .tagcloud a:hover, .left_side_optin .form  input[type="submit"]:hover, .read_more a:hover, .edit_news_cont_left .permalink a:hover, .sidebar_optin_cnt input[type="submit"]:hover{
background-color: <?php echo $hover_bg; ?>;
}

.footer-widgets {
background-color: <?php echo $top_footer_bg; ?>;
}


<?php echo genesism_option('custom_css'); ?>

</style>
<?php
}



add_action('wp_footer','script_box');
function script_box(){?>
<script type="text/javascript">
function loadScript(src) {
     var element = document.createElement("script");
     element.src = src;
     document.body.appendChild(element);
}
// Add a script element as a child of the body
function downloadJSAtOnload() {
	
	
	loadScript("<?php bloginfo('stylesheet_directory'); ?>/scripts/custom.js");
 }
 // Check for browser support of event handling capability
 if (window.addEventListener)
     window.addEventListener("load", downloadJSAtOnload, false);
	 else if (window.attachEvent)
     window.attachEvent("onload", downloadJSAtOnload);
 else window.onload = downloadJSAtOnload; 
 (function() {
      function getScript(url,success){
        var script=document.createElement('script');
        script.src=url;
        var head=document.getElementsByTagName('head')[0],
            done=false;
        script.onload=script.onreadystatechange = function(){
          if ( !done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete') ) {
            done=true;
            success();
            script.onload = script.onreadystatechange = null;
            head.removeChild(script);
          }
        };
        head.appendChild(script);
      }
        getScript('https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js',function(){
        });
    })();
</script>
<?php
}

// Auto Resize Image

function aq_resize( $url, $width, $height = null, $crop = null, $single = true ) {

//validate inputs
if(!$url OR !$width ) return false;

//define upload path & dir
$upload_info = wp_upload_dir();
$upload_dir = $upload_info['basedir'];
$upload_url = $upload_info['baseurl'];

//check if $img_url is local
if(strpos( $url, $upload_url ) === false) return false;

//define path of image
$rel_path = str_replace( $upload_url, '', $url);
$img_path = $upload_dir . $rel_path;

//check if img path exists, and is an image indeed
if( !file_exists($img_path) OR !getimagesize($img_path) ) return false;

//get image info
$info = pathinfo($img_path);
$ext = $info['extension'];
list($orig_w,$orig_h) = getimagesize($img_path);

//get image size after cropping
$dims = image_resize_dimensions($orig_w, $orig_h, $width, $height, $crop);
$dst_w = $dims[4];
$dst_h = $dims[5];

//use this to check if cropped image already exists, so we can return that instead
$suffix = "{$dst_w}x{$dst_h}";
$dst_rel_path = str_replace( '.'.$ext, '', $rel_path);
$destfilename = "{$upload_dir}{$dst_rel_path}-{$suffix}.{$ext}";

if(!$dst_h) {
//can't resize, so return original url
$img_url = $url;
$dst_w = $orig_w;
$dst_h = $orig_h;
}
//else check if cache exists
elseif(file_exists($destfilename) && getimagesize($destfilename)) {
$img_url = "{$upload_url}{$dst_rel_path}-{$suffix}.{$ext}";
}
//else, we resize the image and return the new resized image url
else {

// Note: This pre-3.5 fallback check will edited out in subsequent version
if(function_exists('wp_get_image_editor')) {

$editor = wp_get_image_editor($img_path);

if ( is_wp_error( $editor ) || is_wp_error( $editor->resize( $width, $height, $crop ) ) )
return false;

$resized_file = $editor->save();

if(!is_wp_error($resized_file)) {
$resized_rel_path = str_replace( $upload_dir, '', $resized_file['path']);
$img_url = $upload_url . $resized_rel_path;
} else {
return false;
}

} else {

$resized_img_path = image_resize( $img_path, $width, $height, $crop ); // Fallback foo
if(!is_wp_error($resized_img_path)) {
$resized_rel_path = str_replace( $upload_dir, '', $resized_img_path);
$img_url = $upload_url . $resized_rel_path;
} else {
return false;
}

}

}

//return the output
if($single) {
//str return
$image = $img_url;
} else {
//array return
$image = array (
0 => $img_url,
1 => $dst_w,
2 => $dst_h
);
}

return $image;
}

function catch_that_image() {
        global $post, $posts;
        $first_img = '';
        ob_start();
        ob_end_clean();
        $output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
        if(count($matches [1]))$first_img = $matches [1] [0];
        return $first_img;
}


function limit_words($string, $word_limit)
{
  $words = explode(' ', $string, ($word_limit + 1));
  if(count($words) > $word_limit)
  array_pop($words);
  return implode(' ', $words);
}

function new_excerpt_length($length) {
    return 40;
}
add_filter('excerpt_length', 'new_excerpt_length');

function string_limit_words($string, $word_limit)
{
  $words = explode(' ', $string, ($word_limit + 1));
  if(count($words) > $word_limit)
  array_pop($words);
  return implode(' ', $words);
}   








function custom_pagination($numpages = '', $pagerange = '', $paged='') {

  if (empty($pagerange)) {
    $pagerange = 2;
  }

  /**
   * This first part of our function is a fallback
   * for custom pagination inside a regular loop that
   * uses the global $paged and global $wp_query variables.
   * 
   * It's good because we can now override default pagination
   * in our theme, and use this function in default quries
   * and custom queries.
   */
  global $paged;
  if (empty($paged)) {
    $paged = 1;
  }
  if ($numpages == '') {
    global $wp_query;
    $numpages = $wp_query->max_num_pages;
    if(!$numpages) {
        $numpages = 1;
    }
  }

  /** 
   * We construct the pagination arguments to enter into our paginate_links
   * function. 
   */
  $pagination_args = array(
    'base'            => get_pagenum_link(1) . '%_%',
    'format'          => 'page/%#%',
    'total'           => $numpages,
    'current'         => $paged,
    'show_all'        => False,
    'end_size'        => 1,
    'mid_size'        => $pagerange,
    'prev_next'       => True,
    'prev_text'       => __('&laquo;'),
    'next_text'       => __('&raquo;'),
    'type'            => 'plain',
    'add_args'        => false,
    'add_fragment'    => ''
  );

  $paginate_links = paginate_links($pagination_args);

  if ($paginate_links) {
    echo "<nav class='custom-pagination'>";
      echo "<span class='page-numbers page-num'>Page " . $paged . " of " . $numpages . "</span> ";
      echo $paginate_links;
    echo "</nav>";
  }

}



#-----------------------------------------------------------------
# Plugin Recommendations
#-----------------------------------------------------------------

require_once ('lib/class-tgm-plugin-activation.php');
add_action( 'tgmpa_register', 'pngs_register_required_plugins' );

function pngs_register_required_plugins() {
	
	$plugins = array(
		
		array(
			'name'     				=> 'Replace Featured Image with Video',
			'slug'     				=> 'replace-featured-image-with-video',
			'source'   				=> 'https://downloads.wordpress.org/plugin/replace-featured-image-with-video.zip',
			'required' 				=> true,
			'version' 				=> '2.1',
			'force_activation' 		=> false,
			'force_deactivation' 	=> false,
			'external_url' 			=> '',
		),
		
		
		
		

	);

	$config = array( 
		'domain'       		=> 'pngs',
		'default_path' 		=> '',
		'parent_menu_slug' 	=> 'themes.php',
		'parent_url_slug' 	=> 'themes.php',
		'menu'         		=> 'install-required-plugins',
		'has_notices'      	=> true,
		'is_automatic'    	=> false,
		'message' 			=> '',
		'strings'      		=> array(
			'page_title'                       			=> __( 'Install Required Plugins', 'pngs' ),
			'menu_title'                       			=> __( 'Install Plugins', 'pngs' ),
			'installing'                       			=> __( 'Installing Plugin: %s', 'pngs' ), // %1$s = plugin name
			'oops'                             			=> __( 'Something went wrong with the plugin API.', 'pngs' ),
			'notice_can_install_required'     			=> _n_noop( 'This theme requires the following plugin: %1$s.', 'This theme requires the following plugins: %1$s.', 'pngs' ), // %1$s = plugin name(s)
			'notice_can_install_recommended'			=> _n_noop( 'This theme recommends the following plugin: %1$s.', 'This theme recommends the following plugins: %1$s.', 'pngs' ), // %1$s = plugin name(s)
			'notice_cannot_install'  					=> _n_noop( 'Sorry, but you do not have the correct permissions to install the %s plugin. Contact the administrator of this site for help on getting the plugin installed.', 'Sorry, but you do not have the correct permissions to install the %s plugins. Contact the administrator of this site for help on getting the plugins installed.', 'pngs' ), // %1$s = plugin name(s)
			'notice_can_activate_required'    			=> _n_noop( 'The following required plugin is currently inactive: %1$s.', 'The following required plugins are currently inactive: %1$s.', 'pngs' ), // %1$s = plugin name(s)
			'notice_can_activate_recommended'			=> _n_noop( 'The following recommended plugin is currently inactive: %1$s.', 'The following recommended plugins are currently inactive: %1$s.', 'pngs' ), // %1$s = plugin name(s)
			'notice_cannot_activate' 					=> _n_noop( 'Sorry, but you do not have the correct permissions to activate the %s plugin. Contact the administrator of this site for help on getting the plugin activated.', 'Sorry, but you do not have the correct permissions to activate the %s plugins. Contact the administrator of this site for help on getting the plugins activated.', 'pngs' ), // %1$s = plugin name(s)
			'notice_ask_to_update' 						=> _n_noop( 'The following plugin needs to be updated to its latest version to ensure maximum compatibility with this theme: %1$s.', 'The following plugins need to be updated to their latest version to ensure maximum compatibility with this theme: %1$s.', 'pngs' ), // %1$s = plugin name(s)
			'notice_cannot_update' 						=> _n_noop( 'Sorry, but you do not have the correct permissions to update the %s plugin. Contact the administrator of this site for help on getting the plugin updated.', 'Sorry, but you do not have the correct permissions to update the %s plugins. Contact the administrator of this site for help on getting the plugins updated.', 'pngs' ), // %1$s = plugin name(s)
			'install_link' 					  			=> _n_noop( 'Begin installing plugin', 'Begin installing plugins', 'pngs'  ),
			'activate_link' 				  			=> _n_noop( 'Activate installed plugin', 'Activate installed plugins', 'pngs'  ),
			'return'                           			=> __( 'Return to Required Plugins Installer', 'pngs' ),
			'plugin_activated'                 			=> __( 'Plugin activated successfully.', 'pngs' ),
			'complete' 									=> __( 'All plugins installed and activated successfully. %s', 'pngs' ), // %1$s = dashboard link
			'nag_type'									=> 'updated'
		)
	);

	tgmpa( $plugins, $config );
}


//All Genesis Lovers Widget Starts Here

// Popular Widget Starts Here

class gl_popular_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_popular_widget', 

__('Pngs - Popular Post', 'gl_popular_widget_domain'), 

array( 'description' => __( 'Displays Popular Post', 'gl_popular_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );

echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];

?>

<div class="popular_post sidebar_widget">
	
	<div class='popular_post_cnt sidebar_content'>
		<?php
			query_posts('post_type=post&posts_per_page='. $post_count .'&orderby=comment_count&order=DESC');
			while (have_posts()): the_post(); 
		?>
			<div class='popular_post_section border_line entry_cnt'>
				<div class='popular_img'>
					<?php
					if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true);
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video
						// Auto feature image defaults
						$f_img_width3 = $instance['width_size'];
						$f_img_height3 = $instance['height_size'];
						$thumb = get_post_thumbnail_id(); 
						$img_url = wp_get_attachment_url( $thumb,'full' ); 
						
						$image = aq_resize( $img_url, $f_img_width3, $f_img_height3, true );
						// Catch the Image defaults
						$catch_img_url = catch_that_image( $thumb,'full' );
						$catch_image = aq_resize( $catch_img_url, $f_img_width3, $f_img_height3, true );
						if(has_post_thumbnail())
						echo
						"<div class=\"featured_image\">\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width3 . "\" height=\"" . $f_img_height3 . "\" alt=\"" . get_the_title() . "\"></a><div class='thumb_hover'><a class=\"link\" href=\"" . get_permalink() . "\"></a></div>\n".
						"</div>\n";
						elseif (catch_that_image()){ 
						echo
						"<div class=\"featured_image\">\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width3 . "\" height=\"" . $f_img_height3 . "\" alt=\"" . get_the_title() . "\"></a><div class='thumb_hover'><a class=\"link\" href=\"" . get_permalink() . "\"></a></div>\n".
						"</div>\n";  
						} 
						}
						}
					?>
				</div>
				<div class="popular_cnt">
					<h3><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a></h3>
				
				<div class='pop_byline'>
				<span><?php the_time('M jS, Y'); ?></span>
				</div>
				</div>
			</div>
		<?php
			endwhile;
		?>
	</div>
</div>
<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Most Popular', 'gl_popular_widget_domain' );
}

 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '5', 'gl_popular_widget_domain' );
}

 if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '128', 'gl_popular_widget_domain' );
}

 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '80', 'gl_popular_widget_domain' );
}

?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>
<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';
return $instance;
}
}

//Popular Post Widget Ends Here

// Random Widget Starts Here

class gl_randomr_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_randomr_widget', 

__('Pngs - Random Post', 'gl_randomr_widget_domain'), 

array( 'description' => __( 'Displays Random Post', 'gl_randomr_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );

echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];

?>

<div class="random_post sidebar_widget">
	
	<div class='random_post_cnt sidebar_content'>
		<?php
			query_posts('post_type=post&posts_per_page='. $post_count .'&orderby=rand&order=DESC');
			while (have_posts()): the_post(); 
		?>
			<div class='random'>
				<div class='random_img'>
					<?php
					if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true);
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video
						// Auto feature image defaults
						$f_img_width2 = $instance['width_size'];
						$f_img_height2 = $instance['height_size'];
						$thumb = get_post_thumbnail_id(); 
						$img_url = wp_get_attachment_url( $thumb,'full' ); 
						
						$image = aq_resize( $img_url, $f_img_width2, $f_img_height2, true );
						// Catch the Image defaults
						$catch_img_url = catch_that_image( $thumb,'full' );
						$catch_image = aq_resize( $catch_img_url, $f_img_width2, $f_img_height2, true );
						if(has_post_thumbnail())
						echo
						"<div class=\"featured_image\">\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width2 . "\" height=\"" . $f_img_height2 . "\" alt=\"" . get_the_title() . "\"></a><div class='thumb_hover'><a class=\"link\" href=\"" . get_permalink() . "\"></a></div>\n".
						"</div>\n";
						elseif (catch_that_image()){ 
						echo
						"<div class=\"featured_image\">\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width2 . "\" height=\"" . $f_img_height2 . "\" alt=\"" . get_the_title() . "\"></a><div class='thumb_hover'><a class=\"link\" href=\"" . get_permalink() . "\"></a></div>\n".
						"</div>\n";  
						} 
						}
						}
					?>
				</div>
				<div class="random_cnt">
					<h3><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a></h3>
				</div>
			</div>
		<?php
			endwhile;
		?>
	</div>
</div>
<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Random Post', 'gl_randomr_widget_domain' );
}

 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '4', 'gl_randomr_widget_domain' );
}

 if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '169', 'gl_randomr_widget_domain' );
}

 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '120', 'gl_randomr_widget_domain' );
}

?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>
<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';
return $instance;
}
}

//Random Post Widget Ends Here



// Sidebar Category Widget Starts Here

class gl_sidbar_catgory_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_sidbar_catgory_widget', 

__('Pngs - Sidebar Category', 'gl_sidbar_catgory_widget_domain'), 

array( 'description' => __( 'Displays Sidebar Category Post', 'gl_sidbar_catgory_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );
$fifth_cat_id = apply_filters( 'fifth_cat_id', $instance['fifth_cat_id'] );
$lat_readmore = apply_filters( 'lat_readmore', $instance['lat_readmore'] );

echo $args['before_widget'];
if ( ! empty( $title ) )
/*echo $args['before_title'] . $title . $args['after_title'];*/

?>

<div  class="sidebar_category">


<div class="sb_category_content sidebar_widget">
		
		<?php 
		query_posts( array('posts_per_page'=> $instance['post_count'] , cat=> $instance['fifth_cat_id']) );
		while ( have_posts() ) : the_post();
		
		?>
			<div class="fifth_cat_details img_content_area">
				<div class="fifth_cat_img entry_image thumb">
							<?php
							if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true);
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video
							
							$f_img_width1 = $instance['width_size'];
							$f_img_height1 = $instance['height_size'];	
							// Auto feature image defaults
							$thumb = get_post_thumbnail_id(); 
							$img_url = wp_get_attachment_url( $thumb,'full' ); 
							
							$image = aq_resize( $img_url, $f_img_width1, $f_img_height1, true );
							// Catch the Image defaults
							$catch_img_url = catch_that_image( $thumb,'full' );
							$catch_image = aq_resize( $catch_img_url, $f_img_width1, $f_img_height1, true );
							if(has_post_thumbnail())
							echo
							"<div class=\"featured_image\">\n".
							"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width1 . "\" height=\"" . $f_img_height1 . "\" alt=\"" . get_the_title() . "\"><div class='thumb_hover'></div></a>\n".
							"</div>\n";
							elseif (catch_that_image()){ 
							echo
							"<div class=\"featured_image\">\n".
							"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width1 . "\" height=\"" . $f_img_height1 . "\" alt=\"" . get_the_title() . "\"></a>\n".
							"</div>\n"; 
							}
						}
						}							
							/*featured image ends here*/
							?>
							
							<div class="entry_cat_title">
							<?php
							$category = get_the_category(); 
							?>
							<h4><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></h4>
							<?php echo "<h3><a href='". get_permalink() ."'>".get_the_title()."";
							echo "</a></h3>";?>
							</div>
							
						</div>
						
						<div class="sb_cat_detail">
						<?php
						echo"<p>";
						$excerpt=get_the_excerpt();
						echo limit_words($excerpt,14);
						echo "</p>";
						echo"<div class='permalink readmore'><a href='". get_permalink() ."'>". $lat_readmore ."</a></div>";	
						?>
						</div>
			</div>
		<?php

				$i++;
				endwhile;
				wp_reset_query(); 
				?>

		
</div>

</div>

<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Sidebar Category Post', 'gl_sidbar_catgory_widget_domain' );
}

 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '2', 'gl_sidbar_catgory_widget_domain' );
}

 if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '320', 'gl_sidbar_catgory_widget_domain' );
}

 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '222', 'gl_sidbar_catgory_widget_domain' );
}

 if ( isset( $instance[ 'fifth_cat_id' ] ) ) {
$fifth_cat_id = $instance[ 'fifth_cat_id' ];
}
else {
$fifth_cat_id = __( '3', 'gl_sidbar_catgory_widget_domain' );
}

 if ( isset( $instance[ 'lat_readmore' ] ) ) {
$lat_readmore = $instance[ 'lat_readmore' ];
}
else {
$lat_readmore = __( 'Read More', 'gl_sidbar_catgory_widget_domain' );
}

?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'fifth_cat_id' ); ?>"><?php _e( 'Sidebar Category ID:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'fifth_cat_id' ); ?>" name="<?php echo $this->get_field_name( 'fifth_cat_id' ); ?>" type="text" value="<?php echo esc_attr( $fifth_cat_id ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'lat_readmore' ); ?>"><?php _e( 'Read More Text:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'lat_readmore' ); ?>" name="<?php echo $this->get_field_name( 'lat_readmore' ); ?>" type="text" value="<?php echo esc_attr( $lat_readmore ); ?>" />
</p>
<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';
$instance['fifth_cat_id'] = ( ! empty( $new_instance['fifth_cat_id'] ) ) ? strip_tags( $new_instance['fifth_cat_id'] ) : '';
$instance['lat_readmore'] = ( ! empty( $new_instance['lat_readmore'] ) ) ? strip_tags( $new_instance['lat_readmore'] ) : '';
return $instance;
}
}

//Sidebar Category Widget Ends Here

// About Us Widget Starts Here

class gl_aboutus_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_aboutus_widget', 

__('Pngs - About Us ', 'gl_aboutus_widget_domain'), 

array( 'description' => __( 'Displays About Us Content', 'gl_aboutus_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$about_us_img = apply_filters( 'about_us_img', $instance['about_us_img'] );
$sb_aboutus_cnt = apply_filters( 'sb_aboutus_cnt', $instance['sb_aboutus_cnt'] );
$sb_aboutus_name = apply_filters( 'sb_aboutus_name', $instance['sb_aboutus_name'] );
$sb_aboutus_read_link = apply_filters( 'sb_aboutus_read_link', $instance['sb_aboutus_read_link'] );

echo $args['before_widget'];
if ( ! empty( $title ) )
/*echo $args['before_title'] . $title . $args['after_title'];*/

?>
<div class="sidebar_aboutus sidebar_widget">
	<div class="aboutus_cnt">
			<img alt="<?php  echo $instance['title'];?>" src='<?php  echo $instance['about_us_img'];?>'/>
			<a href="<?php  echo $instance['sb_aboutus_read_link'];?>" class="grid-overlay"><div class="aboutus_cnt_title_para">
			<h3><?php  echo $instance['title'];?></h3>
				<div class="aboutus_cnt_main">
			<p><?php  echo $instance['sb_aboutus_cnt'];?></p>
			<h4><?php  echo $instance['sb_aboutus_name'];?></h4>
			</div>
			</div>
			</a>
		</div>
	
</div>

<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'About Us', 'gl_aboutus_widget_domain' );
}

 if ( isset( $instance[ 'about_us_img' ] ) ) {
$about_us_img = $instance[ 'about_us_img' ];
}
else {
$about_us_img = __( ' ', 'gl_aboutus_widget_domain' );
}

 if ( isset( $instance[ 'sb_aboutus_cnt' ] ) ) {
$sb_aboutus_cnt = $instance[ 'sb_aboutus_cnt' ];
}
else {
$sb_aboutus_cnt = __( 'About Us Content', 'gl_aboutus_widget_domain' );
}

 if ( isset( $instance[ 'sb_aboutus_name' ] ) ) {
$sb_aboutus_name = $instance[ 'sb_aboutus_name' ];
}
else {
$sb_aboutus_name = __( '-Steve Jobs', 'gl_aboutus_widget_domain' );
}

 if ( isset( $instance[ 'sb_aboutus_read_link' ] ) ) {
$sb_aboutus_read_link = $instance[ 'sb_aboutus_read_link' ];
}
else {
$sb_aboutus_read_link = __( '', 'gl_aboutus_widget_domain' );
}

?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'About Us Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'about_us_img' ); ?>"><?php _e( 'About Us Image URL Link:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'about_us_img' ); ?>" name="<?php echo $this->get_field_name( 'about_us_img' ); ?>" type="text" value="<?php echo esc_attr( $about_us_img ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'sb_aboutus_cnt' ); ?>"><?php _e( 'About Us Content:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'sb_aboutus_cnt' ); ?>" name="<?php echo $this->get_field_name( 'sb_aboutus_cnt' ); ?>" type="text" value="<?php echo esc_attr( $sb_aboutus_cnt ); ?>"/>
</p>
<p>
<label for="<?php echo $this->get_field_id( 'sb_aboutus_name' ); ?>"><?php _e( 'About Us Name:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'sb_aboutus_name' ); ?>" name="<?php echo $this->get_field_name( 'sb_aboutus_name' ); ?>" type="text" value="<?php echo esc_attr( $sb_aboutus_name ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'sb_aboutus_read_link' ); ?>"><?php _e( 'About Us title URL Link:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'sb_aboutus_read_link' ); ?>" name="<?php echo $this->get_field_name( 'sb_aboutus_read_link' ); ?>" type="text" value="<?php echo esc_attr( $sb_aboutus_read_link ); ?>" />
</p>
<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['about_us_img'] = ( ! empty( $new_instance['about_us_img'] ) ) ? strip_tags( $new_instance['about_us_img'] ) : '';
$instance['sb_aboutus_cnt'] = ( ! empty( $new_instance['sb_aboutus_cnt'] ) ) ? strip_tags( $new_instance['sb_aboutus_cnt'] ) : '';
$instance['sb_aboutus_name'] = ( ! empty( $new_instance['sb_aboutus_name'] ) ) ? strip_tags( $new_instance['sb_aboutus_name'] ) : '';
$instance['sb_aboutus_read_link'] = ( ! empty( $new_instance['sb_aboutus_read_link'] ) ) ? strip_tags( $new_instance['sb_aboutus_read_link'] ) : '';
return $instance;
}
}

//About Us  Widget Ends Here

// Breaking News Widget Starts Here

class gl_breaking_news_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_breaking_news_widget', 

__('Pngs - Breaking News', 'gl_breaking_news_widget_domain'), 

array( 'description' => __( 'Displays Breaking News Post', 'gl_breaking_news_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );


echo $args['before_widget'];
if ( ! empty( $title ) )
/*echo $args['before_title'] . $title . $args['after_title'];*/

?>


<div class="breaking_news_content">
<div class="bn_inner_content">
<ul class='breaking_news'>
<?php
$month = date('m');
query_posts('post_type=post&posts_per_page='. $post_count .'&orderby=comment_count&order=DESC&monthnum=' . $month);
while (have_posts()): the_post(); ?>
<li>
<?php 

echo"<div class='brk_img'>";
if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true);
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video
			
 // Defaults
        $f_img_width6 = $instance['width_size'];
        $f_img_height6 = $instance['height_size'];

		// Auto feature image defaults
		$thumb = get_post_thumbnail_id(); 
		$img_url = wp_get_attachment_url( $thumb,'full' ); 
		$image = aq_resize( $img_url,$f_img_width6,$f_img_height6, true );
		// Catch the Image defaults
        $catch_img_url = catch_that_image( $thumb,'full' );
        $catch_image = aq_resize( $catch_img_url, $f_img_width6, $f_img_height6, true );
        // Default Image
		if(has_post_thumbnail())
		echo
		"<div class=\"featured_image\">\n".
		"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width6 . "\" height=\"" . $f_img_height6 . "\" alt=\"" . get_the_title() . "\"><div class='thumb_hover'></div></a>\n".
		"</div>\n";
		elseif (catch_that_image()){ 
		echo
		"<div class=\"featured_image\">\n".
		"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width6 . "\" height=\"" . $f_img_height6 . "\" alt=\"" . get_the_title() . "\"></a>\n".
		"</div>\n"; 
		}
}
}		
		/*featured image ends here*/

echo "</div>";


echo "<h4><a href='". get_permalink() ."'>".
get_the_title() ."".
"</a></h4>";
?>
</li>
<?php endwhile;
wp_reset_query(); ?>

</ul>
</div>
</div>

<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Breaking News', 'gl_breaking_news_widget_domain' );
}

 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '5', 'gl_breaking_news_widget_domain' );
}

 if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '240', 'gl_breaking_news_widget_domain' );
}

 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '150', 'gl_breaking_news_widget_domain' );
}


?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>

<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';

return $instance;
}
}

//Breaking News Widget Ends Here


// Editors Picks Widget Starts Here

class gl_editor_picks_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_editor_picks_widget', 

__('Pngs - Editors Picks', 'gl_editor_picks_widget_domain'), 

array( 'description' => __( 'Displays Editors Picks Post', 'gl_editor_picks_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );
$lat_readmore = apply_filters( 'lat_readmore', $instance['lat_readmore'] );

echo $args['before_widget'];
if ( ! empty( $title ) )
/*echo $args['before_title'] . $title . $args['after_title'];*/

?>

<div class="editors_picks_content">

<?php

query_posts('p='. $post_count .'&posts_per_page=1');
while (have_posts()): the_post(); 
?>
<div class='editors'>
<?php
echo "<div class='editor_news_sec'>";

echo"<div class='edit_img'>";
if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true);
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video
			
 // Defaults
         $f_img_width4 = $instance['width_size'];
        $f_img_height4 = $instance['height_size'];

		// Auto feature image defaults
		$thumb = get_post_thumbnail_id(); 
		$img_url = wp_get_attachment_url( $thumb,'full' ); 
		$image = aq_resize( $img_url,$f_img_width4,$f_img_height4, true );
		// Catch the Image defaults
        $catch_img_url = catch_that_image( $thumb,'full' );
        $catch_image = aq_resize( $catch_img_url, $f_img_width4, $f_img_height4, true );
        // Default Image
		if(has_post_thumbnail())
		echo
		"<div class=\"featured_image\">\n".
		"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width4 . "\" height=\"" . $f_img_height4 . "\" alt=\"" . get_the_title() . "\"><div class='thumb_hover'></div></a>\n".
		"</div>\n";
		elseif (catch_that_image()){ 
		echo
		"<div class=\"featured_image\">\n".
		"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width4 . "\" height=\"" . $f_img_height4 . "\" alt=\"" . get_the_title() . "\"></a>\n".
		"</div>\n"; 
		}
}
}		
		/*featured image ends here*/

echo "</div>";

echo "<div class='edit_news_cont_left'>";
echo"<div class='blog_title'><h4><a href='". get_permalink() ."'>". get_the_title() ."".
"</a></h4></div>";

echo"<div class='blog_byline'>";?>
	
	<span class='author'><?php the_author() ?></span>
	<span class='date'><?php echo get_the_time('M jS, Y'); ?></span>
	<span class='info_comments'><a  href="<?php the_permalink(); ?>#comments" title="<?php comments_number(__('0 Comment','fb'),__('1 Comment','periodic'),__('% Comments','fb')); ?>"><?php comments_number(__('0','periodic'),__('1','periodic'),__('%','fb')); ?> </a></span>
		<?php
echo "</div>";
echo"<p>";
$excerpt=get_the_excerpt();
echo limit_words($excerpt,14);
echo "</p>";
echo"<div class='permalink readmore'><a href='". get_permalink() ."'>". $lat_readmore ."</a></div>";
echo "</div>";
echo "</div>";

?>
</div>


<?php
endwhile;
wp_reset_query();
?>
</div>

<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Editors Picks', 'gl_editor_picks_widget_domain' );
}

 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '123', 'gl_editor_picks_widget_domain' );
}

 if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '792', 'gl_editor_picks_widget_domain' );
}

 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '396', 'gl_editor_picks_widget_domain' );
}

 if ( isset( $instance[ 'lat_readmore' ] ) ) {
$lat_readmore = $instance[ 'lat_readmore' ];
}
else {
$lat_readmore = __( 'Readmore', 'gl_editor_picks_widget_domain' );
}

?>

<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Editors Picks Post ID:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'lat_readmore' ); ?>"><?php _e( 'Readmore Text:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'lat_readmore' ); ?>" name="<?php echo $this->get_field_name( 'lat_readmore' ); ?>" type="text" value="<?php echo esc_attr( $lat_readmore ); ?>" />
</p>

<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';
$instance['lat_readmore'] = ( ! empty( $new_instance['lat_readmore'] ) ) ? strip_tags( $new_instance['lat_readmore'] ) : '';
return $instance;
}
}

//Editors Picks Widget Ends Here

// Content First Category Widget Starts Here

class gl_content_first_catgory_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_content_first_catgory_widget', 

__('Pngs - Content First Category', 'gl_content_first_catgory_widget_domain'), 

array( 'description' => __( 'Displays Content First Category Post', 'gl_content_first_catgory_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );
$width_size1 = apply_filters( 'width_size1', $instance['width_size1'] );
$height_size1 = apply_filters( 'height_size1', $instance['height_size1'] );
$cat_id = apply_filters( 'cat_id', $instance['cat_id'] );

echo $args['before_widget'];
if ( ! empty( $title ) )
/*echo $args['before_title'] . $title . $args['after_title'];*/

?>
<div class="first_category cat_content_sec">
	<div class="first_category_content">
				

		<?php 
		$i = 1;
		query_posts( array('posts_per_page'=> $instance['post_count'] , cat=> $instance['cat_id']) );
		while ( have_posts() ) : the_post();
		if($i == 1){
			?>
			
			<div class="third_full_width">
			
			<div class="third_full_width_cont cat_head_para">
							<div class="entry_cat_title">
							<?php
							$category = get_the_category(); 
							?>
							<h4><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></h4>
							<?php echo "<h3><a href='". get_permalink() ."'>".get_the_title()."";
							echo "</a></h3>";?>
							</div>
							
						</div>
			
			<div class="third_full_width_btm entry_image">
				<?php
				if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true);
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video
							// Auto feature image defaults
							$f_img_width7 = $instance['width_size'];
							$f_img_height7 = $instance['height_size'];	
							$thumb = get_post_thumbnail_id(); 
							$img_url = wp_get_attachment_url( $thumb,'full' ); 
							
							$image = aq_resize( $img_url, $f_img_width7, $f_img_height7, true );
							// Catch the Image defaults
							$catch_img_url = catch_that_image( $thumb,'full' );
							$catch_image = aq_resize( $catch_img_url, $f_img_width7, $f_img_height7, true );
							if(has_post_thumbnail())
							echo
							"<div class=\"featured_image\">\n".
							"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width7 . "\" height=\"" . $f_img_height7 . "\" alt=\"" . get_the_title() . "\"><div class='thumb_hover'></div></a>\n".
							"</div>\n";
							elseif (catch_that_image()){ 
							echo
							"<div class=\"featured_image\">\n".
							"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width7 . "\" height=\"" . $f_img_height7 . "\" alt=\"" . get_the_title() . "\"></a>\n".
							"</div>\n"; 
							}
}
}							
							/*featured image ends here*/
							?>
			</div>
			<div class="entry_excerpt">
							<p>
							<?php
							$excerpt=get_the_excerpt();
							echo string_limit_words($excerpt,28);
							?>
							</p>
							</div>
			</div>
			<?php 
			}
		
		
		
		else if($i == 2){
		?>
		
			<div class="first_cat_top_section">
				<div class="first_cat_top_right entry_image thumb">
							<?php
							if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true);
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video
							// Auto feature image defaults
							$f_img_width8 = $instance['width_size1'];
							$f_img_height8 = $instance['height_size1'];	
							$thumb = get_post_thumbnail_id(); 
							$img_url = wp_get_attachment_url( $thumb,'full' ); 
							
							$image = aq_resize( $img_url, $f_img_width8, $f_img_height8, true );
							// Catch the Image defaults
							$catch_img_url = catch_that_image( $thumb,'full' );
							$catch_image = aq_resize( $catch_img_url, $f_img_width8, $f_img_height8, true );
							if(has_post_thumbnail())
							echo
							"<div class=\"featured_image\">\n".
							"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width8 . "\" height=\"" . $f_img_height8 . "\" alt=\"" . get_the_title() . "\"><div class='thumb_hover'></div></a>\n".
							"</div>\n";
							elseif (catch_that_image()){ 
							echo
							"<div class=\"featured_image\">\n".
							"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width8 . "\" height=\"" . $f_img_height8 . "\" alt=\"" . get_the_title() . "\"></a>\n".
							"</div>\n"; 
							}
}
}							
							/*featured image ends here*/
							?>
							
						</div>
						
						
						<div class="first_cat_top_left cat_head_para">
							<div class="entry_cat_title">
							<?php
							$category = get_the_category(); 
							?>
							<h4><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></h4>
							<?php echo "<h3><a href='". get_permalink() ."'>".get_the_title()."";
							echo "</a></h3>";?>
							</div>
							<div class="entry_excerpt">
							<p>
							<?php
							$excerpt=get_the_excerpt();
							echo string_limit_words($excerpt,13);
							?>
							</p>
							</div>
						</div>
			</div>
			
			
			<?php 
			}
			
			else {
			?>
			
			<div class="first_cat_btm">
			<div class="first_cat_btm_section">
				
							<div class="header_title">
							<?php echo "<h3><a href='". get_permalink() ."'>".get_the_title()."";
							echo "</a></h3>";?>
							</div>
							
				
			</div>
				
			
			
			</div>
			
			
			
				<?php 
			}
				$i++;
				endwhile;
				wp_reset_query(); 
				?>

		
	</div>
</div>

<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Content First Category Post', 'gl_content_first_catgory_widget_domain' );
}

 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '5', 'gl_content_first_catgory_widget_domain' );
}

 if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '800', 'gl_content_first_catgory_widget_domain' );
}

 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '400', 'gl_content_first_catgory_widget_domain' );
}

 if ( isset( $instance[ 'cat_id' ] ) ) {
$cat_id = $instance[ 'cat_id' ];
}
else {
$cat_id = __( '4', 'gl_content_first_catgory_widget_domain' );
}

 if ( isset( $instance[ 'width_size1' ] ) ) {
$width_size1 = $instance[ 'width_size1' ];
}
else {
$width_size1 = __( '400', 'gl_content_first_catgory_widget_domain' );
}

 if ( isset( $instance[ 'height_size1' ] ) ) {
$height_size1 = $instance[ 'height_size1' ];
}
else {
$height_size1 = __( '200', 'gl_content_first_catgory_widget_domain' );
}

?>

<p>
<label for="<?php echo $this->get_field_id( 'cat_id' ); ?>"><?php _e( 'Content First Category ID:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'cat_id' ); ?>" name="<?php echo $this->get_field_name( 'cat_id' ); ?>" type="text" value="<?php echo esc_attr( $cat_id ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Top Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Top Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'width_size1' ); ?>"><?php _e( 'Bottom Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size1' ); ?>" name="<?php echo $this->get_field_name( 'width_size1' ); ?>" type="text" value="<?php echo esc_attr( $width_size1 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size1' ); ?>"><?php _e( 'Bottom Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size1' ); ?>" name="<?php echo $this->get_field_name( 'height_size1' ); ?>" type="text" value="<?php echo esc_attr( $height_size1 ); ?>" />
</p>
<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';
$instance['cat_id'] = ( ! empty( $new_instance['cat_id'] ) ) ? strip_tags( $new_instance['cat_id'] ) : '';
$instance['width_size1'] = ( ! empty( $new_instance['width_size1'] ) ) ? strip_tags( $new_instance['width_size1'] ) : '';
$instance['height_size1'] = ( ! empty( $new_instance['height_size1'] ) ) ? strip_tags( $new_instance['height_size1'] ) : '';

return $instance;
}
}

//Content First Category Widget Ends Here


// Content Second Category Widget Starts Here

class gl_content_second_catgory_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_content_second_catgory_widget', 

__('Pngs - Content Second Category', 'gl_content_second_catgory_widget_domain'), 

array( 'description' => __( 'Displays Content Second Category Post', 'gl_content_second_catgory_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );
$cat_id = apply_filters( 'cat_id', $instance['cat_id'] );
$width_size1 = apply_filters( 'width_size1', $instance['width_size1'] );
$height_size1 = apply_filters( 'height_size1', $instance['height_size1'] );

echo $args['before_widget'];
if ( ! empty( $title ) )
/*echo $args['before_title'] . $title . $args['after_title'];*/

?>
<div class="second_category cat_content_sec">
	<div class="sec_category_content">
		
		<?php 
		$i = 1;
		query_posts( array('posts_per_page'=> $instance['post_count'] , cat=> $instance['cat_id']) );
		//query_posts( array('posts_per_page'=>4, cat=> 4) );
		while ( have_posts() ) : the_post();
		if($i == 1){
		?>
			<div class="sec_cat_left_section">
				<div class="sec_cat_top_left entry_image thumb">
							<?php
							
							if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true);
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video
							
							$f_img_width9 = $instance['width_size'];
							$f_img_height9 = $instance['height_size'];	
							// Auto feature image defaults
							$thumb = get_post_thumbnail_id(); 
							$img_url = wp_get_attachment_url( $thumb,'full' ); 
							
							$image = aq_resize( $img_url, $f_img_width9, $f_img_height9, true );
							// Catch the Image defaults
							$catch_img_url = catch_that_image( $thumb,'full' );
							$catch_image = aq_resize( $catch_img_url, $f_img_width9, $f_img_height9, true );
							if(has_post_thumbnail())
							echo
							"<div class=\"featured_image\">\n".
							"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width9 . "\" height=\"" . $f_img_height9 . "\" alt=\"" . get_the_title() . "\"><div class='thumb_hover'></div></a>\n".
							"</div>\n";
							elseif (catch_that_image()){ 
							echo
							"<div class=\"featured_image\">\n".
							"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width9 . "\" height=\"" . $f_img_height9 . "\" alt=\"" . get_the_title() . "\"></a>\n".
							"</div>\n"; 
							}
}
}							
							/*featured image ends here*/
							?>
							
							<div class="entry_cat_title">
							<?php
							$category = get_the_category(); 
							?>
							<h4><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></h4>
							<?php echo "<h3><a href='". get_permalink() ."'>".get_the_title()."";
							echo "</a></h3>";?>
							</div>
							
						</div>
						
						
						<div class="sec_cat_left_btm">
							<div class="entry_excerpt">
							<p>
							<?php
							$excerpt=get_the_excerpt();
							echo string_limit_words($excerpt,23);
							?>
							</p>
							</div>
							<div class="second_cat_byline">
							<span class='author'><?php the_author() ?></span>
							<span class='date'><?php the_time('M jS, Y') ?> </span>
							<span class='info_comments'><a  href="<?php the_permalink(); ?>#comments" title="<?php comments_number(__('0 Comment','fb'),__('1 Comment','periodic'),__('% Comments','fb')); ?>"><?php comments_number(__('0','periodic'),__('1','periodic'),__('%','fb')); ?> </a></span>					
							</div>
							
						</div>
			</div>
			
			
			<?php 
			}
			
			else {
			?>
			
			<div class="sec_cat_right">
				<div class="sec_cat_top_right entry_image thumb">
							<?php
							
							if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true);
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video
							$f_img_width10 = $instance['width_size1'];
							$f_img_height10 = $instance['height_size1'];	
							// Auto feature image defaults
							$thumb = get_post_thumbnail_id(); 
							$img_url = wp_get_attachment_url( $thumb,'full' ); 
							
							$image = aq_resize( $img_url, $f_img_width10, $f_img_height10, true );
							// Catch the Image defaults
							$catch_img_url = catch_that_image( $thumb,'full' );
							$catch_image = aq_resize( $catch_img_url, $f_img_width10, $f_img_height10, true );
							if(has_post_thumbnail())
							echo
							"<div class=\"featured_image\">\n".
							"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width10 . "\" height=\"" . $f_img_height10 . "\" alt=\"" . get_the_title() . "\"><div class='thumb_hover'></div></a>\n".
							"</div>\n";
							elseif (catch_that_image()){ 
							echo
							"<div class=\"featured_image\">\n".
							"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width10 . "\" height=\"" . $f_img_height10 . "\" alt=\"" . get_the_title() . "\"></a>\n".
							"</div>\n"; 
							} 
							}
							}
							/*featured image ends here*/
							?>
							
							<div class="entry_cat_title">
							<?php
							$category = get_the_category(); 
							?>
							<h4><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></h4>
							<?php echo "<h3><a href='". get_permalink() ."'>".get_the_title()."";
							echo "</a></h3>";?>
							</div>
							
						</div>
				
			</div>
			
			
			
				<?php 
			}
				$i++;
				endwhile;
				wp_reset_query(); 
				?>

		
	</div>
</div>
<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Content Second Category Post', 'gl_content_second_catgory_widget_domain' );
}

 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '4', 'gl_content_second_catgory_widget_domain' );
}

 if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '440', 'gl_content_second_catgory_widget_domain' );
}

 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '396', 'gl_content_second_catgory_widget_domain' );
}

 if ( isset( $instance[ 'cat_id' ] ) ) {
$cat_id = $instance[ 'cat_id' ];
}
else {
$cat_id = __( '6', 'gl_content_second_catgory_widget_domain' );
}

 if ( isset( $instance[ 'width_size1' ] ) ) {
$width_size1 = $instance[ 'width_size1' ];
}
else {
$width_size1 = __( '336', 'gl_content_second_catgory_widget_domain' );
}

 if ( isset( $instance[ 'height_size1' ] ) ) {
$height_size1 = $instance[ 'height_size1' ];
}
else {
$height_size1 = __( '176', 'gl_content_second_catgory_widget_domain' );
}

?>

<p>
<label for="<?php echo $this->get_field_id( 'cat_id' ); ?>"><?php _e( 'Content Second Category ID:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'cat_id' ); ?>" name="<?php echo $this->get_field_name( 'cat_id' ); ?>" type="text" value="<?php echo esc_attr( $cat_id ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Left Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Left Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'width_size1' ); ?>"><?php _e( 'Right Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size1' ); ?>" name="<?php echo $this->get_field_name( 'width_size1' ); ?>" type="text" value="<?php echo esc_attr( $width_size1 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size1' ); ?>"><?php _e( 'Right Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size1' ); ?>" name="<?php echo $this->get_field_name( 'height_size1' ); ?>" type="text" value="<?php echo esc_attr( $height_size1 ); ?>" />
</p>
<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';
$instance['cat_id'] = ( ! empty( $new_instance['cat_id'] ) ) ? strip_tags( $new_instance['cat_id'] ) : '';
$instance['width_size1'] = ( ! empty( $new_instance['width_size1'] ) ) ? strip_tags( $new_instance['width_size1'] ) : '';
$instance['height_size1'] = ( ! empty( $new_instance['height_size1'] ) ) ? strip_tags( $new_instance['height_size1'] ) : '';
return $instance;
}
}

//Content Second Category Widget Ends Here

// Content Third Category Widget Starts Here

class gl_content_third_catgory_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_content_third_catgory_widget', 

__('Pngs - Content Third Category', 'gl_content_third_catgory_widget_domain'), 

array( 'description' => __( 'Displays Content Third Category Post', 'gl_content_third_catgory_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );
$cat_id = apply_filters( 'cat_id', $instance['cat_id'] );
$width_size1 = apply_filters( 'width_size1', $instance['width_size1'] );
$height_size1 = apply_filters( 'height_size1', $instance['height_size1'] );

echo $args['before_widget'];
if ( ! empty( $title ) )
/*echo $args['before_title'] . $title . $args['after_title'];*/

?>

<div class="third_category cat_content_sec">
	<div class="third_category_content">
				

		<?php 
		$i = 1;
		query_posts( array('posts_per_page'=> $instance['post_count'] , cat=> $instance['cat_id']) );		
		while ( have_posts() ) : the_post();
		
		if($i == 1){
			?>
			
			<div class="third_full_width">
			
			<div class="third_full_width_cont cat_head_para">
							<div class="entry_cat_title">
							<?php
							$category = get_the_category(); 
							?>
							<h4><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></h4>
							<?php echo "<h3><a href='". get_permalink() ."'>".get_the_title()."";
							echo "</a></h3>";?>
							</div>
							
						</div>
			
			<div class="third_full_width_btm entry_image">
				<?php
				
				if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true);
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video
							$f_img_width11 = $instance['width_size'];
							$f_img_height11 = $instance['height_size'];	
							// Auto feature image defaults
							$thumb = get_post_thumbnail_id(); 
							$img_url = wp_get_attachment_url( $thumb,'full' ); 
							
							$image = aq_resize( $img_url, $f_img_width11, $f_img_height11, true );
							// Catch the Image defaults
							$catch_img_url = catch_that_image( $thumb,'full' );
							$catch_image = aq_resize( $catch_img_url, $f_img_width11, $f_img_height11, true );
							if(has_post_thumbnail())
							echo
							"<div class=\"featured_image\">\n".
							"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width11 . "\" height=\"" . $f_img_height11 . "\" alt=\"" . get_the_title() . "\"><div class='thumb_hover'></div></a>\n".
							"</div>\n";
							elseif (catch_that_image()){ 
							echo
							"<div class=\"featured_image\">\n".
							"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width11 . "\" height=\"" . $f_img_height11 . "\" alt=\"" . get_the_title() . "\"></a>\n".
							"</div>\n"; 
							} 
							}
							}
							/*featured image ends here*/
							?>
			</div>
			<div class="entry_excerpt">
							<p>
							<?php
							$excerpt=get_the_excerpt();
							echo string_limit_words($excerpt,28);
							?>
							</p>
							</div>
			
			</div>
			<?php 
			}
		
		
		
		else if($i == 2){
			?>
		
			<div class="first_cat_top_section">
				<div class="first_cat_top_right entry_image thumb">
							<?php
							
							if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true);
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video
							$f_img_width12 = $instance['width_size1'];
							$f_img_height12 = $instance['height_size1'];	
							// Auto feature image defaults
							$thumb = get_post_thumbnail_id(); 
							$img_url = wp_get_attachment_url( $thumb,'full' ); 
							
							$image = aq_resize( $img_url, $f_img_width12, $f_img_height12, true );
							// Catch the Image defaults
							$catch_img_url = catch_that_image( $thumb,'full' );
							$catch_image = aq_resize( $catch_img_url, $f_img_width12, $f_img_height12, true );
							if(has_post_thumbnail())
							echo
							"<div class=\"featured_image\">\n".
							"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width12 . "\" height=\"" . $f_img_height12 . "\" alt=\"" . get_the_title() . "\"><div class='thumb_hover'></div></a>\n".
							"</div>\n";
							elseif (catch_that_image()){ 
							echo
							"<div class=\"featured_image\">\n".
							"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width12 . "\" height=\"" . $f_img_height12 . "\" alt=\"" . get_the_title() . "\"></a>\n".
							"</div>\n"; 
							}
}
}							
							/*featured image ends here*/
							?>
							
						</div>
						
						
						<div class="first_cat_top_left cat_head_para">
							<div class="entry_cat_title">
							<?php
							$category = get_the_category(); 
							?>
							<h4><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></h4>
							<?php echo "<h3><a href='". get_permalink() ."'>".get_the_title()."";
							echo "</a></h3>";?>
							</div>
							<div class="entry_excerpt">
							<p>
							<?php
							$excerpt=get_the_excerpt();
							echo string_limit_words($excerpt,13);
							?>
							</p>
							</div>
						</div>
			</div>
			
			
			<?php 
			}
			
			else {
			?>
			<div class="first_cat_btm">
			<div class="first_cat_btm_section">
			<div class="header_title">
			<?php echo "<h3><a href='". get_permalink() ."'>".get_the_title()."";
			echo "</a></h3>";?>
			</div>	
			</div>
			</div>
			<?php 
			}
			
				$i++;
				endwhile;
				wp_reset_query(); 
				?>

		
	</div>
</div>

<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Content Third Category Post', 'gl_content_third_catgory_widget_domain' );
}

 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '4', 'gl_content_third_catgory_widget_domain' );
}

 if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '800', 'gl_content_third_catgory_widget_domain' );
}

 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '400', 'gl_content_third_catgory_widget_domain' );
}

 if ( isset( $instance[ 'cat_id' ] ) ) {
$cat_id = $instance[ 'cat_id' ];
}
else {
$cat_id = __( '7', 'gl_content_third_catgory_widget_domain' );
}

 if ( isset( $instance[ 'width_size1' ] ) ) {
$width_size1 = $instance[ 'width_size1' ];
}
else {
$width_size1 = __( '400', 'gl_content_third_catgory_widget_domain' );
}

 if ( isset( $instance[ 'height_size1' ] ) ) {
$height_size1 = $instance[ 'height_size1' ];
}
else {
$height_size1 = __( '200', 'gl_content_third_catgory_widget_domain' );
}


?>

<p>
<label for="<?php echo $this->get_field_id( 'cat_id' ); ?>"><?php _e( 'Content Third Category ID:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'cat_id' ); ?>" name="<?php echo $this->get_field_name( 'cat_id' ); ?>" type="text" value="<?php echo esc_attr( $cat_id ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Top Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Top Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'width_size1' ); ?>"><?php _e( 'Bottom Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size1' ); ?>" name="<?php echo $this->get_field_name( 'width_size1' ); ?>" type="text" value="<?php echo esc_attr( $width_size1 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size1' ); ?>"><?php _e( 'Bottom Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size1' ); ?>" name="<?php echo $this->get_field_name( 'height_size1' ); ?>" type="text" value="<?php echo esc_attr( $height_size1 ); ?>" />
</p>


<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';
$instance['cat_id'] = ( ! empty( $new_instance['cat_id'] ) ) ? strip_tags( $new_instance['cat_id'] ) : '';
$instance['width_size1'] = ( ! empty( $new_instance['width_size1'] ) ) ? strip_tags( $new_instance['width_size1'] ) : '';
$instance['height_size1'] = ( ! empty( $new_instance['height_size1'] ) ) ? strip_tags( $new_instance['height_size1'] ) : '';

return $instance;
}
}

//Content Third Category Widget Ends Here


class gl_content_fourth_catgory_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_content_fourth_catgory_widget', 

__('Pngs - Content Fourth Category', 'gl_content_fourth_catgory_widget_domain'), 

array( 'description' => __( 'Displays Content Fourth Category Post', 'gl_content_fourth_catgory_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );
$cat_id = apply_filters( 'cat_id', $instance['cat_id'] );

echo $args['before_widget'];
if ( ! empty( $title ) )
/*echo $args['before_title'] . $title . $args['after_title'];*/

?>
<div class="fourth_category cat_content_sec">
	<div class="fourth_category_content sec_category_content">
		
		<?php 
		$i = 1;
		query_posts( array('posts_per_page'=> $instance['post_count'] , cat=> $instance['cat_id']) );		
		while ( have_posts() ) : the_post();
		if($i == 1){
		?>
			<div class="fourth_cat_left_section">
				<div class="sec_cat_top_left fourth_cat_top_left entry_image thumb">
							<?php
							
							if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true);
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video
							$f_img_width13 = $instance['width_size'];
							$f_img_height13 = $instance['height_size'];	
							// Auto feature image defaults
							$thumb = get_post_thumbnail_id(); 
							$img_url = wp_get_attachment_url( $thumb,'full' ); 
							
							$image = aq_resize( $img_url, $f_img_width13, $f_img_height13, true );
							// Catch the Image defaults
							$catch_img_url = catch_that_image( $thumb,'full' );
							$catch_image = aq_resize( $catch_img_url, $f_img_width13, $f_img_height13, true );
							if(has_post_thumbnail())
							echo
							"<div class=\"featured_image\">\n".
							"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width13 . "\" height=\"" . $f_img_height13 . "\" alt=\"" . get_the_title() . "\"><div class='thumb_hover'></div></a>\n".
							"</div>\n";
							elseif (catch_that_image()){ 
							echo
							"<div class=\"featured_image\">\n".
							"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width13 . "\" height=\"" . $f_img_height13 . "\" alt=\"" . get_the_title() . "\"></a>\n".
							"</div>\n"; 
							} 
							}
							}
							/*featured image ends here*/
							?>
							
							<div class="entry_cat_title">
							<?php
							$category = get_the_category(); 
							?>
							<h4><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></h4>
							<?php echo "<h3><a href='". get_permalink() ."'>".get_the_title()."";
							echo "</a></h3>";?>
							</div>
							
						</div>
						
						
						<div class="sec_cat_left_btm">
							<div class="entry_excerpt">
							<p>
							<?php
							$excerpt=get_the_excerpt();
							echo string_limit_words($excerpt,23);
							?>
							</p>
							</div>
							<div class="second_cat_byline">
							<span class='author'><?php the_author() ?></span>
							<span class='date'><?php the_time('M jS, Y') ?> </span>
							<span class='info_comments'><a  href="<?php the_permalink(); ?>#comments" title="<?php comments_number(__('0 Comment','fb'),__('1 Comment','periodic'),__('% Comments','fb')); ?>"><?php comments_number(__('0','periodic'),__('1','periodic'),__('%','fb')); ?> </a></span>					
							</div>
							
						</div>
			</div>
			
			
			<?php 
			}
			
			else {
			?>
			
			<div class="fourth_cat_right">
			<div class="fourth_cat_title">
							<?php
							$category = get_the_category(); 
							?>
							<h4><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></h4>
							<?php echo "<h3><a href='". get_permalink() ."'>".get_the_title()."";
							echo "</a></h3>";?>
							</div>
			</div>
			
			
			
				<?php 
			}
				$i++;
				endwhile;
				wp_reset_query(); 
				?>

		
	</div>
</div>

<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Content Fourth Category Post', 'gl_content_fourth_catgory_widget_domain' );
}

 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '4', 'gl_content_fourth_catgory_widget_domain' );
}

 if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '416', 'gl_content_fourth_catgory_widget_domain' );
}

 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '236', 'gl_content_fourth_catgory_widget_domain' );
}

 if ( isset( $instance[ 'cat_id' ] ) ) {
$cat_id = $instance[ 'cat_id' ];
}
else {
$cat_id = __( '3', 'gl_content_fourth_catgory_widget_domain' );
}


?>

<p>
<label for="<?php echo $this->get_field_id( 'cat_id' ); ?>"><?php _e( 'Content Fourth Category ID:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'cat_id' ); ?>" name="<?php echo $this->get_field_name( 'cat_id' ); ?>" type="text" value="<?php echo esc_attr( $cat_id ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>


<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';
$instance['cat_id'] = ( ! empty( $new_instance['cat_id'] ) ) ? strip_tags( $new_instance['cat_id'] ) : '';

return $instance;
}
}

//Content Fourth Category Widget Ends Here

// Double Column Category Widget Starts Here

class gl_double_column_category_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_double_column_category_widget', 

__('Pngs - Double Column Category', 'gl_double_column_category_widget_domain'), 

array( 'description' => __( 'Displays Content Double Column Category Post', 'gl_double_column_category_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
$cat_id = apply_filters( 'cat_id', $instance['cat_id'] );
$cat_id = apply_filters( 'cat_id1', $instance['cat_id1'] );

echo $args['before_widget'];
if ( ! empty( $title ) )
/*echo $args['before_title'] . $title . $args['after_title'];*/

?>
<div class="double_column_category_box cat_content_sec">

<div class="fifth_category_content">
		
		<?php 
		$i = 1;
		query_posts( array('posts_per_page'=> $instance['post_count'] , cat=> $instance['cat_id']) );
		
		while ( have_posts() ) : the_post();
		
		if($i == 1){
		?>
			<div class="fifth_cat_details img_content_area">
				<div class="fifth_cat_img img_mid entry_image thumb">
							<?php
							if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true);
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video
							$f_img_width14 = 384;
							$f_img_height14 = 399;	
							// Auto feature image defaults
							$thumb = get_post_thumbnail_id(); 
							$img_url = wp_get_attachment_url( $thumb,'full' ); 
							$image = aq_resize( $img_url, $f_img_width14, $f_img_height14, true );
							// Catch the Image defaults
							$catch_img_url = catch_that_image( $thumb,'full' );
							$catch_image = aq_resize( $catch_img_url, $f_img_width14, $f_img_height14, true );
							if(has_post_thumbnail())
							echo
							"<div class=\"featured_image\">\n".
							"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width14 . "\" height=\"" . $f_img_height14 . "\" alt=\"" . get_the_title() . "\"><div class='thumb_hover'></div></a>\n".
							"</div>\n";
							elseif (catch_that_image()){ 
							echo
							"<div class=\"featured_image\">\n".
							"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width14 . "\" height=\"" . $f_img_height14 . "\" alt=\"" . get_the_title() . "\"></a>\n".
							"</div>\n"; 
							} 
							}
							}
							/*featured image ends here*/
							?>
							
							<div class="entry_cat_title">
							<?php
							$category = get_the_category(); 
							?>
							<h4><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></h4>
							<?php echo "<h3><a href='". get_permalink() ."'>".get_the_title()."";
							echo "</a></h3>";?>
							</div>
							
						</div>
			</div>
			
			
			<?php 
			}
			
			else if($i == 2){
			?>
			
			<div class="ffifth_cat_details img_content_area">
				<div class="fifth_cat_img img_max entry_image thumb">
							<?php
							if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true);
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video
							$f_img_width15 = 384;
							$f_img_height15 = 447;	
							// Auto feature image defaults
							$thumb = get_post_thumbnail_id(); 
							$img_url = wp_get_attachment_url( $thumb,'full' ); 
							$image = aq_resize( $img_url, $f_img_width15, $f_img_height15, true );
							// Catch the Image defaults
							$catch_img_url = catch_that_image( $thumb,'full' );
							$catch_image = aq_resize( $catch_img_url, $f_img_width15, $f_img_height15, true );
							if(has_post_thumbnail())
							echo
							"<div class=\"featured_image\">\n".
							"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width15 . "\" height=\"" . $f_img_height15 . "\" alt=\"" . get_the_title() . "\"><div class='thumb_hover'></div></a>\n".
							"</div>\n";
							elseif (catch_that_image()){ 
							echo
							"<div class=\"featured_image\">\n".
							"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width15 . "\" height=\"" . $f_img_height15 . "\" alt=\"" . get_the_title() . "\"></a>\n".
							"</div>\n"; 
							} 
							}
							}
							/*featured image ends here*/
							?>
							
							<div class="entry_cat_title">
							<?php
							$category = get_the_category(); 
							?>
							<h4><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></h4>
							<?php echo "<h3><a href='". get_permalink() ."'>".get_the_title()."";
							echo "</a></h3>";?>
							</div>
							
						</div>
			</div>
			
			<?php 
			}
			
				else if($i == 3){
			?>
			<div class="fifth_cat_details img_content_area">
				<div class="fifth_cat_img img_min entry_image thumb">
							<?php
							if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true);
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video
							$f_img_width16 = 384;
							$f_img_height16 = 199;
							// Auto feature image defaults
							$thumb = get_post_thumbnail_id(); 
							$img_url = wp_get_attachment_url( $thumb,'full' ); 
							$image = aq_resize( $img_url, $f_img_width16, $f_img_height16, true );
							// Catch the Image defaults
							$catch_img_url = catch_that_image( $thumb,'full' );
							$catch_image = aq_resize( $catch_img_url, $f_img_width16, $f_img_height16, true );
							if(has_post_thumbnail())
							echo
							"<div class=\"featured_image\">\n".
							"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width16 . "\" height=\"" . $f_img_height16 . "\" alt=\"" . get_the_title() . "\"><div class='thumb_hover'></div></a>\n".
							"</div>\n";
							elseif (catch_that_image()){ 
							echo
							"<div class=\"featured_image\">\n".
							"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width16 . "\" height=\"" . $f_img_height16 . "\" alt=\"" . get_the_title() . "\"></a>\n".
							"</div>\n"; 
							} 
							}
							}
							/*featured image ends here*/
							?>
							
							<div class="entry_cat_title">
							<?php
							$category = get_the_category(); 
							?>
							<h4><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></h4>
							<?php echo "<h3><a href='". get_permalink() ."'>".get_the_title()."";
							echo "</a></h3>";?>
							</div>
							
						</div>
			</div>
			
			
			<?php 
			}
			
						
				$i++;
				endwhile;
				wp_reset_query(); 
				?>

		
</div>


<div class="sixth_category_content">
		
		<?php 
		$i = 1;
		query_posts( array('posts_per_page'=> $instance['post_count'] , cat=> $instance['cat_id1']) );
		
		while ( have_posts() ) : the_post();
		
		if($i == 1){
		?>
			<div class="fifth_cat_details img_content_area">
				<div class="fifth_cat_img img_min entry_image thumb">
							<?php
							if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true);
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video
							$f_img_width17 = 384;
							$f_img_height17 = 199;
							// Auto feature image defaults
							$thumb = get_post_thumbnail_id(); 
							$img_url = wp_get_attachment_url( $thumb,'full' ); 
							$image = aq_resize( $img_url, $f_img_width17, $f_img_height17, true );
							// Catch the Image defaults
							$catch_img_url = catch_that_image( $thumb,'full' );
							$catch_image = aq_resize( $catch_img_url, $f_img_width17, $f_img_height17, true );
							if(has_post_thumbnail())
							echo
							"<div class=\"featured_image\">\n".
							"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width17 . "\" height=\"" . $f_img_height17 . "\" alt=\"" . get_the_title() . "\"><div class='thumb_hover'></div></a>\n".
							"</div>\n";
							elseif (catch_that_image()){ 
							echo
							"<div class=\"featured_image\">\n".
							"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width17 . "\" height=\"" . $f_img_height17 . "\" alt=\"" . get_the_title() . "\"></a>\n".
							"</div>\n"; 
							} 
							}
							}
							/*featured image ends here*/
							?>
							
							<div class="entry_cat_title">
							<?php
							$category = get_the_category(); 
							?>
							<h4><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></h4>
							<?php echo "<h3><a href='". get_permalink() ."'>".get_the_title()."";
							echo "</a></h3>";?>
							</div>
							
						</div>
			</div>
			
			
			<?php 
			}
			
			else if($i == 2){
			?>
			
			<div class="fifth_cat_details img_content_area">
				<div class="fifth_cat_img img_max entry_image thumb">
							<?php
							if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true);
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video
							$f_img_width18 = 384;
							$f_img_height18 = 447;
							// Auto feature image defaults
							$thumb = get_post_thumbnail_id(); 
							$img_url = wp_get_attachment_url( $thumb,'full' ); 
							$image = aq_resize( $img_url, $f_img_width18, $f_img_height18, true );
							// Catch the Image defaults
							$catch_img_url = catch_that_image( $thumb,'full' );
							$catch_image = aq_resize( $catch_img_url, $f_img_width18, $f_img_height18, true );
							if(has_post_thumbnail())
							echo
							"<div class=\"featured_image\">\n".
							"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width18 . "\" height=\"" . $f_img_height18 . "\" alt=\"" . get_the_title() . "\"><div class='thumb_hover'></div></a>\n".
							"</div>\n";
							elseif (catch_that_image()){ 
							echo
							"<div class=\"featured_image\">\n".
							"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width18 . "\" height=\"" . $f_img_height18 . "\" alt=\"" . get_the_title() . "\"></a>\n".
							"</div>\n"; 
							} 
							}
							}
							/*featured image ends here*/
							?>
							
							<div class="entry_cat_title">
							<?php
							$category = get_the_category(); 
							?>
							<h4><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></h4>
							<?php echo "<h3><a href='". get_permalink() ."'>".get_the_title()."";
							echo "</a></h3>";?>
							</div>
							
						</div>
			</div>
			
			<?php 
			}
			
				else if($i == 3){
			?>
			<div class="fifth_cat_details img_content_area">
				<div class="fifth_cat_img img_mid entry_image thumb">
							<?php
							if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true);
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video
							$f_img_width19 = 384;
							$f_img_height19 = 399;
							// Auto feature image defaults
							$thumb = get_post_thumbnail_id(); 
							$img_url = wp_get_attachment_url( $thumb,'full' ); 
							$image = aq_resize( $img_url, $f_img_width19, $f_img_height19, true );
							// Catch the Image defaults
							$catch_img_url = catch_that_image( $thumb,'full' );
							$catch_image = aq_resize( $catch_img_url, $f_img_width19, $f_img_height19, true );
							if(has_post_thumbnail())
							echo
							"<div class=\"featured_image\">\n".
							"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width19 . "\" height=\"" . $f_img_height19 . "\" alt=\"" . get_the_title() . "\"><div class='thumb_hover'></div></a>\n".
							"</div>\n";
							elseif (catch_that_image()){ 
							echo
							"<div class=\"featured_image\">\n".
							"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width19 . "\" height=\"" . $f_img_height19 . "\" alt=\"" . get_the_title() . "\"></a>\n".
							"</div>\n"; 
							} 
							}
							}
							/*featured image ends here*/
							?>
							
							<div class="entry_cat_title">
							<?php
							$category = get_the_category(); 
							?>
							<h4><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></h4>
							<?php echo "<h3><a href='". get_permalink() ."'>".get_the_title()."";
							echo "</a></h3>";?>
							</div>
							
						</div>
			</div>
			
			
			<?php 
			}
			
						
				$i++;
				endwhile;
				wp_reset_query(); 
				?>

		
</div>

</div>

<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Double Column Category Post', 'gl_double_column_category_widget_domain' );
}

 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '3', 'gl_double_column_category_widget_domain' );
}


 if ( isset( $instance[ 'cat_id' ] ) ) {
$cat_id = $instance[ 'cat_id' ];
}
else {
$cat_id = __( '7', 'gl_double_column_category_widget_domain' );
}

 if ( isset( $instance[ 'cat_id1' ] ) ) {
$cat_id1 = $instance[ 'cat_id1' ];
}
else {
$cat_id1 = __( '4', 'gl_double_column_category_widget_domain' );
}


?>

<p>
<label for="<?php echo $this->get_field_id( 'cat_id' ); ?>"><?php _e( 'Double Column Category ID One:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'cat_id' ); ?>" name="<?php echo $this->get_field_name( 'cat_id' ); ?>" type="text" value="<?php echo esc_attr( $cat_id ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'cat_id1' ); ?>"><?php _e( 'Double Column Category ID Two:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'cat_id1' ); ?>" name="<?php echo $this->get_field_name( 'cat_id1' ); ?>" type="text" value="<?php echo esc_attr( $cat_id1 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>

<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['cat_id1'] = ( ! empty( $new_instance['cat_id1'] ) ) ? strip_tags( $new_instance['cat_id1'] ) : '';
$instance['cat_id'] = ( ! empty( $new_instance['cat_id'] ) ) ? strip_tags( $new_instance['cat_id'] ) : '';

return $instance;
}
}

//Double Column Category Widget Ends Here

// Content Fifth Category Widget Starts Here

class gl_content_fifth_catgory_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_content_fifth_catgory_widget', 

__('Pngs - Content Fifth Category', 'gl_content_fifth_catgory_widget_domain'), 

array( 'description' => __( 'Displays Content Fifth Category Post', 'gl_content_fifth_catgory_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );
$width_size1 = apply_filters( 'width_size1', $instance['width_size1'] );
$height_size1 = apply_filters( 'height_size1', $instance['height_size1'] );
$cat_id = apply_filters( 'cat_id', $instance['cat_id'] );


echo $args['before_widget'];
if ( ! empty( $title ) )
/*echo $args['before_title'] . $title . $args['after_title'];*/

?>
<div class="seventh_category cat_content_sec">
	<div class="third_category_content">
				

		<?php 
		$i = 1;
		query_posts( array('posts_per_page'=> $instance['post_count'] , cat=> $instance['cat_id']) );
		while ( have_posts() ) : the_post();
		
		if($i == 1){
			?>
			
			<div class="third_full_width">
			
			<div class="third_full_width_cont cat_head_para">
							<div class="entry_cat_title">
							<?php
							$category = get_the_category(); 
							?>
							<h4><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></h4>
							<?php echo "<h3><a href='". get_permalink() ."'>".get_the_title()."";
							echo "</a></h3>";?>
							</div>
							
						</div>
			
			<div class="third_full_width_btm entry_image">
				<?php
				if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true);
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video
							$f_img_width20 = $instance['width_size'];
							$f_img_height20 = $instance['height_size'];
							// Auto feature image defaults
							$thumb = get_post_thumbnail_id(); 
							$img_url = wp_get_attachment_url( $thumb,'full' ); 
							$image = aq_resize( $img_url, $f_img_width20, $f_img_height20, true );
							// Catch the Image defaults
							$catch_img_url = catch_that_image( $thumb,'full' );
							$catch_image = aq_resize( $catch_img_url, $f_img_width20, $f_img_height20, true );
							if(has_post_thumbnail())
							echo
							"<div class=\"featured_image\">\n".
							"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width20 . "\" height=\"" . $f_img_height20 . "\" alt=\"" . get_the_title() . "\"><div class='thumb_hover'></div></a>\n".
							"</div>\n";
							elseif (catch_that_image()){ 
							echo
							"<div class=\"featured_image\">\n".
							"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width20 . "\" height=\"" . $f_img_height20 . "\" alt=\"" . get_the_title() . "\"></a>\n".
							"</div>\n"; 
							}
}
}							
							/*featured image ends here*/
							?>
			</div>
			
			<div class="entry_excerpt">
							<p>
							<?php
							$excerpt=get_the_excerpt();
							echo string_limit_words($excerpt,28);
							?>
							</p>
							</div>
			
			</div>
			<?php 
			}
		
		
		
		else {
			?>
		
			<div class="first_cat_top_section">
				<div class="first_cat_top_right entry_image thumb">
							<?php
							if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true);
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video
							$f_img_width21 = $instance['width_size1'];
							$f_img_height21 = $instance['height_size1'];
							// Auto feature image defaults
							$thumb = get_post_thumbnail_id(); 
							$img_url = wp_get_attachment_url( $thumb,'full' ); 
							$image = aq_resize( $img_url, $f_img_width21, $f_img_height21, true );
							// Catch the Image defaults
							$catch_img_url = catch_that_image( $thumb,'full' );
							$catch_image = aq_resize( $catch_img_url, $f_img_width21, $f_img_height21, true );
							if(has_post_thumbnail())
							echo
							"<div class=\"featured_image\">\n".
							"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width21 . "\" height=\"" . $f_img_height21 . "\" alt=\"" . get_the_title() . "\"><div class='thumb_hover'></div></a>\n".
							"</div>\n";
							elseif (catch_that_image()){ 
							echo
							"<div class=\"featured_image\">\n".
							"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width21 . "\" height=\"" . $f_img_height21 . "\" alt=\"" . get_the_title() . "\"></a>\n".
							"</div>\n"; 
							} 
							}
							}
							/*featured image ends here*/
							?>
							
						</div>
						
						
						<div class="first_cat_top_left cat_head_para">
							<div class="entry_cat_title">
							<?php
							$category = get_the_category(); 
							?>
							<h4><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></h4>
							<?php echo "<h3><a href='". get_permalink() ."'>".get_the_title()."";
							echo "</a></h3>";?>
							</div>
							<div class="entry_excerpt">
							<p>
							<?php
							$excerpt=get_the_excerpt();
							echo string_limit_words($excerpt,13);
							?>
							</p>
							</div>
						</div>
			</div>
			
			
			<?php 
			}
			
			
				$i++;
				endwhile;
				wp_reset_query(); 
				?>

		
	</div>
</div>

<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Content Fifth Category Post', 'gl_content_fifth_catgory_widget_domain' );
}

 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '3', 'gl_content_fifth_catgory_widget_domain' );
}

 if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '800', 'gl_content_fifth_catgory_widget_domain' );
}

 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '400', 'gl_content_fifth_catgory_widget_domain' );
}

 if ( isset( $instance[ 'cat_id' ] ) ) {
$cat_id = $instance[ 'cat_id' ];
}
else {
$cat_id = __( '5', 'gl_content_fifth_catgory_widget_domain' );
}

 if ( isset( $instance[ 'width_size1' ] ) ) {
$width_size1 = $instance[ 'width_size1' ];
}
else {
$width_size1 = __( '400', 'gl_content_fifth_catgory_widget_domain' );
}

 if ( isset( $instance[ 'height_size1' ] ) ) {
$height_size1 = $instance[ 'height_size1' ];
}
else {
$height_size1 = __( '200', 'gl_content_fifth_catgory_widget_domain' );
}


?>

<p>
<label for="<?php echo $this->get_field_id( 'cat_id' ); ?>"><?php _e( 'Content Fifth Category ID:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'cat_id' ); ?>" name="<?php echo $this->get_field_name( 'cat_id' ); ?>" type="text" value="<?php echo esc_attr( $cat_id ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Top Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Top Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'width_size1' ); ?>"><?php _e( 'Bottom Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size1' ); ?>" name="<?php echo $this->get_field_name( 'width_size1' ); ?>" type="text" value="<?php echo esc_attr( $width_size1 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'height_size1' ); ?>"><?php _e( 'Bottom Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size1' ); ?>" name="<?php echo $this->get_field_name( 'height_size1' ); ?>" type="text" value="<?php echo esc_attr( $height_size1 ); ?>" />
</p>


<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';
$instance['cat_id'] = ( ! empty( $new_instance['cat_id'] ) ) ? strip_tags( $new_instance['cat_id'] ) : '';
$instance['width_size1'] = ( ! empty( $new_instance['width_size1'] ) ) ? strip_tags( $new_instance['width_size1'] ) : '';
$instance['height_size1'] = ( ! empty( $new_instance['height_size1'] ) ) ? strip_tags( $new_instance['height_size1'] ) : '';

return $instance;
}
}

//Content Fifth Category Widget Ends Here

// Latest News Widget Starts Here

class gl_latest_news_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_latest_news_widget', 

__('Pngs - Latest News', 'gl_latest_news_widget_domain'), 

array( 'description' => __( 'Displays Latest News Post', 'gl_latest_news_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
$read_more = apply_filters( 'read_more', $instance['read_more'] );

echo $args['before_widget'];
if ( ! empty( $title ) )
/*echo $args['before_title'] . $title . $args['after_title'];*/

?>
<?php

 echo "<div class='latest_content content_sec'>";
 echo "<div class='inner_latest_content'>";

?>
<h2 class='block_title'><?php echo $instance['title']; ?></h2>
<?php

query_posts( array('posts_per_page'=>  $instance['post_count'] ) );
while ( have_posts() ) : the_post();

echo "<div class='lat_news_sec'>";

echo"<div class='lat_img'>";
if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true);
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video
			
 // Defaults
         $f_img_width22 = $instance['width_size'];
        $f_img_height22 = $instance['height_size'];

		// Auto feature image defaults
		$thumb = get_post_thumbnail_id(); 
		$img_url = wp_get_attachment_url( $thumb,'full' ); 
		$image = aq_resize( $img_url,$f_img_width22,$f_img_height22, true );
		// Catch the Image defaults
        $catch_img_url = catch_that_image( $thumb,'full' );
        $catch_image = aq_resize( $catch_img_url, $f_img_width22, $f_img_height22, true );
        // Default Image
        
		if(has_post_thumbnail())
		echo
		"<div class=\"featured_image\">\n".
		"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width22 . "\" height=\"" . $f_img_height22 . "\" alt=\"" . get_the_title() . "\"><div class='thumb_hover'></div></a>\n".
		"</div>\n";
		elseif (catch_that_image()){ 
		echo
		"<div class=\"featured_image\">\n".
		"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width22 . "\" height=\"" . $f_img_height22 . "\" alt=\"" . get_the_title() . "\"></a>\n".
		"</div>\n"; 
		}
}
}		
		/*featured image ends here*/

echo "</div>";

echo "<div class='lat_news_cont_right'>";
$category = get_the_category(); 
							?>
							<h4><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></h4>
<?php
echo"<div class='blog_title'><h3><a href='". get_permalink() ."'>". get_the_title() ."".
"</a></h3></div>";

echo"<div class='blog_byline'>";?>
	
	<span class='author'><?php the_author() ?></span>
	<span class='date'><?php echo get_the_time('M jS, Y'); ?></span>
	<span class='info_comments'><a  href="<?php the_permalink(); ?>#comments" title="<?php comments_number(__('0 Comment','fb'),__('1 Comment','periodic'),__('% Comments','fb')); ?>"><?php comments_number(__('0','periodic'),__('1','periodic'),__('%','fb')); ?> </a></span>
		<?php
echo "</div>";
echo"<p>";
$excerpt=get_the_excerpt();
echo limit_words($excerpt,14);
echo "</p>";
echo"<div class='permalink readmore'><a href='". get_permalink() ."'>". $read_more ."</a></div>";
echo "</div>";
echo "</div>";


$i++;
endwhile;
wp_reset_query();


echo "</div>";  
echo "</div>";
?>
<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Latest News!', 'gl_latest_news_widget_domain' );
}

 if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '300', 'gl_latest_news_widget_domain' );
}

 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '180', 'gl_latest_news_widget_domain' );
}

 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '5', 'gl_latest_news_widget_domain' );
}

 if ( isset( $instance[ 'read_more' ] ) ) {
$read_more = $instance[ 'read_more' ];
}
else {
$read_more = __( 'Read More', 'gl_latest_news_widget_domain' );
}

?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>


<p>
<label for="<?php echo $this->get_field_id( 'read_more' ); ?>"><?php _e( 'Read More Text:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'read_more' ); ?>" name="<?php echo $this->get_field_name( 'read_more' ); ?>" type="text" value="<?php echo esc_attr( $read_more ); ?>" />
</p>
<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';

$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['read_more'] = ( ! empty( $new_instance['read_more'] ) ) ? strip_tags( $new_instance['read_more'] ) : '';
return $instance;
}
}

//Latest News Widget Ends Here

// Realated Post Widget Starts Here

class gl_related_post_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_related_post_widget', 

__('Pngs - Realated Post', 'gl_related_post_widget_domain'), 

array( 'description' => __( 'Displays Realated Post', 'gl_related_post_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );


echo $args['before_widget'];
if ( ! empty( $title ) )
/*echo $args['before_title'] . $title . $args['after_title'];*/

?>
<div class="thesis_related single_page_cnt">
<?php
global $post;

	if ( is_single() ) {
		$tags = get_the_tags($post->ID);
			if ($tags) {
			$tag_ids = array();
			foreach($tags as $individual_tag) $tag_ids[] = $individual_tag->term_id;
			$args=array(
			'tag__in' => $tag_ids,
			'post__not_in' => array($post->ID),
			'showposts'=>$instance['post_count'],  // Number of related posts that will be shown.
			'caller_get_posts'=>1
			);
	$my_query = new wp_query($args);
			if( $my_query->have_posts() ) {
	echo	'<div id="relatedposts">'.
				'<div class="single_title">'.
					'<h3>'. $title .'</h3>'.
				
				'</div>'.
			'<div class="related_section">';
		while ($my_query->have_posts()) {
			$my_query->the_post();
			$i++;
			$class = ( $i % 3) ? 'related_post_section' : 'related_post_section last';
	 ?>
			<div class="<?php echo $class; ?>">
							<div class="related_img">
								<?php
								if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true);
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video
						$f_img_width5 = $instance['width_size'];
						$f_img_height5 = $instance['height_size'];	
						// Auto feature image defaults
						$thumb = get_post_thumbnail_id(); 
						$img_url = wp_get_attachment_url( $thumb,'full' );
						
						$image = aq_resize( $img_url, $f_img_width5, $f_img_height5, true );
						// Catch the Image defaults
						$catch_img_url = catch_that_image( $thumb,'full' );
						$catch_image = aq_resize( $catch_img_url, $f_img_width5, $f_img_height5, true );
						if(has_post_thumbnail())
						echo
						"<div class=\"featured_image\">\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width5 . "\" height=\"" . $f_img_height5 . "\" alt=\"" . get_the_title() . "\"></a><div class='img_hover'><a class=\"link\" href=\"" . get_permalink() . "\"></a></div>\n".
						"</div>\n";
						elseif (catch_that_image()){ 
						echo
						"<div class=\"featured_image\">\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width5 . "\" height=\"" . $f_img_height5 . "\" alt=\"" . get_the_title() . "\"></a><div class='img_hover'><a class=\"link\" href=\"" . get_permalink() . "\"></a></div>\n".
						"</div>\n";  
						}
}
}						
					?>
							</div>

							<div class="related_post_cnt">
									<?php echo "<h3><a href='". get_permalink() ."'>".get_the_title()."";
									echo "</a></h3>";?>
									<span class='date'><?php the_time('M jS, Y') ?></span>
									<p>
							<?php
							$excerpt=get_the_excerpt();
							echo string_limit_words($excerpt,13);
							?>
							</p>
							</div>
					</div>
	<?php
			}
			echo '</div>';
			echo '</div>';
			}
		}
	$post = $backup;
			wp_reset_query();
			?>
			<div class="clear"></div>
			<?php
			 }
		
?>
</div>

<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Realated Post', 'gl_related_post_widget_domain' );
}

 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '3', 'gl_related_post_widget_domain' );
}

 if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '231', 'gl_related_post_widget_domain' );
}

 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '148', 'gl_related_post_widget_domain' );
}


?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>


<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>



<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';


return $instance;
}
}

//Realated Post Widget Ends Here

// Register and load the widget
function gl_load_widget() {
	register_widget( 'gl_popular_widget' );
	register_widget( 'gl_randomr_widget' );
	register_widget( 'gl_sidbar_catgory_widget' );
	register_widget( 'gl_aboutus_widget' );
	register_widget( 'gl_breaking_news_widget' );
	register_widget( 'gl_editor_picks_widget' );
	register_widget( 'gl_content_first_catgory_widget' );
	register_widget( 'gl_content_second_catgory_widget' );
	register_widget( 'gl_content_third_catgory_widget' );
	register_widget( 'gl_content_fourth_catgory_widget' );
	register_widget( 'gl_double_column_category_widget' );
	register_widget( 'gl_content_fifth_catgory_widget' );
	register_widget( 'gl_latest_news_widget' );
	register_widget( 'gl_related_post_widget' );
}
add_action( 'widgets_init', 'gl_load_widget' );