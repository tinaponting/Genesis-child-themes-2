<?php
//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );

//* Child theme (do not remove)
define( 'CHILD_THEME_NAME', 'Stylin Theme' );
define( 'CHILD_THEME_VERSION', '2.0' );


//* Enqueue Fonts and Scripts
add_action( 'wp_enqueue_scripts', 'genesis_fonts_and_scripts' );
function genesis_fonts_and_scripts() {
	wp_enqueue_script( 'jquery', get_bloginfo( 'stylesheet_directory' ) . '/lib/js/jquery-2.1.4.js', array( 'jquery' ) );
	wp_enqueue_style( 'font-awesome', '//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css' );
	wp_enqueue_script( 'global', get_bloginfo( 'stylesheet_directory' ) . '/lib/js/global.js', array( 'jquery' ), '1.0.0', true );
	wp_enqueue_script( 'prefix-responsive-menu', get_stylesheet_directory_uri() . '/lib/js/responsive-menu.js', array( 'jquery' ), '1.0.0', true ); // Change 'prefix' to your theme's prefix
	wp_enqueue_script( 'owl-init', get_bloginfo( 'stylesheet_directory' ) . '/lib/js/owl-init.js', array( 'jquery' ), '', true );
	wp_enqueue_style( 'owl-style', get_stylesheet_directory_uri() . '/lib/owlcarousel/owl.carousel.css' );
	wp_enqueue_script( 'owl-script', get_bloginfo( 'stylesheet_directory' ) . '/lib/owlcarousel/owl.carousel.min.js', array( 'jquery' ), '', true );
}


//* Install Necessary Plugins
/**
 * This file represents an example of the code that themes would use to register
 * the required plugins.
 * @package    TGM-Plugin-Activation
 * @subpackage Example
 */
/**
 * Include the TGM_Plugin_Activation class.
 */
require_once dirname( __FILE__ ) . '/lib/tgmpa/class-tgm-plugin-activation.php';

add_action( 'tgmpa_register', 'my_theme_register_required_plugins' );
/**
 * Register the required plugins for this theme.
 *
 * In this example, we register five plugins:
 * - one included with the TGMPA library
 * - two from an external source, one from an arbitrary source, one from a GitHub repository
 * - two from the .org repo, where one demonstrates the use of the `is_callable` argument
 *
 * The variable passed to tgmpa_register_plugins() should be an array of plugin
 * arrays.
 *
 * This function is hooked into tgmpa_init, which is fired within the
 * TGM_Plugin_Activation class constructor.
 */
function my_theme_register_required_plugins() {
	/*
	 * Array of plugin arrays. Required keys are name and slug.
	 * If the source is NOT from the .org repo, then source is also required.
	 */
	$plugins = array(

		// This is an example of the use of 'is_callable' functionality. A user could - for instance -
		// have WPSEO installed *or* WPSEO Premium. The slug would in that last case be different, i.e.
		// 'wordpress-seo-premium'.
		// By setting 'is_callable' to either a function from that plugin or a class method
		// `array( 'class', 'method' )` similar to how you hook in to actions and filters, TGMPA can still
		// recognize the plugin as being installed.
		array(
			'name'        => 'Genesis Grid',
			'slug'        => 'genesis-grid-loop',
			'required' => true,
			),
		
		array(
			'name'        => 'Genesis Simple Edits',
			'slug'        => 'genesis-simple-edits',
			'required' => true,
			),
		
		array(
			'name'        => 'Instagram Slider Widget',
			'slug'        => 'instagram-slider-widget',
			'required' => true,
		),
		
		array(
			'name'        => 'OTF Regenerate Thumbnails',
			'slug'        => 'otf-regenerate-thumbnails',
			'required' => true,
		),
		
			array(
			'name'        => 'Simple Social Icons',
			'slug'        => 'simple-social-icons',
			'required' => true,
		),
		
					array(
			'name'        => 'Contact Form Clean And Simple',
			'slug'        => 'clean-and-simple-contact-form-by-meg-nicholas',
			'required' => true,
		),
		
		
	);

	/*
	 * Array of configuration settings. Amend each line as needed.
	 *
	 * TGMPA will start providing localized text strings soon. If you already have translations of our standard
	 * strings available, please help us make TGMPA even better by giving us access to these translations or by
	 * sending in a pull-request with .po file(s) with the translations.
	 *
	 * Only uncomment the strings in the config array if you want to customize the strings.
	 */
	$config = array(
		'id'           => 'tgmpa',                 // Unique ID for hashing notices for multiple instances of TGMPA.
		'default_path' => '',                      // Default absolute path to bundled plugins.
		'menu'         => 'tgmpa-install-plugins', // Menu slug.
		'parent_slug'  => 'themes.php',            // Parent menu slug.
		'capability'   => 'edit_theme_options',    // Capability needed to view plugin install page, should be a capability associated with the parent menu used.
		'has_notices'  => true,                    // Show admin notices or not.
		'dismissable'  => true,                    // If false, a user cannot dismiss the nag message.
		'dismiss_msg'  => '',                      // If 'dismissable' is false, this message will be output at top of nag.
		'is_automatic' => false,                   // Automatically activate plugins after installation or not.
		'message'      => '',                      // Message to output right before the plugins table.

	);

	tgmpa( $plugins, $config );
}


//* Add HTML5 markup structure
add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list' ) );


//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );


//* Add support for 3-column footer widgets
add_theme_support( 'genesis-footer-widgets', 3 );


//* Remove the header right widget area
unregister_sidebar( 'header-right' );


//* Reposition the primary navigation menu
remove_action( 'genesis_after_header', 'genesis_do_nav' );
add_action( 'genesis_after_header', 'genesis_do_nav', 9 );


//* Reposition the secondary navigation menu
remove_action( 'genesis_after_header', 'genesis_do_subnav' );
add_action( 'genesis_before_footer', 'genesis_do_subnav', 8 );


/**
 * Remove Genesis child theme style sheet
 * @uses  genesis_meta  <genesis/lib/css/load-styles.php>
*/ 
remove_action( 'genesis_meta', 'genesis_load_stylesheet' );
/**
 * Enqueue Genesis child theme style sheet at higher priority
 */
add_action( 'wp_enqueue_scripts', 'genesis_enqueue_main_stylesheet', 15 );

//* Add support for post formats
add_theme_support( 'post-formats', array(
	'gallery',
	'image',
	'video'
) );


/** Back to top Button */
function ll_backtotop() {
	wp_enqueue_script(
		'custom-script',
		get_stylesheet_directory_uri() . '/lib/js/backtotop.js',
		array( 'jquery' )
	);
}
add_action( 'wp_enqueue_scripts', 'll_backtotop' );


//* Register widget areas
genesis_register_sidebar( array(
	'id'          => 'home-slider',
	'name'        => __( 'Home - Slider', 'your-theme' ),
	'description' => __( 'This section is for homepage slider.', 'your-theme' ),
) );

genesis_register_sidebar( array(
	'id'          => 'insta-container',
	'name'        => __( 'Instagram  - Container', 'your-theme' ),
	'description' => __( 'This section is for Instagram.', 'your-theme' ),
) );

genesis_register_sidebar( array(
	'id'          => 'footer-container',
	'name'        => __( 'Footer - Container', 'your-theme' ),
	'description' => __( 'This section is for Footer.', 'your-theme' ),
) );


//* Hook Widget Areas
add_action( 'genesis_after_header', 'll_home_slider' );
	function ll_home_slider() {
	if ( is_home() )
		genesis_widget_area( 'home-slider', array(
			'before' => '<div class="home-slider widget-area"><div class="wrap">',
			'after' => '</div></div>',
	) );
}

add_action( 'genesis_before_footer', 'll_home_insta', 7 );
	function ll_home_insta() {
	if ( is_singular( 'post' ) | is_page() | is_home() | is_search() | is_archive() )
		genesis_widget_area( 'insta-container', array(
			'before' => '<div class="insta-container widget-area">',
			'after' => '</div>',
	) ); 
}

add_action( 'genesis_before_footer', 'll_custom_footer', 9);
	function ll_custom_footer() {
	if ( is_singular( 'post' ) | is_page () | is_home() | is_search() | is_archive() )
		genesis_widget_area( 'footer-container', array(
			'before' => '<div class="footer-container widget-area"><div class="wrap">',
			'after' => '</div></div>',
	) );
}

//* Add Structural Wraps
add_theme_support( 'genesis-structural-wraps', array( 'header', 'nav', 'subnav', 'inner', 'footer-widgets', 'footer' ) );


//* Customize search form input button text
add_filter( 'genesis_search_button_text', 'sp_search_button_text' );
function sp_search_button_text( $text ) {
	return esc_attr( 'Search' );
}

//* Remove usual Footer
remove_action( 'genesis_footer', 'genesis_footer_markup_open', 5 );
remove_action( 'genesis_footer', 'genesis_do_footer' );
remove_action( 'genesis_footer', 'genesis_footer_markup_close', 15 );


//* Add Back To Top Button
function ll_back_to_top() {
	echo '<a href="#" class="backtotop"></a>';
};
add_action('genesis_before_footer', 'll_back_to_top');


//* Add Recent Posts Carousel Shortcodes
include_once('recent-posts-carousel.php');
include_once('related-posts.php');


//* Modify Read More Link
add_filter( 'excerpt_more', 'child_read_more_link' );
add_filter( 'get_the_content_more_link', 'child_read_more_link' );
add_filter( 'the_content_more_link', 'child_read_more_link' );
/**
 * Custom Read More link.
 */
function child_read_more_link() {
	return '<a class="more-link" href="' . get_permalink() . '" rel="nofollow">Continue reading</a>';
}

//* Add new image sizes
if ( function_exists( 'add_theme_support' ) ) {
  add_theme_support( 'post-thumbnails' );
}
add_image_size( 'Recent_Post', 80, 80, true );

//* Execute shortcodes in widgets
add_filter('widget_text', 'do_shortcode');

// Add div.wrap inside of div#inner
function ll_wrap_before_content_sidebar_wrap() {
	echo '<div class="wrap">';
}
add_action('genesis_before_sidebar_widget_area', 'll_wrap_before_content_sidebar_wrap');

function ll_wrap_after_content_sidebar_wrap() {
	echo '</div><!-- end .wrap -->';
}
add_action('genesis_after_sidebar_widget_area', 'll_wrap_after_content_sidebar_wrap');

function ll_wrap_before_loop() {
	echo '<div class="wrap">';
}
add_action('genesis_before_loop', 'll_wrap_before_loop');

function ll_wrap_after_loop() {
	echo '</div><!-- end .wrap -->';
}
add_action('genesis_after_loop', 'll_wrap_after_loop');

//* Post cats over title
function ll_post_cats () {
	if ( is_home() || is_archive() || is_single() ) { ?>
		<div class="entry-meta custom-post-cats"><?php echo do_shortcode("[post_categories before=\"\" sep=\"\"]"); ?></div>
	<?php }

}
add_filter( 'genesis_entry_header', 'll_post_cats', 8 );

add_action( 'genesis_loop', 'sk_full_content_first_post_category_pages', 6 );
function sk_full_content_first_post_category_pages() {
	if( is_home() ) {
		add_filter( 'genesis_pre_get_option_content_archive', 'sk_do_full_content' );
		add_filter( 'genesis_pre_get_option_content_archive_limit', 'sk_no_content_limit' );
	}
}

// Set the content archives to full
function sk_do_full_content() {
	remove_action( 'genesis_entry_content', 'genesis_do_post_image' );
	add_action( 'genesis_entry_header', 'genesis_do_post_image', 7 );
}

// Make sure the content limit isn't set
function sk_no_content_limit() {return;
}