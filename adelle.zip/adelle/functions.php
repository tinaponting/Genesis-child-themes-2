<?php
//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );

//* Child theme (do not remove)
define( 'CHILD_THEME_NAME', 'Adelle Theme' );
define( 'CHILD_THEME_VERSION', '1.0.0' );

//* Enqueue Google Fonts
add_action( 'wp_enqueue_scripts', 'genesis_sample_google_fonts' );
function genesis_sample_google_fonts() {

	wp_enqueue_style( 'google-fonts', '//fonts.googleapis.com/css?family=Lato:300,400,700', array(), CHILD_THEME_VERSION );

}

//* Add HTML5 markup structure
add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list' ) );

//* Add Accessibility support
add_theme_support( 'genesis-accessibility', array( 'headings', 'drop-down-menu',  'search-form', 'skip-links', 'rems' ) );

//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Add support for custom background
add_theme_support( 'custom-background' );

//* Add support for 3-column footer widgets
add_theme_support( 'genesis-footer-widgets', 3 );

// Add Home Page Widget
genesis_register_sidebar( array(
	'id'          => 'home-page',
	'name'        => __( 'Home Page', 'adelle-theme' ),
	'description' => __( 'Widgets in this section will show on the Home page of your blog, if you decide to activate it.', 'adelle-theme' ),
) );

// Add Widget Next To Secondary Navigation Menu
genesis_register_sidebar( array(
	'id'          => 'subnav-menu',
	'name'        => __( 'SubNavigation Menu', 'adelle-theme' ),
	'description' => __( 'Widgets in this section will appear in the SubNavigation bar. This widget area is not suitable to display every type of widget, and works best with a search form and social icons.', 'adelle-theme' ),
) );

add_filter( 'genesis_nav_items', 'sws_social_icons', 10, 2 );
add_filter( 'wp_nav_menu_items', 'sws_social_icons', 10, 2 );

function sws_social_icons($menu, $args) {
	$args = (array)$args;
	if ( 'secondary' !== $args['theme_location'] )
		return $menu;
	ob_start();
	genesis_widget_area('subnav-menu');
	$social = ob_get_clean();
	return $menu . $social;
}

// Customize Search Bar Text
add_filter( 'genesis_search_text', 'sp_search_text' );
function sp_search_text( $text ) {
	return esc_attr( 'Search & Enter' );
}

//* Reposition the secondary navigation menu
remove_action( 'genesis_after_header', 'genesis_do_subnav' );
add_action( 'genesis_before_header', 'genesis_do_subnav' );


//* Customize the entry meta in the entry header (requires HTML5 theme support)
add_filter( 'genesis_post_info', 'sp_post_info_filter' );
function sp_post_info_filter($post_info) {
	$post_info = '[post_date] [post_author_posts_link] [post_categories] [post_edit]';
	return $post_info;
}

//* Modify the length of post excerpts
add_filter( 'excerpt_length', 'sp_excerpt_length' );
function sp_excerpt_length( $length ) {
	return 100; // pull first 50 words
}

// Add Read More Link to Excerpts
add_filter('excerpt_more', 'get_read_more_link');
add_filter( 'the_content_more_link', 'get_read_more_link' );
function get_read_more_link() {
   return '...&nbsp;<a href="' . get_permalink() . '"><button>Read More</button></a>';
}

// Change Gravatar Image Size in Comment Section
function afn_comment_list_args( $args ) {
    return array( 'type' => 'comment', 'avatar_size' => 80, 'callback' => 'genesis_comment_callback' );
}
add_filter( 'genesis_comment_list_args', 'afn_comment_list_args' );

//* Add new featured image sizes
add_image_size( 'home', 1200, FALSE );

//* Change the footer text
add_filter('genesis_footer_creds_text', 'sp_footer_creds_filter');
function sp_footer_creds_filter( $creds ) {
	$creds = "Copyright [footer_copyright] &middot; <a href='http://ezempel.se/'>MY OWN Site!</a> ";
	return $creds;
}

// Remove query string from static files
function _remove_script_version( $src ){
$parts = explode( '?', $src );
return $parts[0];
}
add_filter( 'script_loader_src', '_remove_script_version', 15, 1 );
add_filter( 'style_loader_src', '_remove_script_version', 15, 1 );