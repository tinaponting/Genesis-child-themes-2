<?php

//* Add color options to the customizer
function sugar_customize_register( $wp_customize ) {
	
// Remove default 'Colors' section
$wp_customize->remove_section( 'colors' );

// Add the section to contain the settings
$wp_customize->add_section( 'textcolors' , array(
    'title' =>  'Color Scheme',
    'priority' => 20,
) );

$txtcolors[] = array(
    'slug'=>'logo_color', 
    'default' => '#f7cfda',
    'label' => 'Logo & Site Description'
);

$txtcolors[] = array(
    'slug'=>'nav_link_color', 
    'default' => '#999595',
    'label' => 'Navigation Link'
);

$txtcolors[] = array(
    'slug'=>'nav_link_hover_color', 
    'default' => '#f7cfda',
    'label' => 'Navigation Link: Hover'
);

$txtcolors[] = array(
    'slug'=>'body_text_color', 
    'default' => '#660033',
    'label' => 'Body Text'
);

$txtcolors[] = array(
    'slug'=>'link_text_color', 
    'default' => '#999595',
    'label' => 'Link'
);

$txtcolors[] = array(
    'slug'=>'link_text_hover_color', 
    'default' => '#f7cfda',
    'label' => 'Link: Hover'
);

$txtcolors[] = array(
    'slug'=>'post_header_color', 
    'default' => '#999595',
    'label' => 'Post Title'
);

$txtcolors[] = array(
    'slug'=>'sidebar_header_color', 
    'default' => '#000000',
    'label' => 'Widget Title'
);

// Add the settings and controls for each color
foreach( $txtcolors as $txtcolor ) {
 
    // SETTINGS
    $wp_customize->add_setting(
        $txtcolor['slug'], array(
            'default' => $txtcolor['default'],
            'type' => 'option', 
            'capability' => 
            'edit_theme_options'
        )
    );
    // CONTROLS
    $wp_customize->add_control(
        new WP_Customize_Color_Control(
            $wp_customize,
            $txtcolor['slug'], 
            array('label' => $txtcolor['label'], 
            'section' => 'textcolors',
            'settings' => $txtcolor['slug'])
        )
    );
}
}

add_action( 'customize_register', 'sugar_customize_register' );

function sugar_customize_colors() {
	$logo_color = get_option( 'logo_color' );
	$nav_link_color = get_option( 'nav_link_color' );
	$nav_link_hover_color = get_option( 'nav_link_hover_color' );
	$body_text_color = get_option( 'body_text_color' );
	$link_text_color = get_option( 'link_text_color' );
	$link_text_hover_color = get_option( 'link_text_hover_color' );
	$post_header_color = get_option( 'post_header_color' );
	$sidebar_header_color = get_option( 'sidebar_header_color' );
?>
<style>
	.site-title a,
	.site-description { 
	    color: <?php echo $logo_color; ?>; 
	}
	.nav-primary .genesis-nav-menu a,
	.nav-primary .genesis-nav-menu .current-menu-item > a,
	.genesis-nav-menu a,
	.genesis-nav-menu .current-menu-item > a,
	.genesis-nav-menu .sub-menu a { 
	    color: <?php echo $nav_link_color; ?>; 
	}
	.nav-primary .genesis-nav-menu a:hover,
	.nav-primary .genesis-nav-menu .current-menu-item > a:hover,
	.genesis-nav-menu a:hover,
	.genesis-nav-menu .sub-menu a:hover,
	.widget_nav_menu a:hover { 
	    color: <?php echo $nav_link_hover_color; ?>; 
	}
	.nav-secondary .genesis-nav-menu a { 
	    color: <?php echo $secondary_nav_link_color; ?>; 
	}
	.nav-secondary .genesis-nav-menu a:hover { 
	    color: <?php echo $secondary_nav_link_hover_color; ?>; 
	}
	body {
		color: <?php echo $body_text_color; ?>;
	}
	a,
	.entry-content a,
	.sidebar .entry-title a,
	#genesis-footer-widgets a,
	.widget a,
	.entry-footer a { 
	    color: <?php echo $link_text_color; ?>; 
	}
	.entry-content a:hover,
	.sidebar .entry-title a:hover,
	#genesis-footer-widgets a:hover { 
	    color: <?php echo $link_text_hover_color; ?>; 
	}
	#genesis-content .sharedaddy .sd-content ul li a.sd-button { 
	    color: <?php echo $link_text_color; ?> !important; 
	}
	#genesis-content .sharedaddy .sd-content ul li a.sd-button:hover { 
	    color: <?php echo $link_text_hover_color; ?> !important; 
	}
	.entry-title,
	.entry-title a {
		color: <?php echo $post_header_color; ?>; 
	}
	.sidebar .widget-title a,
	.widget-title,
	.footer-widgets .widget-title {
		color: <?php echo $sidebar_header_color; ?>; 
	}
	.sidebar .widget {
		border-color: <?php echo $sidebar_border_color; ?>; 
	}
	#newsletter-widget {
		background-color: <?php echo $newsletter_background_color; ?>;
	}
</style>
     
<?php

}

add_action( 'wp_head', 'sugar_customize_colors' );