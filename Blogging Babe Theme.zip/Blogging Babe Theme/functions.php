<?php

/**
 * Theme customizations
 *
 * @package      Sugar
 * @author       Sugar+Code
 * @link         http://sugarandcode.com
 * @copyright    Copyright (c) 2016, Sugar+Code
 * @license      GPL-2.0+
 */

//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );

//* Setup Theme
include_once( get_stylesheet_directory() . '/lib/theme-defaults.php' );

//* Set Localization (do not remove)
load_child_theme_textdomain( 'genesis-sample', apply_filters( 'child_theme_textdomain', get_stylesheet_directory() . '/languages', 'genesis-sample' ) );

//* Initialize the update checker
require ('lib/plugins/automatic-theme-updates/theme-updates/theme-update-checker.php');
$coastal_update_checker = new ThemeUpdateChecker(
    'sugar',
    'http://updates.sugarandcode.com/blogging-babe-theme-update.zip'
);

//* Configure one click install
require get_stylesheet_directory() .'/lib/plugins/radium-one-click-demo-install/init.php';

//* Configure third party plugins
require_once('lib/plugins/tgm-plugin-activation/tgm-plugin-activation-config.php');

//* Add Image upload and Color select to WordPress Theme Customizer
require_once( get_stylesheet_directory() . '/lib/customize.php' );

//* Include the custom customizer
require_once('includes/theme-customizer.php');

//* Include Customizer CSS
include_once( get_stylesheet_directory() . '/lib/output.php' );

//* Child theme (do not remove)
define( 'CHILD_THEME_NAME', __( 'Blogging Babe', 'sugar' ) );
define( 'CHILD_THEME_URL', 'http://blogging-babe.sugarandcode.com' );
define( 'CHILD_THEME_VERSION', '1.2' );

//* Add HTML5 markup structure
add_theme_support( 'html5', array( 'caption', 'comment-form', 'comment-list', 'gallery', 'search-form' ) );

//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Add theme support for accessibility
add_theme_support( 'genesis-accessibility', array(
	'404-page',
	'drop-down-menu',
	'headings',
	'rems',
	'search-form',
	'skip-links',
) );

//* Enqueue Scripts and Styles
add_action( 'wp_enqueue_scripts', 'genesis_sample_enqueue_scripts_styles' );
function genesis_sample_enqueue_scripts_styles() {

	wp_enqueue_style( 'genesis-font-open-sans', '//fonts.googleapis.com/css?family=Open+Sans|Lora', array(), CHILD_THEME_VERSION );

	wp_enqueue_style( 'dashicons' );

	wp_enqueue_script( 'genesis-sample-responsive-menu', get_stylesheet_directory_uri() . '/js/responsive-menu.js', array( 'jquery' ), '1.0.0', true );
	$output = array(
		'mainMenu' => __( 'Menu', 'genesis-sample' ),
		'subMenu'  => __( 'Menu', 'genesis-sample' ),
	);
	wp_localize_script( 'genesis-sample-responsive-menu', 'genesisSampleL10n', $output );

}

//* Load Font Awesome
add_action( 'wp_enqueue_scripts', 'enqueue_font_awesome' );
function enqueue_font_awesome() {
	wp_enqueue_style( 'font-awesome', '//maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css' );
}

//* Add support for custom header
add_theme_support( 'custom-header', array(
	'width'           => 500,
	'height'          => 200,
	'header-selector' => '.site-title a',
	'header-text'     => false,
	'flex-height'     => true,
) );

//* Unregister secondary navigation menu
add_theme_support( 'genesis-menus', array( 'primary' => __( 'Primary Navigation Menu', 'genesis' ) ) );

//* Reposition the primary navigation
remove_action( 'genesis_after_header', 'genesis_do_nav' );
add_action( 'genesis_before_header', 'genesis_do_nav' );

// Move image above post title
remove_action( 'genesis_entry_content', 'genesis_do_post_image', 8 );
add_action( 'genesis_entry_header', 'genesis_do_post_image', 8 );

//* Customize the Post Info Function
add_filter( 'genesis_post_info', 'sugar_post_info_filter' );
function sugar_post_info_filter( $post_info ) {

	$post_info = '[post_date format="F j, Y"]';
    return $post_info;

}

//* Customize the Post Meta function
add_filter( 'genesis_post_meta', 'sugar_post_meta_filter' );
function sugar_post_meta_filter( $post_meta ) {

    $post_meta = '';
    return $post_meta;

}

//* Customize the entry meta in the entry header (requires HTML5 theme support)
add_filter( 'genesis_post_info', 'sp_post_info_filter' );
function sp_post_info_filter($post_info) {
	$post_info = '[post_date]';
	return $post_info;
}

//* Change footer text
add_filter('genesis_footer_creds_text', 'custom_footer_creds_text');
function custom_footer_creds_text($creds) {
	$creds = 'Copyright [footer_copyright] &middot; ' . get_bloginfo(' name') . ' &middot; Design by <a href="http://sugarandcode.com" target="_blank">Sugar+Code</a>';
 	return  $creds;
}

//* Modify the Genesis content limit read more link
add_filter( 'get_the_content_more_link', 'sp_read_more_link' );
function sp_read_more_link() {
	return '... <p class="more-paragraph"><a class="more-link" href="' . get_permalink() . '">View Post</a></p>';
}

//* Add Read More Link to Excerpts
add_filter('excerpt_more', 'get_read_more_link');
add_filter( 'the_content_more_link', 'get_read_more_link' );
function get_read_more_link() {
   return '... <p class="more-paragraph"><a class="more-link" href="' . get_permalink() . '">View Post</a></p>';
}

//* Move Genesis Comments
add_action( 'genesis_before_comments' , 'eo_move_comments' );
function eo_move_comments ()
{
  if ( is_single() && have_comments() )
  {
    remove_action( 'genesis_comment_form', 'genesis_do_comment_form' );
    add_action( 'genesis_comments', 'genesis_do_comment_form', 5 );
  }
}

//* Modify size of the Gravatar in the author box
add_filter( 'genesis_author_box_gravatar_size', 'genesis_sample_author_box_gravatar' );
function genesis_sample_author_box_gravatar( $size ) {
	return 90;
}

//* Modify size of the Gravatar in the entry comments
add_filter( 'genesis_comment_list_args', 'genesis_sample_comments_gravatar' );
function genesis_sample_comments_gravatar( $args ) {
	$args['avatar_size'] = 60;
	return $args;
}

//* Add full-width Instagram section
genesis_register_sidebar( array(
	'id'				=> 'instagram-widget',
	'name'			=> __( 'Instagram', 'sugar' ),
	'description'	=> __( 'This is the full-width Instagram area.', 'sugar' ),
) );

add_action( 'genesis_before_footer', 'sugar_instagram_widget' );

function sugar_instagram_widget() {
	genesis_widget_area( 'instagram-widget', array(
		'before' => '<div id="instagram-widget">',
		'after' => '</div>',
	) );
}

//* Set default layout as full width
genesis_set_default_layout( 'content-sidebar' );

//* Unregister layouts
genesis_unregister_layout( 'content-sidebar-sidebar' );
genesis_unregister_layout( 'sidebar-content-sidebar' );
genesis_unregister_layout( 'sidebar-sidebar-content' );

//* Unregister header right
unregister_sidebar( 'header-right' );

//* Unregister secondary sidebar
unregister_sidebar( 'sidebar-alt' );

//* Add support for post formats
add_theme_support( 'post-formats', array(
    'aside',
    'audio',
    'chat',
    'gallery',
    'image',
    'link',
    'quote',
    'status',
    'video'
) );

//* Add new image sizes
add_image_size( 'blog-square-featured', 400, 400, TRUE );
add_image_size( 'blog-vertical-featured', 400, 600, TRUE );
add_image_size( 'sidebar-featured', 125, 125, TRUE );
add_image_size( 'large-featured', 700, 500, TRUE );
add_image_size( 'recent-posts', 375, 450, true );