<?php
/**
 * Blossom.
 * @package      Blossom
 */
//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );

//* Loads Responsive Menu, Google Fonts, and Dashicons
add_action( 'wp_enqueue_scripts', 'genesis_sample_google_fonts' );
function genesis_sample_google_fonts() {

	wp_enqueue_script( 'blossom-responsive-menu', get_bloginfo( 'stylesheet_directory' ) . '/js/responsive-menu.js', array( 'jquery' ), '1.0.0' );
	wp_enqueue_style( 'google-fonts', '//fonts.googleapis.com/css?family=Halant:400,300,500,600,700', array() );
	wp_enqueue_style( 'dashicons' );
	
	// If WooCommerce is installed, add Blossom Custom CSS for WooCommerce
	if ( class_exists( 'woocommerce' ) ) {
		wp_enqueue_style( 'custom-stylesheet', CHILD_URL . '/woo/woocommerce.css', array() );
	}
}

//* Add HTML5 markup structure
add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list' ) );

//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Add support for custom background
add_theme_support( 'custom-background' );

//* Add support for custom header
add_theme_support( 'custom-header', array(
	'width'           => 360,
	'height'          => 150,
	'header-selector' => '.site-title a',
	'header-text'     => false,
) );

//* Add new image sizes
add_image_size( 'home-left-double', 350, 240, TRUE );
add_image_size( 'home-left-single', 350, 500, TRUE );
add_image_size( 'home-mid', 350, 200, TRUE );
add_image_size( 'category-index', 350, 350, TRUE );

//* Add support for 2-column footer widgets
add_theme_support( 'genesis-footer-widgets', 2 );

//* Add support for after entry widget
add_theme_support( 'genesis-after-entry-widget-area' );

//* Add support for additional color style options
add_theme_support( 'genesis-style-selector', array(
	'blossom-gold'         => __( 'Gold', 'blossom' ),
	'blossom-teal'         => __( 'Teal', 'blossom' ),
	'blossom-custom'       => __( 'Custom', 'blossom' ),
) );

//* Add support for demo color links
add_filter( 'body_class', 'blossom_body_class' );
function blossom_body_class( $classes ) {

	// Check to see if URL contains a querystring name 'color'
	if ( isset( $_GET['color'] ) ) :
		// add 'blossom-your-color-name' to the $classes array
		$classes[] = 'blossom-' . sanitize_html_class( $_GET['color'] );
	endif;
	return $classes;
}

//* Set Genesis Responsonsive Slider Defaults
add_filter( 'genesis_responsive_slider_settings_defaults', 'blossom_responsive_slider_defaults' );
function blossom_responsive_slider_defaults( $defaults ) {

	$args = array(
		'posts_num'         => '3',
		'slideshow_height'  => '500',
		'slideshow_width'   => '720',
	);

	$args = wp_parse_args( $args, $defaults );
	return $args;
}

//* Reposition the secondary navigation menu
remove_action( 'genesis_after_header', 'genesis_do_subnav' );
add_action( 'genesis_before_header', 'genesis_do_subnav', 7 );


//* Customize search form input box text
add_filter( 'genesis_search_text', 'custom_search_text' ); 
function custom_search_text($text) {
    return esc_attr('Looking for something?');
}

//* Adds adjacent post links on single posts
add_action( 'genesis_entry_footer', 'blossom_single_post_nav', 9 );
function blossom_single_post_nav() {

	if ( is_singular('post' ) ) {

		$prev_post = get_adjacent_post( false, '', true );
		$next_post = get_adjacent_post( false, '', false );

		echo '<div class="prev-next-post-links">';
			previous_post_link( '<div class="previous-post-link" title="Previous Post: ' . $prev_post->post_title . '">%link</div>', '&laquo;' );
			next_post_link( '<div class="next-post-link" title="Next Post: ' . $next_post->post_title . '">%link</div>', '&raquo;' );
		echo '</div>';

	}

}

//* Remove default WooCommerce Styles
add_filter( 'woocommerce_enqueue_styles', 'blossom_dequeue_styles' );
function blossom_dequeue_styles( $enqueue_styles ) {

	unset( $enqueue_styles['woocommerce-general'] );
	return $enqueue_styles;

}

//* Remove site layouts
genesis_unregister_layout( 'content-sidebar-sidebar' );
genesis_unregister_layout( 'sidebar-sidebar-content' );
genesis_unregister_layout( 'sidebar-content-sidebar' );

//* Remove comment form allowed tags
add_filter( 'comment_form_defaults', 'bg_remove_comment_form_allowed_tags' );
function bg_remove_comment_form_allowed_tags( $defaults ) {
$defaults['comment_notes_after'] = '';
return $defaults;
 
}

//* Add Theme Support for WooCommerce
add_theme_support( 'genesis-connect-woocommerce' );

//* Remove Related Products
remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20 );

//* Remove Add to Cart on Archives
add_action( 'woocommerce_after_shop_loop_item', 'remove_add_to_cart_buttons', 1 );
function remove_add_to_cart_buttons() {
    remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart' );
}

//* Display 12 products per page
add_filter( 'loop_shop_per_page', create_function( '$cols', 'return 12;' ), 20 );

// Change number or products per row to 3
add_filter('loop_shop_columns', 'loop_columns');
if (!function_exists('loop_columns')) {
function loop_columns() {
return 3; // 3 products per row
}
}

//* Customize the credits
add_filter( 'genesis_footer_creds_text', 'blossom_footer_creds_text' );
function blossom_footer_creds_text() {
    echo '<div class="creds"><p>';
    echo 'Copyright &copy; ';
    echo date('Y');
    echo ' &middot; <a target="_blank" href="http://exempel.se">MY OWN BLOG!</a>';
    echo '</p></div>';

}

//* Register widget areas
genesis_register_sidebar( array(
	'id'           => 'home-top-left',
	'name'         => __( 'Home Top Left', 'blossom' ),
	'description'  => __( 'This is the home top left widget area on the home page', 'blossom' ),
) );
genesis_register_sidebar( array(
	'id'           => 'home-top-right',
	'name'         => __( 'Home Top Right', 'blossom' ),
	'description'  => __( 'This is the home top right widget area on the home page', 'blossom' ),
) );
genesis_register_sidebar( array(
	'id'           => 'home-mid-left',
	'name'         => __( 'Home Mid Left', 'blossom' ),
	'description'  => __( 'This is the home mid left widget area on the home page', 'blossom' ),
) );
genesis_register_sidebar( array(
	'id'           => 'home-mid-right',
	'name'         => __( 'Home Mid Right', 'blossom' ),
	'description'  => __( 'This is the home mid right widget area on the home page', 'blossom' ),
) );
genesis_register_sidebar( array(
	'id'           => 'home-bottom',
	'name'         => __( 'Home Bottom', 'blossom' ),
	'description'  => __( 'This is the home bottom widget area on the home page', 'blossom' ),
) );
genesis_register_sidebar( array(
	'id'          => 'category-index',
	'name'        => __( 'Category Index', 'blossom' ),
	'description' => __( 'This is the category index for the category index page template.', 'blossom' ),
) );