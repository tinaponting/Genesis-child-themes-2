<?php
/**
 * This file adds the Home Page to the Blossom Theme.
 * @package Blossom
 * @subpackage Customizations
 */
add_action( 'genesis_meta', 'blossom_home_genesis_meta' );
/**
 * Add widget support for homepage. If no widgets active, display the default loop.
 */
function blossom_home_genesis_meta() {

	if ( is_active_sidebar( 'home-top-left' ) || is_active_sidebar( 'home-top-right' ) || is_active_sidebar( 'home-bottom' ) ) {

		remove_action( 'genesis_loop', 'genesis_do_loop' );

		add_action( 'genesis_loop', 'blossom_home_sections' );
		add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );
		add_filter( 'body_class', 'blossom_add_home_body_class' );
	
	}
}

//* Display content for the home sections
function blossom_home_sections() {

	echo '<div class="home-top">';
	
	echo '<div class="home-right">';

		genesis_widget_area( 'home-top-right', array(
			'before' => '<div class="home-top-right widget-area">',
			'after'  => '</div>',
		) );
		
		genesis_widget_area( 'home-mid-left', array(
			'before' => '<div class="home-mid-left one-half first widget-area">',
			'after'  => '</div>',
		) );
		
		genesis_widget_area( 'home-mid-right', array(
			'before' => '<div class="home-mid-right one-half widget-area">',
			'after'  => '</div>',
		) );
		
	echo '</div><div class="home-left">';
		
		genesis_widget_area( 'home-top-left', array(
			'before' => '<div class="home-top-left widget-area">',
			'after'  => '</div>',
		) );

	echo '</div></div>';
	
	echo '<div class="home-bottom">';

		genesis_widget_area( 'home-bottom', array(
			'before' => '<div class="home-bottom widget-area">',
			'after'  => '</div>',
		) );

	echo '</div>';

}

//* Add body class to home page		
function blossom_add_home_body_class( $classes ) {

	$classes[] = 'blossom-home';
	return $classes;
	
}
genesis();