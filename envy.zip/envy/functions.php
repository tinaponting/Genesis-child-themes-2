<?php
//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );

//* Child theme (do not remove)
define( 'CHILD_THEME_NAME', 'Envy' );
define( 'CHILD_THEME_URL', 'http://envy.krolyn.com' );
define( 'CHILD_THEME_VERSION', '1.2' );

//* Set localization (do not remove)
load_child_theme_textdomain( 'envy', apply_filters( 'child_theme_textdomain', get_stylesheet_directory() . '/lib/languages', 'envy' ) );

//* Enqueue scripts
add_action( 'wp_enqueue_scripts', 'envy_scripts' );
function envy_scripts() {
	wp_enqueue_script( 'main', get_stylesheet_directory_uri() . '/lib/js/main.js', array( 'jquery' ), '1.2' );
	wp_enqueue_style( 'google-fonts', '//fonts.googleapis.com/css?family=Raleway:200,300,400,500,600', array(), CHILD_THEME_VERSION );
	wp_enqueue_style( 'dashicons' );
}

//* Add HTML5 markup structure
add_theme_support( 'html5' );

//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Add theme support for 3-column footer widgets
add_theme_support( 'genesis-footer-widgets', 3 );

//* Add theme support for custom header
add_theme_support( 'custom-header', array(
	'width'           => 260,
	'height'          => 100,
	'header-selector' => '.site-title a',
	'header-text'     => false
) );

//* Add support for custom background
add_theme_support( 'custom-background' );

//* Add theme support for additional color style options
add_theme_support( 'genesis-style-selector', array(
	'envy-green'  => __( 'Green With Envy', 'envy' ),
	'envy-orange'  => __( 'Orange With Envy', 'envy' ),
	'envy-purple'  => __( 'Purple With Envy', 'envy' ),
	'envy-pink'  => __( 'Pink With Envy', 'envy' ),
	'envy-blue'  =>  __( 'Blue With Envy', 'envy' ),
) );

//* Enable shortcodes in widgets
add_filter('widget_text', 'do_shortcode');

//* Remove the site description
remove_action( 'genesis_site_description', 'genesis_seo_site_description' );

//* Unregister site layouts
genesis_unregister_layout( 'content-sidebar-sidebar' );
genesis_unregister_layout( 'sidebar-sidebar-content' );
genesis_unregister_layout( 'sidebar-content-sidebar' );

//* Relocate Secondary Sidebar to before loop and append (Top)
unregister_sidebar( 'sidebar-alt' );
genesis_register_sidebar( array( 'id' => 'sidebar-alt', 'name' => __( 'Secondary Sidebar (Top)', 'envy' ) ) );
remove_action( 'genesis_after_content', 'genesis_get_sidebar_alt' );
add_action( 'genesis_before_loop', 'genesis_get_sidebar_alt' );

//* Register new layouts with Secondary Sidebar (Top)
genesis_register_layout( 'topbar-content-sidebar', array(
	'label' => __('Topbar/Content/Sidebar', 'envy'),
	'img' => get_bloginfo('stylesheet_directory') . '/lib/icons/tcs.gif'
) );
genesis_register_layout( 'sidebar-topbar-content', array(
	'label' => __('Sidebar/Topbar/Content', 'envy'),
	'img' => get_bloginfo('stylesheet_directory') . '/lib/icons/stc.gif'
) );

//* Register widget areas
genesis_register_sidebar( array(
	'id'			=> 'home-slider',
	'name'			=> __( 'Home Slider', 'envy' ),
	'description'	=> __( 'This is the Slider (full-width) section of the homepage.', 'envy' ),
) );
genesis_register_sidebar( array(
	'id'			=> 'home-featured-products',
	'name'			=> __( 'Home Featured Products', 'envy' ),
	'description'	=> __( 'This is the Featured Products (full-width) section of the homepage.', 'envy' ),
) );
genesis_register_sidebar( array(
	'id'			=> 'call-to-action',
	'name'			=> __( 'Home Call-to-Action', 'envy' ),
	'description'	=> __( 'This is Call-to-Action (full-width) section of the homepage.', 'envy' ),
) );
genesis_register_sidebar( array(
	'id'			=> 'home-featured-content',
	'name'			=> __( 'Home Featured Content', 'envy' ),
	'description'	=> __( 'This is the Featured Content (two-thirds-width) section of the homepage.', 'envy' ),
) );
genesis_register_sidebar( array(
	'id'			=> 'sponsor-logos',
	'name'			=> __( 'Sponsor Logos', 'envy' ),
	'description'	=> __( 'This is the Sponsor Logos (full-width) section of the homepage.', 'envy' ),
) );

//* Add Sponsor Logos widget area above footer
add_action( 'genesis_before_footer', 'sponsor_logos_widget' );
	function sponsor_logos_widget() {
		genesis_widget_area( 'sponsor-logos', array(
			'before' => '<div class="sponsor-logos widget-area">',
			'after' => '</div>',
	) );
}
remove_action( 'genesis_before_footer', 'genesis_footer_widget_areas' );
add_action( 'genesis_before_footer', 'genesis_footer_widget_areas' );

//* Add new image sizes
add_image_size( 'slider', 1200, 450, TRUE );
add_image_size( 'featured', 720, 210, TRUE );

//* Position Secondary Menu before header
remove_action( 'genesis_after_header', 'genesis_do_subnav' );
add_action( 'genesis_before_header', 'genesis_do_subnav' );

//* Set Genesis Responsive Slider defaults
add_filter( 'genesis_responsive_slider_settings_defaults', 'latitude_responsive_slider_defaults' );
function latitude_responsive_slider_defaults( $defaults ) {
 
	$args = array( 
		'posts_num'                       => '3',
		'slideshow_pager'		  	      => '',
		'slideshow_height'                => '450',
		'slideshow_width'                 => '1200',
		'slideshow_excerpt_content'       => 'full',
		'slideshow_excerpt_content_limit' => '',
		'slideshow_more_text'             => __( 'More Details', 'envy' ),
		'slideshow_excerpt_width'         => '45',
		'slideshow_title_show'            => 1,
		'location_horizontal'             => 'right',
		'location_vertical'               => 'top'
	);
 
	$args = wp_parse_args( $args, $defaults );
	
	return $args;
}
 
//* Customize search form placeholder and button text
add_filter( 'genesis_search_text', 'envy_search_text' );
function envy_search_text( $text ) {
	return esc_attr( __('Website search', 'envy') );
}
add_filter( 'genesis_search_button_text', 'envy_search_button' );
function envy_search_button( $text ) {
	return esc_attr( '&#xf179;', 'envy' );
}

//* Relocate Page Titles to before the loop
add_action( 'get_header', 'relocate_page_titles' );
function relocate_page_titles() {
	if ( !is_page_template(page_blog-php) && is_singular('page') ) {
		remove_action( 'genesis_entry_header', 'genesis_do_post_title' );
		add_action ( 'genesis_before_loop', 'genesis_do_post_title' );
	}
}

//* Change archive pagination previous and next texts
add_filter( 'genesis_prev_link_text', 'envy_prev_link_text' );
function envy_prev_link_text() {
	$prevlink = '&#8592;';
	return $prevlink;
}
add_filter( 'genesis_next_link_text', 'envy_next_link_text' );
function envy_next_link_text() {
	$nextlink = '&#8594;';
	return $nextlink;
}


/**
 * WooCommerce functions
 */
 
//* Add theme support for WooCommerce
add_theme_support( 'genesis-connect-woocommerce' );
 
//* Add custom style sheet for WooCommerce
function envy_woocommerce_styles() {
wp_enqueue_style( 'woocommerce-styling', get_stylesheet_directory_uri() . '/woocommerce/woocommerce.css' );
}
add_action('wp_enqueue_scripts', 'envy_woocommerce_styles');

//* Redefine WooCommerce default image sizes
global $pagenow;
if ( is_admin() && isset( $_GET['activated'] ) && $pagenow == 'themes.php' ) add_action( 'init', 'envy_woocommerce_image_dimensions', 1 );
 
function envy_woocommerce_image_dimensions() {
  	$catalog = array(
		'width' 	=> '320',
		'height'	=> '320',
		'crop'		=> 1
	);
 
	$single = array(
		'width' 	=> '440',
		'height'	=> '440',
		'crop'		=> 1
	);
 
	$thumbnail = array(
		'width' 	=> '90',
		'height'	=> '90',
		'crop'		=> 0
	);
 
	update_option( 'shop_catalog_image_size', $catalog );
	update_option( 'shop_single_image_size', $single );
	update_option( 'shop_thumbnail_image_size', $thumbnail );
}

//* Customize text in WooCommerce sale-flash
add_filter('woocommerce_sale_flash', 'envy_sale_flash', 10, 3);
function envy_sale_flash($text, $post, $_product) {
	return '<span class="onsale">' . __( 'Special', 'envy' ) . '</span>';  
}

//* Customize WooCommerce product search form
add_filter( 'get_product_search_form' , 'envy_product_searchform' );
function envy_product_searchform( $form ) {
	$form = '<form role="search" method="get" id="searchform" action="' . esc_url( home_url( '/'  ) ) . '">
		<div>
			<input type="text" value="' . get_search_query() . '" name="s" id="s" placeholder="' . __( 'Product search', 'envy' ) . '" />
			<input type="submit" id="searchsubmit" value="'. esc_attr__( '&#xf179;', 'envy' ) .'" />
			<input type="hidden" name="post_type" value="product" />
		</div>
	</form>';
	return $form;	
}

//* Set number of products per row
add_filter('loop_shop_columns', 'loop_columns');
if (!function_exists('loop_columns')) {
	function loop_columns() {
		$layout = genesis_site_layout();
		if (is_home() || 'full-width-content' == $layout) {
			return 4;
		} else {
			return 3;
		}
	}
}

//* Display 12 products per page maximum
add_filter( 'loop_shop_per_page', create_function( '$cols', 'return 12;' ), 20 );

//* Replace default placeholder image with custom image
add_action( 'init', 'envy_custom_thumbnail' );
function envy_custom_thumbnail() {
	add_filter('woocommerce_placeholder_img_src', 'envy_custom_placeholder_img_src');   
	function envy_custom_placeholder_img_src( $src ) {
		$src = get_stylesheet_directory_uri() . '/images/placeholder.gif';	 
		return $src;
	}
}

//* Replace WooCommerce pagination with Genesis pagination
remove_action( 'woocommerce_after_shop_loop', 'woocommerce_pagination', 10 );
add_action( 'woocommerce_after_shop_loop', 'genesis_posts_nav', 10 );