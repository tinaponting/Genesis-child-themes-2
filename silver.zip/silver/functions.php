<?php
/**
 * Theme customizations
 * @package      Silver
 */
//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );

//* Setup Theme
include_once( get_stylesheet_directory() . '/lib/theme-defaults.php' );

//* Configure one click install
require get_stylesheet_directory() .'/lib/plugins/radium-one-click-demo-install/init.php';

//* Configure third party plugins
require_once('lib/plugins/tgm-plugin-activation/tgm-plugin-activation-config.php');

//* Initialize the update checker
require 'lib/plugins/automatic-theme-updates/theme-updates/theme-update-checker.php';
$silver_update_checker = new ThemeUpdateChecker(
    'silver',
    'updates.boutiquedesignstudio.xyz/silver-theme-update.json'
);

//* Include the color customizer
include_once( get_stylesheet_directory() . '/lib/customizer.php' );

//* Set Localization (do not remove)
load_child_theme_textdomain( 'silver', apply_filters( 'child_theme_textdomain', get_stylesheet_directory() . '/languages', 'silver' ) );

//* Child theme (do not remove)
define( 'CHILD_THEME_NAME', 'silver' );
define( 'CHILD_THEME_VERSION', '1.8' );

//* Add WooCommerce Support
function woocommerce_setup_genesis() {
  woocommerce_content();
}
add_theme_support( 'woocommerce' );

//* Load Google Fonts
add_action( 'wp_enqueue_scripts', 'silver_load_google_fonts' );
function silver_load_google_fonts() {
	wp_enqueue_style( 'google-font-montserrat', '//fonts.googleapis.com/css?family=Montserrat|Pinyon+Script|Open+Sans', array(), CHILD_THEME_VERSION );
}

//* Unregister secondary navigation menu
add_theme_support( 'genesis-menus', array( 'primary' => __( 'Primary Navigation Menu', 'genesis' ) ) );

//* Add HTML5 markup structure
add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption' ) );

//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Enqueue Scripts
add_action( 'wp_enqueue_scripts', 'silver_load_scripts' );
function silver_load_scripts() {
	
	wp_enqueue_script( 'silver-responsive-menu', get_bloginfo( 'stylesheet_directory' ) . '/js/responsive-menu.js', array( 'jquery' ), '1.0.0' );
	
	wp_enqueue_style( 'dashicons' );
	
	wp_enqueue_style( 'google-fonts', '//fonts.googleapis.com/css?family=Open+Sans|Montserrat|Pinyon+Script', array(), CHILD_THEME_VERSION );
}

///* Add support for post formats
add_theme_support( 'post-formats', array(
    'aside',
    'audio',
    'chat',
    'gallery',
    'image',
    'link',
    'quote',
    'status',
    'video'
) );

//* Add new image sizes
add_image_size( 'home-large', 740, 1100, TRUE );
add_image_size( 'home-medium', 740, 380, TRUE );
add_image_size( 'home-small', 266, 160, TRUE );
add_image_size( 'pin', 735, 1000, TRUE );


//* Making Footer Area Full Width
remove_action( 'genesis_before_footer', 'genesis_footer_widget_areas' );
add_action( 'genesis_after', 'genesis_footer_widget_areas' );

remove_action( 'genesis_footer', 'genesis_footer_markup_open', 5 );
remove_action( 'genesis_footer', 'genesis_do_footer' );
remove_action( 'genesis_footer', 'genesis_footer_markup_close', 15 );
add_action( 'genesis_after', 'genesis_footer_markup_open', 11 );
add_action( 'genesis_after', 'genesis_do_footer', 12 );
add_action( 'genesis_after', 'genesis_footer_markup_close', 13 );

//* Remove Widgets
function remove_some_widgets(){

     // Unregsiter some of the TwentyTen sidebars
     unregister_sidebar( 'header-right' );
     unregister_sidebar( 'home-top' );
     unregister_sidebar( 'home-middle' );
     unregister_sidebar( 'home-bottom-left' );
     unregister_sidebar( 'home-bottom-right' );
     unregister_sidebar( 'sidebar-alt' );
     unregister_sidebar( 'after-entry' );
}
add_action( 'widgets_init', 'remove_some_widgets', 11 );

//* Unregister Layouts
genesis_unregister_layout( 'content-sidebar-sidebar' ); 
genesis_unregister_layout( 'sidebar-sidebar-content' ); 
genesis_unregister_layout( 'sidebar-content-sidebar' );

//* Remove Nav Extras
add_action( 'genesis_theme_settings_metaboxes', 'child_remove_metaboxes' );
	function child_remove_metaboxes( $_genesis_theme_settings ) {
   	remove_meta_box( 'genesis-theme-settings-nav', $_genesis_theme_settings, 'main' );
}

//* Modify the Genesis content limit read more link
add_filter( 'get_the_content_more_link', 'sp_read_more_link' );
function sp_read_more_link() {
	return '... <p class="more-paragraph"><a class="more-link" href="' . get_permalink() . '">View Post</a></p>';
}

//* Add Read More Link to Excerpts
add_filter('excerpt_more', 'get_read_more_link');
add_filter( 'the_content_more_link', 'get_read_more_link' );
function get_read_more_link() {
   return '... <p class="more-paragraph"><a class="more-link" href="' . get_permalink() . '">View Post</a></p>';
}

//* Customize the Copyright and credits
add_filter('genesis_footer_creds_text', 'custom_footer_creds_text');
function custom_footer_creds_text($creds) {
	$creds = 'Copyright [footer_copyright] &middot; ' . get_bloginfo(' name') . ' &middot; Made in vain <a href="http://exempel.se" target="_blank">My own site!</a>';
 	return  $creds;
}

//* Customize the entry meta in the entry header (requires HTML5 theme support)
add_filter( 'genesis_post_info', 'silver_post_info_filter' );
function silver_post_info_filter($post_info) {
	$post_info = '[post_date] [post_categories before=" | "]';
	return $post_info;
}

//* Customize the Post Meta function
add_filter( 'genesis_post_meta', 'silver_post_meta_filter' );
function silver_post_meta_filter( $post_meta ) {

    $post_meta = '';
    return $post_meta;

}

//* Add support for custom header
add_theme_support( 'custom-header', array(
	'width'           => 1200,
	'height'          => 200,
	'header-selector' => '.site-title a',
	'header-text'     => false,
	'flex-height'     => true,
) );

//* Reposition the primary navigation
remove_action( 'genesis_after_header', 'genesis_do_nav' );
add_action( 'genesis_before_header', 'genesis_do_nav' );

//* Modify the size of the Gravatar in the author box
add_filter( 'genesis_author_box_gravatar_size', 'silver_author_box_gravatar' );
function silver_author_box_gravatar( $size ) {

	return 96;
		
}

//* Modify the size of the Gravatar in the entry comments
add_filter( 'genesis_comment_list_args', 'silver_comments_gravatar' );
function silver_comments_gravatar( $args ) {

	$args['avatar_size'] = 60;
	return $args;
	
}

//* Remove comment form allowed tags
add_filter( 'comment_form_defaults', 'silver_remove_comment_form_allowed_tags' );
function silver_remove_comment_form_allowed_tags( $defaults ) {
	
	$defaults['comment_notes_after'] = '';
	return $defaults;

}

//* Add full-width Instagram section
genesis_register_sidebar( array(
	'id'				=> 'instagram-widget',
	'name'			=> __( 'Instagram Footer', 'silver' ),
	'description'	=> __( 'This is the full-width Instagram footer area.', 'silver' ),
) );

add_action( 'genesis_before_footer', 'silver_instagram_widget' );

function silver_instagram_widget() {
	genesis_widget_area( 'instagram-widget', array(
		'before' => '<div id="instagram-widget">',
		'after' => '</div>',
	) );
}

//* Add support for 3-column footer widgets
add_theme_support( 'genesis-footer-widgets', 3 );

//* Register after entry widget area
genesis_register_sidebar( array(
	'id'          => 'after-entry',
	'name'        => __( 'After Post', 'silver' ),
	'description' => __( 'This is the after post section.', 'silver' ),
) );

add_action( 'genesis_entry_footer', 'silver_after_entry'  ); 
function silver_after_entry() {

    if ( ! is_singular( 'post' ) )
    	return;

    genesis_widget_area( 'after-entry', array(
		'before' => '<div class="after-entry widget-area"><div class="wrap">',
		'after'  => '</div></div>',
    ) );

}
