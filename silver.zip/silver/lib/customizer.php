<?php
/**
 * Customizer Additions
 *
 * @package      Name
 * @author       Boutique Web Design Studio
 * @link         http://www.boutiquedesignstudio.xyz
 * @license      GPL-2.0+
 */
 
/**
 * Get default primary color for Customizer.
 *
 * Abstracted here since at least two functions use it.
 *
 * @since 1.0.0
 *
 * @return string Hex color code for primary color.
 */

function silver_customizer_get_default_accent_color() {
	return '#eee';
}

function silver_customizer_get_default_border_color() {
	return '#eee';
}

function silver_customizer_get_default_title_color() {
	return '#eee';
}

function silver_customizer_get_default_heading_color() {
	return '#eee';
}





add_action( 'customize_register', 'silver_customizer_register' );
/**
 * Register settings and controls with the Customizer.
 *
 * @since 1.0.0
 * 
 * @param WP_Customize_Manager $wp_customize Customizer object.
 */
function silver_customizer_register() {

	global $wp_customize;



	
	$wp_customize->add_setting(
		'silver_accent_color',
		array(
			'default' => silver_customizer_get_default_accent_color(),
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'silver_accent_color',
			array(
			    'label'    => __( 'Accent Color', 'silver' ),
			    'section'  => 'colors',
			    'settings' => 'silver_accent_color',
			)
		)
	);





	$wp_customize->add_setting(
		'silver_border_color',
		array(
			'default' => silver_customizer_get_default_border_color(),
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'silver_border_color',
			array(
			    'label'    => __( 'Border Color', 'silver' ),
			    'section'  => 'colors',
			    'settings' => 'silver_border_color',
			)
		)
	);





$wp_customize->add_setting(
		'silver_title_color',
		array(
			'default' => silver_customizer_get_default_title_color(),
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'silver_title_color',
			array(
			    'label'    => __( 'Title Text Color', 'silver' ),
			    'section'  => 'colors',
			    'settings' => 'silver_title_color',
			)
		)
	);




	$wp_customize->add_setting(
		'silver_heading_color',
		array(
			'default' => silver_customizer_get_default_heading_color(),
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'silver_heading_color',
			array(
			    'label'    => __( 'Heading Text Color', 'silver' ),
			    'section'  => 'colors',
			    'settings' => 'silver_heading_color',
			)
		)
	);
}




add_action( 'wp_enqueue_scripts', 'silver_css' );
/**
* Checks the settings for the accent color, highlight color, and header
* If any of these value are set the appropriate CSS is output
*
* @since 1.0.0
*/
function silver_css() {

	$handle  = defined( 'CHILD_THEME_NAME' ) && CHILD_THEME_NAME ? sanitize_title_with_dashes( CHILD_THEME_NAME ) : 'child-theme';

	$color_accent = get_theme_mod( 'silver_accent_color', silver_customizer_get_default_accent_color() );
	$color_border = get_theme_mod( 'silver_border_color', silver_customizer_get_default_border_color() );
	$color_title = get_theme_mod( 'silver_title_color', silver_customizer_get_default_title_color() );
	$color_heading = get_theme_mod( 'silver_heading_color', silver_customizer_get_default_heading_color() );

	$css = '';

		
	$css .= ( silver_customizer_get_default_accent_color() !== 	$color_accent ) ? sprintf( '
		
.a,
.h2, .home-top .entry-title,
.entry-title a:hover,
.site-description,
.silver-home .content,
.more-from-category, .category-page,
.simple-social-icons .social-bloglovin, .simple-social-icons .social-dribbble,
.simple-social-icons .social-email, .simple-social-icons .social-facebook,
.simple-social-icons .social-flickr, .simple-social-icons .social-github,
.simple-social-icons .social-gplus, .simple-social-icons .social-instagram,
.simple-social-icons .social-linkedin, .simple-social-icons .social-pinterest,
.simple-social-icons .social-rss, .simple-social-icons .social-stumbleupon,
.simple-social-icons .social-tumblr, .simple-social-icons .social-twitter,
.simple-social-icons .social-vimeo, .simple-social-icons .social-youtube{
	color: %1$s;
}

		
		', $color_accent ) : '';





    $css .= ( silver_customizer_get_default_border_color() !== $color_border ) ? sprintf( '

			.entry-title { border-color: %1$s !important; }
			.nav-primary { border-color: %1$s !important; }
			.button, input[type="button"], input[type="reset"] { background-color: %1$s !important; }
			.input[type="submit"], .button, .entry-content .button { background-color: %1$s !important; }
			.enews-widget input[type="submit"] { background-color: %1$s !important; }
			.sd-social-icon .sd-button span.share-count,
			.simple-social-icons .social-bloglovin a:hover, .simple-social-icons .social-dribbble a:hover,
            .simple-social-icons .social-email a:hover, .simple-social-icons .social-facebook a:hover,
            .simple-social-icons .social-flickr a:hover, .simple-social-icons .social-github a:hover,
            .simple-social-icons .social-gplus a:hover, .simple-social-icons .social-instagram a:hover,
            .simple-social-icons .social-linkedin a:hover, .simple-social-icons .social-pinterest a:hover,
            .simple-social-icons .social-rss a:hover, .simple-social-icons .social-stumbleupon a:hover,
            .simple-social-icons .social-tumblr a:hover, .simple-social-icons .social-twitter a:hover,
            .simple-social-icons .social-vimeo a:hover, .simple-social-icons .social-youtube a:hover {
	color: %1$s;
}
		
		', $color_border ) : '';



$css .= ( silver_customizer_get_default_title_color() !== 	$color_title ) ? sprintf( '

.site-title a, .site-title a:hover {
		color: %1$s;
}
		
		', $color_title ) : '';




$css .= ( silver_customizer_get_default_heading_color() !== 	$color_heading ) ? sprintf( '

			.more-link, h1, h2, h3, h4, h5, h6, .entry-title a,
			.sidebar .widget-title a, .enews-widget input,
			.content a.sd-button > span, .sd-content ul li a.sd-button:before,
			.genesis-nav-menu, .genesis-nav-menu a, 
			.genesis-nav-menu a:hover,
			.genesis-nav-menu .current-menu-item > a,
			.genesis-nav-menu .sub-menu a, .genesis-nav-menu > li:hover .sub-menu a,
			.responsive-menu-icon::before,
			.archive-pagination li a, .archive-pagination li.active a,
			.sidebar .widget h4, .widget-title,
			.content div.sharedaddy a.sd-button, div.sharedaddy h3.sd-title,
			#sharing_email .sharing_send, .sd-content ul li .option a.share-ustom, 
			.sd-content ul li a.sd-button, .sd-content ul li.advanced a.share-more, 
			.sd-content ul li.preview-item div.option.option-smart-off a, 
			.sd-social-icon .sd-content ul li a.sd-button, 
			.sd-social-icon-text .sd-content ul li a.sd-button, 
			.sd-social-official .sd-content > ul > li .digg_button > a, 
			.sd-social-official .sd-content > ul > li > a.sd-button, 
			.sd-social-text .sd-content ul li a.sd-button {
		color: %1$s;
} 

			', $color_heading ) : '';

		
		if (
silver_customizer_get_default_accent_color() !== $color_accent ||

silver_customizer_get_default_border_color() !== $color_border ||

silver_customizer_get_default_title_color() !== $color_title  ||

silver_customizer_get_default_title_color() !== $color_heading

 )	
 {

		$css .= '
		}
		';
	}

	if( $css ){
		wp_add_inline_style( $handle, $css );
	}

}