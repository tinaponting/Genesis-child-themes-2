var j=jQuery.noConflict();
j(window).scroll(function() {
var scroll = j(window).scrollTop();
if (scroll >= 200) {
j('.btm_header_cont').addClass('scrolltop');
}
else {
j('.btm_header_cont').removeClass('scrolltop');
}
}
);
