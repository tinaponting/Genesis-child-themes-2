/*sticky */
var j=jQuery.noConflict();
j('.center').slick({
  centerMode: true,
  centerPadding: '250px',
  slidesToScroll: 1,
  autoplay: true,
  autoplaySpeed: 2000,
  slidesToShow: 1,
  responsive: [
    {
      breakpoint: 868,
      settings: {
        arrows: false,
        centerMode: true,
        centerPadding: '40px',
        slidesToShow: 1
      }
    },
    {
      breakpoint: 580,
      settings: {
        arrows: false,
        centerMode: true,
        centerPadding: '40px',
        slidesToShow: 1
      }
    }
  ]
});

/* Menu */
var j=jQuery.noConflict();
(function(){
var classes = document.getElementsByClassName('menu_control');
for (i = 0; i < classes.length; i++) {
classes[i].onclick = function() {
var menu = this.nextElementSibling;
if (/show_menu/.test(menu.className))
menu.className = menu.className.replace('show_menu', '').trim();
else
menu.className += ' show_menu';
};
}
})();