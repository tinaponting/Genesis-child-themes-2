<?php
function fragranz_customize_register( $wp_customize ) {
 /*******************************************
Color scheme
********************************************/

// add the section to contain the settings
$wp_customize->add_section( 'textcolors' , array(
    'title' =>  'Color Scheme',
) );

// Background Color
$txtcolors[] = array(
    'slug'=>'bgcolor', 
    'default' => '#FFFFFF',
    'label' => 'Background Color'
);

 
// Body Text Color
$txtcolors[] = array(
    'slug'=>'bodytextcolor', 
    'default' => '#555555',
    'label' => 'Body Text Color'
);

// Header BG Color
$txtcolors[] = array(
    'slug'=>'bottom_header_bg', 
    'default' => '#1b1a19',
    'label' => 'Bottom Header BG Color'
);

// Header Text Color
$txtcolors[] = array(
    'slug'=>'header_text_color', 
    'default' => '#333333',
    'label' => 'Header Text Color'
);

// Byline color
$txtcolors[] = array(
    'slug'=>'byline_color', 
    'default' => '#666666',
    'label' => 'Byline Color'
);

// link color
$txtcolors[] = array(
    'slug'=>'link_color', 
    'default' => '#cbaa5c',
    'label' => 'Link Color'
);

// Sidebar Background

$txtcolors[] = array(
    'slug'=>'sb_cont_bg', 
    'default' => '#f9f9f9',
    'label' => 'Sidebar BG Color'
);

// Sidebar Optin Background

$txtcolors[] = array(
    'slug'=>'sb_optin_bg', 
    'default' => '#383838',
    'label' => 'Sidebar Optin BG Color'
);

 
// Border color 
$txtcolors[] = array(
    'slug'=>'border_color', 
    'default' => '#EEEEEE',
    'label' => 'Border Color '
);

//Footer Widget border
$txtcolors[] = array(
    'slug'=>'footer_widget_border', 
    'default' => '#403f3f',
    'label' => 'Footer Widget border Color '
);

//site Footer BG
$txtcolors[] = array(
    'slug'=>'site_footer_bg', 
    'default' => '#212121',
    'label' => 'Site Footer BG Color '
);

//Footer Text
$txtcolors[] = array(
    'slug'=>'footer_text_clr', 
    'default' => '#cccccc',
    'label' => 'Footer Text Color '
);



// add the settings and controls for each color
foreach( $txtcolors as $txtcolor ) {
 
    // SETTINGS
    $wp_customize->add_setting(
        $txtcolor['slug'], array(
            'default' => $txtcolor['default'],
            'type' => 'option', 
            'capability' => 
            'edit_theme_options'
        )
    );
    // CONTROLS
    $wp_customize->add_control(
        new WP_Customize_Color_Control(
            $wp_customize,
            $txtcolor['slug'], 
            array('label' => $txtcolor['label'], 
            'section' => 'textcolors',
            'settings' => $txtcolor['slug'])
        )
    );
}
}
add_action( 'customize_register', 'fragranz_customize_register' );