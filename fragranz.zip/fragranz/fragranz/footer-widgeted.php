<div class="footer-widgets" id="footer-left">
	<div class="wrap">
	
	
    	<div class="footer-widgets-1">
		<div class="footer_menu_sec">
	
			<?php 
			if (genesism_get_option('footer_menu')){
			?>
			<div class="ftr_menu">
				<span class="menu_control">≡ Menu</span>
				<?php wp_nav_menu( array( 'theme_location' => 'ThirdMenu','container' => false,'menu_id' => 'menu_ftr_menu' ) );?>
			</div>
			
			<?php 
			}
			?>
			
			</div>
		 </div>
		 
		 <div class="footer_social_follow">
<?php
if (genesism_get_option('footer_social_follow_box')){
?>
				
				<div class="social_widget">
				<?php if (!genesism_get_option('fbcheck')){
				?>
				
					<a class="fb" title="Facebook" href="<?php echo genesism_option('facebook_text1'); ?>" target="_blank">
					<i class="fa icon-facebook"></i><?php echo genesism_option('facebook_title1'); ?>
					</a>
				
				<?php
				}
				?>
				
				<?php if (!genesism_get_option('tcheck')){
				?>
				
					<a class="twt" title="Twitter" href="<?php echo genesism_option('twitter_text1'); ?>" target="_blank">
					<i class="fa icon-twitter"></i><?php echo genesism_option('twitter_title1'); ?>
					</a>
				
				<?php
				}		
				?>
				
				<?php if (!genesism_get_option('gpcheck')){
				?>
				
					<a class="gp" title="google plus" href="<?php echo genesism_option('googleplus_text1'); ?>" target="_blank">
					<i class="fa icon-google-plus"></i><?php echo genesism_option('googleplus_title1'); ?>
					</a>
				
				<?php
				}
				?>
				
				<?php if (!genesism_get_option('inscheck')){
				?>
				
					<a class="inst" title="Instagram" href="<?php echo genesism_option('instagram_text1'); ?>" target="_blank">
					<i class="fa icon-instagram"></i><?php echo genesism_option('instagram_title1'); ?>
					</a>
				
				<?php
				}
				?>
				
				<?php if (!genesism_get_option('ytcheck')){
				?>
				
					<a class="yt" title="youtube" href="<?php echo genesism_option('youtube_text1'); ?>" target="_blank">
					<i class="fa icon-youtube"></i><?php echo genesism_option('youtube_title1'); ?>
					</a>
				
				<?php
				}
				?>
				
			</div>
				
				
				<?php
				}
				?>
				
</div>

   		<!-- end .footer-left -->

    
 
    	</div><!-- end .wrap -->
</div><!-- end #footer-widgets -->