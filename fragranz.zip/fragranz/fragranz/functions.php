<?php
require_once(TEMPLATEPATH.'/lib/init.php'); // Start Genesis Engine
require_once(STYLESHEETPATH.'/lib/init.php'); // Start blog Options
require_once(STYLESHEETPATH.'/lib/updates.php'); // updates

include_once( 'lib/customizer.php' );
//* Add HTML5 markup structure
add_theme_support( 'html5' );


/** Support for various Image sizes */
add_theme_support('post-thumbnails');
//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Add support for custom background
add_theme_support( 'custom-background' );

//* Remove for custom background
 remove_custom_background();
 

//* Display author box on archive pages
add_filter( 'get_the_author_genesis_author_box_archive', '__return_true' );

//* Customize the author box title
add_filter( 'genesis_author_box_title', 'custom_author_box_title' );
function custom_author_box_title() {
	return "<h3 itemscope=\"Name\"> " . get_the_author() . "</h3>";
	}

// Add widgeted footer section
add_action('genesis_before_footer', 'footer_bottom_widgets'); 
function footer_bottom_widgets() {
    require(CHILD_DIR.'/footer-widgeted.php');
}

/** Register widget areas */
genesis_register_sidebar( array(
	'id'			=> 'front_page_top_widget',
	'name'			=> __( 'Front Page Top Widget', 'Fragranz Genesis Theme' ),
	'description'	=> __( 'This is the front page top widget if you are using a two or three column site layout option.', 'Fragranz Genesis Theme' ),
	
) );

genesis_register_sidebar( array(
	'id'			=> 'single_related_post_widget',
	'name'			=> __( 'Single Related Post Widget', 'Fragranz Genesis Theme' ),
	'description'	=> __( 'This is the single page Content widget if you are using a two or three column site layout option.', 'Fragranz Genesis Theme' ),
	
) );

genesis_register_sidebar( array(
	'id'			=> 'footer-left',
	'name'			=> __( 'Footer Left', 'Fragranz Theme' ),
	'description'	=> __( 'This is the footer left section.', 'Fragranz Theme' ),
) );

genesis_register_sidebar( array(
	'id'			=> 'footer-right',
	'name'			=> __( 'Footer Right', 'Fragranz Theme' ),
	'description'	=> __( 'This is the footer right section.', 'Fragranz Theme' ),
) );

//Remove Post  entry footer  Meta data 
remove_action( 'genesis_entry_footer', 'genesis_post_meta' );
//remove archive description
remove_action( 'genesis_before_content', 'genesis_do_taxonomy_title_description', 15 );

//placeholder for comment box in single page
add_filter('comment_form_default_fields','comment_form_placeholder');
function comment_form_placeholder($fields){ 
	$fields['author'] = '<p class="comment-form-author">' . '<label for="author">' . __( '', 'genesis' ) . '</label> ' . 	
	( $req ? '<span class="required">*</span>' : '' ) .                   
	'<input id="author" name="author" type="text" placeholder="Name *" value="' . 				
	esc_attr( $commenter['comment_author'] ) . '" size="30"' . $aria_req . ' /></p>';				
    $fields['email'] = '<p class="comment-form-email"><label for="email">' . __( '', 'genesis' ) . '</label> ' .
	( $req ? '<span class="required">*</span>' : '' ) .
	'<input id="email" name="email" type="text" placeholder="Email *" value="' . 	
	esc_attr(  $commenter['comment_author_email'] ) . '" size="30"' . $aria_req . ' /></p>';	
	$fields['url'] = '<p class="comment-form-url"><label for="url">' . __( '', 'genesis' ) . '</label>' .    
	'<input id="url" name="url" type="text" placeholder="URL *" value="' . 	
	esc_attr( $commenter['comment_author_url'] ) . '" size="30" /></p>';	
    return $fields;
}

// Customizes Footer Text (set in options) 
if (genesism_get_option('footer1')) { 
	add_filter('genesis_footer_creds_text', 'custom_footer_creds_text');
	function custom_footer_creds_text($creds) {
    	$creds = genesism_get_option('footer_text');
    return $creds;
	}
}

add_filter( 'genesis_before_header', 'search_box',2 );
function search_box( $text ) {
	return esc_attr( 'Go' );
}
remove_action( 'genesis_site_title', 'genesis_seo_site_title' );
remove_action( 'genesis_site_description', 'genesis_seo_site_description' );
/* BEGIN Custom User Contact Info */
function extra_contact_info($contactmethods) {

$contactmethods['facebook'] = 'Facebook';
$contactmethods['twitter'] = 'Twitter';

return $contactmethods;
}
add_filter('user_contactmethods', 'extra_contact_info');
/* END Custom User Contact Info */


add_action( 'genesis_before_comments', 'themeprefix_alt_author_box',2 );
function themeprefix_alt_author_box() {
if( is_single() ) {
 echo"<div class='single_title'><h3>THIS ARTICLE WAS WRITTEN BY</h3></div>";
echo "<div class=\"about-author\"><div class=\"author-info\" itemscope=\"itemscope\" itemtype=\"http://schema.org/person\">" . get_avatar( get_the_author_meta( 'ID' ), '100' ) . "</div>
<div class='author_right_cnt'>";?>
<p class="author_name"><?php the_author_posts_link(); ?></p>

<?php echo "<p itemprop=\"description\">" . get_the_author_meta( 'description' ) . 
 "</p>
 <div class=\"author_social\">"; 

 if ( get_the_author_meta( 'facebook' ) != '' ) {
 echo "<a class=\"afb  fa\" href=\"https://www.facebook.com/". get_the_author_meta( 'facebook' ) . "\"></a>";
 }
 if ( get_the_author_meta( 'twitter' ) != '' ) {
 echo "<a class=\"atw fa\" href=\"https://twitter.com/". get_the_author_meta( 'twitter' ) . "\"></a>";
 }
echo "</div></div></div>";
 }
} 
//* Remove the entry meta in the entry header 
 add_filter( 'genesis_post_info', 'sp_post_info_filter' );
function sp_post_info_filter($post_info) {
if ( is_single() ) {
	$post_info = '[post_date] by [post_author_posts_link] [post_comments]';
	return $post_info;
}}
 
// Register Genesis Menus
add_action( 'init', 'register_additional_menu' );
function register_additional_menu() {
  
register_nav_menu( 'FirstMenu' ,__( 'Top Menu' ));
register_nav_menu( 'SecondMenu' ,__( 'Bottom Menu' )); 
register_nav_menu( 'ThirdMenu' ,__( 'Footer Menu' ));   
}

/** Remove Header */
remove_action( 'genesis_header', 'genesis_header_markup_open', 5 );
remove_action( 'genesis_header', 'genesis_do_header' );
remove_action( 'genesis_header', 'genesis_header_markup_close', 15 );

/** Add custom header support */	  
add_action('genesis_header','injectHeader');	  
function injectHeader(){ 

?>
<div class="center_header_cont">
<div class="center_inner_header wrap">
 <div class="logo_section">
				<?php
				if (genesism_get_option('center_header')){
				?>
					<a title="<?php bloginfo('name'); ?>" href="<?php bloginfo('wpurl'); ?>"><img src="<?php echo genesism_get_option('center_header_logo_img'); ?>" alt="<?php bloginfo('name'); ?>"/></a>
				<?php
				}
				else { ?>
					<h1 itemprop="headline"><a title="<?php bloginfo('name'); ?>" href="<?php bloginfo('wpurl'); ?>"><?php bloginfo('name');?> </a></h1>
					
				<?php } ?>
</div>

 <div class="ctr_right_section">
<?php
if (genesism_get_option('center_right_header')){
?>
<div class="header_ad">
<?php  echo stripslashes(genesism_get_option('hdr_ad_img'));?>
</div>				
<?php } ?>
 
 </div>
 
</div>
</div>

<div class="btm_header_cont">
 <div class="btm_inner_header wrap ">
	<div class="btm_left_header">
		
		<div class="bottom_menu_sec">
	
			<?php 
			if (genesism_get_option('btm_menu')){
			?>
			<div class="btm_menu">
				<span class="menu_control">≡ Menu</span>
				<?php wp_nav_menu( array( 'theme_location' => 'SecondMenu','container' => false,'menu_id' => 'menu_btm_menu' ) );?>
			</div>
			
			<?php 
			}
			?>
			
			</div>
		
		
	</div> 
	
	<div class="btm_right_header">
	
			<div class="header_search_box">
			<?php
			if (genesism_get_option('search_section')){
			?>
				
				
				<div class="hdr_search_box sidebar_wid">
				<div class="header_search_icon">
				<i class='fa icon-search'></i>
				</div>
					<div class="header_search text_box">
						<form  method='get' action='<?php echo get_bloginfo('home'); ?>'>
						<input  type='text' placeholder='<?php echo genesism_option('search_text1'); ?>' name='s' id='s' />
						<input name="submit" class="btn btn-success" type="submit" value="<?php echo stripslashes(genesism_get_option('hdr_submit_text')); ?>"/>
						
							
										
						</form>
					</div>
		</div>
				
				
			<?php 
			}
			?>
			</div>	
		
	</div>
		
 </div>
</div>


<?php 
}
 
add_action('genesis_before_header','before_header');	
function before_header() { ?>
<div class="header" itemscope="itemscope" itemtype="http://schema.org/WPHeader">
<?php
}
 
add_action('genesis_after_header','after_header');			
function after_header() { ?>

 </div>	

<?php
}

//add before content sidebar wrap
add_action('genesis_after_header','top_slider_section',1);
function top_slider_section(){

if ( is_home() ) {
?>
<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Front Page Top Widget') ) : ?>
<div class="widget">
<h4 itemprop="headline"><?php _e("Front Page Top #Widget", 'genesis'); ?></h4>
<p><?php _e("Displays Trending Post.", 'genesis'); ?></p>
</div><!-- end .widget -->
<?php endif; ?> 
<?php
}

 }

// Add Post Feature image
add_action( 'genesis_entry_header', 'custom_post_featureimage',1);
function custom_post_featureimage() {
if(!is_page()&&!is_single()){  
?>
<div class="post_featured_img">
<?php
if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
 echo "<div class='featured_viedo_image'>";
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true);echo "</div>";	
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video
 // Defaults
         $f_img_width = genesism_get_option('f_img_width');
        $f_img_height = genesism_get_option('f_img_height');
        $default_img =  'Feature_image'; 
      
        // Auto feature image defaults
        $thumb = get_post_thumbnail_id(); 
        $img_url = wp_get_attachment_url( $thumb,'full' ); 
        $image = aq_resize( $img_url,$f_img_width,$f_img_height, true );
        // Catch the Image defaults
        $catch_img_url = catch_that_image( $thumb,'full' );
        $catch_image = aq_resize( $catch_img_url, $f_img_width, $f_img_height, true );
        // Default Image
        $default_image = aq_resize( $default_img, $f_img_width, $f_img_height, true );		
			
		if(has_post_thumbnail()) { ?>
		<div class="featured_image">
        <a href="<?php echo the_permalink();?>" title="<?php echo the_title();?>"><img src="<?php echo $image;?>" width="<?php echo $f_img_width;?>" height="<?php echo $f_img_height;?>"  alt="<?php the_title(); ?>"  itemprop="image"></a></div>
		<?php        
		}
		elseif (catch_that_image()){ 	?>
		<div class="featured_image">
		<a href="<?php echo the_permalink();?>" title="<?php echo the_title();?>"><img src="<?php echo $catch_image;?>" width="<?php echo $f_img_width;?>" height="<?php echo $f_img_height;?>"  alt="<?php the_title(); ?>"  itemprop="image"></a></div>
		<?php        
		} 
		 else if(!empty($default_img)){     ?> 
		 <div class="featured_image">
          <a href="<?php echo the_permalink();?>" title="<?php echo the_title();?>"><img class="featureimg" src="<?php echo $default_img;?>" width="<?php echo $f_img_width;?>" height="<?php echo $f_img_height;?>"  alt="<?php the_title(); ?>"  itemprop="image"></a></div>
<?php     
	 }
	 }
	}

		/*featured image ends here*/
?>

</div>
<?php	
}      
}
  
add_action( 'genesis_post_info', 'post_info_filter');
function post_info_filter() {
if(!is_page()){ 
?>
<div class="byline">
<?php
		$category = get_the_category(); 
	?>
	<span class='author'><?php the_author() ?></span>
	<span class='date'><?php the_time('j M , Y') ?></span>
	<span class="cat"><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></span>
	<span class='info_comments'><a  href="<?php the_permalink(); ?>#comments" title="<?php comments_number(__('0 ','fb'),__('1 ','periodic'),__('% ','fb')); ?>"><?php comments_number(__('0 ','periodic'),__('1 ','periodic'),__('% ','fb')); ?> </a></span>
</div>								
<?php
}
}

add_action('genesis_entry_content','post_ad',2);
function post_ad(){
if(genesism_get_option('postadcheck')){
if ( is_single() ) {?>
		<div class="post-ad" style="float:<?php echo genesism_option('float');?>; padding-right:5px; padding-left:15px; padding-top: 10px;">
		<?php  echo stripslashes((genesism_get_option('postad')));?>
		</div>
        <?php
		}
	}
	}
	
add_action ('genesis_entry_content','post_read_more');
function post_read_more(){
if (genesism_get_option('read_more')){
if(!is_page()&&!is_single()){
?>
<div class="read_more">
	<a class="read_more_btn" href="<?php echo the_permalink(); ?>"><?php  echo (genesism_get_option('read_text'));?></a>
</div>
<?php 
}
}	
}	

add_action ('genesis_before_sidebar_widget_area','before_sidebar_widget_area');
function before_sidebar_widget_area(){

?>
<div class="sidebar_section">
<?php 
}

add_action ('genesis_before_sidebar_widget_area','sidebar_optin',2);
function sidebar_optin(){	
if (genesism_get_option('sidebar_optin_section')){
?>
<div class="sidebar_optin_cnt">

<div class='sb_optin_hdr'>
<h2><?php echo genesism_get_option('sb_optin_header1'); ?></h2>
<h3><?php echo genesism_get_option('sb_optin_header2'); ?></h3>

</div>
<div class='form_content'>
<form method="post" action="<?php echo stripslashes(genesism_get_option('optin_url')); ?>" target="_blank">	
<div class="names">
<label><?php echo genesism_get_option('email'); ?></label>
<div class="sb_input">
<input class="name" type="text" name="<?php echo stripslashes(genesism_get_option('optin_name')); ?>" placeholder="<?php echo stripslashes(genesism_get_option('name_text')); ?>"><div class='admins'></div>
<input class="email" type="text" name="<?php echo stripslashes(genesism_get_option('optin_email')); ?>" placeholder="<?php echo stripslashes(genesism_get_option('email_text')); ?>"><div class='mails'></div>
<?php echo stripslashes(genesism_get_option('optin_hidden')); ?>
<input name="submit" class="submit" type="submit" value="<?php echo stripslashes(genesism_get_option('submit_text')); ?>"/>
</div>
</div>
</form>
</div>
</div>
<?php 
}
}

add_action ('genesis_after_sidebar_widget_area','after_sidebar_widget_area');
function after_sidebar_widget_area(){
?>
</div>
<?php 
}

// Customize the post meta function
add_filter('genesis_entry_footer', 'post_meta_filter',1);
function post_meta_filter() {
if ( is_single() ) {?>
<p class='post_tags'> 
<?php the_tags( 'Tagged with: ', ' • ', '<br />' ); ?>
</p>
<?php
}
}

add_action ('genesis_after_content_sidebar_wrap','editor_picks_two');
function editor_picks_two(){
if (genesism_get_option('editor_picks_two')){
if ( is_home() ) {	
?>
<div class="bottom_editor_picks_cont">

<div class="bottom_editor_header">
<h3><?php echo (genesism_option('editors_title1')); ?></h3>
<p><?php echo (genesism_option('editors_cnt1')); ?></p>
</div>

<div class="bottom_editor_picks_inner">
<div class="editors_picks_content">
<?php
query_posts('p='. genesism_get_option('post_id1') .'&posts_per_page=1');
while (have_posts()): the_post(); 
?>
<?php
echo "<div class='editor_news_sec'>";
echo"<div class='edit_img'>";
if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true);
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video		
 // Defaults
         $f_img_width = 360;
        $f_img_height = 400;
        $default_img =  'Feature_image'; 

		// Auto feature image defaults
		$thumb = get_post_thumbnail_id(); 
		$img_url = wp_get_attachment_url( $thumb,'full' ); 
		$image = aq_resize( $img_url,$f_img_width,$f_img_height, true );
		// Catch the Image defaults
        $catch_img_url = catch_that_image( $thumb,'full' );
        $catch_image = aq_resize( $catch_img_url, $f_img_width, $f_img_height, true );
        // Default Image
        $default_image = aq_resize( $default_img, $f_img_width, $f_img_height, true );
		if(has_post_thumbnail())
		echo
		"<div class=\"featured_image\">\n".
		"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width . "\" height=\"" . $f_img_height . "\" alt=\"" . get_the_title() . "\"><div class='thumb_hover'></div></a>\n".
		"</div>\n";
		elseif (catch_that_image()){ 
		echo
		"<div class=\"featured_image\">\n".
		"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width . "\" height=\"" . $f_img_height . "\" alt=\"" . get_the_title() . "\"></a>\n".
		"</div>\n"; 
		}
}
}		
		/*featured image ends here*/

echo "</div>";
echo "<div class='editor_cont'>";
?>
<div class='cat_name'>
<?php
$category = get_the_category(); 
?>
<h4><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></h4>
</div>
<?php
echo"<div class='blog_title'><h4><a href='". get_permalink() ."'>". get_the_title() ."".
"</a></h4></div>";

echo"<div class='blog_byline'>";?>
	<span class='date'><?php echo get_the_time('M jS, Y'); ?></span>
	<span class='info_comments'><a  href="<?php the_permalink(); ?>#comments" title="<?php comments_number(__('0 Comment','fb'),__('1 Comment','periodic'),__('% Comments','fb')); ?>"><?php comments_number(__('0','periodic'),__('1','periodic'),__('%','fb')); ?> </a></span>
		<?php
echo "</div>";
echo "</div>";
echo "</div>";
?>
<?php
endwhile;
wp_reset_query();
?>
</div>
<div class="editors_picks_content">
<?php
query_posts('p='. genesism_get_option('post_id2') .'&posts_per_page=1');
while (have_posts()): the_post(); 
?>
<?php
echo "<div class='editor_news_sec'>";
echo"<div class='edit_img'>";
if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true);
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video			
 // Defaults
         $f_img_width = 360;
        $f_img_height = 400;
        $default_img =  'Feature_image'; 

		// Auto feature image defaults
		$thumb = get_post_thumbnail_id(); 
		$img_url = wp_get_attachment_url( $thumb,'full' ); 
		$image = aq_resize( $img_url,$f_img_width,$f_img_height, true );
		// Catch the Image defaults
        $catch_img_url = catch_that_image( $thumb,'full' );
        $catch_image = aq_resize( $catch_img_url, $f_img_width, $f_img_height, true );
        // Default Image
        $default_image = aq_resize( $default_img, $f_img_width, $f_img_height, true );
		if(has_post_thumbnail())
		echo
		"<div class=\"featured_image\">\n".
		"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width . "\" height=\"" . $f_img_height . "\" alt=\"" . get_the_title() . "\"><div class='thumb_hover'></div></a>\n".
		"</div>\n";
		elseif (catch_that_image()){ 
		echo
		"<div class=\"featured_image\">\n".
		"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width . "\" height=\"" . $f_img_height . "\" alt=\"" . get_the_title() . "\"></a>\n".
		"</div>\n"; 
		}
}
}		
		/*featured image ends here*/

echo "</div>";
echo "<div class='editor_cont'>";
?>
<div class='cat_name'>
<?php
$category = get_the_category(); 
?>
<h4><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></h4>
</div>
<?php
echo"<div class='blog_title'><h4><a href='". get_permalink() ."'>". get_the_title() ."".
"</a></h4></div>";
echo"<div class='blog_byline'>";?>
	<span class='date'><?php echo get_the_time('M jS, Y'); ?></span>
	<span class='info_comments'><a  href="<?php the_permalink(); ?>#comments" title="<?php comments_number(__('0 Comment','fb'),__('1 Comment','periodic'),__('% Comments','fb')); ?>"><?php comments_number(__('0','periodic'),__('1','periodic'),__('%','fb')); ?> </a></span>
		<?php
echo "</div>";
echo "</div>";
echo "</div>";
?>
<?php
endwhile;
wp_reset_query();
?>
</div>
<div class="editors_picks_content">
<?php
query_posts('p='. genesism_get_option('post_id3') .'&posts_per_page=1');
while (have_posts()): the_post(); 
?>
<?php
echo "<div class='editor_news_sec'>";
echo"<div class='edit_img'>";
if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true);
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video			
 // Defaults
         $f_img_width = 360;
        $f_img_height = 400;
        $default_img =  'Feature_image'; 

		// Auto feature image defaults
		$thumb = get_post_thumbnail_id(); 
		$img_url = wp_get_attachment_url( $thumb,'full' ); 
		$image = aq_resize( $img_url,$f_img_width,$f_img_height, true );
		// Catch the Image defaults
        $catch_img_url = catch_that_image( $thumb,'full' );
        $catch_image = aq_resize( $catch_img_url, $f_img_width, $f_img_height, true );
        // Default Image
        $default_image = aq_resize( $default_img, $f_img_width, $f_img_height, true );
		if(has_post_thumbnail())
		echo
		"<div class=\"featured_image\">\n".
		"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width . "\" height=\"" . $f_img_height . "\" alt=\"" . get_the_title() . "\"><div class='thumb_hover'></div></a>\n".
		"</div>\n";
		elseif (catch_that_image()){ 
		echo
		"<div class=\"featured_image\">\n".
		"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width . "\" height=\"" . $f_img_height . "\" alt=\"" . get_the_title() . "\"></a>\n".
		"</div>\n"; 
		}
}
}		
		/*featured image ends here*/

echo "</div>";
echo "<div class='editor_cont'>";
?>
<div class='cat_name'>
<?php
$category = get_the_category(); 
?>
<h4><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></h4>
</div>
<?php
echo"<div class='blog_title'><h4><a href='". get_permalink() ."'>". get_the_title() ."".
"</a></h4></div>";
echo"<div class='blog_byline'>";?>
	<span class='date'><?php echo get_the_time('M jS, Y'); ?></span>
	<span class='info_comments'><a  href="<?php the_permalink(); ?>#comments" title="<?php comments_number(__('0 Comment','fb'),__('1 Comment','periodic'),__('% Comments','fb')); ?>"><?php comments_number(__('0','periodic'),__('1','periodic'),__('%','fb')); ?> </a></span>
		<?php
echo "</div>";
echo "</div>";
echo "</div>";
?>
<?php
endwhile;
wp_reset_query();
?>
</div>
<div class="editors_picks_content">
<?php
query_posts('p='. genesism_get_option('post_id4') .'&posts_per_page=1');
while (have_posts()): the_post(); 
?>

<?php
echo "<div class='editor_news_sec'>";
echo"<div class='edit_img'>";
if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true);
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video
			
 // Defaults
         $f_img_width = 360;
        $f_img_height = 400;
        $default_img =  'Feature_image'; 

		// Auto feature image defaults
		$thumb = get_post_thumbnail_id(); 
		$img_url = wp_get_attachment_url( $thumb,'full' ); 
		$image = aq_resize( $img_url,$f_img_width,$f_img_height, true );
		// Catch the Image defaults
        $catch_img_url = catch_that_image( $thumb,'full' );
        $catch_image = aq_resize( $catch_img_url, $f_img_width, $f_img_height, true );
        // Default Image
        $default_image = aq_resize( $default_img, $f_img_width, $f_img_height, true );
		if(has_post_thumbnail())
		echo
		"<div class=\"featured_image\">\n".
		"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width . "\" height=\"" . $f_img_height . "\" alt=\"" . get_the_title() . "\"><div class='thumb_hover'></div></a>\n".
		"</div>\n";
		elseif (catch_that_image()){ 
		echo
		"<div class=\"featured_image\">\n".
		"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width . "\" height=\"" . $f_img_height . "\" alt=\"" . get_the_title() . "\"></a>\n".
		"</div>\n"; 
		}
}
}		
		/*featured image ends here*/

echo "</div>";
echo "<div class='editor_cont'>";
?>
<div class='cat_name'>
<?php
$category = get_the_category(); 
?>
<h4><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></h4>
</div>
<?php
echo"<div class='blog_title'><h4><a href='". get_permalink() ."'>". get_the_title() ."".
"</a></h4></div>";
echo"<div class='blog_byline'>";?>
	<span class='date'><?php echo get_the_time('M jS, Y'); ?></span>
	<span class='info_comments'><a  href="<?php the_permalink(); ?>#comments" title="<?php comments_number(__('0 Comment','fb'),__('1 Comment','periodic'),__('% Comments','fb')); ?>"><?php comments_number(__('0','periodic'),__('1','periodic'),__('%','fb')); ?> </a></span>
		<?php
echo "</div>";
echo "</div>";
echo "</div>";
?>
<?php
endwhile;
wp_reset_query();
?>
</div>
</div>
</div>
<?php 
}
}
}

add_filter( 'genesis_term_meta_headline', 'be_default_category_title', 10, 2 );
function be_default_category_title( $headline, $term ) {
	if( ( is_category() || is_tag() || is_tax() ) && empty( $headline ) )
		$headline = $term->name;	
	return $headline;
}
	
/** Genesis Previous/Next Post Post Navigation */
add_action ('genesis_entry_footer','prev_next_post_nav',3);
function prev_next_post_nav(){
if ( is_single() ) {
echo '<div class="prev-next-navigation">';
previous_post_link( '<div class="previous"><span>Previous article:</span> %link</div>', '%title' );
next_post_link( '<div class="next"><span>Next article:</span> %link</div>', '%title' );
echo '</div><!-- .prev-next-navigation -->';
}
}	
add_action( 'genesis_entry_header', 'breadcrumbs',2);
function breadcrumbs(){
if ( is_single() ) {

}
}
add_action( 'genesis_before_comments', 'single_page_socialshare',2);
function single_page_socialshare(){
if (genesism_get_option('single_social_share')){
if ( is_single() ) {?>
<div class="sharing group sharing_social_count">
<div class="single_title">
	<h3><?php  echo (genesism_get_option('share_title'));?></h3>
	<span class="sep"></span>
</div>
<ul class="social_share_count">

		<li class="share_tweet">
		<a href="http://twitter.com/share?text=<?php echo htmlspecialchars(urlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8')), ENT_COMPAT, 'UTF-8'); ?>&amp;url=<?php the_permalink(); ?>" target="_blank">
		<i class="icon-twitter icon"></i>
		<span>
		 Twitter
		</span>
		</a>
		</li>
		<li class="share_fb">
		<a href="http://www.facebook.com/sharer.php?u=<?php the_permalink(); ?>&amp;t=<?php echo htmlspecialchars(urlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8')), ENT_COMPAT, 'UTF-8'); ?>" target="_blank">
		<i class="icon-facebook icon"></i>
		<span>
		 Facebook
		</span>
		</a>
		</li>
		<li class="share_linkedin">
		<a target="_blank" href="http://www.linkedin.com/shareArticle?mini=true&amp;url=<?php the_permalink(); ?>">
		<i class="icon-linkedin icon"></i>
		<span>
		 Linkedin
		</span>
		</a> 
		</li>
		<li class="share_reddit">
		<a target="_blank" href="http://www.reddit.com/submit?url=<?php the_permalink(); ?>&amp;title=<?php echo htmlspecialchars(urlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8')), ENT_COMPAT, 'UTF-8'); ?>">
		<i class="icon-reddit icon"></i>
		<span>
		 Reddit
		</span>
		</a>
		</li>
		<li class="share_pintrest">
		<a target="_blank" href="http://pinterest.com/pinthis?url=<?php the_permalink(); ?>&amp;title=<?php echo htmlspecialchars(urlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8')), ENT_COMPAT, 'UTF-8'); ?>">
		<i class="icon-pinterest icon"></i>
		<span>
		 Pintrest
		</span>
		</a>
		</li>		
	</ul>

</div>
<?php
}
}
}

	//Related Post Box
add_action( 'genesis_before_comments', 'related_posts',3);
function related_posts(){
if (genesism_get_option('related_post')){
?>
<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Single Related Post Widget') ) : ?>
<div class="widget">
<h4 itemprop="headline"><?php _e("Single Related Post #Widget", 'genesis'); ?></h4>
<p><?php _e("Displays Related posts with thumbnails.", 'genesis'); ?></p>
</div><!-- end .widget -->
<?php endif; ?> 
<?php
}
}

//Single Optin Box
add_action( 'genesis_before_comments', 'single_page_optin',3);
function single_page_optin(){
if (genesism_get_option('single_optin_section')){
?>
<div class="single_optin_cnt">
<div class='sp_optin_hdr'>
<h2><?php echo genesism_get_option('sp_optin_header1'); ?></h2>
<h3><?php echo genesism_get_option('sp_optin_header2'); ?></h3>
<p><?php echo genesism_option('sp_optin_para'); ?></p>
</div>
<div class='form_content'>
<form method="post" action="<?php echo stripslashes(genesism_get_option('optin_url2')); ?>" target="_blank">	
<div class="names">
<label><?php echo genesism_get_option('email2'); ?></label>
<div class="sp_input">
<input class="name" type="text" name="<?php echo stripslashes(genesism_get_option('optin_name2')); ?>" placeholder="<?php echo stripslashes(genesism_get_option('name_text2')); ?>"><div class='mails'></div>
<input class="email" type="text" name="<?php echo stripslashes(genesism_get_option('optin_email2')); ?>" placeholder="<?php echo stripslashes(genesism_get_option('email_text2')); ?>"><div class='mails'></div>
<?php echo stripslashes(genesism_get_option('optin_hidden2')); ?>
<input name="submit" class="submit" type="submit" value="<?php echo stripslashes(genesism_get_option('submit_text2')); ?>"/>
</div>
</div>
</form>
</div>
</div>
<?php
}
}

add_action('wp_head','color_box');
function color_box(){
$bgcolor = get_option('bgcolor');
$bodytextcolor = get_option('bodytextcolor');
$bottom_header_bg = get_option('bottom_header_bg');
$header_text_color =get_option('header_text_color');
$byline_color =get_option('byline_color');
$link_color =get_option('link_color');

$sb_cont_bg =get_option('sb_cont_bg');

$sb_optin_bg =get_option('sb_optin_bg');
$border_color =get_option('border_color');
$footer_widget_border =get_option('footer_widget_border');
$site_footer_bg =get_option('site_footer_bg');
$footer_text_clr =get_option('footer_text_clr');

?>
<style type="text/css">

body, .single_optin_cnt {
background:<?php echo $bgcolor; ?>;
}



.btm_header_cont{
background: <?php echo $bottom_header_bg; ?>;
}

.header_search_icon, .text_box{
background: <?php echo $bodytextcolor; ?>;
}

.archive-pagination li a, .read_more a{
border-color: <?php echo $bodytextcolor; ?>;


}

.aboutus_cnt_main p, .sidebar .widget_categories ul li  a, .blog .entry-content p, .archive .entry-content p, .search .entry-content p, .content .single_title h3, #reply-title{
color: <?php echo $bodytextcolor; ?>;

}

.widget_search .search_text, .aboutus_cnt_main a, .land-img-overlay {
background-color: <?php echo $bodytextcolor; ?>;

}

body{
color:<?php echo $bodytextcolor; ?>;
}

a, .sidebar .tagcloud a, .aboutus_cnt h3, .blog .entry-title a, .archive .entry-title a, .read_more a, .info_comments a{
color:<?php echo $header_text_color; ?>;
}

.menu .sub-menu a{
background: <?php echo $header_text_color; ?>;
}

.sidebar .tagcloud a:hover, .related_post_section, .featured-slider-overlay {
background-color:<?php echo $header_text_color; ?>;
}

.sidebar .tagcloud a:hover{
border-color:<?php echo $header_text_color; ?>;
}

.sidebar h4.widgettitle, .sidebar_widget  .sidebar_heading h3{
color: <?php echo $header_text_color; ?>;
}

.sidebar h4.widgettitle, .sidebar_widget  .sidebar_heading h3{
border-color: <?php echo $header_text_color; ?>;
}


.header_search .btn-success{
background: <?php echo $byline_color; ?>;
}

.trend_btm .blog_byline span, .trend_btm .blog_byline a, .last_updated ul li h3, .blog .byline .cat a, .archive .byline .cat a, .search .byline .cat a, .blog .entry-header .byline, .archive .entry-header .byline, .search .entry-header .byline, .blog .entry-header .byline a, .archive .entry-header .byline a, .search .entry-header .byline a, .entry-header .byline, .entry-header .byline a {
color:<?php echo $byline_color; ?>;
}

.header_search_icon, .landing_right_optin{
border-color: <?php echo $byline_color; ?>;
}

a:hover, .menu .current-menu-item > a, entry-header a:hover, .blog .entry-title a:hover,  .archive-description .archive-title, 
.footer-widgets-1 .tagcloud a:hover, .ftr_menu .menu a:hover, .site-footer p a, .menu .sub-menu li:hover a,.entry-title a:hover,
.post_tags a, .author-box h3 {
color: <?php echo $link_color; ?>;
}

.form-submit input[type="submit"]:hover, .landing_right_optin input[type="submit"], .archive-pagination li a:hover, .archive-pagination .active a, .sidebar_optin_cnt h2:after, .sidebar_optin_cnt input[type="submit"], .header_search .btn-success:hover, .featured-carousel .featured-cat a, .cat_name h4 a, .aboutus_cnt_main a:hover, .read_more a:hover, .feature_cont .about_read a, .single .post_tags:hover{
background-color: <?php echo $link_color; ?>;
}


.featured-area.loaded button.slick-prev:hover,
.featured-area.loaded button.slick-next:hover {
	background-color:<?php echo $link_color; ?>;
	}
	
.entry blockquote, .author-box{
border-top-color: <?php echo $link_color; ?>;
}
.landing_right_optin input[type="submit"], .sidebar_optin_cnt input[type="submit"], .social_icons a:hover, .featured-carousel .featured-cat a:after, .read_more a:hover, .feature_cont h2 a:hover, .feature_cont .about_read a:hover, .single .post_tags {
border-color: <?php echo $link_color; ?>;
}

.featured-carousel.style-7 .carousel-meta span.feat-author a:hover,
.featured-carousel .carousel-meta span a:hover, .feature_cont .about_read a:hover, .featured-carousel .featured-content .feat-text h3 a:hover, .single .post_tags {
	color: <?php echo $link_color; ?>;
}

.bottom_menu_sec .menu a:hover, .landing_right_optin input[type="submit"]:hover, .sidebar_optin_cnt input[type="submit"]:hover, .popular_cnt h3 a:hover, .random_cnt h3 a:hover, .pop_byline span, .editor_news_sec .blog_title h4 a:hover, .sidebar .widget_categories ul li  a:hover, .related_post_cnt h3 a:hover, .related_post_cnt .date{
color: <?php echo $link_color; ?>;
}

.sidebar_content, .entry-comments, .aboutus_cnt, .author-box {
background: <?php echo $sb_cont_bg; ?>;
}
.form-allowed-tags {
background-color: <?php echo $sb_cont_bg; ?>;
}

.bottom_menu_sec .menu li{
border-left-color: <?php echo $sb_cont_bg; ?>;
}

.landing_feature_box{
background-color:<?php echo $sb_cont_bg; ?>;
}

.sidebar_optin_cnt{
background: <?php echo $sb_optin_bg; ?>;
}


.bottom_menu_sec .menu .sub-menu li, .top_menu_sec .menu .sub-menu li {
border-color: <?php echo $sb_optin_bg; ?>;
}


.bottom_editor_header, .single .post .byline{
border-top-color: <?php echo $border_color; ?>;
}

.byline span{
border-right-color: <?php echo $border_color; ?>;
}

.sidebar_optin_cnt  input[type="text"], .entry .entry-content pre {
background-color: <?php echo $border_color; ?>;
}

.sp_optin_hdr p{
color: <?php echo $border_color; ?>;
}

 .header_search  input[type='text'], .sidebar_content, .sidebar_optin_cnt  input[type="text"], .trend_btm, .prev-next-navigation, li.comment{
border-color: <?php echo $border_color; ?>;
}
 
.sidebar li, .aboutus_cnt_title_para, .bottom_editor_header, .sidebar .widget_categories ul li, .single .post .byline, .related_post_section, .content .single_title h3, #reply-title, .feature_cont, .feature_cont h2 a, .bottom_menu_sec .menu li ,.entry blockquote{
border-bottom-color: <?php echo $border_color; ?>;
}

.menu .sub-menu a{
border-bottom-color: <?php echo $footer_widget_border; ?>;
}

.footer-widgets-1, .footer_social_follow{
border-bottom-color: <?php echo $footer_widget_border; ?>;
}

.landing_right_optin{
background-color: <?php echo $site_footer_bg; ?>;
}

.footer-widgets, .site-footer{
background-color: <?php echo $site_footer_bg; ?>;
}

.site-footer p, .footer_social_follow .social_widget a:hover, .footer_social_follow .social_widget a i {
color: <?php echo $footer_text_clr; ?>;
}

.sidebar_optin_cnt h3, .footer-widgets li a{
color:  <?php echo $footer_text_clr; ?>;
}

<?php echo genesism_option('custom_css'); ?>
</style>
<?php
}

add_action( 'wp_enqueue_scripts', 'enqueue_script' );
function enqueue_script() {
	
wp_enqueue_script( 'slick.min', get_stylesheet_directory_uri() . '/scripts/slick.min.js', array( 'jquery' ), '', true );	
	
	wp_enqueue_script( 'custom', get_stylesheet_directory_uri() . '/scripts/custom.js', array( 'jquery' ), '', true );	
	
}

add_action('wp_footer','script_box');
function script_box(){?>
<script type="text/javascript">
function loadScript(src) {
     var element = document.createElement("script");
     element.src = src;
     document.body.appendChild(element);
}
// Add a script element as a child of the body
function downloadJSAtOnload() {

	
	loadScript("<?php bloginfo('stylesheet_directory'); ?>/scripts/stick.js");
 
}
 // Check for browser support of event handling capability
 if (window.addEventListener)
     window.addEventListener("load", downloadJSAtOnload, false);
	 else if (window.attachEvent)
     window.attachEvent("onload", downloadJSAtOnload);
 else window.onload = downloadJSAtOnload; 
 (function() {
      function getScript(url,success){
        var script=document.createElement('script');
        script.src=url;
        var head=document.getElementsByTagName('head')[0],
            done=false;
        script.onload=script.onreadystatechange = function(){
          if ( !done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete') ) {
            done=true;
            success();
            script.onload = script.onreadystatechange = null;
            head.removeChild(script);
          }
        };
        head.appendChild(script);
      }
	   getScript('http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js',function(){
        });
    })();
</script>
<?php
}

// Auto Resize Image
function aq_resize( $url, $width, $height = null, $crop = null, $single = true ) {

//validate inputs
if(!$url OR !$width ) return false;

//define upload path & dir
$upload_info = wp_upload_dir();
$upload_dir = $upload_info['basedir'];
$upload_url = $upload_info['baseurl'];

//check if $img_url is local
if(strpos( $url, $upload_url ) === false) return false;

//define path of image
$rel_path = str_replace( $upload_url, '', $url);
$img_path = $upload_dir . $rel_path;

//check if img path exists, and is an image indeed
if( !file_exists($img_path) OR !getimagesize($img_path) ) return false;

//get image info
$info = pathinfo($img_path);
$ext = $info['extension'];
list($orig_w,$orig_h) = getimagesize($img_path);

//get image size after cropping
$dims = image_resize_dimensions($orig_w, $orig_h, $width, $height, $crop);
$dst_w = $dims[4];
$dst_h = $dims[5];

//use this to check if cropped image already exists, so we can return that instead
$suffix = "{$dst_w}x{$dst_h}";
$dst_rel_path = str_replace( '.'.$ext, '', $rel_path);
$destfilename = "{$upload_dir}{$dst_rel_path}-{$suffix}.{$ext}";

if(!$dst_h) {
//can't resize, so return original url
$img_url = $url;
$dst_w = $orig_w;
$dst_h = $orig_h;
}
//else check if cache exists
elseif(file_exists($destfilename) && getimagesize($destfilename)) {
$img_url = "{$upload_url}{$dst_rel_path}-{$suffix}.{$ext}";
}
//else, we resize the image and return the new resized image url
else {

// Note: This pre-3.5 fallback check will edited out in subsequent version
if(function_exists('wp_get_image_editor')) {

$editor = wp_get_image_editor($img_path);

if ( is_wp_error( $editor ) || is_wp_error( $editor->resize( $width, $height, $crop ) ) )
return false;

$resized_file = $editor->save();

if(!is_wp_error($resized_file)) {
$resized_rel_path = str_replace( $upload_dir, '', $resized_file['path']);
$img_url = $upload_url . $resized_rel_path;
} else {
return false;
}

} else {

$resized_img_path = image_resize( $img_path, $width, $height, $crop ); // Fallback foo
if(!is_wp_error($resized_img_path)) {
$resized_rel_path = str_replace( $upload_dir, '', $resized_img_path);
$img_url = $upload_url . $resized_rel_path;
} else {
return false;
}

}

}

//return the output
if($single) {
//str return
$image = $img_url;
} else {
//array return
$image = array (
0 => $img_url,
1 => $dst_w,
2 => $dst_h
);
}
return $image;
}

function catch_that_image() {
        global $post, $posts;
        $first_img = '';
        ob_start();
        ob_end_clean();
        $output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
        if(count($matches [1]))$first_img = $matches [1] [0];
        return $first_img;
}

function new_excerpt_length($length) {
    return 40;
}
add_filter('excerpt_length', 'new_excerpt_length');
function string_limit_words($string, $word_limit)
{
  $words = explode(' ', $string, ($word_limit + 1));
  if(count($words) > $word_limit)
  array_pop($words);
  return implode(' ', $words);
}   

//top slider widget starts here
class gl_top_slider_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_top_slider_widget', 

__('Top Slider Trending Post Widget', 'gl_top_slider_widget_domain'), 

array( 'description' => __( 'Displays Top Slider', 'gl_top_slider_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {

$post_count = apply_filters( 'post_count', $instance['post_count'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );

echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];
?>
<div class="slider_section">
 <div class = "featured-area style-2 loaded loaded-wait container" id = "slider">
<div class = "featured-carousel style-2 center">
<?php 
global $query_string;
				query_posts( array( 'posts_per_page'=> $post_count  , 'post_type' => 'post', 'orderby' => 'comment_count','order' => 'desc', 'paged' => get_query_var('paged')) );
				
				if(have_posts()) : 
				while(have_posts()) : the_post();

			?>
<div class = "item">
<div class="featured-overlay featured-overlay-color"></div>
<div class="featured-overlay featured-overlay-partent"></div>
<?php
// Defaults
$f_img_width3 = $instance['width_size'];;
$f_img_height3 = $instance['height_size'];;
$default_img =  'Feature_image'; 

// Auto feature image defaults
$thumb = get_post_thumbnail_id(); 
$img_url = wp_get_attachment_url( $thumb,'full' ); 
$image = aq_resize( $img_url,$f_img_width3,$f_img_height3, true );
// Catch the Image defaults
$catch_img_url = catch_that_image( $thumb,'full' );
$catch_image = aq_resize( $catch_img_url, $f_img_width3, $f_img_height3, true );
// Default Image
$default_image = aq_resize( $default_img, $f_img_width3, $f_img_height3, true );

if(has_post_thumbnail())
echo
"<div class=\"featured_image\">\n".
"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width3 . "\" height=\"" . $f_img_height3 . "\" alt=\"" . get_the_title() . "\"><div class='img-overlay'></div></a>\n".
"</div>\n";
elseif (catch_that_image()){ 
echo
"<div class=\"featured_image\">\n".
"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width3 . "\" height=\"" . $f_img_height3 . "\" alt=\"" . get_the_title() . "\"><div class='img-overlay'></div></a>\n".
"</div>\n"; 
} 
/*featured image ends here*/
?>
<div class="featured-content">
<div class="feat-text">
<div class="featured-slider-overlay"></div>

<?php
$category = get_the_category(); 
?>
<div class="featured-cat"><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></div>
<h3><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a></h3>
<div class="carousel-meta">

<span class="feat-author">by <?php the_author_posts_link(); ?></span>
<span class='feat-comments'><a  href="<?php the_permalink(); ?>#comments" title="<?php comments_number(__('0 Comment','fb'),__('1 Comment','periodic'),__('% Comments','fb')); ?>"><?php comments_number(__('0 Comment','periodic'),__('1 Comment','periodic'),__('% Comments','fb')); ?> </a></span>
<span class="feat-time"  itemprop="datePublished"><?php the_time('M jS, Y') ?></span>					
</div>
</div>
</div>
</div>
<?php
			endwhile;
				endif; 
				wp_reset_query();?>              
 </div>
</div>
</div>
<?php
echo $args['after_widget'];
}
		
public function form( $instance ) {
 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '6', 'gl_top_slider_widget_domain' );
}

if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '893', 'gl_top_slider_widget_domain' );
}

 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '502', 'gl_top_slider_widget_domain' );
}

?>
<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>
<?php 
}
	
public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';
return $instance;
}
}

//top slider widget ends here
//Single Page Related Post Widget starts Here
class gl_related_post_widget extends WP_Widget {
function __construct() {
parent::__construct(
'gl_related_post_widget', 

__('Fargranz - Single Related Post', 'gl_related_post_widget_domain'), 

array( 'description' => __( 'Displays Single Related Post', 'gl_related_post_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$related_title = apply_filters( 'related_title', $instance['related_title'] );

$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );

echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];

?>
<div class="thesis_related single_page_cnt">
<?php
global $post;
	if ( is_single() ) {
		$tags = get_the_tags($post->ID);
			if ($tags) {
			$tag_ids = array();
			foreach($tags as $individual_tag) $tag_ids[] = $individual_tag->term_id;
			$args=array(
			'tag__in' => $tag_ids,
			'post__not_in' => array($post->ID),
			'showposts'=>3,  // Number of related posts that will be shown.
			'caller_get_posts'=>1
			);
	$my_query = new wp_query($args);
			if( $my_query->have_posts() ) {
	echo	'<div id="relatedposts">'.
				'<div class="single_title">'.
					'<h3>'. $related_title .'</h3>'.
				'</div>'.
			'<div class="related_section">';
		while ($my_query->have_posts()) {
			$my_query->the_post();
			$i++;
			$class = ( $i % 3) ? 'related_post_section' : 'related_post_section last';
	 ?>
			<div class="<?php echo $class; ?>">
							<div class="related_img">
								<?php
if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
 echo "<div class='featured_viedo_image featured_image'>";
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true); "</div>";	
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video
						  $f_img_width8 = $instance['width_size'];
							$f_img_height8 =$instance['height_size'];
							$default_img =  'Feature_image'; 
						// Auto feature image defaults
						$thumb = get_post_thumbnail_id(); 
						$img_url = wp_get_attachment_url( $thumb,'full' ); 
						$image = aq_resize( $img_url, $f_img_width8, $f_img_height8, true );
						// Catch the Image defaults
						$catch_img_url = catch_that_image( $thumb,'full' );
						$catch_image = aq_resize( $catch_img_url, $f_img_width8, $f_img_height8, true );
						if(has_post_thumbnail())
						echo
						"<div class=\"featured_image\">\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width8 . "\" height=\"" . $f_img_height8 . "\" alt=\"" . get_the_title() . "\"></a><div class='img_hover'><a class=\"link\" href=\"" . get_permalink() . "\"></a></div>\n".
						"</div>\n";
						elseif (catch_that_image()){ 
						echo
						"<div class=\"featured_image\">\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width8 . "\" height=\"" . $f_img_height8 . "\" alt=\"" . get_the_title() . "\"></a><div class='img_hover'><a class=\"link\" href=\"" . get_permalink() . "\"></a></div>\n".
						"</div>\n";  
						}
						}
						}						
					?>
							</div>

							<div class="related_post_cnt">
									<?php echo "<h3><a href='". get_permalink() ."'>".get_the_title()."";
									echo "</a></h3>";?>
									<span class='date'><?php the_time('M jS, Y') ?></span>
							
							</div>
					</div>
	<?php
			}
			echo '</div>';
			echo '</div>';
			}
		}
	$post = $backup;
			wp_reset_query();
			?>
			<div class="clear"></div>
			<?php
			 }
		
?>
</div>
<?php

echo $args['after_widget'];
}
		
public function form( $instance ) {
if ( isset( $instance[ 'related_title' ] ) ) {
$related_title = $instance[ 'related_title' ];
}
else {
$related_title = __( 'Related Post', 'gl_related_post_widget_domain' );
}

if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '228', 'gl_related_post_widget_domain' );
}

 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '223', 'gl_related_post_widget_domain' );
}

?>
<p>
<label for="<?php echo $this->get_field_id( 'related_title' ); ?>"><?php _e( 'Post Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'related_title' ); ?>" name="<?php echo $this->get_field_name( 'related_title' ); ?>" type="text" value="<?php echo esc_attr( $related_title ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Left Latest News Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Left Latest News  Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>
<?php 
}
	
public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['related_title'] = ( ! empty( $new_instance['related_title'] ) ) ? strip_tags( $new_instance['related_title'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';
return $instance;
}
}

//Single Page Related Post Widget Ends Here
// About Us Widget Starts Here
class gl_aboutus_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_aboutus_widget', 

__('Fragranz - About Us ', 'gl_aboutus_widget_domain'), 

array( 'description' => __( 'Displays About Us Content', 'gl_aboutus_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$sb_aboutus_title = apply_filters( 'sb_aboutus_title', $instance['sb_aboutus_title'] );
$about_us_img = apply_filters( 'about_us_img', $instance['about_us_img'] );
$sb_aboutus_cnt = apply_filters( 'sb_aboutus_cnt', $instance['sb_aboutus_cnt'] );
$sb_aboutus_read = apply_filters( 'sb_aboutus_read', $instance['sb_aboutus_read'] );
$sb_aboutus_read_link = apply_filters( 'sb_aboutus_read_link', $instance['sb_aboutus_read_link'] );
echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];

?>
<div class="sidebar_aboutus sidebar_widget_bg sidebar_widget">
	<div class="aboutus_cnt">
			<img alt="<?php  echo $instance['sb_aboutus_title'];?>" src='<?php  echo $instance['about_us_img'];?>'/>
			<div class="aboutus_cnt_title_para">
			<h3><?php  echo $instance['sb_aboutus_title'];?></h3>
				<div class="aboutus_cnt_main">
			<p><?php  echo $instance['sb_aboutus_cnt'];?></p>
			<a class="custom" href="<?php  echo $instance['sb_aboutus_read_link'];?>"><?php  echo $instance['sb_aboutus_read'];?></a>
			</div>
			</div>
		</div>	
</div>
<?php
echo $args['after_widget'];
}
		
public function form( $instance ) {

if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'About Me', 'gl_random_widget_domain' );
}

if ( isset( $instance[ 'sb_aboutus_title' ] ) ) {
$sb_aboutus_title = $instance[ 'sb_aboutus_title' ];
}
else {
$sb_aboutus_title = __( 'About Emma Clarke', 'gl_aboutus_widget_domain' );
}

 if ( isset( $instance[ 'about_us_img' ] ) ) {
$about_us_img = $instance[ 'about_us_img' ];
}
else {
$about_us_img = __( ' ', 'gl_aboutus_widget_domain' );
}

 if ( isset( $instance[ 'sb_aboutus_cnt' ] ) ) {
$sb_aboutus_cnt = $instance[ 'sb_aboutus_cnt' ];
}
else {
$sb_aboutus_cnt = __( 'About Us Content', 'gl_aboutus_widget_domain' );
}

 if ( isset( $instance[ 'sb_aboutus_read' ] ) ) {
$sb_aboutus_read = $instance[ 'sb_aboutus_read' ];
}
else {
$sb_aboutus_read = __( 'Read More', 'gl_aboutus_widget_domain' );
}

 if ( isset( $instance[ 'sb_aboutus_read_link' ] ) ) {
$sb_aboutus_read_link = $instance[ 'sb_aboutus_read_link' ];
}
else {
$sb_aboutus_read_link = __( '', 'gl_aboutus_widget_domain' );
}

?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'sb_aboutus_title' ); ?>"><?php _e( 'About Us Name:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'sb_aboutus_title' ); ?>" name="<?php echo $this->get_field_name( 'sb_aboutus_title' ); ?>" type="text" value="<?php echo esc_attr( $sb_aboutus_title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'about_us_img' ); ?>"><?php _e( 'About Us Image URL Link:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'about_us_img' ); ?>" name="<?php echo $this->get_field_name( 'about_us_img' ); ?>" type="text" value="<?php echo esc_attr( $about_us_img ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'sb_aboutus_cnt' ); ?>"><?php _e( 'About Us Content:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'sb_aboutus_cnt' ); ?>" name="<?php echo $this->get_field_name( 'sb_aboutus_cnt' ); ?>" type="text" value="<?php echo esc_attr( $sb_aboutus_cnt ); ?>"/>
</p>
<p>
<label for="<?php echo $this->get_field_id( 'sb_aboutus_read' ); ?>"><?php _e( 'About Us Readmore Text:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'sb_aboutus_read' ); ?>" name="<?php echo $this->get_field_name( 'sb_aboutus_read' ); ?>" type="text" value="<?php echo esc_attr( $sb_aboutus_read ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'sb_aboutus_read_link' ); ?>"><?php _e( 'About Us Readmore Text URL Link:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'sb_aboutus_read_link' ); ?>" name="<?php echo $this->get_field_name( 'sb_aboutus_read_link' ); ?>" type="text" value="<?php echo esc_attr( $sb_aboutus_read_link ); ?>" />
</p>
<?php 
}
	
public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['sb_aboutus_title'] = ( ! empty( $new_instance['sb_aboutus_title'] ) ) ? strip_tags( $new_instance['sb_aboutus_title'] ) : '';
$instance['about_us_img'] = ( ! empty( $new_instance['about_us_img'] ) ) ? strip_tags( $new_instance['about_us_img'] ) : '';
$instance['sb_aboutus_cnt'] = ( ! empty( $new_instance['sb_aboutus_cnt'] ) ) ? strip_tags( $new_instance['sb_aboutus_cnt'] ) : '';
$instance['sb_aboutus_read'] = ( ! empty( $new_instance['sb_aboutus_read'] ) ) ? strip_tags( $new_instance['sb_aboutus_read'] ) : '';
$instance['sb_aboutus_read_link'] = ( ! empty( $new_instance['sb_aboutus_read_link'] ) ) ? strip_tags( $new_instance['sb_aboutus_read_link'] ) : '';
return $instance;
}
}
// About us post widget ends here
// Popular Widget Starts Here
class gl_popular_widget extends WP_Widget {
function __construct() {
parent::__construct(
'gl_popular_widget', 

__('Fragrenz - Popular Post', 'gl_popular_widget_domain'), 

array( 'description' => __( 'Displays Popular Post', 'gl_popular_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );

echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];

?>
<div class="popular_post sidebar_widget_bg sidebar_widget">	
	<div class='popular_post_cnt sidebar_content'>
		<?php
			query_posts('post_type=post&posts_per_page= '. $post_count .' &orderby=comment_count&order=DESC');
			while (have_posts()): the_post(); 
		?>
			<div class='popular_post_section border_line entry_cnt'>
				<div class='popular_img'>
					<?php
					if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
 echo "<div class='featured_viedo_image'>";
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true); echo "</div>";	
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video
						  $f_img_width2 = $instance['width_size'];
							$f_img_height2 =$instance['height_size'];
							$default_img =  'Feature_image'; 
						// Auto feature image defaults
						$thumb = get_post_thumbnail_id(); 
						$img_url = wp_get_attachment_url( $thumb,'full' ); 
						$image = aq_resize( $img_url, $f_img_width2, $f_img_height2, true );
						// Catch the Image defaults
						$catch_img_url = catch_that_image( $thumb,'full' );
						$catch_image = aq_resize( $catch_img_url, $f_img_width2, $f_img_height2, true );
						if(has_post_thumbnail())
						echo
						"<div class=\"featured_image\">\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width2 . "\" height=\"" . $f_img_height2 . "\" alt=\"" . get_the_title() . "\"></a><div class='thumb_hover'><a class=\"link\" href=\"" . get_permalink() . "\"></a></div>\n".
						"</div>\n";
						elseif (catch_that_image()){ 
						echo
						"<div class=\"featured_image\">\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width2 . "\" height=\"" . $f_img_height2 . "\" alt=\"" . get_the_title() . "\"></a><div class='thumb_hover'><a class=\"link\" href=\"" . get_permalink() . "\"></a></div>\n".
						"</div>\n";  
						} 
						}
						}
					?>
				</div>
				<div class="popular_cnt">
					<h3><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a></h3>
				
				<div class='pop_byline'>
				<span><?php the_time('M jS, Y'); ?></span>
				</div>
				</div>
			</div>
		<?php
			endwhile;
		?>
	</div>
</div>
<?php
echo $args['after_widget'];
}
		
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Popular Posts', 'gl_popular_widget_domain' );
}

 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '4', 'gl_popular_widget_domain' );
}

 if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '98', 'gl_popular_widget_domain' );
}

 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '98', 'gl_popular_widget_domain' );
}

?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>
<?php 
}
	
public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';
return $instance;
}
}

//Popular Post Widget Ends Here//
// Random Post Widget Starts Here
class gl_random_widget extends WP_Widget {
function __construct() {
parent::__construct(
'gl_random_widget', 

__('Fragrenz - Random Post', 'gl_random_widget_domain'), 

array( 'description' => __( 'Displays Random Post', 'gl_random_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );
echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];
?>
<div class="random_post sidebar_widget_bg sidebar_widget">	
	<div class='random_post_cnt sidebar_content'>
		<?php
		query_posts('post_type=post&posts_per_page='. $post_count .' &orderby=rand&order=DESC');	
			while (have_posts()): the_post(); 
		?>
			<div class='random border_line'>
				<div class='random_img'>
					<?php
					if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
 echo "<div class='featured_viedo_image featured_image'>";
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true);echo "</div>";	
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video
			
					// Defaults
						$f_img_width4 = $instance['width_size'];
						$f_img_height4 = $instance['height_size'];
						// Auto feature image defaults
						$thumb = get_post_thumbnail_id(); 
						$img_url = wp_get_attachment_url( $thumb,'full' ); 
						$image = aq_resize( $img_url, $f_img_width4, $f_img_height4, true );
						// Catch the Image defaults
						$catch_img_url = catch_that_image( $thumb,'full' );
						$catch_image = aq_resize( $catch_img_url, $f_img_width4, $f_img_height4, true );
						if(has_post_thumbnail())
						echo
						"<div class=\"featured_image\">\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width4 . "\" height=\"" . $f_img_height4 . "\" alt=\"" . get_the_title() . "\"></a><div class='thumb_hover'><a class=\"link\" href=\"" . get_permalink() . "\"></a></div>\n".
						"</div>\n";
						elseif (catch_that_image()){ 
						echo
						"<div class=\"featured_image\">\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width4 . "\" height=\"" . $f_img_height4 . "\" alt=\"" . get_the_title() . "\"></a><div class='thumb_hover'><a class=\"link\" href=\"" . get_permalink() . "\"></a></div>\n".
						"</div>\n";  
						} 
						}
						}
					?>
				</div>
				<div class="random_cnt">
					<h3><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a></h3>
				</div>
			</div>
		<?php
			endwhile;
		?>
	</div>
</div>
<?php
echo $args['after_widget'];
}
		
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Random Posts', 'gl_random_widget_domain' );
}

 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '4', 'gl_random_widget_domain' );
}

 if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '103', 'gl_random_widget_domain' );
}

 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '93', 'gl_random_widget_domain' );
}

?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>
<?php 
}
	
public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';
return $instance;
}
}

//Random Post Widget Ends Here//
//Last Updated Post Widget Starts Here
class gl_last_update_widget extends WP_Widget {
function __construct() {
parent::__construct(
'gl_last_update_widget', 

__('Fragrenz - Last Updated Post', 'gl_last_update_widget_domain'), 

array( 'description' => __( 'Displays Last Updated Post', 'gl_last_update_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );
echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];
?>
<div class="last_updated_pst sidebar_widget_bg ">	
	<div class="last_updated sidebar_content">
		<?php
			
			// Query Arguments
			$lastupdated_args = array(
			'orderby' => 'modified',
			);
			//Loop to display 5 recently updated posts
			$lastupdated_loop = new WP_Query( $lastupdated_args );
			$counter = 1;
			echo '<ul>';
			while( $lastupdated_loop->have_posts() && $counter <= $instance[ 'post_count' ] ) : $lastupdated_loop->the_post();
			echo '<li>';			
echo"<div class='trend_img'>";
if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
 echo "<div class='featured_viedo_image featured_image'>";
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true);echo "</div>";	
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video			
 // Defaults
        $f_img_width6 = $instance['width_size'];
        $f_img_height6 = $instance['height_size'];

		// Auto feature image defaults
		$thumb = get_post_thumbnail_id(); 
		$img_url = wp_get_attachment_url( $thumb,'full' ); 
		$image = aq_resize( $img_url,$f_img_width6,$f_img_height6, true );
		// Catch the Image defaults
        $catch_img_url = catch_that_image( $thumb,'full' );
        $catch_image = aq_resize( $catch_img_url, $f_img_width6, $f_img_height6, true );
        // Default Image
		if(has_post_thumbnail())
		echo
		"<div class=\"featured_image\">\n".
		"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width6 . "\" height=\"" . $f_img_height6 . "\" alt=\"" . get_the_title() . "\"><div class='thumb_hover'></div></a>\n".
		"</div>\n";
		elseif (catch_that_image()){ 
		echo
		"<div class=\"featured_image\">\n".
		"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width6 . "\" height=\"" . $f_img_height6 . "\" alt=\"" . get_the_title() . "\"></a>\n".
		"</div>\n"; 
		}
}
}		
		/*featured image ends here*/
echo "</div>".
'<h3><a href="' . get_permalink( $lastupdated_loop->post->ID ) . '"> ' .get_the_title( $lastupdated_loop->post->ID ) . '</a> ( '. get_the_modified_date() .')</h3> '.
'</li>';
			$counter++;
			endwhile; 
			echo '</ul>';
			wp_reset_postdata(); 
			
		?>
	</div>
</div>
<?php
echo $args['after_widget'];
}
		
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Last Updated Posts', 'gl_last_update_widget_domain' );
}

 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '4', 'gl_last_update_widget_domain' );
}

 if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '98', 'gl_last_update_widget_domain' );
}

 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '98', 'gl_last_update_widget_domain' );
}

?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>

<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>
<?php 
}
	
public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';
return $instance;
}
} 

//Last Updated Post Widget Ends Here//
//Sidebar Trending Post Widget Starts here
class gl_sb_trend_widget extends WP_Widget {
function __construct() {
parent::__construct(
'gl_sb_trend_widget', 

__('Fragrenz - Sidebar Trending Post', 'gl_sb_trend_widget_domain'), 

array( 'description' => __( 'Displays Sidebar Trending Post', 'gl_sb_trend_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );

echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];
?>
<div class="trending_post sidebar_widget">	
	<div class="trending_post_section">
		<ul>
			<?php
				global $query_string;
				query_posts( array( 'posts_per_page'=> $instance['post_count']  , 'post_type' => 'post', 'orderby' => 'comment_count','order' => 'desc', 'paged' => get_query_var('paged')) );
				if(have_posts()) : 
				while(have_posts()) : the_post();
			?>
				<li class="trend_cont">
				<?php 
echo"<div class='trend_img'>";
if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
 echo "<div class='featured_viedo_image featured_image'>";
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true);echo "</div>";		
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video			
 // Defaults
        $f_img_width5 = $instance['width_size'];
        $f_img_height5 = $instance['height_size'];

		// Auto feature image defaults
		$thumb = get_post_thumbnail_id(); 
		$img_url = wp_get_attachment_url( $thumb,'full' ); 
		$image = aq_resize( $img_url,$f_img_width5,$f_img_height5, true );
		// Catch the Image defaults
        $catch_img_url = catch_that_image( $thumb,'full' );
        $catch_image = aq_resize( $catch_img_url, $f_img_width5, $f_img_height5, true );
        // Default Image
		if(has_post_thumbnail())
		echo
		"<div class=\"featured_image\">\n".
		"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width5 . "\" height=\"" . $f_img_height5 . "\" alt=\"" . get_the_title() . "\"><div class='thumb_hover'></div></a>\n".
		"</div>\n";
		elseif (catch_that_image()){ 
		echo
		"<div class=\"featured_image\">\n".
		"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width5 . "\" height=\"" . $f_img_height5 . "\" alt=\"" . get_the_title() . "\"></a>\n".
		"</div>\n"; 
		}
}
}		
		/*featured image ends here*/

echo "</div>";
echo"<div class='trend_btm'>";
echo "<h3><a href='". get_permalink() ."'>".
get_the_title() ."".
"</a></h3>";
echo"<div class='blog_byline'>";?>	
	<span class='author'><?php the_author() ?></span>
	<span class='date'><?php echo get_the_time('M jS, Y'); ?></span>
	<span class='info_comments'><a  href="<?php the_permalink(); ?>#comments" title="<?php comments_number(__('0 Comment','fb'),__('1 Comment','periodic'),__('% Comments','fb')); ?>"><?php comments_number(__('0','periodic'),__('1','periodic'),__('%','fb')); ?> </a></span>
		<?php
echo "</div>";
echo "</div>";
?>
				</li>
			<?php 
				endwhile;
				endif;
			?>
		</ul>
	</div>
</div>
<?php
echo $args['after_widget'];
}
		
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Sidebar Trending Posts', 'gl_sb_trend_widget_domain' );
}

 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '4', 'gl_sb_trend_widget_domain' );
}

 if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '360', 'gl_sb_trend_widget_domain' );
}

 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '250', 'gl_sb_trend_widget_domain' );
}
?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>
<?php 
}
public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';
return $instance;
}
}
//Sidebar Trending Post Widget ends here
//Sidebar Editor Picks Widget Starts here
class gl_sb_editorpick_widget extends WP_Widget {
function __construct() {
parent::__construct(
'gl_sb_editorpick_widget', 

__('Fragrenz - Sidebar Editor Picks', 'gl_sb_editorpick_widget_domain'), 

array( 'description' => __( 'Displays Sidebar Editor Picks', 'gl_sb_editorpick_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$post_id = apply_filters( 'post_id', $instance['post_id'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );
echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];
?>
<div class="editors_picks_content">
<?php
query_posts('p='. $post_id .'&posts_per_page= 1');
while (have_posts()): the_post(); 
?>
<div class='editors'>
<?php
echo "<div class='editor_news_sec'>";
echo"<div class='edit_img'>";
if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true);
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video		
 // Defaults
         $f_img_width = $instance['width_size'];
        $f_img_height = $instance['height_size'];
        $default_img =  'Feature_image'; 

		// Auto feature image defaults
		$thumb = get_post_thumbnail_id(); 
		$img_url = wp_get_attachment_url( $thumb,'full' ); 
		$image = aq_resize( $img_url,$f_img_width,$f_img_height, true );
		// Catch the Image defaults
        $catch_img_url = catch_that_image( $thumb,'full' );
        $catch_image = aq_resize( $catch_img_url, $f_img_width, $f_img_height, true );
        // Default Image
        $default_image = aq_resize( $default_img, $f_img_width, $f_img_height, true );
		if(has_post_thumbnail())
		echo
		"<div class=\"featured_image\">\n".
		"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width . "\" height=\"" . $f_img_height . "\" alt=\"" . get_the_title() . "\"><div class='thumb_hover'></div></a>\n".
		"</div>\n";
		elseif (catch_that_image()){ 
		echo
		"<div class=\"featured_image\">\n".
		"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width . "\" height=\"" . $f_img_height . "\" alt=\"" . get_the_title() . "\"></a>\n".
		"</div>\n"; 
		}
}
}		
		/*featured image ends here*/

echo "</div>";
echo "<div class='edit_news_cont_left'>";
?>
<div class='cat_name'>
<?php
$category = get_the_category(); 
?>
<h4><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></h4>
</div>
<?php
echo"<div class='blog_title'><h4><a href='". get_permalink() ."'>". get_the_title() ."".
"</a></h4></div>";
echo"<div class='blog_byline'>";?>	
	<span class='author'><?php the_author() ?></span>
	<span class='date'><?php echo get_the_time('M jS, Y'); ?></span>
	<span class='info_comments'><a  href="<?php the_permalink(); ?>#comments" title="<?php comments_number(__('0 Comment','fb'),__('1 Comment','periodic'),__('% Comments','fb')); ?>"><?php comments_number(__('0','periodic'),__('1','periodic'),__('%','fb')); ?> </a></span>
		<?php
echo "</div>";
echo "</div>";
echo "</div>";
?>
</div>
<?php
endwhile;
wp_reset_query();
?>
</div>
<?php
echo $args['after_widget'];
}
		
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Editor Picks', 'gl_sb_editorpick_widget_domain' );
}

 if ( isset( $instance[ 'post_id' ] ) ) {
$post_id = $instance[ 'post_id' ];
}
else {
$post_id = __( '', 'gl_top_editor_picks_widget_domain' );
}

 if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '360', 'gl_sb_editorpick_widget_domain' );
}

 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '400', 'gl_sb_editorpick_widget_domain' );
}
?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_id' ); ?>"><?php _e( 'Post ID:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_id' ); ?>" name="<?php echo $this->get_field_name( 'post_id' ); ?>" type="text" value="<?php echo esc_attr( $post_id ); ?>" />
</p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>
<?php 
}
	
public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_id'] = ( ! empty( $new_instance['post_id'] ) ) ? strip_tags( $new_instance['post_id'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';
return $instance;
}
}
//Sidebar Editor Picks Widget ends here
// Register and load the widget
function gl_load_widget() {

	register_widget( 'gl_top_slider_widget' );
	register_widget( 'gl_related_post_widget' );	
	register_widget( 'gl_aboutus_widget' );
	register_widget( 'gl_popular_widget' );
	register_widget( 'gl_random_widget' );
	register_widget( 'gl_last_update_widget' );
	register_widget( 'gl_sb_trend_widget' );
	register_widget( 'gl_sb_editorpick_widget' );	
}
add_action( 'widgets_init', 'gl_load_widget' );